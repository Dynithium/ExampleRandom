import React, { useState, useRef, useEffect, useCallback } from 'react';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import { 
  Play, 
  Globe, 
  RotateCcw, 
  Download, 
  Copy, 
  Check, 
  Maximize2, 
  Minimize2, 
  X,
  FileCode,
  ExternalLink,
  Sparkles,
  Wand2,
  ChevronDown,
  User,
  Bot,
  ArrowRight,
  Smartphone,
  Tablet,
  Monitor,
  Trash2,
  PlusCircle,
  Palette,
  CheckSquare,
  Info,
  FolderOpen,
  FilePlus2,
  AlignLeft,
  GitCommit,
  Circle,
  CheckCircle2,
  Loader,
  AlertTriangle,
  Plus,
  Compass,
  Target,
  Mic,
  Square
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, cleanMessage } from '../utils';
import { Tooltip } from './Tooltip';
import { getCompletion } from '../services/llm';
import { Settings } from '../db';
import { VoiceInterface } from './VoiceInterface';

interface WebSandboxProps {
  isOpen: boolean;
  onClose: () => void;
  settings: Settings;
  chatModels: any[];
  getModelInfo: (id: string) => any;
  initialProjectId?: string;
}

// Support a versatile custom virtual filesystem structure
type VFSFile = {
  name: string;
  content: string;
};

export const WebSandbox: React.FC<WebSandboxProps> = ({ 
  isOpen,
  onClose,
  settings,
  chatModels,
  getModelInfo,
  initialProjectId
}) => {
  // Global Project Registry structures loaded from local storage if available
  const [projects, setProjects] = useState<Record<string, { id: string; name: string; description: string; lastModified: number; fs: Record<string, string> }>>(() => {
    try {
      const stored = localStorage.getItem("gemini_workspace_projects");
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);

  useEffect(() => {
    if (initialProjectId && projects[initialProjectId]) {
      // Find the project and launch it
      const proj = projects[initialProjectId];
      if (proj) {
        setActiveProjectId(initialProjectId);
        setVirtualFS(proj.fs || {});
        const firstFile = Object.keys(proj.fs || {})[0] || 'index.html';
        setActiveFileName(firstFile);
      }
    }
  }, [initialProjectId]);
  
  // Custom non-blocking Confirm Dialog state to bypass iframe modal limitations
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);
  
  // Active files and folders inside workspace sandbox
  const [virtualFS, setVirtualFS] = useState<Record<string, string>>({
    'index.html': `<!DOCTYPE html>
<html>
<head>
  <style>
    body { 
      font-family: sans-serif; 
      display: flex; 
      align-items: center; 
      justify-content: center; 
      height: 100vh; 
      margin: 0; 
      background: linear-gradient(135deg, #1e1b4b, #0f172a); 
      color: #f8fafc;
    }
    .card { 
      background: rgba(30, 41, 59, 0.7); 
      padding: 2.5rem; 
      border-radius: 1.5rem; 
      box-shadow: 0 10px 30px rgba(0,0,0,0.3); 
      text-align: center; 
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255,255,255,0.1);
      max-width: 400px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1 id="heading">Hello WebCraft!</h1>
    <p>Edit index.html, style.css, and app.js in real-time to adjust the design and functionality.</p>
    <button id="btn">Rotate Hue</button>
  </div>
</body>
</html>`,
    'style.css': `h1 { 
  color: #818cf8; 
  font-size: 2.5rem;
  margin-top: 0;
}
button { 
  background: #6366f1; 
  color: white; 
  border: none; 
  padding: 0.75rem 1.5rem; 
  border-radius: 0.75rem; 
  cursor: pointer; 
  font-weight: bold;
  transition: all 0.2s; 
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
}
button:hover {
  background: #4f46e5;
  transform: translateY(-1px);
}
button:active { 
  transform: translateY(1px); 
}`,
    'app.js': `const btn = document.getElementById('btn');
const heading = document.getElementById('heading');
 
btn.addEventListener('click', () => {
  const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
  heading.style.color = randomColor;
  console.log('Rotated heading color to ' + randomColor);
});`
  });

  const [activeFileName, setActiveFileName] = useState<string>('index.html');
  const [previewContent, setPreviewContent] = useState('');
  const [isMaximized, setIsMaximized] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isAutoRefreshing, setIsAutoRefreshing] = useState(true);
  const [selectedModel, setSelectedModel] = useState(() => {
    if (settings.enabledChatModels && settings.enabledChatModels.length > 0) {
      if (settings.puterModel && settings.enabledChatModels.includes(settings.puterModel)) {
        return settings.puterModel;
      }
      return settings.enabledChatModels[0];
    }
    return settings.puterModel || 'puter:gemini-3.5-flash';
  });
  const [showVibe, setShowVibe] = useState(true);
  const [vibePrompt, setVibePrompt] = useState('');
  const [isVibing, setIsVibing] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [vibeSuggestion, setVibeSuggestion] = useState<{ filepath: string; content: string }[] | null>(null);
  const [vibeMessages, setVibeMessages] = useState<{ role: 'user' | 'assistant', content: string }[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [previewSize, setPreviewSize] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  const [consoleLogs, setConsoleLogs] = useState<{ type: 'log' | 'warn' | 'error', args: string[] }[]>([]);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isMonacoLoaded, setIsMonacoLoaded] = useState(false);
  
  // Multi-Agent Pipeline tracking progress states
  const [isMultiAgentMode, setIsMultiAgentMode] = useState(false);
  const [multiAgentStep, setMultiAgentStep] = useState<number | null>(null); // null means idle, index 0 to 4 shows progress
  const [multiAgentReport, setMultiAgentReport] = useState<string>('');

  // Modals visibility state
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [showRenameFileModal, setShowRenameFileModal] = useState(false);
  const [renameOldName, setRenameOldName] = useState('');
  const [renameNewName, setRenameNewName] = useState('');
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [newProjectTemplate, setNewProjectTemplate] = useState('counter');

  // Human in the Loop configuration
  const [hitlEnabled, setHitlEnabled] = useState(true);

  // --- Planning Mode and Goal Mode States ---
  const [planningModeEnabled, setPlanningModeEnabled] = useState(false);
  const [goalModeEnabled, setGoalModeEnabled] = useState(false);
  
  const [activePlan, setActivePlan] = useState<string | null>(null);
  const [planOriginalInstructions, setPlanOriginalInstructions] = useState<string | null>(null);

  const [currentGoal, setCurrentGoal] = useState<string>('');
  const [goalIteration, setGoalIteration] = useState<number>(0);
  const [goalStatusList, setGoalStatusList] = useState<{ step: string; status: 'completed' | 'active' | 'pending' }[]>([]);

  // Active Errors stream
  const [activeErrors, setActiveErrors] = useState<string[]>([]);

  // Persistent editor reference to inject changes directly
  const editorRef = useRef<any>(null);
  const editorContainerRef = useRef<HTMLDivElement>(null);

  // Configure templates matching original design
  const templates = {
    counter: {
      'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic Counter</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-gray-950 text-white min-h-screen flex flex-col justify-center items-center">
    <div class="bg-zinc-900 border border-zinc-800 p-8 rounded-2xl w-96 text-center shadow-xl">
        <h2 class="text-xl font-bold mb-4">Counter Engine</h2>
        <div id="display" class="text-5xl font-mono text-cyan-400 mb-6 font-bold">0</div>
        <div class="flex justify-around">
            <button onclick="decrement()" class="bg-red-600 px-4 py-2 rounded-lg font-bold hover:bg-red-500 transition">-</button>
            <button onclick="reset()" class="bg-zinc-700 px-4 py-2 rounded-lg font-bold hover:bg-zinc-650 transition">Reset</button>
            <button onclick="increment()" class="bg-green-600 px-4 py-2 rounded-lg font-bold hover:bg-green-500 transition">+</button>
        </div>
    </div>
    <script src="app.js"></script>
</body>
</html>`,
      'style.css': `body { background-image: radial-gradient(circle at center, #111 0%, #050505 100%); }`,
      'app.js': `let count = 0;
function increment() {
  count++;
  updateDisplay();
}
function decrement() {
  count--;
  updateDisplay();
}
function reset() {
  count = 0;
  updateDisplay();
}
function updateDisplay() {
  document.getElementById('display').innerText = count;
  console.log("Display updated: " + count);
}`
    },
    canvas: {
      'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pixel Rain</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-black overflow-hidden flex flex-col items-center justify-center min-h-screen">
    <div class="absolute top-4 left-4 z-10 bg-zinc-900/80 border border-zinc-800 p-3 rounded text-xs text-zinc-300">
        <h1 class="font-semibold text-white">Dynamic 2D Rain Sandbox</h1>
        <p class="text-[10px] text-zinc-500">Rendered in high performance HTML5 canvas loop.</p>
    </div>
    <canvas id="canvas"></canvas>
    <script src="app.js"></script>
</body>
</html>`,
      'style.css': `canvas { display: block; width: 100vw; height: 100vh; }`,
      'app.js': `const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const drops = [];
for (let i = 0; i < 150; i++) {
    drops.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 3 + 1,
        speed: Math.random() * 8 + 4,
        color: 'hsla(' + (Math.random() * 120 + 180) + ', 100%, 50%, 0.8)'
    });
}

function animate() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    drops.forEach(drop => {
        ctx.beginPath();
        ctx.arc(drop.x, drop.y, drop.size, 0, Math.PI * 2);
        ctx.fillStyle = drop.color;
        ctx.fill();
        drop.y += drop.speed;
        if (drop.y > canvas.height) {
            drop.y = -10;
            drop.x = Math.random() * canvas.width;
        }
    });
    
    requestAnimationFrame(animate);
}

window.addEventListener('resize', () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
});

console.log("Canvas particle loop started.");
animate();`
    },
    threejs: {
      'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ThreeJS 3D Scene</title>
    <!-- ThreeJS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-zinc-950 text-white overflow-hidden h-screen w-screen">
    <div id="info" class="absolute top-4 left-4 bg-zinc-900/80 border border-zinc-800 p-3 rounded z-10 text-xs">
        <h1 class="font-bold text-white">Three.js Particle Sphere</h1>
        <p class="text-[10px] text-zinc-500">Interactive 3D geometry engine inside virtual framework.</p>
    </div>
    <div id="webgl" class="w-full h-full"></div>
    <script src="app.js"></script>
</body>
</html>`,
      'app.js': `console.log("Initialing WebGL Scene...");
const container = document.getElementById('webgl');
const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.z = 5;

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
container.appendChild(renderer.domElement);

// Create a glowing sphere
const geometry = new THREE.IcosahedronGeometry(2, 2);
const material = new THREE.MeshBasicMaterial({ color: 0x6366f1, wireframe: true });
const sphere = new THREE.Mesh(geometry, material);
scene.add(sphere);

function animate() {
    requestAnimationFrame(animate);
    sphere.rotation.x += 0.005;
    sphere.rotation.y += 0.01;
    renderer.render(scene, camera);
}

window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();
console.log("3D Rendering started successfully.");`
    },
    blank: {
      'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Blank Application</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-zinc-900 text-zinc-300 p-8">
    <h1 class="text-2xl font-bold text-white">Blank Sandbox Workspace</h1>
    <p class="text-xs text-zinc-500 mt-2">Initialize your files and scripts inside the editor panels.</p>
</body>
</html>`
    }
  };

  const getLanguageFromExtension = (filename: string) => {
    if (filename.endsWith('.html')) return 'html';
    if (filename.endsWith('.css')) return 'css';
    if (filename.endsWith('.js')) return 'javascript';
    if (filename.endsWith('.ts')) return 'typescript';
    if (filename.endsWith('.json')) return 'json';
    return 'plaintext';
  };

  // Helper dynamic RequireJS & Monaco library loader
  useEffect(() => {
    const loadMonaco = () => {
      const windowWithRequire = window as any;
      if (windowWithRequire.require) {
        windowWithRequire.require.config({ 
          paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.39.0/min/vs' }
        });
        
        // Satisfy optional dependency checks
        if (windowWithRequire.define && windowWithRequire.define.amd) {
          windowWithRequire.define('jszip', [], () => (window as any).JSZip);
        }

        windowWithRequire.require(['vs/editor/editor.main'], () => {
          setIsMonacoLoaded(true);
        });
      }
    };

    if (!(window as any).require) {
      const script = document.createElement('script');
      script.src = "https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js";
      script.async = true;
      script.onload = loadMonaco;
      document.body.appendChild(script);
    } else {
      loadMonaco();
    }
  }, []);

  // Update Monaco content and language safely
  useEffect(() => {
    if (isMonacoLoaded && editorContainerRef.current) {
      const monaco = (window as any).monaco;
      if (!editorRef.current) {
        monaco.editor.defineTheme('customDark', {
          base: 'vs-dark',
          inherit: true,
          rules: [
            { token: 'comment', foreground: '5c6370', fontStyle: 'italic' },
            { token: 'keyword', foreground: 'c678dd' },
            { token: 'string', foreground: '98c379' },
            { token: 'number', foreground: 'd19a66' }
          ],
          colors: {
            'editor.background': '#131316',
            'editor.lineHighlightBackground': '#1e1e24',
            'editorLineNumber.foreground': '#5c6370'
          }
        });

        editorRef.current = monaco.editor.create(editorContainerRef.current, {
          value: virtualFS[activeFileName] || '',
          language: getLanguageFromExtension(activeFileName),
          theme: 'customDark',
          automaticLayout: true,
          fontSize: 13,
          tabSize: 2,
          minimap: { enabled: true },
          autoIndent: 'full',
          formatOnPaste: true,
          formatOnType: true,
          wordWrap: 'on'
        });

        editorRef.current.onDidChangeModelContent(() => {
          const val = editorRef.current.getValue();
          setVirtualFS(prev => {
            const next = { ...prev, [activeFileName]: val };
            if (activeProjectId && projects[activeProjectId]) {
              const updatedProjects = { ...projects };
              updatedProjects[activeProjectId].fs = next;
              updatedProjects[activeProjectId].lastModified = Date.now();
              setProjects(updatedProjects);
              localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
            }
            return next;
          });
        });
      } else {
        const currentModel = editorRef.current.getModel();
        if (currentModel) {
          if (editorRef.current.getValue() !== (virtualFS[activeFileName] || '')) {
            editorRef.current.setValue(virtualFS[activeFileName] || '');
          }
          monaco.editor.setModelLanguage(currentModel, getLanguageFromExtension(activeFileName));
        }
      }
    }
  }, [isMonacoLoaded, activeFileName, activeProjectId]);

  // Sync virtual files when project changes
  const launchProjectIDE = (projectId: string) => {
    const proj = projects[projectId];
    if (proj) {
      setActiveProjectId(projectId);
      setVirtualFS(proj.fs || {});
      const firstFile = Object.keys(proj.fs || {})[0] || 'index.html';
      setActiveFileName(firstFile);
    }
  };

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [vibeMessages, multiAgentStep]);

  const updatePreview = () => {
    const consoleHookScript = `
      <script>
        (function() {
          const originalLog = console.log;
          const originalWarn = console.warn;
          const originalError = console.error;

          function formatArgs(args) {
            return Array.from(args).map(arg => {
              if (typeof arg === 'object' && arg !== null) {
                try { return JSON.stringify(arg); } catch(e) { return "[Unserializable Object]"; }
              }
              return String(arg);
            });
          }

          console.log = function() {
            originalLog.apply(console, arguments);
            window.parent.postMessage({
              source: 'webcraft-sandbox-iframe-log',
              type: 'log',
              args: formatArgs(arguments)
            }, '*');
          };

          console.warn = function() {
            originalWarn.apply(console, arguments);
            window.parent.postMessage({
              source: 'webcraft-sandbox-iframe-log',
              type: 'warn',
              args: formatArgs(arguments)
            }, '*');
          };

          console.error = function() {
            originalError.apply(console, arguments);
            window.parent.postMessage({
              source: 'webcraft-sandbox-iframe-log',
              type: 'error',
              args: formatArgs(arguments)
            }, '*');
          };

          window.onerror = function(message, source, lineno, colno, error) {
            window.parent.postMessage({
              source: 'webcraft-sandbox-iframe-log',
              type: 'error',
              args: [message + ' (line ' + lineno + ':' + colno + ')']
            }, '*');
          };
        })();
      </script>
    `;

    let html = virtualFS['index.html'] || '<h1>Empty Workspace</h1>';

    // Inline style injections
    const cssRegex = /<link\s+[^>]*href=["']([^"']+)["'][^>]*>/gi;
    html = html.replace(cssRegex, (match, href) => {
      const cleanHref = href.replace(/^\.\//, '').trim();
      if (virtualFS[cleanHref]) {
        return `<style>\n${virtualFS[cleanHref]}\n</style>`;
      }
      return match;
    });

    // Inline script link injections
    const scriptRegex = /<script\s+[^>]*src=["']([^"']+)["'][^>]*><\/script>/gi;
    html = html.replace(scriptRegex, (match, src) => {
      const cleanSrc = src.replace(/^\.\//, '').trim();
      if (virtualFS[cleanSrc]) {
        return `<script>\n${virtualFS[cleanSrc]}\n<\/script>`;
      }
      return match;
    });

    const combinedContent = html.includes('</head>') 
      ? html.replace('</head>', `${consoleHookScript}</head>`)
      : `${consoleHookScript}${html}`;

    setPreviewContent(combinedContent);
  };

  useEffect(() => {
    const handleLogsMessage = (event: MessageEvent) => {
      if (event.data && event.data.source === 'webcraft-sandbox-iframe-log') {
        const { type, args } = event.data;
        setConsoleLogs(prev => [...prev, { type, args }]);
        if (type === 'error') {
          setActiveErrors(prev => [...prev, args.join(' ')]);
        }
      }
    };

    window.addEventListener('message', handleLogsMessage);
    return () => window.removeEventListener('message', handleLogsMessage);
  }, []);

  useEffect(() => {
    if (isAutoRefreshing) {
      const timer = setTimeout(updatePreview, 650);
      return () => clearTimeout(timer);
    }
  }, [virtualFS, isAutoRefreshing]);

  const handleCopy = () => {
    navigator.clipboard.writeText(virtualFS[activeFileName] || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([virtualFS[activeFileName] || ''], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = activeFileName;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const loadTemplate = (type: 'counter' | 'canvas' | 'threejs' | 'blank') => {
    const templateFS = templates[type];
    setVirtualFS(templateFS);
    const firstFile = Object.keys(templateFS)[0];
    setActiveFileName(firstFile);
    if (activeProjectId && projects[activeProjectId]) {
      const updatedProjects = { ...projects };
      updatedProjects[activeProjectId].fs = templateFS;
      setProjects(updatedProjects);
      localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
    }
  };

  // Human in the loop Multi-Agent Orchestrated Plan
  const runMultiAgentLoop = async (userPrompt: string) => {
    setMultiAgentStep(0);
    setMultiAgentReport('Orchestration Planning...');
    
    let workspaceContext = "";
    Object.keys(virtualFS).forEach(file => {
      workspaceContext += `\n--- FILE PATH: ${file} ---\n${virtualFS[file]}\n`;
    });

    const milestoneList = [
      "Milestone 1: Orchestration Planning",
      "Milestone 2: Senior System Architect Design",
      "Milestone 3: Lead Software Developer Implementation",
      "Milestone 4: Quality Control Verification & Polish"
    ];

    try {
      // --- STEP 1: LEAD PROJECT ORCHESTRATOR ---
      const orchestratorInstruction = `You are a Lead Project Orchestrator. 
Analyze the user goal and create a detailed multi-agent plan detailing exactly what updates, new variables, or UI layouts are required.

Return a structured JSON with:
{
  "milestones": ["Milestone 1:...", "Milestone 2:...", "Milestone 3:..."],
  "architectPrompt": "Instructions emphasizing aesthetic layouts, color styling rules, and visual tokens",
  "developerPrompt": "Instructions prioritizing variables, javascript loops, and state hook functions"
}`;

      const orchResponse = await getCompletion({
        messages: [
          { role: 'system', content: orchestratorInstruction },
          { role: 'user', content: `Goal: ${userPrompt}\n\nWorkspace:\n${workspaceContext}` }
        ],
        config: { temperature: 0.5, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const orchText = orchResponse.choices[0]?.message?.content || '';
      const orchJSON = JSON.parse(orchText.slice(orchText.indexOf('{'), orchText.lastIndexOf('}') + 1));
      
      setMultiAgentStep(1);
      setMultiAgentReport('Architectural Systems Design...');

      // --- STEP 2: SENIOR SYSTEM ARCHITECT ---
      const architectInstruction = `You are a Senior System Architect. Design the style layouts, flex grid coordinates, CSS tokens, and reactive state systems based on original instructions.
Return a structured JSON:
{
  "blueprintNotes": "Blueprint specifications",
  "recommendedStyles": "Visual classes and guidelines",
  "javascriptStateModel": "Required objects and structures"
}`;

      const archResponse = await getCompletion({
        messages: [
          { role: 'system', content: architectInstruction },
          { role: 'user', content: `Orchestrator Prompt: ${orchJSON.architectPrompt}\n\nFiles:\n${workspaceContext}` }
        ],
        config: { temperature: 0.5, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const archText = archResponse.choices[0]?.message?.content || '';
      const archJSON = JSON.parse(archText.slice(archText.indexOf('{'), archText.lastIndexOf('}') + 1));

      setMultiAgentStep(2);
      setMultiAgentReport('Lead Software Developer Coding...');

      // --- STEP 3: LEAD SOFTWARE DEVELOPER ---
      const developerInstruction = `You are Lead Software Developer. Fully synthesize and draft the exact modified files of the workspace based on the system blueprint. Use standard spacings. Specify code replacements as a list of modified files.

Return a structured JSON:
{
  "explanation": "Summary of updates",
  "files": [
    {
      "filepath": "index.html",
      "action": "write",
      "content": "Full indented HTML code..."
    }
  ]
}`;

      const devResponse = await getCompletion({
        messages: [
          { role: 'system', content: developerInstruction },
          { role: 'user', content: `Orchestration: ${orchJSON.developerPrompt}\nBlueprint: ${JSON.stringify(archJSON)}\n\nFiles:\n${workspaceContext}` }
        ],
        config: { temperature: 0.7, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const devText = devResponse.choices[0]?.message?.content || '';
      const devJSON = JSON.parse(devText.slice(devText.indexOf('{'), devText.lastIndexOf('}') + 1));

      setMultiAgentStep(3);
      setMultiAgentReport('Quality Control Indentation Audit...');

      // --- STEP 4: QUALITY CONTROL TESTING ---
      const qcInstruction = `You are Quality Control Testing Engineer. Verify the syntax, indent spacings, class lists, and trailing brackets of files generated by Software Developer. Correct any glitches.

Return ONLY structured JSON:
{
  "explanation": "Glitch analysis",
  "files": [
    {
      "filepath": "index.html",
      "action": "write",
      "content": "Perfect verified code..."
    }
  ]
}`;

      const qcResponse = await getCompletion({
        messages: [
          { role: 'system', content: qcInstruction },
          { role: 'user', content: `Developer Code: ${JSON.stringify(devJSON)}\n\nOriginal Context:\n${workspaceContext}` }
        ],
        config: { temperature: 0.2, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const qcText = qcResponse.choices[0]?.message?.content || '';
      const qcJSON = JSON.parse(qcText.slice(qcText.indexOf('{'), qcText.lastIndexOf('}') + 1));

      // Assemble initial target File System proposed by the pipeline
      let currentFS = { ...virtualFS };
      qcJSON.files.forEach((f: any) => {
        if (f.action === 'write') currentFS[f.filepath] = f.content;
        else if (f.action === 'delete') delete currentFS[f.filepath];
      });

      setMultiAgentStep(4);
      setMultiAgentReport('Executing program and checking for active runtime exceptions...');

      let healingAttempts = 0;
      const MAX_HEALING_ATTEMPTS = 3;
      let errorsFound = true;

      while (errorsFound && healingAttempts < MAX_HEALING_ATTEMPTS) {
        const capturedErrors: string[] = [];
        const tempListener = (event: MessageEvent) => {
          if (event.data && event.data.source === 'webcraft-sandbox-iframe-log') {
            const { type, args } = event.data;
            if (type === 'error') {
              capturedErrors.push(args.join(' '));
            }
          }
        };
        window.addEventListener('message', tempListener);

        // Mount the files to compile the preview
        setVirtualFS({ ...currentFS });
        setActiveErrors([]);
        setConsoleLogs([]);

        // Wait 1800ms for iframe boot and execution checks
        await new Promise(resolve => setTimeout(resolve, 1800));
        window.removeEventListener('message', tempListener);

        if (capturedErrors.length > 0) {
          healingAttempts++;
          setMultiAgentReport(`Exceptions detected. Healing (attempt ${healingAttempts}/${MAX_HEALING_ATTEMPTS})...`);

          const healInstruction = `You are a diagnostic code review and healing agent. The workspace you created crashed or reported runtime console exceptions.
Your job is to inspect the error messages, identify the root cause (syntax, invalid objects, undefined functions, missing tags, or incorrect Tailwind/esm configurations), and return corrected file modifications.

Make sure you respect the limits of the sandbox you are in.
[WEB SANDBOX LIMITATIONS]:
- Optimized for purely client-side static web application execution (HTML5, JS, CSS, ESM/CDN packages like Tailwind, Lucide, Recharts).
- NO backend server/Node.js/API endpoints (Express, databases, Python flask, server API routers) can run.
- Runs in a sandboxed iframe. Restricts top-level redirects/parent domain cookie changes. All communication is client-driven.

Return ONLY structured JSON conforming to:
{
  "explanation": "Summarized debug fix explanation",
  "files": [
    {
      "filepath": "index.html",
      "action": "write",
      "content": "Perfect verified code..."
    }
  ]
}`;

          const healResponse = await getCompletion({
            messages: [
              { role: 'system', content: healInstruction },
              { role: 'user', content: `Goal: ${userPrompt}\n\nWorkspace State:\n${JSON.stringify(currentFS)}\n\nCaught Console Errors:\n${capturedErrors.join('\n')}` }
            ],
            config: { temperature: 0.1, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
            settings
          });

          const healContentText = healResponse.choices[0]?.message?.content || '';
          try {
            const healJSON = JSON.parse(healContentText.slice(healContentText.indexOf('{'), healContentText.lastIndexOf('}') + 1));
            if (healJSON.files && healJSON.files.length > 0) {
              healJSON.files.forEach((f: any) => {
                if (f.action === 'write') currentFS[f.filepath] = f.content;
                else if (f.action === 'delete') delete currentFS[f.filepath];
              });
            }
          } catch (errParse) {
            console.error("Failed to parse heal JSON inside multiagent loop", errParse);
            break;
          }
        } else {
          errorsFound = false;
        }
      }

      setMultiAgentReport('Streaming finalized changes...');

      if (hitlEnabled) {
        // Suggested changes
        const suggestionList = Object.keys(currentFS).map(path => ({
          filepath: path,
          action: 'write' as const,
          content: currentFS[path]
        }));
        setVibeSuggestion(suggestionList);
        setVibeMessages(prev => [...prev, { 
          role: 'assistant', 
          content: `📋 **Multi-Agent Coder Pipeline Completed!**\n\n${qcJSON.explanation}\n\n*Run execution state: ${healingAttempts > 0 ? `Successfully applied self-healing correction cycles for ${healingAttempts} console exceptions.` : 'Code runs flawlessly without a single console error.'}*` 
        }]);
      } else {
        setVirtualFS(currentFS);
        if (activeProjectId && projects[activeProjectId]) {
          const updatedProjects = { ...projects };
          updatedProjects[activeProjectId].fs = currentFS;
          setProjects(updatedProjects);
          localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
        }
        setVibeMessages(prev => [...prev, { 
          role: 'assistant', 
          content: `Committed automatic modifications directly to sandbox. ${healingAttempts > 0 ? `Executed self-healing loop successfully through ${healingAttempts} correction attempts to resolve console crashes.` : 'Validated program execution; running smoothly with no exceptions.'}` 
        }]);
      }

    } catch (e: any) {
      console.error(e);
      setVibeMessages(prev => [...prev, { role: 'assistant', content: `Error executing pipeline loop: ${e.message || 'Workflow timeout'}` }]);
    } finally {
      setMultiAgentStep(null);
    }
  };

  // --- Planning Mode implementation ---
  const executeActivePlan = async () => {
    if (!activePlan || !planOriginalInstructions) return;
    abortControllerRef.current = new AbortController();
    setIsVibing(true);
    setMultiAgentStep(1);
    setMultiAgentReport('Executing approved plan...');

    try {
      let workspaceContext = "";
      Object.keys(virtualFS).forEach(file => {
        workspaceContext += `\n--- FILE PATH: ${file} ---\n${virtualFS[file]}\n`;
      });

      const systemPrompt = `You are an expert fullstack code architect working inside a multi-file browser IDE.
Apply the following engineering plan and original user instructions to implement the code.

APPROVED IMPLEMENTATION PLAN:
${activePlan}

Original User Instructions:
${planOriginalInstructions}

Current Workspace State:
${workspaceContext}

Return ONLY a valid, parseable JSON conforming to this schema (no markdown formatting wrapping JSON, just raw json):
{
  "explanation": "Conversational report detailing updated files and why",
  "files": [
    {
      "filepath": "index.html",
      "action": "write",
      "content": "Entire updated file contents here..."
    }
  ]
}
`;

      const response = await getCompletion({
        messages: [
          { role: 'system', content: systemPrompt },
          ...vibeMessages.map(m => ({ role: m.role as any, content: m.content })),
          { role: 'user', content: `Please execute the modifications for the following approved plan: ${activePlan}` }
        ],
        config: {
          temperature: settings.temperature,
          modelOverride: selectedModel,
          signal: abortControllerRef.current?.signal
        },
        settings
      });

      const generatedContent = response.choices[0]?.message?.content || '';
      
      const jsonStart = generatedContent.indexOf('{');
      const jsonEnd = generatedContent.lastIndexOf('}') + 1;
      
      if (jsonStart !== -1 && jsonEnd !== -1 && jsonStart < jsonEnd) {
        const jsonStr = generatedContent.slice(jsonStart, jsonEnd);
        const result = JSON.parse(jsonStr);
        
        if (result.files && result.files.length > 0) {
          if (hitlEnabled) {
            setVibeSuggestion(result.files);
            setVibeMessages(prev => [...prev, { role: 'assistant', content: `🔧 **Changes Compiled Based on Plan!**\n\nPlease approve or discard the modifications below.` }]);
          } else {
            const finalFS = { ...virtualFS };
            result.files.forEach((f: any) => {
              if (f.action === 'write') finalFS[f.filepath] = f.content;
              else if (f.action === 'delete') delete finalFS[f.filepath];
            });
            setVirtualFS(finalFS);
            if (activeProjectId && projects[activeProjectId]) {
              const updatedProjects = { ...projects };
              updatedProjects[activeProjectId].fs = finalFS;
              setProjects(updatedProjects);
              localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
            }
            setVibeMessages(prev => [...prev, { role: 'assistant', content: `Successfully executed plan changes directly in workspace.` }]);
          }
        } else {
          setVibeMessages(prev => [...prev, { role: 'assistant', content: result.explanation || "Execution completed, but no physical files were changed." }]);
        }
      } else {
        throw new Error("Could not parse file suggestions JSON from AI output.");
      }

      // Clear plan tracking so we can generate new plans
      setActivePlan(null);
      setPlanOriginalInstructions(null);

    } catch (err: any) {
      setVibeMessages(prev => [...prev, { role: 'assistant', content: `Error executing approved plan: ${err.message}` }]);
    } finally {
      setMultiAgentStep(null);
      setIsVibing(false);
    }
  };

  // --- Goal Mode implementation ---
  const initializeGoalMode = async (goalText: string) => {
    abortControllerRef.current = new AbortController();
    setIsVibing(true);
    setMultiAgentStep(0);
    setMultiAgentReport('Goal Mode: Breaking down goal into steps...');
    setCurrentGoal(goalText);
    setGoalIteration(1);

    try {
      const pmPrompt = `You are a product manager. A developer is building an application in a browser-based Sandbox.
The user's high-level goal is: "${goalText}".
Break down this goal into 3 specific, modular, and sequential engineering steps that can be implemented iteratively.
Respond ONLY with a JSON object. No markdown, no preambles:
{
  "steps": [
    "Step 1: Description of first logical module or interface mockup",
    "Step 2: Description of interactive behaviors or state controls",
    "Step 3: Description of visual style refinements, extra polished features, scoring, etc."
  ]
}
`;

      const response = await getCompletion({
        messages: [{ role: 'user', content: pmPrompt }],
        config: { temperature: 0.1, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const text = response.choices[0]?.message?.content || '';
      const parsed = JSON.parse(text.slice(text.indexOf('{'), text.lastIndexOf('}') + 1));
      
      const stepsList = (parsed.steps || []).map((step: string) => ({
        step,
        status: 'pending' as const
      }));

      if (stepsList.length > 0) {
        stepsList[0].status = 'active';
      }

      setGoalStatusList(stepsList);
      setVibeMessages(prev => [...prev, { 
        role: 'assistant', 
        content: `🎯 **Goal Initiated:** "${goalText}"\n\nI have structured this into the following incremental milestones:\n${stepsList.map((s: any, idx: number) => `${idx + 1}. ${s.step} (Status: ${s.status})`).join('\n')}\n\n**Goal Mode Controls:** Click **"Iterate Goal Step"** below to implement the first milestone automatically.` 
      }]);

    } catch (err: any) {
      setVibeMessages(prev => [...prev, { role: 'assistant', content: `Failed to initialize goal steps: ${err.message}` }]);
    } finally {
      setMultiAgentStep(null);
      setIsVibing(false);
    }
  };

  const handleIterateGoalStep = async () => {
    if (goalStatusList.length === 0) return;
    const activeIndex = goalStatusList.findIndex(s => s.status === 'active');
    if (activeIndex === -1) {
      setVibeMessages(prev => [...prev, { role: 'assistant', content: `🎉 **Goal fully completed!** All steps are marked as completed.` }]);
      return;
    }

    const activeStep = goalStatusList[activeIndex];
    abortControllerRef.current = new AbortController();
    setIsVibing(true);
    setMultiAgentStep(1);
    setMultiAgentReport(`Goal Mode Iteration #${goalIteration}: Implementing "${activeStep.step}"...`);

    try {
      let workspaceContext = "";
      Object.keys(virtualFS).forEach(file => {
        workspaceContext += `\n--- FILE PATH: ${file} ---\n${virtualFS[file]}\n`;
      });

      const systemPrompt = `You are an expert tech lead. The user is incrementally building a project in Goal Mode.
Goal: ${currentGoal}
Current Milestone to implement: ${activeStep.step}
Current Iteration Count: ${goalIteration}

Workspace:
${workspaceContext}

Return ONLY a valid, parseable JSON conforming to this schema:
{
  "explanation": "Conversational report detailing updated files and why",
  "files": [
    {
      "filepath": "index.html",
      "action": "write",
      "content": "Entire updated file contents here..."
    }
  ]
}
`;

      const response = await getCompletion({
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Please implement Milestone: ${activeStep.step}` }
        ],
        config: {
          temperature: 0.2,
          modelOverride: selectedModel,
          signal: abortControllerRef.current?.signal
        },
        settings
      });

      const generatedContent = response.choices[0]?.message?.content || '';
      
      const jsonStart = generatedContent.indexOf('{');
      const jsonEnd = generatedContent.lastIndexOf('}') + 1;
      
      if (jsonStart !== -1 && jsonEnd !== -1 && jsonStart < jsonEnd) {
        const jsonStr = generatedContent.slice(jsonStart, jsonEnd);
        const result = JSON.parse(jsonStr);
        
        let finalFS = { ...virtualFS };
        if (result.files && result.files.length > 0) {
          result.files.forEach((f: any) => {
            if (f.action === 'write') finalFS[f.filepath] = f.content;
            else if (f.action === 'delete') delete finalFS[f.filepath];
          });
          setVirtualFS(finalFS);
          if (activeProjectId && projects[activeProjectId]) {
            const updatedProjects = { ...projects };
            updatedProjects[activeProjectId].fs = finalFS;
            setProjects(updatedProjects);
            localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
          }
        }

        // Auto Self-healing on Console Crash events in Goal Mode
        let healingAttempts = 0;
        const MAX_HEALING_ATTEMPTS = 3;
        let errorsFound = true;

        while (errorsFound && healingAttempts < MAX_HEALING_ATTEMPTS) {
          const capturedErrors: string[] = [];
          const tempListener = (event: MessageEvent) => {
            if (event.data && event.data.source === 'webcraft-sandbox-iframe-log') {
              const { type, args } = event.data;
              if (type === 'error') {
                capturedErrors.push(args.join(' '));
              }
            }
          };
          window.addEventListener('message', tempListener);

          // Render tentative files
          setVirtualFS({ ...finalFS });
          setActiveErrors([]);
          setConsoleLogs([]);

          // Wait 1800ms
          await new Promise(resolve => setTimeout(resolve, 1800));
          window.removeEventListener('message', tempListener);

          if (capturedErrors.length > 0) {
            healingAttempts++;
            setMultiAgentReport(`Iteration #${goalIteration} console exceptions detected. Auto-healing (attempt ${healingAttempts}/${MAX_HEALING_ATTEMPTS})...`);

            const healPrompt = `You are a self-healing debugger. The application generated for Milestone "${activeStep.step}" crashed with console exceptions.
Your job is to read the error logs, find the root cause, and correct all discrepancies.

Make sure you respect the limits of the sandbox you are in.
[WEB SANDBOX LIMITATIONS]:
- Optimized for purely client-side static web application execution (HTML5, JS, CSS, ESM/CDN packages like Tailwind, Lucide, Recharts).
- NO backend server/Node.js/API endpoints (Express, databases, Python flask, server API routers) can run.
- Runs in a sandboxed iframe. Restricts top-level redirects/parent domain cookie changes. All communication is client-driven.

Errors:
${capturedErrors.join('\n')}

Workspace State:
${JSON.stringify(finalFS)}

Fix these errors and return ONLY structured corrected files JSON conforming to:
{
  "explanation": "Fix details",
  "files": [
    {
      "filepath": "index.html",
      "action": "write",
      "content": "Perfect verified code..."
    }
  ]
}`;

            const healingResponse = await getCompletion({
              messages: [{ role: 'user', content: healPrompt }],
              config: { temperature: 0.1, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
              settings
            });

            const healContent = healingResponse.choices[0]?.message?.content || '';
            const healJsonStart = healContent.indexOf('{');
            const healJsonEnd = healContent.lastIndexOf('}') + 1;

            if (healJsonStart !== -1 && healJsonEnd !== -1 && healJsonStart < healJsonEnd) {
              const healResult = JSON.parse(healContent.slice(healJsonStart, healJsonEnd));
              if (healResult.files && healResult.files.length > 0) {
                healResult.files.forEach((f: any) => {
                  if (f.action === 'write') finalFS[f.filepath] = f.content;
                  else if (f.action === 'delete') delete finalFS[f.filepath];
                });
                setVirtualFS({ ...finalFS });
                if (activeProjectId && projects[activeProjectId]) {
                  const updatedProjects = { ...projects };
                  updatedProjects[activeProjectId].fs = finalFS;
                  setProjects(updatedProjects);
                  localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
                }
              }
            }
          } else {
            errorsFound = false;
          }
        }

        // Mark current step as completed, and advance to next!
        const updatedSteps = [...goalStatusList];
        updatedSteps[activeIndex].status = 'completed';
        
        if (activeIndex + 1 < updatedSteps.length) {
          updatedSteps[activeIndex + 1].status = 'active';
          setGoalIteration(prev => prev + 1);
          setVibeMessages(prev => [...prev, { 
            role: 'assistant', 
            content: `✅ **Milestone "${activeStep.step}" Completed!**\n\nSelf-healing checks completed. Moving to the next milestone:\n${updatedSteps.map((s: any, idx: number) => `${idx + 1}. ${s.step} (Status: ${s.status})`).join('\n')}` 
          }]);
        } else {
          setVibeMessages(prev => [...prev, { 
            role: 'assistant', 
            content: `🎉 **Goal Mode Fully Accomplished!**\n\nAll milestones have been successfully implemented and verified:\n${updatedSteps.map((s: any, idx: number) => `✅ ${s.step}`).join('\n')}` 
          }]);
        }
        setGoalStatusList(updatedSteps);

      } else {
        throw new Error("Could not parse file suggestions JSON from AI output.");
      }

    } catch (err: any) {
      setVibeMessages(prev => [...prev, { role: 'assistant', content: `Error executing goal step: ${err.message}` }]);
    } finally {
      setMultiAgentStep(null);
      setIsVibing(false);
    }
  };

  const handleStopVibe = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsVibing(false);
    setMultiAgentStep(null);
    setVibeMessages(prev => [...prev, { role: 'assistant', content: '🛑 AI Generation stopped.' }]);
  };

  const handleVibe = async () => {
    if (!vibePrompt.trim()) return;
    
    const userMsg = vibePrompt.trim();
    setVibeMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setVibePrompt('');
    abortControllerRef.current = new AbortController();
    setIsVibing(true);

    if (planningModeEnabled && !activePlan) {
      setMultiAgentStep(0);
      setMultiAgentReport('Planning Mode: Analyzing workspace and sketching out design specifications...');
      try {
        let workspaceContext = "";
        Object.keys(virtualFS).forEach(file => {
          workspaceContext += `\n--- FILE PATH: ${file} ---\n${virtualFS[file]}\n`;
        });

        const planningSystemPrompt = `You are a professional software architect. Analyze the current workspace, then generate a detailed step-by-step implementation plan for the user's directions.
Do NOT write complete files or code listings. Present the plan using clean markdown showing what changes are needed, affected files, state updates, and specific engineering phases.
Current Workspace:
${workspaceContext}
`;

        const response = await getCompletion({
          messages: [
            { role: 'system', content: planningSystemPrompt },
            ...vibeMessages.map(m => ({ role: m.role as any, content: m.content })),
            { role: 'user', content: userMsg }
          ],
          config: {
            temperature: settings.temperature,
            modelOverride: selectedModel,
            signal: abortControllerRef.current?.signal
          },
          settings
        });

        const planText = response.choices[0]?.message?.content || '';
        setActivePlan(planText);
        setPlanOriginalInstructions(userMsg);
        setVibeMessages(prev => [...prev, { 
          role: 'assistant', 
          content: `📋 **Proposed Architecture Plan:**\n\n${planText}\n\n**Controls:** You can type feedback here to help me refine this plan, or click **"Approve & Execute"** below to begin automatic modifications!` 
        }]);
      } catch (err: any) {
        setVibeMessages(prev => [...prev, { role: 'assistant', content: `Failed to compile plan: ${err.message}` }]);
      } finally {
        setMultiAgentStep(null);
        setIsVibing(false);
      }
      return;
    }

    if (goalModeEnabled && goalStatusList.length === 0) {
      await initializeGoalMode(userMsg);
      return;
    }

    if (isMultiAgentMode) {
      await runMultiAgentLoop(userMsg);
      setIsVibing(false);
      return;
    }

    try {
      let workspaceContext = "";
      Object.keys(virtualFS).forEach(file => {
        workspaceContext += `\n--- FILE PATH: ${file} ---\n${virtualFS[file]}\n`;
      });

      const systemPrompt = `You are an expert fullstack code architect working inside a multi-file browser IDE.
Analyze active workspace files, then generate modifications, create new files, or delete existing modules based on directions.

Current Workspace State:
${workspaceContext}

Return ONLY a valid, parseable JSON conforming to this schema (no markdown formatting wrapping JSON, just raw json):
{
  "explanation": "Conversational report detailing modified elements and why",
  "files": [
    {
      "filepath": "index.html",
      "action": "write",
      "content": "Entire, pristine rewrite of that specific file code here..."
    }
  ]
}

CRITICAL RULES:
1. "action" must be either "write" (add/overwrite content) or "delete".
2. Always write the ENTIRE updated file contents. Placeholder code comments like "// rest of file continues here" are prohibited.
3. Keep layout indentation consistent. Use clean tabs, indentation spacing, and newline breaks (\\n).
`;

      const response = await getCompletion({
        messages: [
          { role: 'system', content: systemPrompt },
          ...vibeMessages.map(m => ({ role: m.role as any, content: m.content })),
          { role: 'user', content: userMsg }
        ],
        config: {
          temperature: settings.temperature,
          modelOverride: selectedModel,
          signal: abortControllerRef.current?.signal
        },
        settings
      });

      const generatedContent = response.choices[0]?.message?.content || '';
      
      const jsonStart = generatedContent.indexOf('{');
      const jsonEnd = generatedContent.lastIndexOf('}') + 1;
      
      if (jsonStart !== -1 && jsonEnd !== -1 && jsonStart < jsonEnd) {
        const jsonStr = generatedContent.slice(jsonStart, jsonEnd);
        const result = JSON.parse(jsonStr);
        
        if (result.files && result.files.length > 0) {
          if (hitlEnabled) {
            setVibeSuggestion(result.files);
          } else {
            const finalFS = { ...virtualFS };
            result.files.forEach((f: any) => {
              if (f.action === 'write') finalFS[f.filepath] = f.content;
              else if (f.action === 'delete') delete finalFS[f.filepath];
            });
            setVirtualFS(finalFS);
            if (activeProjectId && projects[activeProjectId]) {
              const updatedProjects = { ...projects };
              updatedProjects[activeProjectId].fs = finalFS;
              setProjects(updatedProjects);
              localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
            }
          }
        }
        
        setVibeMessages(prev => [...prev, { role: 'assistant', content: result.explanation || "Workspace modified." }]);
      } else {
        setVibeMessages(prev => [...prev, { role: 'assistant', content: generatedContent }]);
      }
    } catch (error: any) {
      console.error('Vibe error:', error);
      setVibeMessages(prev => [...prev, { role: 'assistant', content: `Error during build routine: ${error.message || 'Execution error'}` }]);
    } finally {
      setIsVibing(false);
    }
  };

  const handleAIDebugger = async () => {
    if (activeErrors.length === 0) return;
    abortControllerRef.current = new AbortController();
    setIsVibing(true);
    setVibeMessages(prev => [...prev, { role: 'user', content: `I encountered the following console crash event in my app. Can you fix it?\n\n\`\`\`\n${activeErrors.join('\n')}\n\`\`\`` }]);
    
    try {
      let workspaceContext = "";
      Object.keys(virtualFS).forEach(file => {
        workspaceContext += `\n--- FILE PATH: ${file} ---\n${virtualFS[file]}\n`;
      });

      const systemPrompt = `You are a diagnostic code review agent. Inspect active files in the workspace and fix the observed runtime console exceptions listed by user.
Return ONLY structured JSON conforming to:
{
  "explanation": "Detailed fix report explaining root cause and resolution",
  "files": [
    {
      "filepath": "app.js",
      "action": "write",
      "content": "Fully corrected complete file code..."
    }
  ]
}`;

      const response = await getCompletion({
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Console exceptions:\n${activeErrors.join('\n')}\n\nWorkspace:\n${workspaceContext}` }
        ],
        config: {
          temperature: 0.1,
          modelOverride: selectedModel,
          signal: abortControllerRef.current?.signal
        },
        settings
      });

      const generatedContent = response.choices[0]?.message?.content || '';
      const jsonStart = generatedContent.indexOf('{');
      const jsonEnd = generatedContent.lastIndexOf('}') + 1;
      
      if (jsonStart !== -1 && jsonEnd !== -1 && jsonStart < jsonEnd) {
        const jsonStr = generatedContent.slice(jsonStart, jsonEnd);
        const result = JSON.parse(jsonStr);
        
        if (result.files && result.files.length > 0) {
          if (hitlEnabled) {
            setVibeSuggestion(result.files);
          } else {
            const finalFS = { ...virtualFS };
            result.files.forEach((f: any) => {
              if (f.action === 'write') finalFS[f.filepath] = f.content;
              else if (f.action === 'delete') delete finalFS[f.filepath];
            });
            setVirtualFS(finalFS);
          }
        }
        
        setVibeMessages(prev => [...prev, { role: 'assistant', content: `🔧 **Diagnostic & Alignment Complete:**\n\n${result.explanation}` }]);
        setActiveErrors([]);
      } else {
        setVibeMessages(prev => [...prev, { role: 'assistant', content: generatedContent }]);
      }
    } catch (e: any) {
      console.error(e);
      setVibeMessages(prev => [...prev, { role: 'assistant', content: 'Diagnostic runtime exception caught.' }]);
    } finally {
      setIsVibing(false);
    }
  };

  const acceptVibe = () => {
    if (vibeSuggestion) {
      const finalFS = { ...virtualFS };
      vibeSuggestion.forEach(f => {
        if (f.content) finalFS[f.filepath] = f.content;
      });
      setVirtualFS(finalFS);
      if (activeProjectId && projects[activeProjectId]) {
        const updatedProjects = { ...projects };
        updatedProjects[activeProjectId].fs = finalFS;
        setProjects(updatedProjects);
        localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
      }
      setVibeSuggestion(null);
    }
  };

  const discardVibe = () => {
    setVibeSuggestion(null);
  };

  // VFS mutations
  const handleAddNewFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;
    const name = newFileName.trim();
    if (virtualFS[name]) {
      alert("A file with this name already exists inside the active workspace sandbox.");
      return;
    }
    const finalFS = { ...virtualFS, [name]: '' };
    setVirtualFS(finalFS);
    setActiveFileName(name);
    setNewFileName('');
    setShowNewFileModal(false);

    if (activeProjectId && projects[activeProjectId]) {
      const updatedProjects = { ...projects };
      updatedProjects[activeProjectId].fs = finalFS;
      setProjects(updatedProjects);
      localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
    }
  };

  const handleDeleteFile = (name: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDialog({
      title: "Delete File",
      message: `Are you sure you want to delete file "${name}"? This action cannot be undone.`,
      onConfirm: () => {
        const finalFS = { ...virtualFS };
        delete finalFS[name];
        setVirtualFS(finalFS);
        if (activeFileName === name) {
          setActiveFileName(Object.keys(finalFS)[0] || 'index.html');
        }

        if (activeProjectId && projects[activeProjectId]) {
          const updatedProjects = { ...projects };
          updatedProjects[activeProjectId].fs = finalFS;
          setProjects(updatedProjects);
          localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
        }
      }
    });
  };

  const handleRenameFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameNewName.trim()) return;
    const oldName = renameOldName;
    const newName = renameNewName.trim();
    
    if (virtualFS[newName]) {
      alert("A file already exists with that name.");
      return;
    }

    const finalFS = { ...virtualFS };
    finalFS[newName] = finalFS[oldName];
    delete finalFS[oldName];

    setVirtualFS(finalFS);
    if (activeFileName === oldName) {
      setActiveFileName(newName);
    }
    setShowRenameFileModal(false);

    if (activeProjectId && projects[activeProjectId]) {
      const updatedProjects = { ...projects };
      updatedProjects[activeProjectId].fs = finalFS;
      setProjects(updatedProjects);
      localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
    }
  };

  const handleCreateNewProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName.trim()) return;
    const projId = 'proj_' + Date.now();
    const templateFS = templates[newProjectTemplate as keyof typeof templates] || templates.counter;
    
    const newProj = {
      id: projId,
      name: newProjectName.trim(),
      description: newProjectDesc.trim() || 'Starting template setup',
      lastModified: Date.now(),
      fs: templateFS
    };

    const updatedProjects = { ...projects, [projId]: newProj };
    setProjects(updatedProjects);
    localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));

    setActiveProjectId(projId);
    setVirtualFS(templateFS);
    setActiveFileName(Object.keys(templateFS)[0]);
    
    setNewProjectName('');
    setNewProjectDesc('');
    setShowNewProjectModal(false);
  };

  const handleDeleteProject = (projId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDialog({
      title: "Delete Sandbox Application",
      message: "Are you completely sure you want to permanently delete this sandbox application? All workspace files inside it will be lost.",
      onConfirm: () => {
        const updatedProjects = { ...projects };
        delete updatedProjects[projId];
        setProjects(updatedProjects);
        localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));

        if (activeProjectId === projId) {
          setActiveProjectId(null);
        }
      }
    });
  };

  // Dynamic Zip exporter helper
  const exportAsZip = async () => {
    try {
      // Lazy-load JSZip
      let JSZipLib = (window as any).JSZip;
      if (!JSZipLib) {
        const script = document.createElement('script');
        script.src = "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js";
        await new Promise((resolve) => {
          script.onload = resolve;
          document.body.appendChild(script);
        });
        JSZipLib = (window as any).JSZip;
      }

      const zip = new JSZipLib();
      Object.keys(virtualFS).forEach(filepath => {
        zip.file(filepath, virtualFS[filepath]);
      });

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `accelerated-logic-sandbox-project.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      alert("Verification library timeout compiling ZIP workspace.");
    }
  };

  const formatCode = () => {
    if (editorRef.current) {
      editorRef.current.trigger('editor-formatting', 'editor.action.formatDocument');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ 
          opacity: 1, 
          scale: 1, 
          y: 0,
          width: isMaximized ? '100%' : '95%',
          height: isMaximized ? '100%' : '92%',
          maxWidth: isMaximized ? 'none' : '1550px'
        }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className={cn(
          "bg-card border border-border shadow-2xl flex flex-col overflow-hidden transition-all duration-300 h-full",
          isMaximized ? "rounded-none" : "rounded-3xl"
        )}
      >
        {/* Header */}
        <div className="p-4 border-b border-border flex items-center justify-between bg-muted/40 shrink-0 select-none">
          <div className="flex items-center gap-3">
            {activeProjectId && (
              <button 
                onClick={() => setActiveProjectId(null)}
                className="p-1.5 hover:bg-accent rounded-lg text-muted-foreground hover:text-foreground transition flex items-center justify-center border border-border"
                title="Back to Dashboard"
              >
                <ChevronDown className="w-4 h-4 rotate-90" />
              </button>
            )}
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold tracking-tight">
                  {activeProjectId ? projects[activeProjectId]?.name : "Web Playground"}
                </h2>
                <span className="text-[10px] bg-indigo-950/80 text-brand-400 font-extrabold px-2 py-0.5 rounded border border-indigo-900 font-mono">PLAYGROUND ENGINE</span>
              </div>
              <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest leading-none mt-1">
                {activeProjectId ? "Sandbox Workspace" : "HTML & Web Applications"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {activeProjectId && (
              <>
                <button 
                  onClick={exportAsZip}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs bg-muted/60 hover:bg-accent hover:text-foreground font-bold transition-all border border-border text-muted-foreground"
                >
                  <Download className="w-3.5 h-3.5 text-sky-500" />
                  Export ZIP
                </button>

                <button 
                  onClick={() => setShowVibe(!showVibe)}
                  className={cn(
                    "flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border",
                    showVibe ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20" : "bg-muted/50 border-border hover:bg-accent text-muted-foreground"
                  )}
                >
                  <Sparkles className={cn("w-3.5 h-3.5", showVibe && "animate-pulse")} />
                  AI Copilot
                </button>
              </>
            )}

            <div className="h-4 w-px bg-border mx-1" />
            <Tooltip content="Close Sandbox">
              <button onClick={onClose} className="p-2 hover:bg-destructive/10 hover:text-destructive rounded-xl text-muted-foreground transition-colors">
                <X className="w-5 h-5" />
              </button>
            </Tooltip>
          </div>
        </div>

        {/* Dynamic Screen View */}
        <div className="flex-1 flex overflow-hidden relative">
          
          {/* SCREEN A: PROJECTS GRID (Home Dashboard) */}
          <AnimatePresence>
            {!activeProjectId && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-zinc-950 flex flex-col p-8 overflow-y-auto"
              >
                <div className="max-w-6xl mx-auto w-full mb-8">
                  <div className="bg-gradient-to-r from-zinc-900 to-indigo-950/40 border border-zinc-800 rounded-2xl p-6 md:p-8 relative overflow-hidden shadow-2xl">
                    <div className="absolute -right-16 -top-16 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
                    <div className="max-w-2xl relative z-10">
                      <span className="bg-indigo-500/15 text-indigo-400 text-[10px] font-extrabold tracking-widest uppercase px-3 py-1 rounded-full border border-indigo-500/20">
                        ⚡ Web Playground Studio
                      </span>
                      <h2 className="text-3xl font-extrabold text-zinc-100 tracking-tight mt-3 mb-2">
                        Design, Edit, or Ship Web Apps of any scale
                      </h2>
                      <p className="text-xs text-zinc-400 leading-relaxed font-medium">
                        Create beautiful canvas particle system prototypes, WebGL Three.js loops or dashboards in our multi-file sandbox environment.
                      </p>
                      <div className="flex gap-3 mt-6">
                        <button 
                          onClick={() => setShowNewProjectModal(true)}
                          className="flex items-center space-x-2 bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-brand-500/15"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Create New App</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="max-w-6xl mx-auto w-full flex-1 flex flex-col">
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-3 mb-6">
                    <h3 className="font-bold text-sm tracking-wide uppercase text-zinc-400 flex items-center gap-2">
                      <FolderOpen className="w-4 h-4 text-indigo-400" />
                      Applications Inventory ({Object.keys(projects).length})
                    </h3>
                  </div>

                  {Object.keys(projects).length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-20 text-center">
                      <p className="text-zinc-500 text-xs italic mb-4">No custom applications loaded yet. Click create new to configure a blueprint template!</p>
                      <button 
                        onClick={() => setShowNewProjectModal(true)}
                        className="bg-zinc-900 border border-zinc-800 text-zinc-300 px-4 py-2 text-xs font-bold rounded-xl hover:bg-zinc-850"
                      >
                        Launch custom template
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                      {Object.values(projects).map(p => (
                        <div key={p.id} className="bg-zinc-900/50 border border-zinc-850 p-5 rounded-2xl flex flex-col justify-between hover:border-zinc-700 transition">
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-bold text-sm text-foreground">{p.name}</h4>
                              <button 
                                onClick={(e) => handleDeleteProject(p.id, e)} 
                                className="p-1 hover:bg-destructive/10 text-muted-foreground hover:text-destructive rounded-lg transition"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                            <p className="text-xs text-muted-foreground leading-normal mb-4 line-clamp-2">{p.description}</p>
                          </div>
                          <div className="flex justify-between items-center pt-3 border-t border-zinc-800">
                            <span className="text-[10px] text-zinc-500 font-bold font-mono">{Object.keys(p.fs || {}).length} files</span>
                            <button 
                              onClick={() => launchProjectIDE(p.id)}
                              className="px-3.5 py-1.5 bg-brand-600/10 hover:bg-brand-600 hover:text-white text-brand-400 border border-brand-500/20 rounded-xl text-xs font-bold transition flex items-center gap-1"
                            >
                              Open Studio
                              <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* SCREEN B: IDE WORKSPACE VIEW */}
          {activeProjectId && (
            <div className="flex-1 flex overflow-hidden w-full">
              
              {/* Left sidebar vibe console */}
              <AnimatePresence>
                {showVibe && (
                  <motion.div 
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: isMaximized ? 420 : 350, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    className="border-r border-border bg-card flex flex-col overflow-hidden z-30"
                  >
                    <div className="p-4 border-b border-border flex items-center justify-between bg-primary/5 select-none shrink-0">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-primary" />
                        <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">AI Copilot</span>
                      </div>
                      <button onClick={() => setShowVibe(false)} className="p-1 hover:bg-muted rounded-md text-muted-foreground">
                        <X className="w-4 h-4" />
                      </button>
                     {/* Chat selection controllers */}
                    <div className="px-4 py-2.5 border-b border-border bg-muted/20 flex flex-col gap-2 shrink-0">
                      <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                        <button 
                          type="button"
                          onClick={() => setIsMultiAgentMode(!isMultiAgentMode)}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1 bg-zinc-900/60 hover:bg-zinc-800/80 border text-[10px] font-medium rounded-full transition-colors h-7 cursor-pointer select-none shadow-sm",
                            isMultiAgentMode 
                              ? "border-indigo-500/40 text-indigo-400 bg-indigo-500/5 hover:bg-indigo-500/10" 
                              : "border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-zinc-300"
                          )}
                        >
                          <span className={cn("h-1.5 w-1.5 rounded-full", isMultiAgentMode ? "bg-indigo-400 animate-pulse" : "bg-zinc-500")} />
                          <span>{isMultiAgentMode ? "Multi-Agent" : "Single Agent"}</span>
                          <ChevronDown className="w-3 h-3 text-zinc-500" />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setPlanningModeEnabled(!planningModeEnabled);
                            setGoalModeEnabled(false);
                            setActivePlan(null);
                            setPlanOriginalInstructions(null);
                          }}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1 border text-[10px] font-medium rounded-full transition-colors h-7 cursor-pointer select-none shadow-sm",
                            planningModeEnabled 
                              ? "bg-amber-500/10 border-amber-500/40 text-amber-500" 
                              : "bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-zinc-300"
                          )}
                        >
                          <Compass className={cn("w-3.5 h-3.5 shrink-0", planningModeEnabled && "animate-spin")} />
                          <span>Planning</span>
                          <ChevronDown className="w-3 h-3 text-zinc-500" />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setGoalModeEnabled(!goalModeEnabled);
                            setPlanningModeEnabled(false);
                            setGoalStatusList([]);
                            setCurrentGoal('');
                          }}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1 border text-[10px] font-medium rounded-full transition-colors h-7 cursor-pointer select-none shadow-sm",
                            goalModeEnabled 
                              ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-500" 
                              : "bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-zinc-300"
                          )}
                        >
                          <Target className={cn("w-3.5 h-3.5 shrink-0", goalModeEnabled && "scale-105")} />
                          <span>Goal Mode</span>
                          <ChevronDown className="w-3 h-3 text-zinc-500" />
                        </button>
                      </div>



                      {/* Active Plan approval console */}
                      {activePlan && (
                        <div className="mt-1 p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-xl space-y-2">
                          <p className="text-[10px] font-bold text-amber-500 uppercase tracking-wider">Plan Ready for Approval</p>
                          <div className="flex gap-1.5">
                            <button
                              onClick={executeActivePlan}
                              className="flex-1 py-1 px-2.5 bg-amber-500 hover:bg-amber-600 text-black font-extrabold text-[10px] rounded-lg transition-colors flex items-center justify-center gap-1 shadow-sm"
                            >
                              <Check className="w-3.5 h-3.5" /> Approve & Execute
                            </button>
                            <button
                              onClick={() => {
                                setActivePlan(null);
                                setPlanOriginalInstructions(null);
                                setVibeMessages(prev => [...prev, { role: 'assistant', content: '❌ Plan discarded. You can instruct me again to generate a new layout.' }]);
                              }}
                              className="py-1 px-2.5 border border-border bg-zinc-900 text-muted-foreground hover:bg-zinc-800 font-bold text-[10px] rounded-lg transition-all"
                            >
                              Discard
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Active Goal tracking console */}
                      {goalStatusList.length > 0 && (
                        <div className="mt-1 p-2.5 bg-zinc-950 border border-emerald-500/20 rounded-xl space-y-2">
                          <div className="flex justify-between items-center text-[9px] font-black uppercase tracking-widest text-emerald-400">
                            <span>Goal Milestones</span>
                            <span>Iteration {goalIteration}</span>
                          </div>
                          <div className="space-y-1.5 max-h-[120px] overflow-y-auto custom-scrollbar">
                            {goalStatusList.map((step, idx) => (
                              <div key={idx} className="flex items-start gap-2 text-[9.5px]">
                                <span className={cn(
                                  "mt-0.5 w-2 h-2 rounded-full shrink-0",
                                  step.status === 'completed' ? "bg-emerald-500" :
                                  step.status === 'active' ? "bg-amber-500 animate-pulse border border-amber-500/40" : "bg-zinc-800"
                                )} />
                                <span className={cn(
                                  "leading-normal",
                                  step.status === 'completed' ? "line-through text-muted-foreground/60" :
                                  step.status === 'active' ? "font-bold text-amber-500" : "text-muted-foreground"
                                )}>
                                  {step.step}
                                </span>
                              </div>
                            ))}
                          </div>
                          <div className="flex gap-1.5 pt-1 border-t border-border/10">
                            <button
                              onClick={handleIterateGoalStep}
                              disabled={isVibing}
                              className="flex-1 py-1.5 px-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-black font-extrabold text-[10px] rounded-lg transition-colors flex items-center justify-center gap-1 shadow-sm uppercase tracking-wider"
                            >
                              {goalStatusList.some(s => s.status === 'active') ? (
                                <>
                                  <Play className="w-3 h-3 fill-black text-black" /> Iterate Goal Step
                                </>
                              ) : (
                                "Goal Finished!"
                              )}
                            </button>
                            <button
                              onClick={() => {
                                setGoalStatusList([]);
                                setCurrentGoal('');
                                setVibeMessages(prev => [...prev, { role: 'assistant', content: '🎯 Goal monitoring reset.' }]);
                              }}
                              className="py-1 px-2.5 border border-border bg-zinc-900 text-muted-foreground hover:bg-zinc-800 font-bold text-[10px] rounded-lg transition-all"
                            >
                              Reset
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Multi-Agent planning layout progression */}
                      {multiAgentStep !== null && (
                        <div className="p-3 bg-zinc-950 rounded-xl space-y-2 border border-zinc-800">
                          <div className="flex justify-between items-center text-[10px] font-bold uppercase text-brand-400">
                            <span className="flex items-center gap-1">
                              <Loader className="w-3 h-3 animate-spin text-primary" />
                              {multiAgentReport}
                            </span>
                            <span>{Math.round((multiAgentStep / 4) * 100)}%</span>
                          </div>
                          <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden border border-zinc-850">
                            <div style={{ width: `${(multiAgentStep / 4) * 100}%` }} className="bg-brand-500 h-full transition-all duration-300" />
                          </div>
                        </div>
                      )}
                    </div>
                    </div>

                    {/* Chat Messages */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-background/50">
                      {vibeMessages.length === 0 && (
                        <div className="flex flex-col items-center justify-center h-full text-center gap-4 py-10 opacity-50 select-none">
                          <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                            <Wand2 className="w-6 h-6 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-xs font-bold uppercase tracking-widest">Workspace Engineer Chat</p>
                            <p className="text-[10px] max-w-[200px] leading-normal mx-auto">Ask me to modify files, build layouts, design styling schemes, or integrate modules dynamically inside the workspace.</p>
                          </div>
                        </div>
                      )}
                      
                      {vibeMessages.map((msg, i) => (
                        <div key={i} className={cn(
                          "flex gap-3.5",
                          msg.role === 'user' ? "flex-row-reverse" : "flex-row"
                        )}>
                          <div className={cn(
                            "w-7 h-7 rounded-lg flex items-center justify-center shrink-0 shadow-sm",
                            msg.role === 'user' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                          )}>
                            {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-indigo-400" />}
                          </div>
                          <div className={cn(
                            "flex flex-col gap-1 max-w-[85%] min-w-0",
                            msg.role === 'user' ? "items-end" : "items-start"
                          )}>
                            <div className={cn(
                              "p-3.5 rounded-2xl text-xs leading-relaxed shadow-sm block-overflow",
                              msg.role === 'user' 
                                ? "bg-primary text-primary-foreground rounded-tr-none" 
                                : "bg-card border border-border rounded-tl-none text-slate-200"
                            )}>
                              {msg.role === 'assistant' ? (
                                <div className="prose prose-invert prose-xs max-w-none">
                                  <Markdown
                                    remarkPlugins={[remarkMath, remarkGfm]}
                                    rehypePlugins={[[rehypeKatex, { output: 'html', throwOnError: false }]]}
                                  >
                                    {cleanMessage(msg.content)}
                                  </Markdown>
                                </div>
                              ) : (
                                msg.content
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                      {isVibing && multiAgentStep === null && (
                        <div className="flex flex-col items-start gap-2">
                          <div className="bg-muted border border-border rounded-xl rounded-tl-none p-4 max-w-[90%] shadow-sm flex items-center gap-3">
                            <RotateCcw className="w-4 h-4 animate-spin text-primary" />
                            <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground animate-pulse">AI is editing code...</span>
                          </div>
                        </div>
                      )}
                      <div ref={chatEndRef} />
                    </div>

                    {/* Vibe input panel (aligned with normal chat style) */}
                    <div className="p-4 border-t border-border bg-background shrink-0">
                      <div className={cn(
                        "flex flex-col relative transition-all duration-200 border-2 rounded-2xl bg-card border-border/80 shadow-md",
                        "focus-within:border-primary/40 focus-within:shadow-[0_0_15px_rgba(var(--primary),0.04)] hover:border-primary/20"
                      )}>
                        {/* Top action accessories */}
                        <div className="flex items-center justify-between px-3 py-1.5 border-b border-border/30 bg-muted/10 text-[9px] font-bold text-muted-foreground select-none">
                          {/* Model selector dropdown */}
                          <div className="relative flex items-center gap-1 z-10">
                            <Sparkles className="w-2.5 h-2.5 text-primary" />
                            <select 
                              value={selectedModel}
                              onChange={(e) => setSelectedModel(e.target.value)}
                              className="appearance-none bg-transparent hover:text-foreground font-black uppercase text-[9px] focus:outline-none cursor-pointer text-muted-foreground pr-3"
                            >
                              {settings.enabledChatModels?.map(equippedId => {
                                const { modelId, provider, catalogModel } = getModelInfo(equippedId);
                                return (
                                  <option key={equippedId} value={equippedId} className="bg-popover text-foreground">
                                    {provider.toUpperCase()}: {(catalogModel?.name || modelId).toUpperCase()}
                                  </option>
                                );
                              })}
                            </select>
                            <ChevronDown className="absolute right-0 top-1/2 -translate-y-1/2 w-2.5 h-2.5 opacity-50 pointer-events-none" />
                          </div>

                          {/* HITL verification checkbox */}
                          <div 
                            className="flex items-center gap-1.5 cursor-pointer hover:text-foreground active:opacity-80 transition-colors"
                            onClick={() => setHitlEnabled(!hitlEnabled)}
                          >
                            <span>HITL CHECKPOINT</span>
                            <input 
                              type="checkbox" 
                              checked={hitlEnabled}
                              onChange={(e) => setHitlEnabled(e.target.checked)}
                              onClick={(e) => e.stopPropagation()}
                              className="w-2.5 h-2.5 rounded bg-muted border-border text-primary cursor-pointer focus:ring-0"
                            />
                          </div>
                        </div>

                        {/* Text input area and Send action button */}
                        <div className="flex items-end p-2 gap-2 w-full">
                          <textarea 
                            value={vibePrompt}
                            onChange={(e) => setVibePrompt(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleVibe();
                              }
                            }}
                            placeholder="Instruct changes or ask questions..."
                            disabled={isVibing}
                            rows={1}
                            className="flex-1 bg-transparent border-none focus:ring-0 resize-none py-2 text-xs max-h-32 min-h-[36px] overflow-y-auto custom-scrollbar focus:outline-none text-slate-200 placeholder:text-muted-foreground/50"
                          />
                          {isVibing ? (
                            <Tooltip content="Stop Generation">
                              <motion.button 
                                type="button"
                                initial={{ scale: 0.8, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                onClick={handleStopVibe}
                                className="p-2 rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-all shadow-md shrink-0 mb-0.5 cursor-pointer flex items-center justify-center animate-pulse"
                              >
                                <Square className="w-3.5 h-3.5 fill-current" />
                              </motion.button>
                            </Tooltip>
                          ) : (
                            <Tooltip content={vibePrompt.trim() ? "Send Instruction" : "Voice Input"}>
                              <button 
                                onClick={() => vibePrompt.trim() ? handleVibe() : setIsVoiceOpen(true)}
                                className={cn(
                                  "p-2 rounded-xl transition-all shadow-md shrink-0 mb-0.5 cursor-pointer flex items-center justify-center",
                                  vibePrompt.trim() 
                                    ? "bg-primary text-primary-foreground hover:opacity-90" 
                                    : "bg-muted text-muted-foreground hover:bg-accent"
                                )}
                              >
                                {vibePrompt.trim() ? <ArrowRight className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                              </button>
                            </Tooltip>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Main functional workspace panels */}
              <div className="flex-1 flex flex-col bg-background relative min-w-0 h-full">
                
                {/* Visual design panel: Files List Explorer, Monaco Editor, Frame Emulator */}
                <div className="flex-1 flex overflow-hidden relative">
                  
                  {/* Vertical file tree drawer */}
                  <div className="w-52 border-r border-border bg-muted/20 flex flex-col shrink-0 overflow-hidden select-none">
                    <div className="p-2 border-b border-border flex justify-between items-center bg-card shrink-0">
                      <span className="text-[10px] font-bold tracking-wide uppercase text-muted-foreground flex items-center gap-1">
                        <FolderOpen className="w-3.5 h-3.5 text-indigo-400" />
                        Virtual Files
                      </span>
                      <button 
                        onClick={() => setShowNewFileModal(true)}
                        className="p-1 hover:bg-accent text-indigo-400 hover:text-indigo-200 rounded transition"
                        title="Add File"
                      >
                        <FilePlus2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-1.5 space-y-0.5 custom-scrollbar">
                      {Object.keys(virtualFS).map(name => {
                        const isActive = name === activeFileName;
                        return (
                          <div
                            key={name}
                            onClick={() => setActiveFileName(name)}
                            className={cn(
                              "group flex items-center justify-between px-2 py-1.5 rounded-lg cursor-pointer text-xs font-semibold transition-all mb-0.5",
                              isActive
                                ? "bg-accent/40 text-indigo-400 border border-border"
                                : "text-muted-foreground hover:bg-accent/20 hover:text-foreground"
                            )}
                          >
                            <span className="truncate flex items-center gap-2">
                              <FileCode className={cn(
                                "w-3.5 h-3.5",
                                name.endsWith('.html') ? "text-orange-500" : 
                                name.endsWith('.css') ? "text-blue-500" : "text-yellow-500"
                              )} />
                              {name}
                            </span>
                            <div className="hidden group-hover:flex items-center gap-1">
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setRenameOldName(name);
                                  setRenameNewName(name);
                                  setShowRenameFileModal(true);
                                }}
                                className="text-zinc-500 hover:text-indigo-400 p-0.5"
                                title="Rename"
                              >
                                <Sparkles className="w-3 h-3" />
                              </button>
                              {Object.keys(virtualFS).length > 1 && (
                                <button 
                                  onClick={(e) => handleDeleteFile(name, e)}
                                  className="text-zinc-500 hover:text-rose-500 p-0.5"
                                  title="Delete"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  {/* Monaco / Textarea container */}
                  <div className="flex-1 flex flex-col border-r border-border min-w-0 h-full relative bg-slate-950/10">
                    <div id="tabs-holder" className="h-9 border-b border-border bg-card flex items-center overflow-x-auto select-none shrink-0 custom-scrollbar">
                      {Object.keys(virtualFS).map(name => {
                        const isActive = name === activeFileName;
                        return (
                          <button
                            key={name}
                            onClick={() => setActiveFileName(name)}
                            className={cn(
                              "px-4 h-full border-r border-border flex items-center gap-2 text-xs font-bold transition-all shrink-0",
                              isActive 
                                ? "bg-background text-indigo-400 border-t-2 border-t-indigo-500" 
                                : "text-muted-foreground hover:bg-accent hover:text-foreground"
                            )}
                          >
                            {name}
                            {vibeSuggestion?.some(f => f.filepath === name) && (
                              <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex-1 relative overflow-hidden bg-[#131316]">
                      {isMonacoLoaded ? (
                        <div ref={editorContainerRef} className="w-full h-full" />
                      ) : (
                        <textarea
                          spellCheck={false}
                          autoComplete="off"
                          className={cn(
                            "w-full h-full p-6 font-mono text-sm resize-none bg-zinc-950 text-slate-200 outline-none",
                            vibeSuggestion && "opacity-30 blur-[1px]"
                          )}
                          value={virtualFS[activeFileName] || ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setVirtualFS(prev => {
                              const next = { ...prev, [activeFileName]: val };
                              if (activeProjectId && projects[activeProjectId]) {
                                const updatedProjects = { ...projects };
                                updatedProjects[activeProjectId].fs = next;
                                setProjects(updatedProjects);
                                localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
                              }
                              return next;
                            });
                          }}
                          placeholder={`Enter custom code for ${activeFileName}...`}
                        />
                      )}

                      {/* Vibe Proposed Comparison Overlay Drawer */}
                      <AnimatePresence>
                        {vibeSuggestion && (
                          <motion.div 
                            initial={{ x: '100%' }}
                            animate={{ x: 0 }}
                            exit={{ x: '100%' }}
                            className="absolute inset-y-0 right-0 w-full lg:w-[450px] xl:w-[550px] bg-zinc-900 border-l border-indigo-500/30 z-20 flex flex-col shadow-2xl shadow-indigo-500/10"
                          >
                            <div className="p-3.5 bg-indigo-950 border-b border-indigo-900 flex items-center justify-between select-none">
                              <span className="text-[10px] font-extrabold tracking-widest text-indigo-400 uppercase flex items-center gap-1.5">
                                <Sparkles className="w-3.5 h-3.5" /> Proposed Diff Rewrite
                              </span>
                              <button onClick={discardVibe} className="p-1 hover:bg-zinc-800 rounded-md text-muted-foreground"><X className="w-4 h-4" /></button>
                            </div>
                            <div className="flex-1 p-6 overflow-auto custom-scrollbar font-mono text-xs bg-zinc-950 text-slate-200">
                              <pre className="whitespace-pre-wrap leading-relaxed">
                                {vibeSuggestion.find(f => f.filepath === activeFileName)?.content || 'No modifications proposed for this file.'}
                              </pre>
                            </div>
                            <div className="p-4 border-t border-indigo-950 bg-indigo-950/20">
                              <button 
                                onClick={acceptVibe}
                                className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 text-white rounded-2xl font-bold text-sm hover:scale-[1.01] active:scale-[0.99] transition-all shadow-xl shadow-indigo-600/20"
                              >
                                Apply proposed rewrite
                                <ArrowRight className="w-4 h-4" />
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Editor Footer */}
                    <div className="h-7 border-t border-border bg-card flex items-center justify-between px-3 text-[11px] text-muted-foreground select-none shrink-0">
                      <span className="font-semibold tracking-wide uppercase font-mono text-[9px]">Workspace active: {activeFileName}</span>
                      <button 
                        onClick={formatCode}
                        className="flex items-center gap-1 hover:text-indigo-400 transition font-bold"
                        title="Indent code file"
                      >
                        <AlignLeft className="w-3.5 h-3.5" />
                        <span>Format Code</span>
                      </button>
                    </div>
                  </div>

                  {/* Device Emulator Container */}
                  <div className="flex-1 flex flex-col min-w-0 bg-slate-900 overflow-hidden h-full">
                    <div className="p-2 border-b border-border bg-slate-950/40 flex items-center justify-between select-none shrink-0">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 px-2 flex items-center gap-1.5">
                        <Globe className="w-3.5 h-3.5 text-indigo-400 animate-pulse" /> Device Simulator
                      </span>

                      <div className="flex items-center gap-1 bg-muted p-0.5 rounded-lg border border-border">
                        <button onClick={() => setPreviewSize('mobile')} className={cn("p-1.5 rounded-md transition-all", previewSize === 'mobile' ? 'bg-background text-primary shadow-sm' : 'text-muted-foreground')} title="Mobile view">
                          <Smartphone className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => setPreviewSize('tablet')} className={cn("p-1.5 rounded-md transition-all", previewSize === 'tablet' ? 'bg-background text-primary shadow-sm' : 'text-muted-foreground')} title="Tablet view">
                          <Tablet className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => setPreviewSize('desktop')} className={cn("p-1.5 rounded-md transition-all", previewSize === 'desktop' ? 'bg-background text-primary shadow-sm' : 'text-muted-foreground')} title="Desktop view">
                          <Monitor className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button 
                          onClick={updatePreview}
                          className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-[10px] font-extrabold text-white transition uppercase tracking-wider"
                        >
                          <Play className="w-3 h-3 fill-current" />
                          <span>Run App</span>
                        </button>
                        <Tooltip content="Open in independent tab">
                          <button 
                            onClick={() => {
                              const win = window.open();
                              win?.document.write(previewContent);
                              win?.document.close();
                            }}
                            className="p-1 text-muted-foreground hover:text-font transition border border-border rounded"
                          >
                            <ExternalLink className="w-3 h-3" />
                          </button>
                        </Tooltip>
                      </div>
                    </div>

                    <div className="flex-1 bg-slate-950 flex items-center justify-center p-4 overflow-auto min-h-0 relative">
                      <div 
                        style={{
                          width: previewSize === 'mobile' ? '375px' : previewSize === 'tablet' ? '768px' : '100%',
                          height: previewSize === 'mobile' ? '667px' : '100%',
                          maxHeight: '100%',
                          maxWidth: '100%'
                        }}
                        className="bg-white rounded-xl shadow-2xl overflow-hidden border border-slate-800 transition-all duration-300 relative h-full flex flex-col"
                      >
                        <iframe
                          ref={iframeRef}
                          title="Visual App Preview"
                          srcDoc={previewContent}
                          className="flex-1 w-full border-none bg-white"
                          sandbox="allow-scripts allow-modals allow-same-origin"
                        />
                      </div>
                    </div>

                    {/* Live console logging drawer */}
                    <div className="h-36 border-t border-border bg-slate-950 flex flex-col shrink-0 overflow-hidden font-mono text-[11px]">
                      <div className="px-3 py-1.5 bg-slate-900/60 border-b border-border flex justify-between items-center text-[10px] text-muted-foreground select-none shrink-0">
                        <span className="font-bold tracking-wider uppercase text-slate-400">Sandbox Output Log</span>
                        <div className="flex items-center gap-2">
                          <AnimatePresence>
                            {activeErrors.length > 0 && (
                              <motion.button 
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                                onClick={handleAIDebugger}
                                className="flex items-center gap-1 px-2.5 py-0.5 bg-gradient-to-r from-indigo-900 to-indigo-700 font-extrabold border border-indigo-500/30 text-indigo-200 rounded-md text-[10px] uppercase tracking-widest animate-pulse hover:text-white"
                              >
                                <Wand2 className="w-3 h-3 text-indigo-400" />
                                Fix with AI
                              </motion.button>
                            )}
                          </AnimatePresence>
                          <button onClick={() => { setConsoleLogs([]); setActiveErrors([]); }} className="hover:text-rose-400 transition">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      <div className="flex-1 overflow-y-auto p-3 space-y-1 bg-[#101012] text-slate-300 custom-scrollbar">
                        {consoleLogs.length === 0 && (
                          <p className="text-zinc-600 italic select-none">No prints stream yet. Execute standard console.log inside JavaScript code to verify output.</p>
                        )}
                        {consoleLogs.map((log, index) => (
                          <div key={index} className={cn(
                            "py-0.5 px-1 rounded break-all font-mono",
                            log.type === 'error' ? "bg-rose-950/20 text-rose-300 border border-rose-900/40 font-semibold" :
                            log.type === 'warn' ? "bg-amber-950/20 text-amber-300 border border-amber-900/40" : ""
                          )}>
                            <span className="opacity-40 select-none">[{log.type.toUpperCase()}] </span>
                            <span>{log.args.join(' ')}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>

                </div>

              </div>
            </div>
          )}

        </div>
      </motion.div>

      {/* DIALOG POPUP MODALS */}

      {/* Modal 1: Create New Project */}
      <AnimatePresence>
        {showNewProjectModal && (
          <div className="fixed inset-0 z-[120] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl p-6"
            >
              <h3 className="text-sm font-bold uppercase tracking-widest mb-4 flex items-center gap-1.5 text-indigo-400">
                <PlusCircle className="w-5 h-5" />
                Initialize New Project
              </h3>
              <form onSubmit={handleCreateNewProject} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-muted-foreground mb-1 uppercase tracking-wider">Project Name</label>
                  <input 
                    type="text" 
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    required
                    placeholder="E.g., Orbit Universe Map"
                    className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-muted-foreground mb-1 uppercase tracking-wider">Description</label>
                  <textarea 
                    value={newProjectDesc}
                    onChange={(e) => setNewProjectDesc(e.target.value)}
                    placeholder="Short summary of files"
                    rows={2}
                    className="w-full bg-muted border border-border rounded-lg p-2 text-xs text-foreground focus:outline-none focus:border-indigo-500 resize-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-muted-foreground mb-1 uppercase tracking-wider">Starting Template</label>
                  <select 
                    value={newProjectTemplate}
                    onChange={(e) => setNewProjectTemplate(e.target.value)}
                    className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="counter">Counter App Canvas (HTML/CSS/JS)</option>
                    <option value="canvas">Pixel Rain Canvas (JS Canvas Particles)</option>
                    <option value="threejs">Interactive Three.js Geometric Sphere</option>
                    <option value="blank">Empty Workspace Layout</option>
                  </select>
                </div>
                <div className="flex justify-end gap-2 pt-3 border-t border-border">
                  <button 
                    type="button" 
                    onClick={() => setShowNewProjectModal(false)}
                    className="px-3.5 py-1.5 bg-muted text-muted-foreground rounded-lg text-xs font-bold hover:bg-accent border border-border transition"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-4 py-1.5 bg-indigo-600 text-white font-bold rounded-lg text-xs hover:bg-indigo-500 transition shadow-lg shadow-indigo-600/20"
                  >
                    Initialize App
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal 2: Create New File */}
      <AnimatePresence>
        {showNewFileModal && (
          <div className="fixed inset-0 z-[120] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card border border-border rounded-2xl w-full max-w-sm p-5 shadow-2xl"
            >
              <h3 className="text-xs font-bold uppercase tracking-widest mb-3">Add Custom File</h3>
              <form onSubmit={handleAddNewFile} className="space-y-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1">Filename</label>
                  <input 
                    type="text" 
                    value={newFileName}
                    onChange={(e) => setNewFileName(e.target.value)}
                    required
                    placeholder="e.g. library.js"
                    className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-indigo-500"
                  />
                  <span className="text-[10px] text-muted-foreground mt-1 block leading-tight">Supported suffixes: .html, .css, .js, .json</span>
                </div>
                <div className="flex justify-end gap-2">
                  <button 
                    type="button" 
                    onClick={() => setShowNewFileModal(false)}
                    className="px-3.5 py-1.5 bg-muted text-muted-foreground rounded-lg text-xs"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-3.5 py-1.5 bg-indigo-600 text-white font-bold rounded-lg text-xs"
                  >
                    Create
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal 3: Rename File */}
      <AnimatePresence>
        {showRenameFileModal && (
          <div className="fixed inset-0 z-[120] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card border border-border rounded-2xl w-full max-w-sm p-5 shadow-2xl"
            >
              <h3 className="text-xs font-bold uppercase tracking-widest mb-3">Rename Workspace File</h3>
              <form onSubmit={handleRenameFile} className="space-y-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1">New Filename</label>
                  <input 
                    type="text" 
                    value={renameNewName}
                    onChange={(e) => setRenameNewName(e.target.value)}
                    required
                    className="w-full bg-muted border border-border rounded-lg px-3 py-2 text-xs text-foreground focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <button 
                    type="button" 
                    onClick={() => setShowRenameFileModal(false)}
                    className="px-3.5 py-1.5 bg-muted text-muted-foreground rounded-lg text-xs"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-3.5 py-1.5 bg-indigo-600 text-white font-bold rounded-lg text-xs"
                  >
                    Save Rename
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Custom Confirm Dialog Overlay */}
      <AnimatePresence>
        {confirmDialog && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-border w-full max-w-sm rounded-2xl p-6 shadow-2xl relative"
            >
              <div className="flex items-center gap-3 text-destructive mb-3">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <h3 className="font-bold text-sm tracking-tight">{confirmDialog.title}</h3>
              </div>
              <p className="text-xs text-muted-foreground leading-normal mb-5">
                {confirmDialog.message}
              </p>
              <div className="flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setConfirmDialog(null)}
                  className="px-3.5 py-1.5 rounded-lg border border-border hover:bg-accent text-xs font-semibold transition text-foreground"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    confirmDialog.onConfirm();
                    setConfirmDialog(null);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-destructive text-destructive-foreground hover:bg-destructive/90 text-xs font-semibold transition shadow-lg shadow-destructive/15"
                >
                  Confirm Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Voice Input Interface overlay */}
      <AnimatePresence>
        {isVoiceOpen && (
          <VoiceInterface 
            onTranscript={(text) => {
              setVibePrompt(text);
              setIsVoiceOpen(false);
            }}
            onClose={() => setIsVoiceOpen(false)}
          />
        )}
      </AnimatePresence>

    </div>
  );
};
