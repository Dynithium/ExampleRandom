import React, { useEffect, useState, useRef } from 'react';
import { X, Download, Maximize2, Minimize2, FileText, ImageIcon, FileCode, FileType, ChevronLeft, ChevronRight, AlertTriangle, ZoomIn, ZoomOut, RotateCcw, Video } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { AppFile } from '../db';
import { cn } from '../utils';
import * as pdfjsLib from 'pdfjs-dist';

// Use Vite's worker import to get the correct URL for the worker file
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker?url';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

interface FilePreviewProps {
  file: AppFile;
  onClose: () => void;
}

export const FilePreview: React.FC<FilePreviewProps> = ({ file, onClose }) => {
  const [isFullscreen, setIsFullscreen] = React.useState(false);
  const [pdfPages, setPdfPages] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [scale, setScale] = useState<number>(1.5);
  const [pdfLoading, setPdfLoading] = useState<boolean>(false);
  const [pdfError, setPdfError] = useState<string | null>(null);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pdfInstance = useRef<any>(null);
  const renderTaskRef = useRef<any>(null);

  const isImage = file.type.startsWith('image/');
  const isPDF = file.type === 'application/pdf';
  const isVideo = file.type.startsWith('video/') || file.name.endsWith('.mp4');
  const isMarkdown = file.name.endsWith('.md') || file.type === 'text/markdown';
  const isHTML = file.name.endsWith('.html') || file.type === 'text/html';
  const isCode = file.name.endsWith('.py') || file.name.endsWith('.js') || file.name.endsWith('.ts') || file.name.endsWith('.tsx') || file.name.endsWith('.css') || file.name.endsWith('.json') || file.name.endsWith('.rs') || file.name.endsWith('.go') || file.name.endsWith('.c') || file.name.endsWith('.cpp') || file.name.endsWith('.java') || file.name.endsWith('.sh');
  const isText = (file.type.startsWith('text/') || file.name.endsWith('.txt') || (!isImage && !isPDF && !isVideo && !file.content.startsWith('data:'))) && !isVideo;
  
  const getLanguage = (fileName: string) => {
    if (fileName.endsWith('.py')) return 'python';
    if (fileName.endsWith('.js')) return 'javascript';
    if (fileName.endsWith('.ts')) return 'typescript';
    if (fileName.endsWith('.tsx')) return 'typescript';
    if (fileName.endsWith('.css')) return 'css';
    if (fileName.endsWith('.json')) return 'json';
    if (fileName.endsWith('.html')) return 'html';
    if (fileName.endsWith('.rs')) return 'rust';
    if (fileName.endsWith('.go')) return 'go';
    if (fileName.endsWith('.c')) return 'c';
    if (fileName.endsWith('.cpp')) return 'cpp';
    if (fileName.endsWith('.java')) return 'java';
    if (fileName.endsWith('.sh')) return 'bash';
    if (fileName.endsWith('.md')) return 'markdown';
    return 'plaintext';
  };

  useEffect(() => {
    if (isPDF) {
      loadPDF();
    }
  }, [file, isPDF]);

  useEffect(() => {
    if (isPDF && pdfInstance.current) {
      renderPage(currentPage, scale);
    }
  }, [currentPage, scale]);

  const loadPDF = async () => {
    setPdfLoading(true);
    setPdfError(null);
    try {
      const base64Data = file.content.includes(',') ? file.content.split(',')[1] : file.content;
      
      // Convert base64 to Uint8Array safely
      const binaryString = window.atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const loadingTask = pdfjsLib.getDocument({ data: bytes });
      const pdf = await loadingTask.promise;
      pdfInstance.current = pdf;
      setPdfPages(pdf.numPages);
      renderPage(1, scale);
    } catch (err: any) {
      console.error('PDF Load Error:', err);
      setPdfError(err.message || 'Failed to decode PDF data. The file might be corrupted or in an unsupported format.');
    } finally {
      setPdfLoading(false);
    }
  };

  const renderPage = async (num: number, currentScale: number) => {
    if (!pdfInstance.current || !canvasRef.current) return;

    // Cancel existing render task to avoid "Cannot use the same canvas" error
    if (renderTaskRef.current) {
      try {
        await renderTaskRef.current.cancel();
      } catch (e) {
        // Task already finished or cancelled
      }
    }

    try {
      const page = await pdfInstance.current.getPage(num);
      const viewport = page.getViewport({ scale: currentScale });
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (!context) return;

      canvas.height = viewport.height;
      canvas.width = viewport.width;

      const renderContext = {
        canvasContext: context,
        viewport: viewport
      };
      
      const renderTask = page.render(renderContext);
      renderTaskRef.current = renderTask;
      
      await renderTask.promise;
      renderTaskRef.current = null;
    } catch (err: any) {
      if (err.name === 'RenderingCancelledException') return;
      console.error('Page Render Error:', err);
    }
  };

  const downloadFile = () => {
    const link = document.createElement('a');
    link.href = file.content;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderContent = () => {
    if (isImage) {
      return (
        <div className="flex-1 flex items-center justify-center bg-black/20 p-4 overflow-auto">
          <img 
            src={file.content} 
            alt={file.name} 
            className="max-w-full max-h-full object-contain shadow-2xl rounded-lg"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://placehold.co/600x400?text=Image+Load+Error';
            }}
          />
        </div>
      );
    }

    if (isVideo) {
      return (
        <div className="flex-1 flex items-center justify-center bg-black/40 p-4 sm:p-8 overflow-auto">
          <video 
            src={file.content} 
            controls 
            className="max-w-full rounded-2xl shadow-2xl border border-border/40 bg-zinc-950 outline-none"
            style={{ maxHeight: 'calc(100vh - 240px)' }}
          >
            Your browser does not support the video tag.
          </video>
        </div>
      );
    }

    if (isPDF) {
      return (
        <div className="flex-1 bg-muted flex flex-col overflow-hidden">
          <div className="h-12 bg-background/50 border-b border-border flex items-center justify-between px-4 shrink-0 transition-all">
            <div className="flex items-center gap-1.5 sm:gap-4">
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="p-1.5 hover:bg-accent rounded-lg disabled:opacity-30 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <div className="bg-background px-2 py-1 rounded-md border border-border flex items-center gap-1">
                  <span className="text-[10px] font-bold text-muted-foreground uppercase opacity-50">PG</span>
                  <span className="text-xs font-bold font-mono">{currentPage}</span>
                </div>
                <button 
                  onClick={() => setCurrentPage(p => Math.min(pdfPages, p + 1))}
                  disabled={currentPage === pdfPages}
                  className="p-1.5 hover:bg-accent rounded-lg disabled:opacity-30 transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="h-4 w-px bg-border hidden sm:block" />

              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setScale(s => Math.max(0.5, s - 0.25))}
                  className="p-1.5 hover:bg-accent rounded-lg transition-colors"
                  title="Zoom Out"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <div className="bg-background px-2 py-1 rounded-md border border-border flex items-center gap-1">
                  <span className="text-xs font-bold font-mono">{Math.round(scale * 100)}%</span>
                </div>
                <button 
                  onClick={() => setScale(s => Math.min(4, s + 0.25))}
                  className="p-1.5 hover:bg-accent rounded-lg transition-colors"
                  title="Zoom In"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setScale(1.5)}
                  className="p-1.5 hover:bg-accent rounded-lg transition-colors"
                  title="Reset Zoom"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            
            <div className="hidden sm:flex items-center gap-2">
               <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" />
               <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground/60">Legacy-Free Browser Renderer</span>
            </div>
          </div>
          <div className="flex-1 overflow-auto p-4 sm:p-8 flex justify-center custom-scrollbar bg-[#1a1a1a]">
            {pdfLoading && (
              <div className="flex flex-col items-center justify-center gap-4 animate-pulse pt-20">
                <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest">Parsing Vector Streams...</p>
              </div>
            )}
            {pdfError && (
              <div className="flex flex-col items-center justify-center gap-4 text-destructive pt-20">
                <AlertTriangle className="w-16 h-16 opacity-50" />
                <div className="text-center">
                  <p className="text-sm font-bold uppercase tracking-widest mb-1">Renderer Failure</p>
                  <p className="text-xs text-muted-foreground max-w-xs">{pdfError}</p>
                </div>
                <button 
                  onClick={loadPDF} 
                  className="px-4 py-2 bg-destructive/10 hover:bg-destructive/20 border border-destructive/20 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all"
                >
                  Retry Boot
                </button>
              </div>
            )}
            <div className="relative group">
               <canvas 
                ref={canvasRef} 
                className={cn(
                  "shadow-[0_0_50px_rgba(0,0,0,0.5)] bg-white rounded-sm transition-opacity duration-300", 
                  (pdfLoading || pdfError) ? "opacity-0" : "opacity-100"
                )} 
              />
               <div className="absolute inset-x-0 bottom-4 flex justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="bg-background/80 backdrop-blur-md border border-border px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-xl">
                    Page {currentPage} of {pdfPages}
                  </div>
               </div>
            </div>
          </div>
        </div>
      );
    }

    if (isHTML) {
      return (
        <div className="flex-1 overflow-hidden flex flex-col bg-zinc-950">
          <div className="px-4 py-2 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode className="w-3.5 h-3.5 text-primary" />
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Live Rendering Preview</span>
            </div>
            <div className="flex items-center gap-2">
               <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
               <span className="text-[10px] font-bold text-green-500/70 uppercase tracking-widest">Sandboxed</span>
            </div>
          </div>
          <div className="flex-1 bg-white">
            <iframe 
              srcDoc={file.content}
              className="w-full h-full border-none"
              title={file.name}
              sandbox="allow-scripts"
            />
          </div>
        </div>
      );
    }

    if (isCode || isText) {
      return (
        <div className="flex-1 overflow-hidden bg-zinc-950 flex flex-col">
          <div className="px-4 py-2 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCode className="w-3.5 h-3.5 text-primary" />
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{getLanguage(file.name)}</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-1 h-1 rounded-full bg-primary/50" />
              <span className="text-[9px] text-zinc-500 uppercase tracking-tighter">Text Preview</span>
            </div>
          </div>
          <div className="flex-1 overflow-auto custom-scrollbar font-mono text-sm">
            <SyntaxHighlighter
              language={getLanguage(file.name)}
              style={vscDarkPlus}
              customStyle={{ background: 'transparent', padding: '1.5rem', margin: 0 }}
            >
              {file.content}
            </SyntaxHighlighter>
          </div>
        </div>
      );
    }

    if (isMarkdown) {
      return (
        <div className="flex-1 overflow-y-auto bg-card p-8 custom-scrollbar">
          <div className="max-w-4xl mx-auto markdown-body">
            <ReactMarkdown 
              remarkPlugins={[remarkMath, remarkGfm]} 
              rehypePlugins={[rehypeKatex]}
            >
              {file.content}
            </ReactMarkdown>
          </div>
        </div>
      );
    }

    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-muted/30 gap-6">
        <div className="relative">
          <div className="absolute inset-0 bg-primary/20 blur-3xl rounded-full" />
          <AlertTriangle className="w-16 h-16 text-muted-foreground relative z-10 opacity-40" />
        </div>
        <div className="text-center space-y-2">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-foreground">Preview Unavailable</p>
          <p className="text-xs text-muted-foreground/60 max-w-[200px]">This file type is binary or not supported for direct preview.</p>
        </div>
        <button 
          onClick={downloadFile}
          className="px-6 py-2.5 bg-primary/10 hover:bg-primary/20 border border-primary/30 rounded-2xl text-[10px] font-bold uppercase tracking-widest transition-all hover:scale-105 active:scale-95"
        >
          Download to View
        </button>
      </div>
    );
  };

  const getFileIcon = () => {
    if (isImage) return <ImageIcon className="w-5 h-5 text-primary" />;
    if (isPDF) return <FileType className="w-5 h-5 text-red-500" />;
    if (isCode) return <FileCode className="w-5 h-5 text-blue-500" />;
    if (isVideo) return <Video className="w-5 h-5 text-purple-500" />;
    return <FileText className="w-5 h-5 text-muted-foreground" />;
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={cn(
        "fixed z-[150] bg-background border border-border shadow-2xl flex flex-col overflow-hidden transition-all duration-300",
        isFullscreen ? "inset-0" : "inset-4 sm:inset-10 lg:inset-20 rounded-3xl"
      )}
    >
      <div className="p-4 border-b border-border flex items-center justify-between bg-muted/30 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <div className="p-2 bg-background rounded-xl border border-border shadow-sm shrink-0">
            {getFileIcon()}
          </div>
          <div className="flex flex-col min-w-0">
            <h3 className="text-sm font-bold truncate leading-tight">{file.name}</h3>
            <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold opacity-60">
              {file.type || 'Unknown Format'} • {new Date(file.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button 
            onClick={downloadFile}
            className="p-2 hover:bg-accent rounded-xl text-muted-foreground hover:text-foreground transition-colors"
            title="Download File"
          >
            <Download className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 hover:bg-accent rounded-xl text-muted-foreground hover:text-foreground transition-colors hidden sm:block"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
          >
            {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
          </button>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-accent rounded-xl text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        {renderContent()}
      </div>

      <div className="p-3 border-t border-border bg-muted/20 flex items-center justify-between px-6 shrink-0">
        <span className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest">Secure File Previewer</span>
        <div className="flex items-center gap-1">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
          <span className="text-[10px] font-bold text-muted-foreground/50 uppercase tracking-widest">Local Integrity Verified</span>
        </div>
      </div>
    </motion.div>
  );
};
