import React, { useState, useEffect, useRef } from 'react';
import { Play, X, RefreshCw, Code, Layout, Maximize2, Minimize2, Terminal, AlertCircle, Wand2, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LogEntry {
  type: 'log' | 'error' | 'warn' | 'info';
  content: string;
  timestamp: number;
}

interface CodePreviewProps {
  code: string;
  language: string;
  onClose: () => void;
  onFixError?: (error: string, code: string) => void;
  onRunPython?: (code: string) => Promise<{ stdout: string, plot: string | null } | any>;
  inline?: boolean;
}

export const CodePreview: React.FC<CodePreviewProps> = ({ code, language, onClose, onFixError, onRunPython, inline }) => {
  const [srcDoc, setSrcDoc] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showConsole, setShowConsole] = useState(true);
  const [viewMode, setViewMode] = useState<'code' | 'preview' | 'split'>('split');
  const canPreview = language === 'html' || language === 'javascript' || language === 'typescript' || language === 'react' || language === 'python';
  const [pythonOutput, setPythonOutput] = useState<{ stdout: string, plot: string | null } | null>(null);
  const [isRunningPython, setIsRunningPython] = useState(false);
  const consoleRef = useRef<HTMLDivElement>(null);

  const handleRunPython = async () => {
    if (!onRunPython) return;
    setIsRunningPython(true);
    try {
      const result = await onRunPython(code);
      setPythonOutput(result);
    } catch (err: any) {
      setPythonOutput({ stdout: `Error: ${err.message || String(err)}`, plot: null });
    } finally {
      setIsRunningPython(false);
    }
  };

  useEffect(() => {
    if (language === 'python') {
      handleRunPython();
    }
  }, [code, language]);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'CONSOLE_LOG') {
        setLogs(prev => [...prev, {
          type: event.data.logType,
          content: event.data.content,
          timestamp: Date.now()
        }]);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  useEffect(() => {
    if (consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [logs]);

  useEffect(() => {
    if (language === 'html' || language === 'javascript' || language === 'typescript' || language === 'react') {
      const timeout = setTimeout(() => {
        const consoleScript = `
          <script>
            (function() {
              const originalLog = console.log.bind(console);
              const originalError = console.error.bind(console);
              const originalWarn = console.warn.bind(console);
              const originalInfo = console.info.bind(console);

              function sendToParent(type, args) {
                const content = args.map(arg => {
                  if (typeof arg === 'object') {
                    try { return JSON.stringify(arg, null, 2); } catch(e) { return String(arg); }
                  }
                  return String(arg);
                }).join(' ');
                
                window.parent.postMessage({
                  type: 'CONSOLE_LOG',
                  logType: type,
                  content: content
                }, '*');
              }

              console.log = (...args) => { originalLog(...args); sendToParent('log', args); };
              console.error = (...args) => { originalError(...args); sendToParent('error', args); };
              console.warn = (...args) => { originalWarn(...args); sendToParent('warn', args); };
              console.info = (...args) => { originalInfo(...args); sendToParent('info', args); };

              window.onerror = (msg, url, line, col, error) => {
                sendToParent('error', [\`Uncaught Error: \${msg} at \${line}:\${col}\`]);
                return false;
              };

              window.onunhandledrejection = (event) => {
                sendToParent('error', [\`Unhandled Promise Rejection: \${event.reason}\`]);
              };
            })();
          </script>
        `;

        if (language === 'html') {
          setSrcDoc(consoleScript + code);
        } else {
          setSrcDoc(`
            <html>
              <head>
                <script src="https://cdn.tailwindcss.com"></script>
                <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
                <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
                <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
                ${consoleScript}
              </head>
              <body class="bg-zinc-950 text-white p-4">
                <div id="root"></div>
                <script type="text/babel">
                  try {
                    ${code.includes('ReactDOM.render') || code.includes('createRoot') ? code : `
                      const App = () => {
                        ${code}
                        return <div>Check console or ensure code is a valid React component.</div>;
                      };
                      const root = ReactDOM.createRoot(document.getElementById('root'));
                      root.render(<App />);
                    `}
                  } catch (err) {
                    console.error(err.message);
                  }
                </script>
              </body>
            </html>
          `);
        }
      }, 500);
      return () => clearTimeout(timeout);
    }
  }, [code, language]);

  const clearLogs = () => setLogs([]);

  return (
    <motion.div 
      id="code-preview-container"
      initial={inline ? { opacity: 0 } : { opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={inline ? { opacity: 0 } : { opacity: 0, scale: 0.95 }}
      className={inline ? "flex-1 flex flex-col overflow-hidden bg-zinc-950 h-full" : `fixed z-[110] bg-zinc-950 border border-zinc-800 shadow-2xl flex flex-col overflow-hidden transition-all duration-500 ${
        isFullscreen ? 'inset-0' : 'inset-10 rounded-3xl'
      }`}
    >
      {/* Header */}
      <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50 backdrop-blur-sm shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/50" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
            <div className="w-3 h-3 rounded-full bg-green-500/50" />
          </div>
          <div className="h-4 w-px bg-zinc-800 mx-2" />
          <div className="flex items-center gap-2">
            <Layout className="w-4 h-4 text-zinc-400" />
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest">
              {viewMode === 'code' ? 'Code View' : viewMode === 'preview' ? 'Live Preview' : 'Split View'}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {canPreview ? (
            <div className="flex items-center bg-zinc-800/50 rounded-xl p-1 mr-2 gap-1 animate-fadeIn">
              <button 
                id="viewmode-code-btn"
                onClick={() => setViewMode('code')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${
                  viewMode === 'code' ? 'bg-zinc-700 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <Code className="w-3.5 h-3.5" />
                Code
              </button>
              <button 
                id="viewmode-preview-btn"
                onClick={() => setViewMode('preview')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${
                  viewMode === 'preview' ? 'bg-zinc-700 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <Play className="w-3.5 h-3.5" />
                Preview
              </button>
              <button 
                id="viewmode-split-btn"
                onClick={() => setViewMode('split')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${
                  viewMode === 'split' ? 'bg-zinc-700 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <Layout className="w-3.5 h-3.5" />
                Split
              </button>

              <div className="h-4 w-px bg-zinc-800 mx-1" />

              <button 
                id="viewmode-console-btn"
                onClick={() => setShowConsole(!showConsole)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${
                  showConsole ? 'bg-zinc-700 text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                Console
              </button>
            </div>
          ) : (
            <div className="flex items-center bg-zinc-800/50 rounded-xl p-1 mr-2">
              <button 
                disabled
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest bg-zinc-700 text-white shadow-sm"
              >
                <Code className="w-3.5 h-3.5" />
                Code Only
              </button>
            </div>
          )}
          {!inline && (
            <button 
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 hover:bg-zinc-800 rounded-xl text-zinc-400 hover:text-white transition-colors"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          )}
          <button 
            onClick={onClose}
            className="p-2 hover:bg-zinc-800 rounded-xl text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content - Split View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Code Side */}
        <AnimatePresence>
          {(viewMode === 'code' || viewMode === 'split' || !canPreview) && (
            <motion.div 
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: (viewMode === 'split' && canPreview) ? '50%' : '100%', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="border-r border-zinc-800 flex flex-col bg-zinc-950 min-h-0 overflow-hidden"
            >
              <div className="px-4 py-2 bg-zinc-900/30 border-b border-zinc-800 flex items-center gap-2 shrink-0">
                <Code className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Source Code</span>
              </div>
              <div className="flex-1 overflow-auto p-4 font-mono text-sm text-zinc-300 custom-scrollbar min-h-0">
                <pre className="whitespace-pre-wrap break-words">{code}</pre>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Preview Side (HTML/JS/TS/React) */}
        {(language === 'html' || language === 'javascript' || language === 'typescript' || language === 'react') && (viewMode === 'preview' || viewMode === 'split') && (
          <div className={`flex flex-col bg-white transition-all duration-300 ${viewMode === 'split' ? 'w-1/2' : 'w-full'}`}>
            <div className="px-4 py-2 bg-zinc-100 border-b border-zinc-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Play className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Live Preview</span>
              </div>
            </div>
            <div className="flex-1 relative flex flex-col">
              <div className="flex-1 relative">
                <iframe
                  srcDoc={srcDoc}
                  title="preview"
                  sandbox="allow-scripts"
                  frameBorder="0"
                  width="100%"
                  height="100%"
                  className="bg-white"
                />
              </div>
              
              {/* Console Overlay */}
              <AnimatePresence>
                {showConsole && (
                  <motion.div 
                    initial={{ height: 0 }}
                    animate={{ height: '35%' }}
                    exit={{ height: 0 }}
                    className="bg-zinc-950 border-t border-zinc-800 flex flex-col overflow-hidden"
                  >
                    <div className="px-4 py-2 bg-zinc-900/80 border-b border-zinc-800 flex items-center justify-between shrink-0">
                      <div className="flex items-center gap-2">
                        <Terminal className="w-3.5 h-3.5 text-zinc-500" />
                        <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Console Output</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={clearLogs}
                          className="p-1 hover:bg-zinc-800 rounded text-zinc-500 hover:text-zinc-300 transition-colors"
                          title="Clear Console"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                    <div 
                      ref={consoleRef}
                      className="flex-1 overflow-y-auto p-2 font-mono text-[11px] space-y-1 custom-scrollbar"
                    >
                      {logs.length === 0 ? (
                        <div className="h-full flex items-center justify-center text-zinc-600 italic">
                          No console output
                        </div>
                      ) : (
                        logs.map((log, i) => (
                          <div key={i} className={`flex gap-2 p-1.5 rounded ${
                            log.type === 'error' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 
                            log.type === 'warn' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' : 
                            'text-zinc-300'
                          }`}>
                            <span className="shrink-0 opacity-50">[{new Date(log.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}]</span>
                            <span className="flex-1 break-words">{log.content}</span>
                            {log.type === 'error' && onFixError && (
                              <button 
                                onClick={() => onFixError(log.content, code)}
                                className="shrink-0 flex items-center gap-1 px-2 py-0.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded text-[9px] font-bold uppercase tracking-wider transition-colors border border-red-500/30"
                              >
                                <Wand2 className="w-3 h-3" />
                                Fix with AI
                              </button>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        )}

        {/* Python Preview Side */}
        {language === 'python' && (viewMode === 'preview' || viewMode === 'split') && (
          <div className={`flex flex-col bg-zinc-950 transition-all duration-300 ${viewMode === 'split' ? 'w-1/2' : 'w-full'}`}>
            <div className="px-4 py-2 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Play className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Python Output</span>
              </div>
              <button 
                onClick={handleRunPython}
                disabled={isRunningPython}
                className="flex items-center gap-2 px-3 py-1 bg-primary text-primary-foreground rounded-lg text-[10px] font-bold uppercase tracking-widest disabled:opacity-50"
              >
                {isRunningPython ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
                Run Code
              </button>
            </div>
            <div className="flex-1 flex flex-col min-h-0">
              <div className="flex-1 overflow-auto p-6 font-mono text-xs custom-scrollbar">
                {isRunningPython ? (
                  <div className="h-full flex flex-col items-center justify-center space-y-4 text-zinc-500">
                    <RefreshCw className="w-8 h-8 animate-spin" />
                    <span className="font-bold uppercase tracking-[0.2em]">Executing Python...</span>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* GUI/Canvas Output for Pygame/Interactive */}
                    <div 
                      id="python-canvas-container" 
                      className="bg-black rounded-xl border border-zinc-800 overflow-hidden flex items-center justify-center min-h-[300px] relative transition-all"
                      style={{ display: 'none' }}
                    >
                      <canvas id="canvas" className="max-w-full h-auto"></canvas>
                    </div>

                    {pythonOutput ? (
                      <>
                        {pythonOutput.plot && (
                          <div className="bg-white p-4 rounded-xl border border-zinc-800 flex justify-center">
                            <img src={pythonOutput.plot} alt="Plot" className="max-w-full h-auto" referrerPolicy="no-referrer" />
                          </div>
                        )}
                        {pythonOutput.stdout && (
                          <div className="space-y-2">
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <Terminal className="w-3 h-3 text-zinc-500" />
                                <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-[0.2em]">Standard Output</span>
                              </div>
                              {pythonOutput.stdout.startsWith('Python Error:') && onFixError && (
                                <button 
                                  onClick={() => onFixError(pythonOutput.stdout, code)}
                                  className="flex items-center gap-1.5 px-2 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-md text-[9px] font-bold uppercase tracking-widest border border-red-500/20 transition-all hover:scale-105 active:scale-95 shadow-sm"
                                >
                                  <Wand2 className="w-3.5 h-3.5" />
                                  Fix with AI
                                </button>
                              )}
                            </div>
                            <pre className={`p-4 rounded-xl border border-zinc-800 whitespace-pre-wrap ${pythonOutput.stdout.startsWith('Python Error:') ? 'text-red-400 bg-red-400/5' : 'text-zinc-300 bg-zinc-900/50'}`}>
                              {pythonOutput.stdout}
                            </pre>
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="h-full flex items-center justify-center text-zinc-600 italic py-20">
                        Press "Run Code" to execute
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-zinc-800 bg-zinc-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Compiler Active</span>
        </div>
        <button 
          onClick={() => {
            setLogs([]);
            setSrcDoc(srcDoc + ' '); // Force refresh
          }}
          className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-[10px] font-bold text-white transition-all"
        >
          <RefreshCw className="w-3 h-3" />
          RELOAD
        </button>
      </div>
    </motion.div>
  );
};
