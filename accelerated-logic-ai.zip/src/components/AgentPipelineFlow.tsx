import React from 'react';
import { motion } from 'motion/react';
import { 
  GitBranch, 
  Code, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight,
  Zap,
  Info,
  PenTool,
  HelpCircle,
  Cpu
} from 'lucide-react';
import { AgentConfig } from '../db';
import { cn } from '../utils';

interface AgentPipelineFlowProps {
  agents: AgentConfig[];
  onSelectAgent: (agent: AgentConfig) => void;
}

export const AgentPipelineFlow: React.FC<AgentPipelineFlowProps> = ({ 
  agents, 
  onSelectAgent 
}) => {
  const activeAgents = agents.filter(a => a.enabled);

  const getAgentIcon = (id: string, name: string) => {
    const term = (id + ' ' + name).toLowerCase();
    if (term.includes('orch') || term.includes('architect') || term.includes('director')) {
      return <GitBranch className="w-4 h-4 text-indigo-400" />;
    }
    if (term.includes('coder') || term.includes('developer') || term.includes('programmer')) {
      return <Code className="w-4 h-4 text-emerald-400" />;
    }
    if (term.includes('auditor') || term.includes('security') || term.includes('reviewer') || term.includes('checker') || term.includes('editor')) {
      return <ShieldCheck className="w-4 h-4 text-amber-400" />;
    }
    if (term.includes('finalizer') || term.includes('assembler')) {
      return <Sparkles className="w-4 h-4 text-purple-400" />;
    }
    if (term.includes('writer')) {
      return <PenTool className="w-4 h-4 text-pink-400" />;
    }
    return <Cpu className="w-4 h-4 text-blue-400" />;
  };

  const getAgentTheme = (id: string, name: string) => {
    const term = (id + ' ' + name).toLowerCase();
    if (term.includes('orch') || term.includes('architect') || term.includes('director')) {
      return {
        bg: 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/20',
        glow: 'shadow-indigo-500/10',
        laserGradients: 'from-indigo-400 to-emerald-400'
      };
    }
    if (term.includes('coder') || term.includes('developer') || term.includes('programmer')) {
      return {
        bg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20',
        glow: 'shadow-emerald-500/10',
        laserGradients: 'from-emerald-400 to-amber-400'
      };
    }
    if (term.includes('auditor') || term.includes('security') || term.includes('reviewer') || term.includes('checker') || term.includes('editor')) {
      return {
        bg: 'bg-amber-500/10 border-amber-500/30 text-amber-400 hover:bg-amber-500/20',
        glow: 'shadow-amber-500/10',
        laserGradients: 'from-amber-400 to-purple-400'
      };
    }
    if (term.includes('finalizer') || term.includes('assembler')) {
      return {
        bg: 'bg-purple-500/10 border-purple-500/30 text-purple-400 hover:bg-purple-500/20',
        glow: 'shadow-purple-500/10',
        laserGradients: 'from-purple-400 to-pink-400'
      };
    }
    return {
      bg: 'bg-blue-500/10 border-blue-500/30 text-blue-400 hover:bg-blue-500/20',
      glow: 'shadow-blue-500/10',
      laserGradients: 'from-blue-400 to-indigo-400'
    };
  };

  return (
    <div className="p-5 bg-muted/20 border border-border/80 rounded-2xl relative overflow-hidden select-none space-y-4">
      {/* Dynamic Laser Animation Styles injected directly for portability */}
      <style>{`
        @keyframes laser-flow {
          0% {
            stroke-dashoffset: 24;
          }
          100% {
            stroke-dashoffset: 0;
          }
        }
        .laser-line {
          stroke-dasharray: 6 6;
          animation: laser-flow 1s linear infinite;
        }
      `}</style>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5 text-primary animate-pulse" />
          <span className="text-[10px] font-black uppercase tracking-widest text-primary">Multi-Agent Workflow Topology</span>
        </div>
        <span className="text-[9px] font-bold text-muted-foreground bg-background px-2 py-0.5 rounded border">
          {activeAgents.length} Active Nodes
        </span>
      </div>

      <div className="relative flex items-center justify-between py-6 px-4">
        {/* Visual Connecting Channels (SVG) */}
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-8 pointer-events-none z-0">
          <svg className="w-full h-full" overflow="visible">
            <defs>
              <linearGradient id="multi-agent-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#818cf8" />
                <stop offset="50%" stopColor="#34d399" />
                <stop offset="100%" stopColor="#c084fc" />
              </linearGradient>
            </defs>
            {activeAgents.length > 1 && (
              <line 
                x1="2%" 
                y1="50%" 
                x2="98%" 
                y2="50%" 
                stroke="url(#multi-agent-gradient)" 
                strokeWidth="2" 
                className="laser-line opacity-80"
              />
            )}
          </svg>
        </div>

        {/* Dynamic Node Pipeline */}
        {activeAgents.length === 0 ? (
          <div className="w-full text-center py-4 text-xs font-bold uppercase tracking-widest text-muted-foreground/60 flex items-center justify-center gap-2">
            <HelpCircle className="w-4 h-4" />
            No active nodes in collective
          </div>
        ) : (
          activeAgents.map((agent, index) => {
            const theme = getAgentTheme(agent.id, agent.name);
            const isLast = index === activeAgents.length - 1;
            
            return (
              <React.Fragment key={agent.id}>
                <motion.div 
                  whileHover={{ y: -3, scale: 1.05 }}
                  onClick={() => onSelectAgent(agent)}
                  className={cn(
                    "flex flex-col items-center gap-2 cursor-pointer relative z-10 p-3 rounded-2xl border bg-card/90 shadow-md backdrop-blur-md transition-all",
                    theme.bg,
                    theme.glow
                  )}
                  title={`Configure "${agent.name}" role`}
                >
                  {/* Glowing core indicator */}
                  <div className="absolute -top-1 right-2 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-60"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                  </div>

                  <div className="w-10 h-10 rounded-xl bg-background/50 border border-border flex items-center justify-center relative">
                    {getAgentIcon(agent.id, agent.name)}
                    <span className="absolute -bottom-1 -right-1 text-[8px] font-black bg-primary text-primary-foreground px-1 py-0.5 rounded-md leading-none shadow-sm min-w-[14px] text-center">
                      x{agent.count}
                    </span>
                  </div>

                  <div className="text-center">
                    <span className="text-[10px] font-black tracking-tight block max-w-[80px] truncate">
                      {agent.name}
                    </span>
                    <span className="text-[8px] font-semibold uppercase tracking-widest text-muted-foreground/70 leading-none">
                      {index === 0 ? 'Orch' : isLast ? 'Fin' : `Node ${index}`}
                    </span>
                  </div>
                </motion.div>

                {/* Arrow helper if not last element */}
                {!isLast && (
                  <div className="flex items-center justify-center z-10 bg-card rounded-md border border-border/80 shadow-xs h-6 w-6">
                    <ArrowRight className="w-3.5 h-3.5 text-muted-foreground animate-pulse" />
                  </div>
                )}
              </React.Fragment>
            );
          })
        )}
      </div>

      <div className="flex items-center gap-1 bg-muted/40 p-2.5 rounded-xl border border-border/40 text-[9px] text-muted-foreground leading-normal">
        <Info className="w-3 h-3 text-primary shrink-0 mt-0.5" />
        <p>
          Clicking any node open-focuses the role configuration forge immediately. Reorder physical cards below to dynamically shift sequential execution flows.
        </p>
      </div>
    </div>
  );
};
