import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Settings as SettingsIcon, 
  X, 
  Check, 
  BrainCircuit,
  Save,
  Info,
  Sparkles,
  Layout,
  Code,
  ShieldCheck,
  Zap,
  PenTool,
  FlaskConical,
  MessageSquare,
  Anchor,
  TrendingUp,
  HelpCircle,
  Code2,
  Upload,
  Loader2,
  FileText,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils';
import { SkillConfig, Settings, AppFile } from '../db';
import { Tooltip } from './Tooltip';
import { getCompletion } from '../services/llm';
import { getModelInfo } from '../models';

interface SkillsManagerProps {
  isOpen: boolean;
  onClose: () => void;
  skills: SkillConfig[];
  settings: Settings;
  onUpdateSkills: (skills: SkillConfig[]) => void;
}

const SKILL_PRESETS: Partial<SkillConfig>[] = [
  // Prompt type skills (standard skills, can parallel activate)
  {
    name: 'Frontend Architect',
    description: 'Expertise in UI components, Tailwind CSS, and polish.',
    systemPrompt: 'You are a Senior Frontend Architect. When this skill is active, you MUST prioritize using modern Tailwind CSS classes, logical component structures, and ensure high visual polish. Follow "Atomic Design" principles. Every component you suggest should be production-ready and aesthetically distinctive. Use lucid-react for icons and motion for animations.',
    type: 'prompt',
  },
  {
    name: 'Logic Debugger',
    description: 'Expertise in finding edge cases and complex debugging.',
    systemPrompt: 'You are a Debugging Specialist. When active, perform a "Step-by-Step" analysis of every logic flow. Actively look for race conditions, null pointers, and off-by-one errors. For every fix you propose, explain why the original code failed and how the new version prevents future regressions.',
    type: 'prompt',
  },
  {
    name: 'System Designer',
    description: 'Focuses on scalable architecture and database design.',
    systemPrompt: 'You are a Systems Architect. Focus on data flow, modularity, and scalability. When designing features, consider database consistency, indexing, and API lifecycle. Propose solutions that minimize technical debt and maximize future flexibility.',
    type: 'prompt',
  },
  {
    name: 'Security Shield',
    description: 'Focuses on auditing code for vulnerabilities.',
    systemPrompt: 'You are a Security Researcher. Audit every suggestion for common vulnerabilities: SQL Injection, XSS, CSRF, and broken access control. If you find a risk, highlight it clearly and provide a secure alternative. Always adhere to "Zero Trust" security principles.',
    type: 'prompt',
  },
  {
    name: 'Creative Director',
    description: 'Focuses on tone, branding, and storytelling.',
    systemPrompt: 'You are a World-Class Creative Director. Ensure all copy is engaging, consistent in tone, and aligns with high-end branding standards. Use descriptive, evocative language. Avoid clichés and prioritize unique storytelling hooks.',
    type: 'prompt',
  },

  // Persona type skills (strictly one active at a time)
  {
    name: 'Pirate Captain',
    description: 'Adopt a rowdy high-seas pirate dialect filled with nautical charm.',
    systemPrompt: 'Ahoy, matey! Adopt the persona of a salty, enthusiastic Pirate Captain. Speak in a broad pirate dialect ("Ahoy!", "Shiver me timbers!", "Aye!"), sprinkle in sailing metaphors, tall tales, and rowdy sea shanties, but always solve the requested tasks in full with a pirate spin.',
    type: 'persona',
  },
  {
    name: 'Silicon Valley VC',
    description: 'Adopt the persona of a hyped-up tech investor focused on hyper-growth.',
    systemPrompt: 'You are an ultra-hyped Silicon Valley Venture Capitalist. Adopt a tone obsessed with disruption, seed/series-A rounds, scaling to the moon, synergy, AI-first pivots, and product-market fit. Use hyped buzzwords, tell the user their idea is "absolutely legendary," and advise them on how to secure a $100M valuation.',
    type: 'persona',
  },
  {
    name: 'Socratic Philosopher',
    description: 'Adopt the persona of a Socratic thinker probing code with deep inquiry.',
    systemPrompt: 'You are a modern Socratic philosopher who treats software engineering as a search for ultimate truth. Respond with intellectual depth, calm composure, and profound inquiry. When writing code, explain the existential meaning of the functions and variables, prompting the user with thoughtful follow-up questions.',
    type: 'persona',
  },
  {
    name: 'Brutalist Minimalist',
    description: 'Speaks with radical clarity, ultra-brief explanations, and direct answers.',
    systemPrompt: 'You are an elite, minimal software purist. Never write greetings, introductory fluff, or polite summaries. Deliver pure code and raw, hyper-dense technical critiques of extreme clarity. Keep text to an absolute minimum.',
    type: 'persona',
  }
];

const getPresetIcon = (name: string) => {
  switch (name) {
    case 'Frontend Architect':
      return <Layout className="w-7 h-7 text-primary shrink-0" />;
    case 'Logic Debugger':
      return <FlaskConical className="w-7 h-7 text-primary shrink-0" />;
    case 'System Designer':
      return <Code className="w-7 h-7 text-primary shrink-0" />;
    case 'Security Shield':
      return <ShieldCheck className="w-7 h-7 text-primary shrink-0" />;
    case 'Creative Director':
      return <PenTool className="w-7 h-7 text-primary shrink-0" />;
    case 'Pirate Captain':
      return <Anchor className="w-7 h-7 text-indigo-400 shrink-0" />;
    case 'Silicon Valley VC':
      return <TrendingUp className="w-7 h-7 text-indigo-400 shrink-0" />;
    case 'Socratic Philosopher':
      return <HelpCircle className="w-7 h-7 text-indigo-400 shrink-0" />;
    case 'Brutalist Minimalist':
      return <Code2 className="w-7 h-7 text-indigo-400 shrink-0" />;
    default:
      return <BrainCircuit className="w-7 h-7 text-primary shrink-0" />;
  }
};

export const SkillsManager = ({ isOpen, onClose, skills, settings, onUpdateSkills }: SkillsManagerProps) => {
  const [editingSkill, setEditingSkill] = useState<SkillConfig | null>(null);
  const [showPresets, setShowPresets] = useState(false);
  const [isModelSelectOpen, setIsModelSelectOpen] = useState(false);
  const [isRewriting, setIsRewriting] = useState(false);

  const readSkillFile = (file: File): Promise<AppFile | null> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      const extension = file.name.split('.').pop()?.toLowerCase() || '';
      const isImage = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension);
      const isPDF = extension === 'pdf';
      const isKnownBinary = ['zip', 'tar', 'gz', 'mp3', 'wav', 'mp4', 'pdf', 'exe', 'dll'].includes(extension);

      reader.onload = (event) => {
        const content = event.target?.result as string;
        resolve({
          id: Math.random().toString(36).substring(2, 15),
          name: file.name,
          type: file.type || (isImage ? 'image/jpeg' : isPDF ? 'application/pdf' : 'text/plain'),
          content: content,
          createdAt: Date.now()
        });
      };

      if (isImage || isPDF || isKnownBinary) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    });
  };

  const handleRewriteWithAI = async (selectedModel: string) => {
    if (isRewriting) return;
    setIsRewriting(true);
    setIsModelSelectOpen(false);

    try {
      const messages = [
        {
          role: 'system',
          content: 'You are an elite prompt engineer specialized in designing hyper-effective custom system instructions/personas for AI agents.'
        },
        {
          role: 'user',
          content: `Draft context to rewrite into a polished, structured agent guidelines prompt:
Name: ${editingSkill?.name || 'Untitled Skill'}
Tagline: ${editingSkill?.description || ''}
Current Instruction Draft: ${editingSkill?.systemPrompt || ''}

Generate an incredibly robust, comprehensive, and highly precise set of system instructions for this skill/persona. Use imperative, commanding language ("You MUST...", "Always...", "Never..."). Incorporate clear formatting rules, tone standards, and instruction guardrails.

CRITICAL: Return only the final revised instruction block itself. Do NOT include any intro or outro fluff or explanations.`
        }
      ];

      const response = await getCompletion({
        messages,
        config: {},
        settings: {
          ...settings,
          puterModel: selectedModel
        },
        activeChatModel: selectedModel
      }) as any;

      const refinedText = response?.choices?.[0]?.message?.content || response?.choices?.[0]?.delta?.content || '';

      if (refinedText && editingSkill) {
        setEditingSkill({
          ...editingSkill,
          systemPrompt: refinedText.trim()
        });
      }
    } catch (err) {
      console.error("Failed to rewrite skill prompt:", err);
    } finally {
      setIsRewriting(false);
    }
  };

  const handleAddSkill = () => {
    const newSkill: SkillConfig = {
      id: crypto.randomUUID(),
      name: 'New Custom Skill',
      description: 'Describe what this behavior does...',
      systemPrompt: 'You are an expert in... When active, you should...',
      enabled: true,
      type: 'prompt'
    };
    onUpdateSkills([...skills, newSkill]);
    setEditingSkill(newSkill);
  };

  const handleAddPreset = (preset: Partial<SkillConfig>) => {
    const targetType = preset.type || 'prompt';
    const newSkill: SkillConfig = {
      id: crypto.randomUUID(),
      name: preset.name || 'New Preset',
      description: preset.description || '',
      systemPrompt: preset.systemPrompt || '',
      enabled: true,
      type: targetType
    };
    
    let updatedSkills = [...skills];
    if (targetType === 'persona') {
      // Deactivate all other personas because only one persona can be active per response
      updatedSkills = updatedSkills.map(s => 
        s.type === 'persona' ? { ...s, enabled: false } : s
      );
    }
    
    onUpdateSkills([...updatedSkills, newSkill]);
    setEditingSkill(newSkill);
    setShowPresets(false);
  };

  const handleRemoveSkill = (id: string) => {
    onUpdateSkills(skills.filter(s => s.id !== id));
    if (editingSkill?.id === id) setEditingSkill(null);
  };

  const handleToggleSkill = (id: string) => {
    const targetSkill = skills.find(s => s.id === id);
    if (!targetSkill) return;
    const targetType = targetSkill.type || 'prompt';
    const willBeEnabled = !targetSkill.enabled;

    let updatedSkills;
    if (willBeEnabled && targetType === 'persona') {
      // Mutually exclusive: disable all other personas
      updatedSkills = skills.map(s => 
        s.id === id 
          ? { ...s, enabled: true } 
          : s.type === 'persona' 
          ? { ...s, enabled: false } 
          : s
      );
    } else {
      updatedSkills = skills.map(s => s.id === id ? { ...s, enabled: willBeEnabled } : s);
    }
    onUpdateSkills(updatedSkills);
  };

  const handleSaveSkill = (updated: SkillConfig) => {
    const targetType = updated.type || 'prompt';
    let updatedSkills;
    if (updated.enabled && targetType === 'persona') {
      // Deactivate all other personas if this edited one is enabled and is type 'persona'
      updatedSkills = skills.map(s => 
        s.id === updated.id 
          ? updated 
          : s.type === 'persona' 
          ? { ...s, enabled: false } 
          : s
      );
    } else {
      updatedSkills = skills.map(s => s.id === updated.id ? updated : s);
    }
    onUpdateSkills(updatedSkills);
    setEditingSkill(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-card border border-border rounded-[2.5rem] shadow-2xl w-full max-w-5xl h-[85vh] overflow-hidden flex"
          >
            {/* Sidebar */}
            <div className="w-1/3 border-r border-border flex flex-col bg-muted/30">
              <div className="p-8 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-primary/15 flex items-center justify-center text-primary shadow-inner">
                    <BrainCircuit className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="font-black text-lg tracking-tight leading-none">Skills</h2>
                    <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mt-1 opacity-70">Extension Library</p>
                  </div>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 space-y-3 custom-scrollbar">
                {skills.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4 opacity-40">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center border-2 border-dashed border-border">
                      <Sparkles className="w-8 h-8" />
                    </div>
                    <p className="text-xs font-bold uppercase tracking-wider">No active skills</p>
                  </div>
                ) : (
                  skills.map(skill => {
                    const isPersona = skill.type === 'persona';
                    return (
                      <div 
                        key={skill.id}
                        onClick={() => { setEditingSkill(skill); setShowPresets(false); }}
                        className={cn(
                          "group p-4 rounded-3xl cursor-pointer transition-all border relative overflow-hidden",
                          editingSkill?.id === skill.id && !showPresets
                            ? "bg-primary/10 border-primary/40 shadow-sm ring-1 ring-primary/20" 
                            : "bg-background/40 border-border/50 hover:bg-background hover:border-border hover:shadow-md"
                        )}
                      >
                        {editingSkill?.id === skill.id && !showPresets && (
                          <div className="absolute top-0 left-0 w-1 h-full bg-primary" />
                        )}
                        <div className="flex items-start justify-between gap-2 mb-1.5">
                          <div className="flex flex-col min-w-0">
                            <span className={cn(
                              "text-sm font-black truncate leading-tight",
                              editingSkill?.id === skill.id && !showPresets ? "text-primary" : "text-card-foreground"
                            )}>
                              {skill.name}
                            </span>
                            <span className={cn(
                              "text-[8.5px] font-bold uppercase tracking-wider mt-1 w-max px-1.5 py-0.5 rounded border leading-none shrink-0",
                              isPersona 
                                ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" 
                                : "bg-primary/10 text-primary border-primary/20"
                            )}>
                              {isPersona ? 'Persona' : 'Prompt Skill'}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 translate-x-2 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 transition-all shrink-0">
                            <Tooltip content={skill.enabled ? "Disable globally" : "Enable globally"}>
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleToggleSkill(skill.id); }}
                                className={cn(
                                  "w-7 h-7 rounded-lg flex items-center justify-center transition-colors shadow-sm",
                                  skill.enabled ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground/30"
                                )}
                              >
                                <Check className={cn("w-4 h-4", !skill.enabled && "opacity-30")} />
                              </button>
                            </Tooltip>
                            <Tooltip content="Permanently Delete">
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleRemoveSkill(skill.id); }}
                                className="w-7 h-7 bg-destructive/10 text-destructive/60 hover:text-destructive hover:bg-destructive/20 rounded-lg flex items-center justify-center transition-colors shadow-sm"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </Tooltip>
                          </div>
                        </div>
                        <p className="text-[10px] text-muted-foreground line-clamp-1 leading-relaxed opacity-70 italic">"{skill.description}"</p>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="p-6 bg-muted/50 border-t border-border flex flex-col gap-3">
                <button 
                  onClick={() => { setShowPresets(true); setEditingSkill(null); }}
                  className="w-full flex items-center justify-center gap-2 py-3.5 bg-background border border-border text-foreground rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-muted transition-all active:scale-95"
                >
                  <Sparkles className="w-4 h-4 text-primary" />
                  Library Presets
                </button>
                <button 
                  onClick={handleAddSkill}
                  className="w-full flex items-center justify-center gap-2 py-3.5 bg-primary text-primary-foreground rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all"
                >
                  <Plus className="w-4 h-4" />
                  New Custom Skill
                </button>
              </div>
            </div>

            {/* Content area */}
            <div className="flex-1 flex flex-col bg-background relative ornament-bg">
              <div className="absolute top-6 right-8 z-20">
                <button onClick={onClose} className="p-2.5 bg-muted/50 hover:bg-muted text-muted-foreground rounded-full transition-all active:scale-90 border border-border/50">
                  <X className="w-6 h-6" />
                </button>
              </div>

              {showPresets ? (
                <div className="flex-1 p-12 overflow-y-auto custom-scrollbar">
                  <div className="max-w-2xl mx-auto space-y-10">
                    <div className="space-y-2 text-center">
                      <h3 className="text-3xl font-black tracking-tight">Skill Presets</h3>
                      <p className="text-muted-foreground">Jumpstart your agents with professional behavioral definitions.</p>
                    </div>

                    <div className="grid grid-cols-1 gap-4">
                      {SKILL_PRESETS.map((preset, idx) => {
                        const isPersona = preset.type === 'persona';
                        return (
                          <motion.div 
                            key={idx}
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.05 }}
                            onClick={() => handleAddPreset(preset)}
                            className="group p-6 bg-muted/20 border border-border/50 rounded-3xl cursor-pointer hover:bg-primary/5 hover:border-primary/30 transition-all flex items-center justify-between"
                          >
                            <div className="flex items-center gap-6">
                              <div className="w-14 h-14 rounded-2xl bg-background border border-border/50 flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm shrink-0">
                                {getPresetIcon(preset.name || '')}
                              </div>
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-black text-lg">{preset.name}</h4>
                                  <span className={cn(
                                    "text-[8px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border leading-none shrink-0",
                                    isPersona 
                                      ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" 
                                      : "bg-primary/10 text-primary border-primary/20"
                                  )}>
                                    {isPersona ? 'Persona' : 'Prompt Skill'}
                                  </span>
                                </div>
                                <p className="text-xs text-muted-foreground font-medium leading-relaxed">{preset.description}</p>
                              </div>
                            </div>
                            <Plus className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                          </motion.div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : editingSkill ? (
                <div className="flex-1 flex flex-col overflow-hidden">
                  <div className="p-10 border-b border-border bg-muted/10 flex items-end justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="text-4xl font-black tracking-tighter">Skill Forge</h3>
                        <Tooltip content="This skill acts as a global behavioral filter injected into all active agents.">
                          <Info className="w-5 h-5 text-muted-foreground/30 hover:text-primary transition-colors cursor-help" />
                        </Tooltip>
                      </div>
                      <p className="text-xs text-primary font-black uppercase tracking-[0.2em]">Architecture Node: {editingSkill.id.slice(0, 8)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1 pl-1">
                        <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mr-1">Global Toggle</label>
                      </div>
                      <button 
                        onClick={() => setEditingSkill({ ...editingSkill, enabled: !editingSkill.enabled })}
                        className={cn(
                          "flex items-center gap-2 px-4 py-2 rounded-xl border transition-all text-[10px] font-black uppercase tracking-widest",
                          editingSkill.enabled ? "bg-primary text-primary-foreground border-primary" : "bg-muted border-border text-muted-foreground"
                        )}
                      >
                        {editingSkill.enabled ? 'Enabled' : 'Disabled'}
                        <div className={cn("w-2 h-2 rounded-full", editingSkill.enabled ? "bg-white shadow-[0_0_8px_white]" : "bg-muted-foreground")} />
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-10 space-y-8 custom-scrollbar">
                    <div className="grid grid-cols-2 gap-8">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground pl-1">Public Name</label>
                        <input 
                          type="text" 
                          value={editingSkill.name}
                          onChange={(e) => setEditingSkill({ ...editingSkill, name: e.target.value })}
                          className="w-full bg-muted/40 border border-border rounded-2xl px-6 py-4 text-base focus:ring-4 focus:ring-primary/10 transition-all font-bold placeholder:opacity-30"
                          placeholder="e.g., Code Auditor"
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground pl-1">Tagline</label>
                        <input 
                          type="text" 
                          value={editingSkill.description}
                          onChange={(e) => setEditingSkill({ ...editingSkill, description: e.target.value })}
                          className="w-full bg-muted/40 border border-border rounded-2xl px-6 py-4 text-base focus:ring-4 focus:ring-primary/10 transition-all font-medium placeholder:opacity-30 italic"
                          placeholder="What does this change?"
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground pl-1">Behavior Mode / Classification</label>
                      <div className="grid grid-cols-2 gap-4">
                        <button
                          type="button"
                          onClick={() => setEditingSkill({ ...editingSkill, type: 'prompt' })}
                          className={cn(
                            "flex items-center gap-3 p-4 rounded-3xl border-2 text-left transition-all",
                            (editingSkill.type || 'prompt') === 'prompt'
                              ? "bg-primary/10 border-primary text-foreground shadow-[0_0_15px_rgba(var(--primary),0.05)]"
                              : "bg-muted/15 border-border/80 text-muted-foreground hover:bg-muted/30"
                          )}
                        >
                          <div className={cn(
                            "w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border transition-all",
                            (editingSkill.type || 'prompt') === 'prompt' ? "bg-primary/20 border-primary/20 text-primary" : "bg-muted border-transparent"
                          )}>
                            <BrainCircuit className="w-4 h-4" />
                          </div>
                          <div>
                            <span className="font-bold text-sm block">Prompt Skill</span>
                            <span className="text-[9px] font-medium opacity-70 block">Combine as many as you want in parallel</span>
                          </div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setEditingSkill({ ...editingSkill, type: 'persona' })}
                          className={cn(
                            "flex items-center gap-3 p-4 rounded-3xl border-2 text-left transition-all",
                            editingSkill.type === 'persona'
                              ? "bg-indigo-500/10 border-indigo-500 text-foreground shadow-[0_0_15px_rgba(99,102,241,0.05)]"
                              : "bg-muted/15 border-border/80 text-muted-foreground hover:bg-muted/30"
                          )}
                        >
                          <div className={cn(
                            "w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border transition-all",
                            editingSkill.type === 'persona' ? "bg-indigo-500/20 border-indigo-500/20 text-indigo-400" : "bg-muted border-transparent"
                          )}>
                            <MessageSquare className="w-4 h-4" />
                          </div>
                          <div>
                            <span className="font-bold text-sm block">Persona</span>
                            <span className="text-[9px] font-medium opacity-70 block">Exclusive tone override (max 1 active per response)</span>
                          </div>
                        </button>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between pl-1">
                        <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                          Core Logic Prompt
                          <Tooltip content="This entire block is prepended to the system prompt of every agent. Use mandatory language like 'You MUST' or 'Always'.">
                            <Zap className="w-3 h-3 text-primary animate-pulse" />
                          </Tooltip>
                        </label>
                        
                        <div className="flex items-center gap-3">
                          {/* Rewrite with AI Button */}
                          <div className="relative">
                            <button
                              type="button"
                              disabled={isRewriting}
                              onClick={() => setIsModelSelectOpen(!isModelSelectOpen)}
                              className="px-3.5 py-1.5 bg-primary/10 hover:bg-primary/20 text-primary rounded-xl font-bold text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
                            >
                              {isRewriting ? (
                                <>
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                  Rewriting...
                                </>
                              ) : (
                                <>
                                  <Sparkles className="w-3.5 h-3.5" />
                                  Rewrite with AI
                                </>
                              )}
                            </button>

                            <AnimatePresence>
                              {isModelSelectOpen && (
                                <>
                                  <div className="fixed inset-0 z-10" onClick={() => setIsModelSelectOpen(false)} />
                                  <motion.div
                                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                    animate={{ opacity: 1, y: 0, scale: 1 }}
                                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                    className="absolute right-0 mt-2 w-56 bg-background border border-border/80 shadow-2xl rounded-2xl p-2 z-20 space-y-1"
                                  >
                                    <div className="px-3 py-1.5 text-[9px] font-black uppercase tracking-widest text-muted-foreground border-b border-border/60 mb-1">
                                      Select Drafting Model
                                    </div>
                                    {(settings.enabledChatModels && settings.enabledChatModels.length > 0
                                      ? settings.enabledChatModels
                                      : ['puter:gemini-3.5-flash']
                                    ).map((equippedId) => {
                                      const { modelId, provider, catalogModel } = getModelInfo(equippedId);
                                      return (
                                        <button
                                          key={equippedId}
                                          type="button"
                                          onClick={() => handleRewriteWithAI(equippedId)}
                                          className="w-full text-left px-3 py-2 text-xs font-bold rounded-xl hover:bg-muted transition-colors flex flex-col gap-0.5 cursor-pointer"
                                        >
                                          <span className="text-foreground">{catalogModel?.name || modelId}</span>
                                          <span className="text-[8px] font-black uppercase tracking-widest text-muted-foreground">{provider}</span>
                                        </button>
                                      );
                                    })}
                                  </motion.div>
                                </>
                              )}
                            </AnimatePresence>
                          </div>

                          <div className="flex items-center gap-1">
                            <span className="text-[9px] font-black text-muted-foreground/40 uppercase tracking-tighter">Markdown Enabled</span>
                            <div className="w-1 h-1 rounded-full bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.5)]" />
                          </div>
                        </div>
                      </div>

                      <div className="relative group/editor">
                        <textarea 
                          value={editingSkill.systemPrompt}
                          onChange={(e) => setEditingSkill({ ...editingSkill, systemPrompt: e.target.value })}
                          className="w-full bg-muted/50 border-2 border-border/50 rounded-[2rem] px-8 py-8 text-sm focus:border-primary/30 focus:ring-8 focus:ring-primary/5 transition-all min-h-[220px] resize-none font-mono leading-relaxed custom-scrollbar"
                          placeholder="Define the behavior rules..."
                        />
                        <div className="absolute bottom-4 right-6 flex items-center gap-2 opacity-0 group-hover/editor:opacity-100 transition-opacity">
                          <div className="px-2 py-1 bg-background text-[8px] font-black uppercase tracking-widest border border-border rounded-md text-muted-foreground">
                            Characters: {editingSkill.systemPrompt.length}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Attached Knowledge Files */}
                    <div className="space-y-3">
                      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground flex items-center justify-between pl-1 mt-6">
                        <span>Attached Knowledge Files</span>
                        <span className="text-[8px] opacity-60">Injected persistently into reasoning contexts</span>
                      </label>

                      {/* File List */}
                      {editingSkill.attachedFiles && editingSkill.attachedFiles.length > 0 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                          {editingSkill.attachedFiles.map((file) => (
                            <div 
                              key={file.id}
                              className="flex items-center justify-between p-3 bg-muted/40 hover:bg-muted/60 border border-border/60 rounded-2xl text-xs gap-3 group/file transition-colors"
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
                                  <FileText className="w-4 h-4" />
                                </div>
                                <div className="min-w-0">
                                  <p className="font-bold truncate text-[13px]" title={file.name}>
                                    {file.name}
                                  </p>
                                  <p className="text-[9px] text-muted-foreground font-black uppercase tracking-widest mt-0.5">
                                    {(file.content.length / 1024).toFixed(1)} KB
                                  </p>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  const updatedFiles = (editingSkill.attachedFiles || []).filter(f => f.id !== file.id);
                                  setEditingSkill({ ...editingSkill, attachedFiles: updatedFiles });
                                }}
                                className="text-muted-foreground hover:text-destructive p-1.5 hover:bg-destructive/10 rounded-lg transition-colors cursor-pointer"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Drag & Drop Upload Zone */}
                      <div 
                        onDragOver={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                        }}
                        onDrop={async (e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          const droppedFiles = Array.from(e.dataTransfer.files);
                          if (droppedFiles.length > 0) {
                            const newFiles: AppFile[] = [];
                            for (const file of droppedFiles) {
                              const readData = await readSkillFile(file);
                              if (readData) newFiles.push(readData);
                            }
                            setEditingSkill({
                              ...editingSkill,
                              attachedFiles: [...(editingSkill.attachedFiles || []), ...newFiles]
                            });
                          }
                        }}
                        onClick={() => {
                          const input = document.createElement('input');
                          input.type = 'file';
                          input.multiple = true;
                          input.onchange = async (e: any) => {
                            const files = Array.from(e.target.files as FileList);
                            if (files.length > 0) {
                              const newFiles: AppFile[] = [];
                              for (const file of files) {
                                const readData = await readSkillFile(file);
                                if (readData) newFiles.push(readData);
                              }
                              setEditingSkill({
                                ...editingSkill,
                                attachedFiles: [...(editingSkill.attachedFiles || []), ...newFiles]
                              });
                            }
                          };
                          input.click();
                        }}
                        className="border-2 border-dashed border-border hover:border-primary/40 rounded-[2rem] p-8 text-center cursor-pointer hover:bg-primary/5 transition-all flex flex-col items-center justify-center gap-2 group"
                      >
                        <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-105 transition-transform">
                          <Upload className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-xs font-black uppercase tracking-wider text-foreground">
                            Drag & Drop Reference Files
                          </p>
                          <p className="text-[10px] text-muted-foreground mt-0.5 font-bold">
                            Supports text logs, schemas, references or click to browse
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-8 border-t border-border bg-muted/5 flex justify-end items-center gap-4">
                    <p className="text-[10px] text-muted-foreground font-medium italic mr-auto pl-4">Changes will take effect in the next message chain.</p>
                    <button 
                      onClick={() => setEditingSkill(null)}
                      className="px-6 py-3 bg-muted text-muted-foreground rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-muted/80 transition-all"
                    >
                      Discard
                    </button>
                    <button 
                      onClick={() => handleSaveSkill(editingSkill)}
                      className="px-10 py-3 bg-primary text-primary-foreground rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-primary/30 flex items-center gap-2 hover:translate-y-[-2px] active:translate-y-[1px] transition-all"
                    >
                      <Save className="w-4 h-4 shadow-sm" />
                      Seal Changes
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-20 space-y-8 max-w-xl mx-auto">
                  <div className="relative">
                    <div className="absolute -inset-8 bg-primary/10 rounded-full blur-[60px] animate-pulse" />
                    <div className="relative w-28 h-28 bg-background border-2 border-border/50 rounded-[3rem] flex items-center justify-center text-primary shadow-2xl scale-110">
                      <Sparkles className="w-12 h-12" />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-4xl font-black tracking-tight leading-tight">Master Skillset</h3>
                    <p className="text-base text-muted-foreground font-medium leading-relaxed">
                      Transform your AI collective by defining custom behavioral DNA. 
                      Architectural skills are injected into the reasoning core of all agents simultaneously.
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <button 
                      onClick={() => setShowPresets(true)}
                      className="flex items-center gap-3 px-8 py-4 bg-muted hover:bg-primary hover:text-primary-foreground border border-border/50 rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] transition-all hover:scale-105 active:scale-95 shadow-lg group"
                    >
                      <Layout className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                      Browse Presets
                    </button>
                    <div className="w-px h-8 bg-border opacity-50" />
                    <button 
                      onClick={handleAddSkill}
                      className="flex items-center gap-3 px-8 py-4 bg-background border-2 border-primary/20 text-primary hover:bg-primary hover:text-primary-foreground rounded-[2rem] font-black text-xs uppercase tracking-[0.2em] transition-all hover:scale-105 active:scale-95 shadow-xl"
                    >
                      <Plus className="w-5 h-5" />
                      Initial Custom
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
