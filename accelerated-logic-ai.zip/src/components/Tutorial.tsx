import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Zap, 
  Cpu, 
  Sparkles, 
  Settings as Gear,
  Cloud,
  CheckCircle2,
  Database,
  BrainCircuit,
  Key,
  Laptop
} from 'lucide-react';
import { cn } from '../utils';

interface Step {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  target?: string; // HTML element ID or class selector
  setup?: () => void;
}

interface TutorialProps {
  onComplete: () => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (open: boolean) => void;
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
  isModelOrganizerOpen: boolean;
  setIsModelOrganizerOpen: (open: boolean) => void;
}

export const Tutorial: React.FC<TutorialProps> = ({ 
  onComplete,
  isSidebarOpen,
  setIsSidebarOpen,
  isSettingsOpen,
  setIsSettingsOpen,
  isModelOrganizerOpen,
  setIsModelOrganizerOpen
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [coords, setCoords] = useState<{ x: number; y: number; width: number; height: number } | null>(null);
  const [cardHeight, setCardHeight] = useState(330);
  const cardRef = useRef<HTMLDivElement>(null);
  const scrolledStepRef = useRef<number>(-1);
  
  // Track original states, so we can restore them when user completes or closes the tour
  const originalSidebarOpenRef = useRef(isSidebarOpen);
  const originalSettingsOpenRef = useRef(isSettingsOpen);
  const originalOrganizerOpenRef = useRef(isModelOrganizerOpen);

  // ResizeObserver to dynamically detect card dimensions
  useEffect(() => {
    if (!cardRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const height = entry.target.getBoundingClientRect().height;
        if (height > 0) {
          setCardHeight(height);
        }
      }
    });
    observer.observe(cardRef.current);
    return () => observer.disconnect();
  }, [currentStep, isSettingsOpen, isModelOrganizerOpen]);

  const steps: Step[] = [
    {
      title: "Model Selection Guide",
      description: "Welcome to Accelerated Logic! Let's take a quick walk through our Model Management architecture. We will show you how to configure direct Gemini cloud models, setup integrations, or run a high-performance local AI model straight on your computer.",
      icon: <Cpu className="w-12 h-12 text-primary animate-pulse" />,
      color: "from-primary/20 to-primary/5",
      setup: () => {
        setIsSettingsOpen(false);
        setIsModelOrganizerOpen(false);
      }
    },
    {
      title: "Global Customization Settings",
      description: "This control toggles the System Settings panel. This is where you configure layout fonts, local file indexing, fact databases, and cloud backup systems.",
      icon: <Gear className="w-10 h-10 text-indigo-400" />,
      color: "from-indigo-500/20 to-indigo-500/5",
      target: "#tour-settings",
      setup: () => {
        setIsSettingsOpen(false);
        setIsModelOrganizerOpen(false);
      }
    },
    {
      title: "Model Catalog & Organizers",
      description: "When the settings panel is open, the 'AI Configuration' panel displays our specialized Model Catalog. Here you explore, download, and construct customizable connection settings to AI endpoints.",
      icon: <Sparkles className="w-10 h-10 text-purple-400" />,
      color: "from-purple-500/20 to-purple-500/5",
      target: "#tour-explore-catalog",
      setup: () => {
        setIsSettingsOpen(true);
        setIsModelOrganizerOpen(false);
      }
    },
    {
      title: "1. Puter.js (Zero Setup Cloud Proxy)",
      description: "Want immediate, zero-configuration access to multiple top-tier models? Puter.js provides a free cloud gateway proxy to popular large language models. No personal API keys or account creation required!",
      icon: <Cloud className="w-10 h-10 text-sky-400" />,
      color: "from-sky-500/20 to-sky-500/5",
      target: "#tour-provider-puter",
      setup: () => {
        setIsSettingsOpen(false);
        setIsModelOrganizerOpen(true);
      }
    },
    {
      title: "2. Direct Gemini Key (Google AI Studio)",
      description: "For highest performance and reliable long-running sessions, use direct Gemini API keys. To acquire your key, grab an API token from Google AI Studio (starting with AIzaSy... or the new AQ.Ab... format). We store keys locally using browser-side AES encryption under client security rules.",
      icon: <Key className="w-10 h-10 text-emerald-400 animate-pulse" />,
      color: "from-emerald-500/20 to-emerald-500/5",
      target: "#tour-provider-gemini",
      setup: () => {
        setIsSettingsOpen(false);
        setIsModelOrganizerOpen(true);
      }
    },
    {
      title: "3. Run Models on Your Computer (WebLLM)",
      description: "Run 100% free, offline, local AI models directly inside your browser! This runs models on your computer leveraging your workstation GPU via WebGPU. All conversations remain local on your storage hardware with zero remote server data transit.",
      icon: <Laptop className="w-10 h-10 text-violet-400" />,
      color: "from-violet-500/20 to-violet-500/5",
      target: "#tour-provider-webllm",
      setup: () => {
        setIsSettingsOpen(false);
        setIsModelOrganizerOpen(true);
      }
    },
    {
      title: "4. local Ollama Integration",
      description: "Already running large language models locally through Ollama? Equip the Ollama provider to link to your custom offline setups at http://localhost:11434 with cross-origin headers.",
      icon: <Cpu className="w-10 h-10 text-blue-400" />,
      color: "from-blue-500/20 to-blue-500/5",
      target: "#tour-provider-ollama",
      setup: () => {
        setIsSettingsOpen(false);
        setIsModelOrganizerOpen(true);
      }
    },
    {
      title: "5. OpenAI Compatible Endpoints",
      description: "Connect to any customized OpenAI proxy, corporate model gateways, OpenRouter, LM Studio, or specialized training endpoints specifying custom base URLs and parameters.",
      icon: <Zap className="w-10 h-10 text-amber-400" />,
      color: "from-amber-500/20 to-amber-500/5",
      target: "#tour-provider-openai",
      setup: () => {
        setIsSettingsOpen(false);
        setIsModelOrganizerOpen(true);
      }
    },
    {
      title: "Configuration Walkthrough Complete!",
      description: "You're ready to power your local threads! Tap the blue buttons inside the catalog at any time to add keys, download local models, or switch back and forth dynamically.",
      icon: <CheckCircle2 className="w-14 h-14 text-emerald-400 animate-bounce" />,
      color: "from-emerald-500/30 to-emerald-500/5",
      setup: () => {
        setIsSettingsOpen(false);
        setIsModelOrganizerOpen(false);
      }
    }
  ];

  // Run the setup effect immediately when step changes
  useEffect(() => {
    const step = steps[currentStep];
    if (step.setup) {
      step.setup();
    }
  }, [currentStep]);

  // Monitor DOM element target coordinates
  useEffect(() => {
    const step = steps[currentStep];
    if (!step.target) {
      setCoords(null);
      return;
    }

    const calcCoords = () => {
      const el = document.querySelector(step.target!);
      if (el) {
        const rect = el.getBoundingClientRect();
        // If element takes zero space, wait for animations or menus
        if (rect.width === 0 || rect.height === 0) {
          return;
        }
        setCoords({
          x: rect.left,
          y: rect.top,
          width: rect.width,
          height: rect.height
        });

        // Scroll target to viewport center once per step so next buttons stay accessible
        if (scrolledStepRef.current !== currentStep) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          scrolledStepRef.current = currentStep;
        }
      } else {
        setCoords(null);
      }
    };

    // Poll to match layout transition heights smoothly
    calcCoords();
    const timers = [
      setTimeout(calcCoords, 50),
      setTimeout(calcCoords, 150),
      setTimeout(calcCoords, 300),
      setTimeout(calcCoords, 500)
    ];

    window.addEventListener('resize', calcCoords);
    window.addEventListener('scroll', calcCoords, true);

    return () => {
      timers.forEach(clearTimeout);
      window.removeEventListener('resize', calcCoords);
      window.removeEventListener('scroll', calcCoords, true);
    };
  }, [currentStep, isSettingsOpen, isModelOrganizerOpen]);

  // Handle keyboard keys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'Enter') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleBack();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        handleClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentStep]);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleClose();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleClose = () => {
    setIsSettingsOpen(originalSettingsOpenRef.current);
    setIsModelOrganizerOpen(originalOrganizerOpenRef.current);
    onComplete();
  };

  const getTooltipStyles = (): React.CSSProperties => {
    if (!coords) {
      return {
        position: 'fixed',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        width: '100%',
        maxWidth: '430px',
        zIndex: 140
      };
    }

    const ww = window.innerWidth;
    const wh = window.innerHeight;
    const padding = 16;
    const cardWidth = 340;
    
    // Position tooltip below element by default, unless target resides in lower portion of the screen
    const placeAbove = (coords.y + coords.height / 2) > (wh * 0.52);
    let top = placeAbove 
      ? coords.y - padding - cardHeight 
      : coords.y + coords.height + padding;

    let left = coords.x + coords.width / 2 - cardWidth / 2;

    // Boundary constraints: ensure card never goes off top and its bottom never overflows viewport
    if (top < padding) {
      top = padding;
    }
    if (top + cardHeight > wh - padding) {
      top = wh - cardHeight - padding;
    }

    if (left < padding) left = padding;
    if (left + cardWidth > ww - padding) left = ww - cardWidth - padding;

    return {
      position: 'fixed',
      left: `${left}px`,
      top: `${top}px`,
      width: `${cardWidth}px`,
      maxWidth: `calc(100vw - ${padding * 2}px)`,
      zIndex: 140
    };
  };

  const getMaskPath = () => {
    const ww = window.innerWidth;
    const wh = window.innerHeight;
    if (!coords) return `M 0 0 H ${ww} V ${wh} H 0 Z`;

    const r = 12; // rounded cutout radius
    const pctX = coords.x - 6;
    const pctY = coords.y - 6;
    const pctW = coords.width + 12;
    const pctH = coords.height + 12;

    return `M 0 0 H ${ww} V ${wh} H 0 Z M ${pctX} ${pctY + r} a ${r} ${r} 0 0 1 ${r} -${r} h ${pctW - 2 * r} a ${r} ${r} 0 0 1 ${r} ${r} v ${pctH - 2 * r} a ${r} ${r} 0 0 1 -${r} ${r} h -${pctW - 2 * r} a ${r} ${r} 0 0 1 -${r} -${r} Z`;
  };

  return (
    <div id="tour-guide-container" className="fixed inset-0 z-[120] overflow-hidden select-none">
      {/* SVG Background Layer Mask */}
      <svg className="absolute inset-0 w-full h-full pointer-events-auto cursor-default">
        <defs>
          <radialGradient id="spotlight-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.15" />
            <stop offset="70%" stopColor="#3b82f6" stopOpacity="0.05" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>
        </defs>
        
        <path 
          d={getMaskPath()} 
          fill="rgba(11, 17, 29, 0.78)" 
          fillRule="evenodd" 
          className="transition-all duration-300 ease-out"
        />

        {coords && (
          <g transform={`translate(${coords.x - 20}, ${coords.y - 20})`}>
            <rect 
              width={coords.width + 40} 
              height={coords.height + 40} 
              rx={16} 
              fill="url(#spotlight-glow)" 
              className="animate-pulse"
            />
          </g>
        )}
      </svg>

      {/* Beacon */}
      <AnimatePresence>
        {coords && (
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            style={{ 
              position: 'fixed',
              left: `${coords.x + coords.width / 2}px`,
              top: `${coords.y + coords.height / 2}px`,
              transform: 'translate(-50%, -50%)',
              zIndex: 135
            }}
            className="pointer-events-none"
          >
            <div className="relative flex h-10 w-10 items-center justify-center">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary/40 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-primary border-2 border-white shadow-md"></span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tutorial Tooltip Card */}
      <div 
        style={getTooltipStyles()} 
        className="transition-all duration-300 ease-out p-1 font-sans"
      >
        <motion.div 
          ref={cardRef}
          key={currentStep}
          initial={{ opacity: 0, scale: 0.96, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          className="relative flex flex-col max-h-[calc(100vh-32px)] bg-slate-900/95 dark:bg-zinc-950/98 border border-slate-800/80 rounded-3xl shadow-2xl overflow-hidden backdrop-blur-xl"
        >
          {/* Close / Skip button */}
          <button 
            type="button"
            onClick={handleClose}
            className="absolute top-4 right-4 p-1.5 bg-slate-800/40 hover:bg-slate-800/80 border border-slate-700/20 text-slate-400 hover:text-white rounded-full transition-colors z-20 cursor-pointer"
            title="Skip Tour"
          >
            <X className="w-3.5 h-3.5" />
          </button>

          {/* Top Banner Gradient Area */}
          <div className={cn("p-6 pb-4 flex flex-col items-center text-center bg-gradient-to-b border-b border-slate-800/20 shrink-0", steps[currentStep].color)}>
            <div className="p-4 bg-slate-950/85 border border-slate-800/80 rounded-2xl shadow-lg mb-4">
              {steps[currentStep].icon}
            </div>

            <span className="text-[9px] font-black tracking-widest text-primary uppercase mb-1 bg-primary/15 px-2.5 py-0.5 rounded-full border border-primary/20">
              Guidance Module • Step {currentStep + 1} of {steps.length}
            </span>

            <h3 className="text-base font-extrabold text-slate-50 tracking-tight leading-tight">
              {steps[currentStep].title}
            </h3>
          </div>

          {/* Body content */}
          <div className="p-5 px-6 min-h-[110px] flex items-center justify-center overflow-y-auto custom-scrollbar">
            <p className="text-xs text-slate-300/90 leading-relaxed text-center font-medium">
              {steps[currentStep].description}
            </p>
          </div>

          {/* Footer Area */}
          <div className="p-4 bg-slate-950/50 border-t border-slate-850/50 flex items-center justify-between shrink-0">
            {/* Step Indicators */}
            <div className="flex gap-1">
              {steps.map((_, idx) => (
                <div 
                  key={idx}
                  onClick={() => setCurrentStep(idx)}
                  className={cn(
                    "h-1.5 rounded-full cursor-pointer transition-all duration-300",
                    idx === currentStep ? "w-5 bg-primary" : "w-1.5 bg-slate-700 hover:bg-slate-500"
                  )}
                  title={`Go to step ${idx + 1}`}
                />
              ))}
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center gap-1.5">
              {currentStep > 0 && (
                <button 
                  type="button"
                  onClick={handleBack}
                  className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800/30 border border-transparent hover:border-slate-800 rounded-xl transition-all cursor-pointer"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  Back
                </button>
              )}
              <button 
                type="button"
                onClick={handleNext}
                className="flex items-center gap-1 px-4 py-2 bg-primary text-primary-foreground font-black text-xs rounded-xl shadow-md shadow-primary/10 hover:shadow-primary/25 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
              >
                {currentStep === steps.length - 1 ? "Finish Guide" : "Next"}
                {currentStep < steps.length - 1 && <ChevronRight className="w-3.5 h-3.5 text-primary-foreground" />}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
