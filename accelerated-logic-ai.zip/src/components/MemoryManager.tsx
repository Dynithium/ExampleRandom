import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  X, 
  Check, 
  Brain,
  Info,
  Sparkles,
  Search,
  Eye,
  EyeOff,
  Edit3,
  Calendar,
  Save,
  Tag
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils';
import { Memory, getAllMemories, saveMemory, deleteMemory, clearAllMemories } from '../db';
import { Tooltip } from './Tooltip';

interface MemoryManagerProps {
  isOpen: boolean;
  onClose: () => void;
  autoMemoryEnabled: boolean;
  onToggleAutoMemory: (enabled: boolean) => void;
  onMemoriesChanged?: () => void;
}

const CATEGORIES = [
  { id: 'all', name: 'All Memories', color: 'text-primary bg-primary/10' },
  { id: 'preferences', name: 'Preferences', color: 'text-blue-500 bg-blue-500/10' },
  { id: 'personal', name: 'Personal', color: 'text-emerald-500 bg-emerald-500/10' },
  { id: 'project', name: 'Projects', color: 'text-amber-500 bg-amber-500/10' },
  { id: 'general', name: 'General', color: 'text-purple-500 bg-purple-500/10' }
] as const;

const PRESET_TEMPLATES = [
  { text: "Prefers TypeScript, React, and Tailwind CSS for full-stack build files.", label: "Default Stack", category: "preferences" },
  { text: "User prefers elegant, eye-comfortable high-contrast light mode with Inter typography.", label: "Aesthetics", category: "preferences" },
  { text: "Current user is a Senior Developer specializing in highly interactive web interfaces.", label: "Developer Role", category: "personal" },
  { text: "This workspace is a premium multi-agent orchestrator powered by Gemini models.", label: "Architecture", category: "project" }
];

export const MemoryManager = ({ 
  isOpen, 
  onClose, 
  autoMemoryEnabled, 
  onToggleAutoMemory,
  onMemoriesChanged
}: MemoryManagerProps) => {
  const [memories, setMemories] = useState<Memory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<'preferences' | 'personal' | 'project' | 'general'>('general');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [editingCategory, setEditingCategory] = useState<'preferences' | 'personal' | 'project' | 'general'>('general');
  const [confirmWipe, setConfirmWipe] = useState(false);

  // Load memories from database
  const loadMemories = async () => {
    const data = await getAllMemories();
    // Sort youngest first
    setMemories(data.sort((a, b) => b.createdAt - a.createdAt));
  };

  useEffect(() => {
    if (isOpen) {
      loadMemories();
    }
  }, [isOpen]);

  const handleAddMemory = async () => {
    const trimmed = newContent.trim();
    if (!trimmed) return;

    const newMemory: Memory = {
      id: crypto.randomUUID(),
      content: trimmed,
      category: newCategory,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isActive: true
    };

    await saveMemory(newMemory);
    setNewContent('');
    setIsAdding(false);
    loadMemories();
    onMemoriesChanged?.();
  };

  const handleToggleActive = async (memory: Memory) => {
    const updated = { ...memory, isActive: !memory.isActive, updatedAt: Date.now() };
    await saveMemory(updated);
    loadMemories();
    onMemoriesChanged?.();
  };

  const handleSaveEdit = async (memory: Memory) => {
    const trimmed = editingContent.trim();
    if (!trimmed) return;

    const updated = { ...memory, content: trimmed, category: editingCategory, updatedAt: Date.now() };
    await saveMemory(updated);
    setEditingId(null);
    setEditingContent('');
    loadMemories();
    onMemoriesChanged?.();
  };

  const handleDelete = async (id: string) => {
    await deleteMemory(id);
    loadMemories();
    onMemoriesChanged?.();
  };

  // Filter memories
  const filteredMemories = memories.filter(memory => {
    const matchesCategory = selectedCategory === 'all' || memory.category === selectedCategory;
    const matchesSearch = memory.content.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (memory.category || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-card border border-border rounded-[2.5rem] shadow-2xl w-full max-w-5xl h-[85vh] overflow-hidden flex"
          >
            {/* Sidebar section */}
            <div className="w-1/3 border-r border-border flex flex-col bg-muted/30">
              <div className="p-8 border-b border-border flex flex-col gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-secondary/20 border border-primary/20 flex items-center justify-center text-primary shadow-inner">
                    <Brain className="w-6 h-6 animate-pulse text-primary" />
                  </div>
                  <div>
                    <h2 className="font-black text-lg tracking-tight leading-none">Memory Base</h2>
                    <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest mt-1 opacity-70">Cross-Chat Continuity</p>
                  </div>
                </div>
              </div>

              {/* Memory Search */}
              <div className="px-6 py-4 border-b border-border bg-muted/10">
                <div className="relative">
                  <Search className="w-4 h-4 text-muted-foreground/60 absolute left-3 top-3" />
                  <input 
                    type="text"
                    placeholder="Search memories..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-background border border-border/80 rounded-xl pl-9 pr-4 py-2 text-xs focus:outline-none focus:ring-1 focus:ring-primary font-medium"
                  />
                  {searchQuery && (
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-2.5 p-0.5 rounded-full hover:bg-muted text-muted-foreground"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>

              {/* Category selector */}
              <div className="flex-1 overflow-y-auto p-6 space-y-2.5 custom-scrollbar">
                <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground px-2 block">Categories</span>
                {CATEGORIES.map(category => {
                  const count = category.id === 'all' 
                    ? memories.length 
                    : memories.filter(m => m.category === category.id).length;

                  return (
                    <button 
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={cn(
                        "w-full flex items-center justify-between px-3 py-3 rounded-2xl text-xs font-bold transition-all border",
                        selectedCategory === category.id
                          ? "bg-primary text-primary-foreground border-primary shadow-md"
                          : "bg-background/40 hover:bg-background/80 border-border/40 text-foreground"
                      )}
                    >
                      <span className="flex items-center gap-2">
                        <span className={cn(
                          "w-2 h-2 rounded-full",
                          selectedCategory === category.id ? "bg-white shadow-[0_0_8px_white]" : 
                            category.id === 'preferences' ? 'bg-blue-500' :
                            category.id === 'personal' ? 'bg-emerald-500' :
                            category.id === 'project' ? 'bg-amber-500' :
                            category.id === 'general' ? 'bg-purple-500' : 'bg-primary'
                        )} />
                        {category.name}
                      </span>
                      <span className={cn(
                        "text-[9px] px-2 py-0.5 rounded-full font-bold",
                        selectedCategory === category.id ? "bg-white/20 text-white" : "bg-muted text-muted-foreground"
                      )}>
                        {count}
                      </span>
                    </button>
                  );
                })}

                <div className="pt-4 border-t border-border/40 px-2 mt-4">
                  {confirmWipe ? (
                    <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-2xl text-center space-y-2">
                      <p className="text-[10px] text-destructive font-black uppercase tracking-wider leading-tight">Are you absolutely sure?</p>
                      <div className="flex gap-2 justify-center">
                        <button 
                          onClick={async () => {
                            await clearAllMemories();
                            setConfirmWipe(false);
                            loadMemories();
                            onMemoriesChanged?.();
                          }}
                          className="px-2.5 py-1.5 bg-destructive hover:bg-destructive/90 text-white rounded-xl text-[10px] font-black uppercase tracking-wider cursor-pointer transition-colors"
                        >
                          Yes, Wipe
                        </button>
                        <button 
                          onClick={() => setConfirmWipe(false)}
                          className="px-2.5 py-1.5 bg-muted hover:bg-muted/80 text-foreground rounded-xl text-[10px] font-bold uppercase tracking-wider cursor-pointer transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setConfirmWipe(true)}
                      className="w-full flex items-center justify-center gap-1.5 py-2.5 bg-destructive/10 hover:bg-destructive/20 text-destructive text-[10px] font-bold uppercase tracking-widest rounded-xl border border-destructive/20 transition-all cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Wipe Memory
                    </button>
                  )}
                </div>
              </div>

              {/* Bottom toggles for Auto Memory extraction */}
              <div className="p-6 bg-muted/50 border-t border-border space-y-4">
                <div className="p-4 bg-background border border-border rounded-2xl flex items-center justify-between gap-3 shadow-inner">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider block">Auto-Save Facts</span>
                    <p className="text-[9px] text-muted-foreground leading-relaxed">Automatically save facts and preferences from your chats.</p>
                  </div>
                  <button 
                    onClick={() => onToggleAutoMemory(!autoMemoryEnabled)}
                    className={cn(
                      "w-10 h-6 rounded-full p-1 transition-all shrink-0 duration-300",
                      autoMemoryEnabled ? "bg-primary" : "bg-muted-foreground/30"
                    )}
                  >
                    <div className={cn(
                      "w-4 h-4 rounded-full bg-white shadow-md transition-all duration-300 transform",
                      autoMemoryEnabled ? "translate-x-4" : "translate-x-0"
                    )} />
                  </button>
                </div>

                <button 
                  onClick={() => setIsAdding(true)}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-primary text-primary-foreground rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all"
                >
                  <Plus className="w-4 h-4" />
                  Manual Entry
                </button>
              </div>
            </div>

            {/* Content area */}
            <div className="flex-1 flex flex-col bg-background relative ornament-bg">
              <div className="absolute top-6 right-8 z-20">
                <button onClick={onClose} className="p-2.5 bg-muted/50 hover:bg-muted text-muted-foreground rounded-full transition-all active:scale-90 border border-border/50">
                  <X className="w-6 h-6" />
                </button>
              </div>

              {isAdding ? (
                // Add Memory form
                <div className="flex-1 p-12 overflow-y-auto custom-scrollbar flex flex-col justify-center max-w-2xl mx-auto w-full space-y-8">
                  <div className="space-y-2 text-center">
                    <div className="w-16 h-16 rounded-[1.5rem] bg-primary/10 flex items-center justify-center text-primary mx-auto border border-primary/20 shadow-inner mb-2">
                      <Sparkles className="w-8 h-8 text-primary animate-pulse" />
                    </div>
                    <h3 className="text-3xl font-black tracking-tight">Add Custom Memory</h3>
                    <p className="text-muted-foreground">Save a custom key fact, preference, or reference detail for the assistant to recall.</p>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-2.5">
                      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground block pl-1">Category Classification</label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {CATEGORIES.filter(c => c.id !== 'all').map(cat => (
                          <button
                            key={cat.id}
                            type="button"
                            onClick={() => setNewCategory(cat.id as any)}
                            className={cn(
                              "py-3 px-2 text-center rounded-xl text-[10px] font-bold uppercase border transition-all",
                              newCategory === cat.id 
                                ? "bg-primary border-primary text-primary-foreground shadow-sm"
                                : "bg-muted/30 border-border/60 text-muted-foreground hover:bg-muted"
                            )}
                          >
                            {cat.name}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground block pl-1">Memory Phrase</label>
                      <textarea
                        value={newContent}
                        onChange={(e) => setNewContent(e.target.value)}
                        placeholder="e.g., User lives in New York and works in TypeScript full stack codebases, preferring dark visual layouts..."
                        rows={5}
                        className="w-full bg-muted/40 border border-border rounded-2xl px-5 py-4 text-sm focus:outline-none focus:ring-1 focus:ring-primary font-medium placeholder:opacity-40"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-3.5 pt-4">
                    <button 
                      onClick={() => { setIsAdding(false); setNewContent(''); }}
                      className="px-6 py-3 bg-muted text-muted-foreground rounded-xl font-bold text-xs uppercase tracking-wider hover:bg-muted/80 transition-all"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleAddMemory}
                      disabled={!newContent.trim()}
                      className="px-8 py-3 bg-primary text-primary-foreground rounded-xl font-black text-xs uppercase tracking-widest disabled:opacity-50 hover:scale-[1.02] active:scale-95 transition-all cursor-pointer shadow-lg shadow-primary/20"
                    >
                      Etch Memory
                    </button>
                  </div>
                </div>
              ) : (
                // Memories list
                <div className="flex-1 flex flex-col overflow-y-auto custom-scrollbar">
                  <div className="p-10 border-b border-border bg-muted/10 flex items-end justify-between shrink-0">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h3 className="text-4xl font-black tracking-tighter flex items-center gap-2">Memory</h3>
                      </div>
                      <p className="text-xs text-primary font-black uppercase tracking-[0.2em]">Saved facts & preferences</p>
                    </div>

                    <div className="px-5 py-2.5 bg-muted/50 rounded-2xl border border-border/80 flex items-center gap-2">
                      <div className={cn("w-2.5 h-2.5 rounded-full animate-pulse", autoMemoryEnabled ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-neutral-500")} />
                      <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                        {autoMemoryEnabled ? "Auto-Reflect Active" : "Auto-Reflect Standby"}
                      </span>
                    </div>
                  </div>

                  {/* List content */}
                  <div className="p-10 space-y-4 flex-1 flex flex-col">
                    {filteredMemories.length === 0 ? (
                      <div className="flex-1 flex flex-col items-center justify-center text-center p-12 space-y-5 max-w-sm mx-auto min-h-[350px]">
                        <div className="relative">
                          <div className="absolute -inset-6 bg-primary/10 rounded-full blur-[40px] animate-pulse" />
                          <div className="relative w-20 h-20 bg-background border border-border/60 rounded-[2rem] flex items-center justify-center text-primary/40 shadow-xl">
                            <Brain className="w-10 h-10" />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <h4 className="text-base font-black tracking-tight">Empty Memory Space</h4>
                          <p className="text-xs text-muted-foreground leading-relaxed">
                            {searchQuery 
                              ? "No memories matched your search criteria. Try a different query." 
                              : "No memories found in this category. As you chat, the AI will build a knowledge graph, or you can add manual facts anytime!"}
                          </p>
                        </div>
                        {!searchQuery && !isAdding && (
                          <div className="w-full space-y-4 pt-4 border-t border-border/50 text-left">
                            <span className="text-[10px] font-black uppercase tracking-widest text-primary block text-center">💡 Quick-Seed Suggested Templates</span>
                            <div className="grid grid-cols-1 gap-2 max-w-md mx-auto">
                              {PRESET_TEMPLATES.map((tpl, idx) => (
                                <button
                                  key={idx}
                                  onClick={async () => {
                                    const seedMemory: Memory = {
                                      id: crypto.randomUUID(),
                                      content: tpl.text,
                                      category: tpl.category as any,
                                      createdAt: Date.now(),
                                      updatedAt: Date.now(),
                                      isActive: true
                                    };
                                    await saveMemory(seedMemory);
                                    loadMemories();
                                    onMemoriesChanged?.();
                                  }}
                                  className="w-full p-3 bg-muted/30 hover:bg-primary/5 hover:text-primary hover:border-primary/20 border border-border/50 rounded-xl text-left transition-all group flex flex-col gap-1 cursor-pointer select-none"
                                >
                                  <div className="flex items-center justify-between">
                                    <span className="text-[8px] font-black uppercase tracking-wider text-muted-foreground group-hover:text-primary transition-colors">
                                      {tpl.label} • {tpl.category}
                                    </span>
                                    <Plus className="w-3 h-3 text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                                  </div>
                                  <p className="text-[11px] font-semibold text-foreground/80 leading-snug line-clamp-2">{tpl.text}</p>
                                </button>
                              ))}
                            </div>
                            
                            <div className="flex justify-center pt-2">
                              <button 
                                onClick={() => setIsAdding(true)}
                                className="flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-xl text-xs font-bold uppercase tracking-wider shadow-md hover:scale-[1.02] active:scale-95 transition-all cursor-pointer"
                              >
                                <Plus className="w-3.5 h-3.5" /> Manual Entry
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 gap-3">
                        {filteredMemories.map(memory => {
                          const isEditing = editingId === memory.id;
                          return (
                            <div 
                              key={memory.id}
                              className={cn(
                                "group p-5 bg-muted/15 border border-border/50 rounded-2xl flex items-start gap-4 transition-all relative overflow-hidden",
                                !memory.isActive && "opacity-50 hover:opacity-75"
                              )}
                            >
                              <div className="flex flex-col items-center gap-1.5 shrink-0 pt-0.5">
                                <span className={cn(
                                  "text-[8px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border leading-none shrink-0 block",
                                  memory.category === 'preferences' ? 'bg-blue-500/10 text-blue-500 border-blue-500/20' :
                                    memory.category === 'personal' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' :
                                    memory.category === 'project' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                                    'bg-purple-500/10 text-purple-500 border-purple-500/20'
                                )}>
                                  {memory.category || 'general'}
                                </span>
                              </div>

                              <div className="flex-1 min-w-0 pr-4">
                                {isEditing ? (
                                  <div className="flex flex-col gap-2.5">
                                    <div className="flex items-center gap-2">
                                      <input 
                                        type="text"
                                        value={editingContent}
                                        onChange={(e) => setEditingContent(e.target.value)}
                                        className="flex-1 bg-background border border-border rounded-xl px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary font-medium"
                                        onKeyDown={(e) => {
                                          if (e.key === 'Enter') handleSaveEdit(memory);
                                        }}
                                      />
                                      <button 
                                        onClick={() => handleSaveEdit(memory)}
                                        className="p-1.5 bg-primary text-primary-foreground rounded-lg hover:bg-primary/95 shadow-sm shrink-0 cursor-pointer"
                                      >
                                        <Check className="w-4 h-4" />
                                      </button>
                                      <button 
                                        onClick={() => { setEditingId(null); setEditingContent(''); }}
                                        className="p-1.5 bg-muted text-muted-foreground rounded-lg hover:bg-muted/80 shrink-0 cursor-pointer"
                                      >
                                        <X className="w-4 h-4" />
                                      </button>
                                    </div>
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      <span className="text-[10px] font-black uppercase tracking-wider text-muted-foreground mr-1 opacity-75">Classification:</span>
                                      {CATEGORIES.filter(c => c.id !== 'all').map(cat => (
                                        <button
                                          key={cat.id}
                                          type="button"
                                          onClick={() => setEditingCategory(cat.id as any)}
                                          className={cn(
                                            "px-2.5 py-1 rounded-full text-[9px] font-bold uppercase border transition-all cursor-pointer",
                                            editingCategory === cat.id
                                              ? "bg-primary text-primary-foreground border-primary"
                                              : "bg-muted text-muted-foreground border-border/55 hover:bg-muted"
                                          )}
                                        >
                                          {cat.name}
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                ) : (
                                  <p className="text-sm font-semibold leading-relaxed text-card-foreground">
                                    {memory.content}
                                  </p>
                                )}

                                <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground font-semibold leading-none opacity-60">
                                  <span className="flex items-center gap-1">
                                    <Calendar className="w-3 h-3" />
                                    {new Date(memory.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                                  </span>
                                </div>
                              </div>

                              {/* Controls */}
                              <div className="flex items-center gap-1 shrink-0 relative z-10">
                                <Tooltip content={memory.isActive ? "Ignore this memory" : "Include this memory"}>
                                  <button 
                                    onClick={() => handleToggleActive(memory)}
                                    className={cn(
                                      "p-2 rounded-xl border transition-all shadow-inner",
                                      memory.isActive ? "bg-primary/10 text-primary border-primary/20" : "bg-muted text-muted-foreground/40 border-transparent"
                                    )}
                                  >
                                    {memory.isActive ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                                  </button>
                                </Tooltip>

                                {!isEditing && (
                                  <Tooltip content="Edit Memory Text">
                                    <button 
                                      onClick={() => {
                                        setEditingId(memory.id);
                                        setEditingContent(memory.content);
                                        setEditingCategory(memory.category || 'general');
                                      }}
                                      className="p-2 hover:bg-background/80 hover:text-primary transition-all rounded-xl border border-transparent hover:border-border/30 text-muted-foreground"
                                    >
                                      <Edit3 className="w-4 h-4" />
                                    </button>
                                  </Tooltip>
                                )}

                                <Tooltip content="Permanently Delete">
                                  <button 
                                    onClick={() => handleDelete(memory.id)}
                                    className="p-2 bg-destructive/10 text-destructive/60 hover:text-destructive hover:bg-destructive/20 rounded-xl flex items-center justify-center transition-all shadow-sm"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </Tooltip>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
