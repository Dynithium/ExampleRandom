if (typeof self !== "undefined" && self.navigator && (self.navigator as any).gpu) {
  const gpu = (self.navigator as any).gpu;
  const original = gpu.requestAdapter.bind(gpu);
  gpu.requestAdapter = (opts?: any) => original({ ...opts, powerPreference: "high-performance" });
}
