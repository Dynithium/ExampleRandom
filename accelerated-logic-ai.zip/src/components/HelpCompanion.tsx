import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CircleHelp, 
  Search, 
  X, 
  ChevronDown, 
  ChevronUp, 
  BookOpen, 
  Sparkles, 
  Cpu, 
  Info,
  Lightbulb,
  ArrowUpRight
} from 'lucide-react';
import { HELP_QA_ITEMS, FAQItem } from '../data/helpData';

export const HelpCompanion: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedId, setExpandedId] = useState<number | null>(null);

  // Close the companion, clear state
  const handleClose = () => {
    setIsOpen(false);
    setSearchQuery('');
    setSelectedCategory('All');
    setExpandedId(null);
  };

  const categories = ['All', 'Getting Started', 'Models & Workflow', 'Features & Storage', 'Troubleshooting'];

  // Filter the FAQ items according to category and search query
  const filteredFAQs = useMemo(() => {
    return HELP_QA_ITEMS.filter((item) => {
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const cleanQuery = searchQuery.trim().toLowerCase();
      if (!cleanQuery) return matchesCategory;

      const matchesText = 
        item.question.toLowerCase().includes(cleanQuery) || 
        item.answer.toLowerCase().includes(cleanQuery) || 
        item.category.toLowerCase().includes(cleanQuery);
        
      return matchesCategory && matchesText;
    });
  }, [selectedCategory, searchQuery]);

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <>
      {/* Floating launcher question mark button in bottom-right corner */}
      <div className="fixed bottom-6 right-6 z-[170]">
        <motion.button
          id="help-companion-launcher"
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center justify-center p-3.5 rounded-full shadow-2xl transition-all cursor-pointer border focus:outline-none ${
            isOpen 
              ? 'bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/25' 
              : 'bg-slate-900 border-indigo-500/30 text-indigo-400 hover:text-white hover:border-indigo-500/70 hover:shadow-[0_0_15px_rgba(99,102,241,0.4)]'
          }`}
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.95 }}
          title="Open Help & FAQ Guide"
        >
          {isOpen ? (
            <X className="w-5 h-5 animate-in fade-in zoom-in duration-300" />
          ) : (
            <div className="relative">
              <CircleHelp className="w-5.5 h-5.5" />
              {/* Pulsing indicator dot */}
              <span className="absolute -top-1.5 -right-1.5 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-500"></span>
              </span>
            </div>
          )}
        </motion.button>
      </div>

      {/* Flyout Searchable Companion Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="help-companion-panel"
            initial={{ opacity: 0, scale: 0.95, y: 30, x: 0 }}
            animate={{ opacity: 1, scale: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 30, x: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="fixed bottom-22 right-6 z-[165] w-[380px] max-w-[calc(100vw-2rem)] h-[550px] bg-slate-950/95 border border-slate-800 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.6)] backdrop-blur-xl flex flex-col overflow-hidden text-slate-100 animate-in zoom-in-95 duration-200"
          >
            {/* Header section with gradient backdrop */}
            <div className="relative p-5 border-b border-slate-800/80 bg-gradient-to-r from-indigo-950/30 via-slate-950 to-slate-950">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl">
                    <Sparkles className="w-4.5 h-4.5 animate-pulse" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                      Help & Guide Center
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Learn how to manage sandboxes & AI models
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleClose}
                  className="p-1 hover:bg-slate-800 border border-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Dynamic Progress/Stat Counter */}
              <div className="mt-4 flex items-center justify-between text-[11px] text-slate-500 bg-slate-900/50 px-3 py-1.5 rounded-xl border border-slate-800/50">
                <span className="flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-400/80" />
                  20 Structured Guide Cards
                </span>
                <span className="text-indigo-400 font-semibold bg-indigo-500/10 px-1.5 py-0.5 rounded-md border border-indigo-500/10">
                  Search Active
                </span>
              </div>
            </div>

            {/* Filter Search Input Area */}
            <div className="p-4 bg-slate-950 border-b border-slate-900 flex flex-col gap-3">
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search questions or features (e.g. speech, sandbox)..."
                  className="w-full pl-10 pr-9 py-2 bg-slate-900/80 text-sm text-slate-100 placeholder-slate-500 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/20 hover:border-slate-700 transition-all font-sans"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-500 hover:text-slate-300"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Category Sliders */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-slate-800/50 scrollbar-track-transparent">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1 text-[11px] font-medium rounded-full whitespace-nowrap transition-all border cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm shadow-indigo-600/10'
                        : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* list-container area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5 scrollbar-thin scrollbar-thumb-slate-800/80 scrollbar-track-transparent">
              {filteredFAQs.length > 0 ? (
                filteredFAQs.map((item) => {
                  const isExpanded = expandedId === item.id;
                  return (
                    <div
                      key={item.id}
                      className={`overflow-hidden rounded-2xl border transition-all ${
                        isExpanded
                          ? 'bg-slate-900/40 border-indigo-500/20 shadow-[0_4px_15px_rgba(0,0,0,0.2)]'
                          : 'bg-slate-900/20 hover:bg-slate-900/35 border-slate-800/60'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => toggleExpand(item.id)}
                        className="w-full text-left p-3.5 flex items-start gap-3 justify-between cursor-pointer focus:outline-none"
                      >
                        <div className="flex items-start gap-2.5 min-w-0">
                          <span className={`p-1.5 rounded-lg border shrink-0 mt-0.5 ${
                            isExpanded 
                              ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400' 
                              : 'bg-slate-800/50 border-slate-800 text-slate-500'
                          }`}>
                            <Lightbulb className="w-3.5 h-3.5" />
                          </span>
                          <span className="text-xs font-semibold text-slate-200 leading-relaxed hover:text-white transition-colors">
                            {item.question}
                          </span>
                        </div>
                        <span className="text-slate-500 shrink-0 mt-0.5">
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4 text-indigo-400" />
                          ) : (
                            <ChevronDown className="w-4 h-4" />
                          )}
                        </span>
                      </button>

                      <AnimatePresence initial={false}>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                          >
                            <div className="px-4 pb-4 pt-1 border-t border-slate-900 text-slate-300 text-[11px] leading-relaxed">
                              <p className="bg-slate-950/40 p-3 rounded-xl border border-slate-900/80 whitespace-pre-wrap">
                                {item.answer}
                              </p>
                              <div className="mt-2.5 flex items-center justify-between text-[10px] text-slate-500">
                                <span className="text-slate-500 italic">
                                  Category: {item.category}
                                </span>
                                <span className="flex items-center gap-1.5 hover:text-slate-300 cursor-pointer">
                                  Action Guide <ArrowUpRight className="w-3 h-3" />
                                </span>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })
              ) : (
                <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
                  <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 text-slate-500 mb-3 animate-bounce">
                    <Info className="w-6 h-6 text-slate-400" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-300">No guides matching.</h4>
                  <p className="text-[11px] text-slate-500 mt-1 max-w-[200px]">
                    Try typing keywords like 'sandbox', 'audio', 'Ollama', or 'model'.
                  </p>
                  <button
                    onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}
                    className="mt-3.5 px-3 py-1.5 bg-slate-905 border border-slate-800 rounded-lg text-[10px] font-semibold hover:bg-slate-800 text-indigo-400 transition-colors"
                  >
                    Clear Filter Search
                  </button>
                </div>
              )}
            </div>

            {/* Footer Prompt advice segment */}
            <div className="p-4 bg-slate-950 border-t border-slate-900 flex items-center justify-between text-[10px] text-slate-500 font-sans">
              <span className="flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5 text-emerald-500" />
                Offline AI active
              </span>
              <span>
                Need more? Prompt the bot in chat!
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
