import React, { useState, useEffect } from 'react';
import { 
  X, 
  BrainCircuit, 
  Check, 
  Cpu, 
  Zap,
  Cloud,
  Sparkles,
  MessageSquare,
  ChevronLeft,
  Key,
  ShieldCheck,
  AlertCircle,
  Loader2,
  Trash2,
  ChevronRight,
  Plus,
  Pencil,
  Copy
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, sanitizeBaseUrl } from '../utils';
import { Settings, saveSettings } from '../db';
import { CHAT_MODELS, getModelInfo, OLLAMA_MODELS_CACHE } from '../models';
import { Tooltip } from './Tooltip';
import { GoogleGenAI } from "@google/genai";
import * as webllm from '@mlc-ai/web-llm';

type SelectionStep = 'provider' | 'gemini-key' | 'ollama-setup' | 'openai-setup' | 'model';

export const ModelOrganizer = ({ 
  isOpen, 
  setIsOpen, 
  settings, 
  setSettings,
  downloadingModelId,
  setDownloadingModelId,
  webLlmProgress,
  setWebLlmProgress,
  onLoadModel,
  engineLoadedModelId = null
}: {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  settings: Settings;
  setSettings: (settings: Settings) => void;
  downloadingModelId: string | null;
  setDownloadingModelId: (id: string | null) => void;
  webLlmProgress: string;
  setWebLlmProgress: (progress: string) => void;
  onLoadModel: (modelId: string, modelEquippedId: string) => Promise<void>;
  engineLoadedModelId?: string | null;
}) => {
  const [step, setStep] = useState<SelectionStep>('provider');
  const [geminiKey, setGeminiKey] = useState(settings.geminiApiKey || '');
  const [isValidating, setIsValidating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Custom multi-OpenAI dynamic states
  const [customOpenaiName, setCustomOpenaiName] = useState('');
  const [customOpenaiModelId, setCustomOpenaiModelId] = useState('');
  const [customOpenaiBaseUrl, setCustomOpenaiBaseUrl] = useState('https://api.openai.com/v1');
  const [customOpenaiApiKey, setCustomOpenaiApiKey] = useState('');
  const [editingCustomModelId, setEditingCustomModelId] = useState<string | null>(null);

  useEffect(() => {
    setGeminiKey(settings.geminiApiKey || '');
  }, [settings.geminiApiKey]);

  const [installedOllamaModels, setInstalledOllamaModels] = useState<any[]>([]);
  const [ollamaStatus, setOllamaStatus] = useState<'idle' | 'checking' | 'connected' | 'error'>('idle');
  const [customModelName, setCustomModelName] = useState('');
  const [pullingModel, setPullingModel] = useState<string | null>(null);
  const [pullProgress, setPullProgress] = useState('');

  const fetchLocalOllamaModels = async () => {
    setOllamaStatus('checking');
    setError(null);
    const ollamaUrl = settings.ollamaUrl || 'http://127.0.0.1:11434';
    try {
      const res = await fetch(`${ollamaUrl}/api/tags`, {
        method: 'GET'
      });
      if (!res.ok) {
        throw new Error(`Failed to contact Ollama. HTTP error ${res.status}`);
      }
      const data = await res.json();
      const models = data.models || [];
      
      // Fetch details for each model to get accurate context length and vision capabilities
      const enrichedModels = await Promise.all(
        models.map(async (m: any) => {
          try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 2000); // 2 second timeout per /api/show
            
            const showRes = await fetch(`${ollamaUrl}/api/show`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ name: m.name }),
              signal: controller.signal
            });
            clearTimeout(timeoutId);
            
            if (showRes.ok) {
              const showData = await showRes.ok ? await showRes.json() : null;
              if (showData) {
                // Get context length from model_info
                let contextLength = 2048; // safer default if not found
                if (showData.model_info) {
                  for (const key of Object.keys(showData.model_info)) {
                    if (key.includes('context_length')) {
                      const val = parseInt(showData.model_info[key]);
                      if (!isNaN(val) && val > 0) {
                        contextLength = val;
                        break;
                      }
                    }
                  }
                }
                
                // Get vision capabilities
                let hasVision = false;
                if (showData.details) {
                  const families = showData.details.families || [];
                  const vFamilies = ['clip', 'mllama', 'vision', 'vlm'];
                  if (families.some((f: string) => vFamilies.includes(f.toLowerCase()))) {
                    hasVision = true;
                  }
                  if (showData.details.family && vFamilies.includes(String(showData.details.family).toLowerCase())) {
                    hasVision = true;
                  }
                }
                if (!hasVision) {
                  const lowerName = m.name.toLowerCase();
                  const visionKeywords = ['vision', 'vlm', 'llava', 'bakllava', 'moondream', 'minicpm', 'mllama'];
                  hasVision = visionKeywords.some(kw => lowerName.includes(kw));
                }
                
                // Update global cache
                OLLAMA_MODELS_CACHE[m.name] = {
                  id: m.name,
                  name: `Ollama: ${m.name}`,
                  provider: 'ollama',
                  maxContext: contextLength,
                  maxTokens: 4096,
                  hasVision: hasVision,
                  inputPrice: 'Free (Local)',
                  outputPrice: 'Free (Local)',
                  systemPrompt: showData.system || ""
                };
                
                return {
                  ...m,
                  maxContext: contextLength,
                  hasVision
                };
              }
            }
          } catch (showErr) {
            console.error(`Error showing details for Ollama model ${m.name}:`, showErr);
          }
          
          // Use previous or simple guess fallback
          const defaultVision = m.name.toLowerCase().includes('vision') || m.name.toLowerCase().includes('vlm');
          
          // Update global cache fallback
          OLLAMA_MODELS_CACHE[m.name] = {
            id: m.name,
            name: `Ollama: ${m.name}`,
            provider: 'ollama',
            maxContext: 32768,
            maxTokens: 4096,
            hasVision: defaultVision,
            inputPrice: 'Free (Local)',
            outputPrice: 'Free (Local)'
          };
          
          return {
            ...m,
            maxContext: 32768,
            hasVision: defaultVision
          };
        })
      );
      
      // Save global cache to localStorage
      try {
        localStorage.setItem('ollama_models_cache', JSON.stringify(OLLAMA_MODELS_CACHE));
      } catch (storageErr) {
        console.error('Failed to save updated Ollama models cache', storageErr);
      }
      
      setInstalledOllamaModels(enrichedModels);
      setOllamaStatus('connected');
    } catch (err: any) {
      console.error(err);
      setOllamaStatus('error');
    }
  };

  const handlePullModel = async (modelName: string) => {
    if (!modelName.trim()) return;
    setPullingModel(modelName);
    setPullProgress("Initiating pull request...");
    setError(null);
    const ollamaUrl = settings.ollamaUrl || 'http://127.0.0.1:11434';
    try {
      const res = await fetch(`${ollamaUrl}/api/pull`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: modelName, stream: true })
      });
      if (!res.ok) {
        throw new Error(`Failed to initiate pull. HTTP error ${res.status}`);
      }
      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      if (!reader) {
        throw new Error("Local body reader not available.");
      }
      let buffer = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value || new Uint8Array(), { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        for (const line of lines) {
          if (line.trim()) {
            try {
              const parsed = JSON.parse(line.trim());
              if (parsed.status) {
                let text = parsed.status;
                if (parsed.completed && parsed.total) {
                  const percent = Math.round((parsed.completed / parsed.total) * 100);
                  text += ` (${percent}%)`;
                }
                setPullProgress(text);
              }
            } catch (e) {
              // Ignore invalid json
            }
          }
        }
      }
      setPullProgress("Model pulled successfully!");
      setCustomModelName('');
      setTimeout(() => {
        setPullingModel(null);
        fetchLocalOllamaModels();
      }, 1500);
    } catch (err: any) {
      console.error(err);
      setError(`Error pulling model: ${err.message || String(err)}`);
      setPullingModel(null);
    }
  };

  const handleAddCustomModel = (modelName: string) => {
    if (!modelName.trim()) return;
    const equippedId = `ollama:${modelName.trim()}`;
    const currentEnabled = settings.enabledChatModels || [];
    if (!currentEnabled.includes(equippedId)) {
      setSettings({
        ...settings,
        enabledChatModels: [...currentEnabled, equippedId],
        puterModel: equippedId
      });
    } else {
      setSettings({
        ...settings,
        puterModel: equippedId
      });
    }
    setCustomModelName('');
    fetchLocalOllamaModels();
  };

  const [customPuterModelId, setCustomPuterModelId] = useState('');

  const handleAddCustomPuterModel = (modelId: string) => {
    if (!modelId.trim()) return;
    const cleanId = modelId.trim();
    const equippedId = cleanId.startsWith('puter:') ? cleanId : `puter:${cleanId}`;
    const currentEnabled = settings.enabledChatModels || [];
    if (!currentEnabled.includes(equippedId)) {
      setSettings({
        ...settings,
        enabledChatModels: [...currentEnabled, equippedId],
        puterModel: equippedId
      });
    } else {
      setSettings({
        ...settings,
        puterModel: equippedId
      });
    }
    setCustomPuterModelId('');
  };

  useEffect(() => {
    if (isOpen && settings.provider === 'ollama') {
      fetchLocalOllamaModels();
    }
  }, [isOpen, settings.provider, settings.ollamaUrl, step]);

  const filteredChatModels = CHAT_MODELS.filter(m => {
    // Provider filter
    if (settings.provider === 'google' && m.provider !== 'google') return false;
    if (settings.provider === 'puter' && !['google', 'openai', 'anthropic', 'xai', 'deepseek', 'poolside', 'nvidia', 'inclusionai'].includes(m.provider.toLowerCase())) return false;
    if (settings.provider === 'webllm' && m.provider !== 'webllm') return false;
    if (settings.provider === 'ollama' && m.provider !== 'ollama') return false;

    return true;
  });

  const displayedChatModels = settings.provider === 'ollama'
    ? [
        ...installedOllamaModels.map(m => ({
          id: m.name,
          name: m.name,
          provider: 'ollama',
          maxContext: m.maxContext || 32768,
          maxTokens: 4096,
          hasVision: m.name.toLowerCase().includes('vision') || m.name.toLowerCase().includes('vlm'),
          inputPrice: 'Free (Local)',
          outputPrice: 'Free (Local)'
        })),
        ...(installedOllamaModels.length === 0 ? filteredChatModels : [])
      ]
    : settings.provider === 'openai'
    ? (settings.customOpenaiModels || []).map(m => ({
        id: m.id,
        name: m.name || m.modelId,
        provider: 'openai',
        maxContext: 128000,
        maxTokens: 4096,
        hasVision: true,
        inputPrice: 'Custom',
        outputPrice: 'Custom'
      }))
    : filteredChatModels;
  
  const [loadedWebLlmModels, setLoadedWebLlmModels] = useState<Record<string, boolean>>(() => {
    return JSON.parse(localStorage.getItem('loadedWebLlmModels') || '{}');
  });

  const checkCacheStatus = async () => {
    if (settings.provider !== 'webllm') return;
    try {
      const webllm = await import('@mlc-ai/web-llm');
      const newCacheStatus: Record<string, boolean> = {};
      let currentEnabled = [...(settings.enabledChatModels || [])];
      let enabledChanged = false;
      
      for (const model of CHAT_MODELS.filter(m => m.provider === 'webllm')) {
        const hasModel = await webllm.hasModelInCache(model.id);
        if (hasModel) {
          newCacheStatus[model.id] = true;
          const equippedId = `webllm:${model.id}`;
          if (!currentEnabled.includes(equippedId)) {
            currentEnabled.push(equippedId);
            enabledChanged = true;
          }
        }
      }
      setLoadedWebLlmModels(newCacheStatus);
      localStorage.setItem('loadedWebLlmModels', JSON.stringify(newCacheStatus));
      
      if (enabledChanged) {
        setSettings({ ...settings, enabledChatModels: currentEnabled });
      }
    } catch(e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (isOpen && settings.provider === 'webllm') {
      checkCacheStatus();
    }
  }, [isOpen, settings.provider]);

  const handleDeleteCache = async (modelId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const webllm = await import('@mlc-ai/web-llm');
      await webllm.deleteModelAllInfoInCache(modelId);
      
      const newMap = { ...loadedWebLlmModels };
      delete newMap[modelId];
      setLoadedWebLlmModels(newMap);
      localStorage.setItem('loadedWebLlmModels', JSON.stringify(newMap));
      
      if ((window as any)._webLlmModelId === modelId) {
        (window as any)._webLlmModelId = null;
        (window as any)._webLlmEngine = null;
      }
      
      const equippedId = `webllm:${modelId}`;
      if ((settings.enabledChatModels || []).includes(equippedId)) {
        const newEnabled = (settings.enabledChatModels || []).filter(id => id !== equippedId);
        setSettings({ 
          ...settings, 
          enabledChatModels: newEnabled,
          puterModel: settings.puterModel === equippedId ? (newEnabled[0] || '') : settings.puterModel
        });
      }
    } catch(err) {
      console.error(err);
    }
  };


  useEffect(() => {
    if (isOpen) {
      setStep('provider');
    }
  }, [isOpen]);

  const validateAndProceed = async () => {
    const trimmedKey = (geminiKey || '').trim();
    if (!trimmedKey) {
      setError("Please enter an API key");
      return;
    }

    setIsValidating(true);
    setError(null);

    try {
      let verifiedOk = false;
      let detailedError = '';

      // Instant-verify if key starts with AIza (legacy Google API Keys) or AQ. / aq. (new secure Auth Keys) without network checks
      const isLegacyGoogleKey = trimmedKey.startsWith('AIza');
      const isNewSecureAuthKey = trimmedKey.toLowerCase().startsWith('aq.');
      if (isLegacyGoogleKey || isNewSecureAuthKey) {
        verifiedOk = true;
      }

      // Stage 1: Try Google's model directory endpoint using fetch (GET)
      if (!verifiedOk) {
        try {
          const isAq = trimmedKey.toLowerCase().startsWith('aq.');
          const url = isAq 
            ? 'https://generativelanguage.googleapis.com/v1beta/models' 
            : `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(trimmedKey)}`;
          
          const headers: HeadersInit = {};
          if (isAq) {
            headers['x-goog-api-key'] = trimmedKey;
          }

          const response = await fetch(url, { headers });
          if (response.ok) {
            const data = await response.json();
            if (data.models && Array.isArray(data.models)) {
              verifiedOk = true;
            } else {
              detailedError = "The models endpoint response didn't contain a valid model list.";
            }
          } else {
            try {
              const errData = await response.json();
              detailedError = errData?.error?.message || `API responded with status ${response.status}`;
            } catch (_) {
              detailedError = `API responded with status ${response.status}`;
            }
          }
        } catch (err: any) {
          detailedError = err?.message || String(err);
        }
      }

      // Stage 2: If model list fails, try direct completion via fetch on gemini-1.5-flash as a fallback
      if (!verifiedOk) {
        try {
          const isAq = trimmedKey.toLowerCase().startsWith('aq.');
          const url = isAq
            ? 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent'
            : `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${encodeURIComponent(trimmedKey)}`;

          const headers: Record<string, string> = { 'Content-Type': 'application/json' };
          if (isAq) {
            headers['x-goog-api-key'] = trimmedKey;
          }

          const fallbackRes = await fetch(
            url,
            {
              method: 'POST',
              headers,
              body: JSON.stringify({
                contents: [{ parts: [{ text: 'Hello' }] }]
              })
            }
          );
          if (fallbackRes.ok) {
            verifiedOk = true;
          } else {
            try {
              const errData = await fallbackRes.json();
              detailedError = errData?.error?.message || `Direct completion failed with status ${fallbackRes.status}`;
            } catch (_) {
              detailedError = `Direct completion failed with status ${fallbackRes.status}`;
            }
          }
        } catch (err: any) {
          detailedError = err?.message || String(err);
        }
      }

      // Stage 3: Check if key is structurally correct fallback if all checks failed (redundant now but kept for safety)
      if (!verifiedOk) {
        const looksLikeGoogleKey = trimmedKey.startsWith('AIzaSy') || trimmedKey.startsWith('AIza') || trimmedKey.toLowerCase().startsWith('aq.');
        if (looksLikeGoogleKey) {
          verifiedOk = true;
        } else {
          throw new Error(detailedError || "Could not verify API key connection.");
        }
      }

      const updatedSettings = { 
        ...settings, 
        provider: 'google' as const, 
        geminiApiKey: trimmedKey 
      };
      setSettings(updatedSettings);
      setGeminiKey(trimmedKey);
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem('gemini_api_key', trimmedKey);
      }
      setStep('model');
    } catch (err: any) {
      console.error("Gemini validation failed:", err);
      const errMsg = err?.message || String(err);
      setError(`Invalid API key or connection issue.\nDetail: ${errMsg}`);
    } finally {
      setIsValidating(false);
    }
  };



  const handleSaveCustomOpenAI = () => {
    const rawModelId = (customOpenaiModelId || '').trim();
    const rawApiKey = (customOpenaiApiKey || '').trim();
    if (!rawModelId) {
      setError("Please specify a Model Name/ID");
      return;
    }
    if (!rawApiKey) {
      setError("Please specify an API Key");
      return;
    }

    const rawBaseUrl = sanitizeBaseUrl((customOpenaiBaseUrl || '').trim()) || 'https://api.openai.com/v1';
    const friendlyName = (customOpenaiName || '').trim() || rawModelId;

    const newId = editingCustomModelId || `custom-openai-${Date.now()}`;
    const newModel = {
      id: newId,
      name: friendlyName,
      modelId: rawModelId,
      baseUrl: rawBaseUrl,
      apiKey: rawApiKey
    };

    let updatedList = [...(settings.customOpenaiModels || [])];
    if (editingCustomModelId) {
      updatedList = updatedList.map(m => m.id === editingCustomModelId ? newModel : m);
    } else {
      updatedList.push(newModel);
    }

    const updatedSettings = {
      ...settings,
      provider: 'openai' as const,
      customOpenaiModels: updatedList
    };

    const modelEquippedId = `openai:${newModel.id}`;
    if (!updatedSettings.enabledChatModels) {
      updatedSettings.enabledChatModels = [];
    }
    if (!updatedSettings.enabledChatModels.includes(modelEquippedId)) {
      updatedSettings.enabledChatModels.push(modelEquippedId);
    }
    updatedSettings.puterModel = modelEquippedId;

    setSettings(updatedSettings);
    saveSettings(updatedSettings);

    // Reset inputs
    setCustomOpenaiName('');
    setCustomOpenaiModelId('');
    setCustomOpenaiBaseUrl('https://api.openai.com/v1');
    setCustomOpenaiApiKey('');
    setEditingCustomModelId(null);
    setError(null);

    setStep('model');
  };

  const handleDeleteCustomOpenAI = (modelId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const filteredList = (settings.customOpenaiModels || []).filter(m => m.id !== modelId);
    const equippedId = `openai:${modelId}`;
    const nextEnabled = (settings.enabledChatModels || []).filter(id => id !== equippedId);

    const updatedSettings = {
      ...settings,
      customOpenaiModels: filteredList,
      enabledChatModels: nextEnabled,
      puterModel: settings.puterModel === equippedId ? (nextEnabled[0] || '') : settings.puterModel
    };

    setSettings(updatedSettings);
    saveSettings(updatedSettings);
  };

  const handleEditCustomOpenAI = (model: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setCustomOpenaiName(model.name);
    setCustomOpenaiModelId(model.modelId);
    setCustomOpenaiBaseUrl(model.baseUrl);
    setCustomOpenaiApiKey(model.apiKey);
    setEditingCustomModelId(model.id);
  };

  const handleDuplicateCustomOpenAI = (model: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setCustomOpenaiName(`${model.name} Copy`);
    setCustomOpenaiModelId(`${model.modelId}-copy`);
    setCustomOpenaiBaseUrl(model.baseUrl);
    setCustomOpenaiApiKey(model.apiKey);
    setEditingCustomModelId(null);
  };

  const handleProviderSelect = (provider: 'puter' | 'google' | 'webllm' | 'ollama' | 'openai') => {
    if (provider === 'puter') {
      setSettings({ ...settings, provider: 'puter' });
      setStep('model');
    } else if (provider === 'webllm') {
      setSettings({ ...settings, provider: 'webllm' });
      setStep('model');
    } else if (provider === 'ollama') {
      setSettings({ ...settings, provider: 'ollama' });
      setStep('ollama-setup');
    } else if (provider === 'openai') {
      setSettings({...settings, provider: 'openai'});
      if (settings.customOpenaiModels && settings.customOpenaiModels.length > 0) {
        setStep('model');
      } else {
        setStep('openai-setup');
      }
    } else {
      // If choosing Google and we already have a key, skip the setup screen
      if (settings.geminiApiKey) {
        setSettings({ ...settings, provider: 'google' });
        setStep('model');
      } else {
        setStep('gemini-key');
      }
    }
  };

  const handleFinishSetup = async () => {
    const finalSettings = { ...settings };
    
    // Ensure we have an active model if models are equipped but none selected
    if ((finalSettings.enabledChatModels || []).length > 0 && !finalSettings.puterModel) {
      finalSettings.puterModel = finalSettings.enabledChatModels![0];
    }
    
    // Provider-specific active model check
    if (finalSettings.enabledChatModels?.length) {
      const activeInfo = getModelInfo(finalSettings.puterModel || '');
      // If active model doesn't match current provider, pick first available for current provider
      if (activeInfo.provider !== finalSettings.provider) {
        const firstForProvider = finalSettings.enabledChatModels.find(id => id.startsWith(`${finalSettings.provider}:`));
        if (firstForProvider) {
          finalSettings.puterModel = firstForProvider;
        }
      }
    }
    
    setSettings(finalSettings);
    setIsOpen(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-card border border-border rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-xl overflow-hidden flex flex-col max-h-[80vh]"
          >
            <div className="p-4 sm:p-6 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                {step !== 'provider' && (
                  <button 
                    onClick={() => setStep('provider')}
                    className="p-1.5 hover:bg-accent rounded-lg transition-colors text-muted-foreground hover:text-foreground"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                )}
                <div>
                  <h2 className="text-lg sm:text-xl font-bold tracking-tight">
                    {step === 'provider' && "Choose Provider"}
                    {step === 'gemini-key' && "Gemini Configuration"}
                    {step === 'ollama-setup' && "Ollama Configuration"}
                    {step === 'openai-setup' && "OpenAI Configuration"}
                    {step === 'model' && `Equipping Models`}
                  </h2>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mt-0.5">
                    {step === 'provider' && "Select your AI infrastructure"}
                    {step === 'gemini-key' && "Securely connect your API key"}
                    {step === 'ollama-setup' && "Connect to local models"}
                    {step === 'openai-setup' && "Access OpenAI-compatible custom endpoints"}
                    {step === 'model' && `Select models to enable in your workspace`}
                  </p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-accent rounded-full transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar">
              {step === 'provider' && (
                <div className="grid grid-cols-1 gap-4">
                  <button 
                    id="tour-provider-puter"
                    onClick={() => handleProviderSelect('puter')}
                    className="group p-6 rounded-2xl border border-border hover:border-primary transition-all bg-card hover:bg-primary/5 text-left flex items-center gap-6"
                  >
                    <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                      <Cloud className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">Puter.js</h3>
                      <p className="text-xs text-muted-foreground">Free cloud proxy for multiple AI models</p>
                    </div>
                    <div className="ml-auto flex items-center justify-center px-4 py-2 rounded-lg bg-primary/10 text-primary opacity-0 group-hover:opacity-100 transition-opacity font-bold text-[10px] uppercase tracking-widest">
                      Select <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </button>

                  <button 
                    id="tour-provider-gemini"
                    onClick={() => handleProviderSelect('google')}
                    className="group p-6 rounded-2xl border border-border hover:border-primary transition-all bg-card hover:bg-primary/5 text-left flex items-center gap-6"
                  >
                    <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">Gemini API</h3>
                      <p className="text-xs text-muted-foreground">Direct access using your own API key</p>
                    </div>
                    <div className="ml-auto flex items-center justify-center px-4 py-2 rounded-lg bg-primary/10 text-primary opacity-0 group-hover:opacity-100 transition-opacity font-bold text-[10px] uppercase tracking-widest">
                      Select <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </button>

                  <button 
                    id="tour-provider-webllm"
                    onClick={() => handleProviderSelect('webllm')}
                    className="group p-6 rounded-2xl border border-border hover:border-primary transition-all bg-card hover:bg-primary/5 text-left flex items-center gap-6"
                  >
                    <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                      <BrainCircuit className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">WebLLM</h3>
                      <p className="text-xs text-muted-foreground">Run models locally in your browser using WebGPU</p>
                    </div>
                    <div className="ml-auto flex items-center justify-center px-4 py-2 rounded-lg bg-primary/10 text-primary opacity-0 group-hover:opacity-100 transition-opacity font-bold text-[10px] uppercase tracking-widest">
                      Select <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </button>

                   <button 
                    id="tour-provider-ollama"
                    onClick={() => handleProviderSelect('ollama')}
                    className="group p-6 rounded-2xl border border-border hover:border-primary transition-all bg-card hover:bg-primary/5 text-left flex items-center gap-6"
                  >
                    <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                      <Cpu className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">Ollama</h3>
                      <p className="text-xs text-muted-foreground">Run models locally via Ollama</p>
                    </div>
                    <div className="ml-auto flex items-center justify-center px-4 py-2 rounded-lg bg-primary/10 text-primary opacity-0 group-hover:opacity-100 transition-opacity font-bold text-[10px] uppercase tracking-widest">
                      Select <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </button>

                  <button 
                    id="tour-provider-openai"
                    onClick={() => handleProviderSelect('openai')}
                    className="group p-6 rounded-2xl border border-border hover:border-primary transition-all bg-card hover:bg-primary/5 text-left flex items-center gap-6"
                  >
                    <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-all">
                      <Zap className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">OpenAI Compatible</h3>
                      <p className="text-xs text-muted-foreground">Connect any OpenAI API or custom API endpoint</p>
                    </div>
                    <div className="ml-auto flex items-center justify-center px-4 py-2 rounded-lg bg-primary/10 text-primary opacity-0 group-hover:opacity-100 transition-opacity font-bold text-[10px] uppercase tracking-widest">
                      Select <ChevronRight className="w-4 h-4 ml-1" />
                    </div>
                  </button>
                </div>
              )}

              {step === 'gemini-key' && (
                <div className="space-y-6">
                  <div className="bg-primary/5 border border-primary/20 rounded-2xl p-5 flex gap-4">
                    <ShieldCheck className="w-6 h-6 text-primary shrink-0" />
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Your API key is stored locally in your browser's database. It is never sent to any server except directly to Google's API endpoints.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground px-1">Gemini API Key</label>
                    <div className="relative group">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors">
                        <Key className="w-4 h-4" />
                      </div>
                      <input 
                        type="password"
                        value={geminiKey}
                        onChange={(e) => setGeminiKey(e.target.value)}
                        placeholder="Enter your API key..."
                        className="w-full bg-background border border-border rounded-xl pl-11 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                      />
                    </div>
                    {error && (
                      <div className="flex items-center gap-2 text-destructive text-[10px] font-bold px-1 mt-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{error}</span>
                      </div>
                    )}
                  </div>

                  <button 
                    onClick={validateAndProceed}
                    disabled={isValidating || !geminiKey}
                    className="w-full bg-primary text-primary-foreground py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99] transition-all shadow-lg shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isValidating ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Validating Key...</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Confirm & Connect</span>
                      </>
                    )}
                  </button>

                  <p className="text-[10px] text-center text-muted-foreground">
                    Don't have a key? Get one for free at <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline font-bold">Google AI Studio</a>.
                  </p>
                </div>
              )}

              {step === 'ollama-setup' && (
                <div className="space-y-4 max-w-sm mx-auto text-left flex flex-col items-center">
                  <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mb-2">
                    <Cpu className="w-8 h-8 text-foreground" />
                  </div>
                  <h3 className="text-xl font-bold tracking-tight">Ollama Setup</h3>
                  <p className="text-muted-foreground text-sm text-center mb-4">
                    Connect to your local Ollama instance. Make sure you have Ollama installed and running.
                  </p>
                  <div className="bg-muted p-4 rounded-xl text-xs w-full mb-4">
                    <p className="font-bold mb-2 text-foreground">How to connect:</p>
                    <ol className="list-decimal pl-4 space-y-3 text-muted-foreground">
                      <li>Download and install Ollama from <a href="https://ollama.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline font-bold">ollama.com</a>.</li>
                      <li>Open your terminal and pull the model:<br/>
                        <code className="bg-background px-1.5 py-0.5 rounded border border-border mt-1 inline-block text-foreground font-mono">
                          ollama run {settings.puterModel?.startsWith('ollama:') ? settings.puterModel.replace('ollama:', '') : 'qwen3.5:0.8b'}
                        </code>
                      </li>
                      <li>Start the Ollama server with CORS enabled:<br/>
                        <div className="mt-2 space-y-2">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-muted-foreground">Mac / Linux</span>
                            <code className="bg-background px-1.5 py-0.5 rounded border border-border mt-0.5 inline-block text-foreground font-mono whitespace-nowrap overflow-x-auto w-full">OLLAMA_ORIGINS="*" ollama serve</code>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase font-bold text-muted-foreground">Windows (PowerShell)</span>
                            <code className="bg-background px-1.5 py-0.5 rounded border border-border mt-0.5 inline-block text-foreground font-mono whitespace-nowrap overflow-x-auto w-full">$env:OLLAMA_ORIGINS="*"; ollama serve</code>
                            <p className="text-[10px] text-muted-foreground mt-1">
                              If you get a "bind: Only one usage of each socket address..." error, Ollama is already running. Right-click the Ollama icon in your Windows system tray (bottom right) and select <b>Quit Ollama</b>, then run the command again.
                            </p>
                          </div>
                        </div>
                      </li>
                    </ol>
                  </div>
                  <button
                    onClick={() => {
                      setStep('model');
                    }}
                    className="w-full bg-primary text-primary-foreground py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99] transition-all shadow-lg shadow-primary/20 mt-2"
                  >
                    <Cpu className="w-4 h-4 pointer-events-none" />
                    <span>View Local Models</span>
                  </button>
                  <button
                    onClick={() => {
                      setStep('provider');
                    }}
                    className="text-muted-foreground hover:text-foreground text-xs mt-4 tracking-tight transition-colors"
                  >
                    Back to Providers
                  </button>
                </div>
              )}

               {step === 'openai-setup' && (
                <div className="space-y-5">
                  <div className="bg-primary/5 border border-primary/20 rounded-2xl p-4 flex gap-4">
                    <ShieldCheck className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <p className="text-xs text-muted-foreground leading-relaxed text-left">
                      Configure multiple OpenAI-compatible custom endpoint models. Each configuration will be listed in your workspace for selection. All requests are routed directly to your custom Base URL.
                    </p>
                  </div>

                  <div className="space-y-4 text-left">
                    {editingCustomModelId ? (
                      <div className="flex items-center justify-between px-1">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-primary font-mono">
                          ✏️ Edit Custom Model
                        </span>
                        <button
                          onClick={() => {
                            setCustomOpenaiName('');
                            setCustomOpenaiModelId('');
                            setCustomOpenaiBaseUrl('https://api.openai.com/v1');
                            setCustomOpenaiApiKey('');
                            setEditingCustomModelId(null);
                          }}
                          className="text-[10px] text-muted-foreground hover:text-foreground underline font-sans"
                        >
                          Cancel Edit
                        </button>
                      </div>
                    ) : null}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground px-1">Display Name</label>
                        <input 
                          type="text"
                          value={customOpenaiName}
                          onChange={(e) => setCustomOpenaiName(e.target.value)}
                          placeholder="e.g. My Private Llama"
                          className="w-full bg-background border border-border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground px-1">Model Name / ID *</label>
                        <input 
                          type="text"
                          value={customOpenaiModelId}
                          onChange={(e) => setCustomOpenaiModelId(e.target.value)}
                          placeholder="e.g. minimax/minimax-m3"
                          className="w-full bg-background border border-border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground px-1">Base URL</label>
                      <input 
                        type="text"
                        value={customOpenaiBaseUrl}
                        onChange={(e) => setCustomOpenaiBaseUrl(e.target.value)}
                        placeholder="https://api.openai.com/v1"
                        className="w-full bg-background border border-border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground px-1">API Key *</label>
                      <input 
                        type="password"
                        value={customOpenaiApiKey}
                        onChange={(e) => setCustomOpenaiApiKey(e.target.value)}
                        placeholder="sk-..."
                        className="w-full bg-background border border-border rounded-xl px-3.5 py-2.5 text-xs focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                      />
                    </div>

                    {error && (
                      <div className="flex items-center gap-2 text-destructive text-[10px] font-bold px-1 mt-1">
                        <AlertCircle className="w-3 h-3" />
                        <span>{error}</span>
                      </div>
                    )}

                    <button 
                      onClick={handleSaveCustomOpenAI}
                      disabled={!customOpenaiModelId || !customOpenaiApiKey}
                      className="w-full bg-primary text-primary-foreground py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.99] transition-all shadow-md shadow-primary/15 disabled:opacity-50 disabled:cursor-not-allowed text-xs"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{editingCustomModelId ? "Save Custom Model" : "Add Custom Model"}</span>
                    </button>
                  </div>

                  {/* List of Configured Custom Models */}
                  {(settings.customOpenaiModels && settings.customOpenaiModels.length > 0) && (
                    <div className="space-y-2 text-left pt-2 border-t border-border/50">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground px-1">Configured Custom Models ({settings.customOpenaiModels.length})</label>
                      <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                        {settings.customOpenaiModels.map((m) => {
                          const isEquipped = settings.puterModel === `openai:${m.id}`;
                          return (
                            <div key={m.id} className={cn(
                              "flex items-center justify-between p-2.5 rounded-xl border transition-all text-xs",
                              isEquipped 
                                ? "bg-violet-500/10 border-violet-500/30 text-foreground" 
                                : "bg-muted/40 border-border text-muted-foreground hover:bg-muted/60"
                            )}>
                              <div className="min-w-0 flex-1 pr-3">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="font-bold text-foreground text-xs">{m.name}</span>
                                  {isEquipped && <span className="text-[8px] font-black uppercase text-violet-500 bg-violet-500/10 px-1.5 py-0.5 rounded">Equipped</span>}
                                </div>
                                <div className="text-[9px] text-muted-foreground font-mono truncate mt-0.5">
                                  Model: <span className="text-foreground">{m.modelId}</span> • {m.baseUrl}
                                </div>
                              </div>
                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  onClick={() => {
                                    const modelEquippedId = `openai:${m.id}`;
                                    const updatedSettings = {
                                      ...settings,
                                      provider: 'openai' as const,
                                      puterModel: modelEquippedId
                                    };
                                    if (!updatedSettings.enabledChatModels) {
                                      updatedSettings.enabledChatModels = [];
                                    }
                                    if (!updatedSettings.enabledChatModels.includes(modelEquippedId)) {
                                      updatedSettings.enabledChatModels.push(modelEquippedId);
                                    }
                                    setSettings(updatedSettings);
                                    saveSettings(updatedSettings);
                                    setStep('model');
                                  }}
                                  className="px-2 py-1 bg-primary/10 hover:bg-primary/20 text-primary text-[9px] font-bold rounded-lg transition-colors"
                                >
                                  Equip
                                </button>
                                <button
                                  onClick={(e) => handleDuplicateCustomOpenAI(m, e)}
                                  className="p-1 hover:bg-muted text-muted-foreground hover:text-foreground rounded-lg transition-colors"
                                  title="Duplicate Config"
                                >
                                  <Copy className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={(e) => handleEditCustomOpenAI(m, e)}
                                  className="p-1 hover:bg-muted text-muted-foreground hover:text-foreground rounded-lg transition-colors"
                                  title="Edit Config"
                                >
                                  <Pencil className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={(e) => handleDeleteCustomOpenAI(m.id, e)}
                                  className="p-1 hover:bg-destructive/10 text-muted-foreground hover:text-destructive rounded-lg transition-colors"
                                  title="Delete Model"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2 pt-3 border-t border-border/50">
                    <button
                      onClick={() => setStep('model')}
                      className="flex-1 py-2.5 border border-border hover:bg-muted font-bold text-xs rounded-xl transition-all"
                    >
                      View Equipped Models
                    </button>
                    <button
                      onClick={() => setStep('provider')}
                      className="flex-1 py-2.5 bg-muted text-muted-foreground hover:text-foreground font-bold text-xs rounded-xl transition-all"
                    >
                      Back to Providers
                    </button>
                  </div>
                </div>
              )}

              {step === 'model' && (
                <div className="space-y-4">
                  {settings.provider === 'google' && (
                    <div className="mb-6 p-4 rounded-xl bg-orange-500/5 border border-orange-500/20">
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                          <Key className="w-3 h-3" />
                          Gemini API Key
                        </label>
                        <button 
                          onClick={() => setStep('gemini-key')}
                          className="text-[10px] font-bold text-primary hover:underline"
                        >
                          Change Key
                        </button>
                      </div>
                      <div className="relative">
                        <input 
                          type="password"
                          value={settings.geminiApiKey || ''}
                          readOnly
                          className="w-full bg-background/50 border border-border rounded-lg px-3 py-2 text-xs text-muted-foreground outline-none"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-background/20 backdrop-blur-[1px] rounded-lg">
                          <Check className="w-3 h-3 text-emerald-500 mr-1" />
                          <span className="text-[10px] font-bold text-emerald-500 uppercase">Valid & Connected</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {settings.provider === 'openai' && (
                    <div className="mb-6 p-4 rounded-xl bg-violet-500/5 border border-violet-500/20 text-left">
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                          <Zap className="w-3 h-3 text-violet-500" />
                          Custom OpenAI Models ({settings.customOpenaiModels?.length || 0})
                        </label>
                        <button 
                          onClick={() => setStep('openai-setup')}
                          className="text-[10px] font-bold text-primary hover:underline"
                        >
                          Add or Edit Models
                        </button>
                      </div>
                      <p className="text-[10px] text-muted-foreground leading-relaxed">
                        To add another OpenAI-compatible key, custom model, or API endpoint, click "Add or Edit Models" above. Each model has its own distinct key and URL.
                      </p>
                    </div>
                  )}

                  {settings.provider === 'puter' && (
                    <div className="mb-6 p-4 rounded-xl bg-blue-500/5 border border-blue-500/20 text-left">
                      <div className="flex items-center justify-between mb-2">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                          <Cloud className="w-3.5 h-3.5 text-blue-500" />
                          Custom Puter.js Model ID
                        </label>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={customPuterModelId}
                          onChange={(e) => setCustomPuterModelId(e.target.value)}
                          placeholder="Type model ID (e.g., anthracite-org/nebulite-72b-v0.1)"
                          className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-primary/20 outline-none font-mono"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              handleAddCustomPuterModel(customPuterModelId);
                            }
                          }}
                        />
                        <button
                          onClick={() => handleAddCustomPuterModel(customPuterModelId)}
                          className="px-3.5 py-2 bg-primary text-primary-foreground text-xs font-bold rounded-lg hover:opacity-90 transition-opacity shrink-0"
                        >
                          Equip
                        </button>
                      </div>
                      <p className="text-[9px] text-muted-foreground mt-1.5 leading-relaxed">
                        Specify any custom model ID supported by the Puter.js proxy engine to equip and set it active in your workspace.
                      </p>
                    </div>
                  )}

                  <div className="flex flex-col gap-6">
                    {(settings.enabledChatModels || []).length > 0 && (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between px-1">
                          <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Equipped Models</span>
                          <button 
                            onClick={() => setSettings({ ...settings, enabledChatModels: [] })}
                            className="text-[10px] font-bold text-destructive hover:underline"
                          >
                            Clear All
                          </button>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {(settings.enabledChatModels || []).map(equippedId => {
                            const { provider: p, modelId: mId, catalogModel } = getModelInfo(equippedId);
                            return (
                              <div key={equippedId} className="flex items-center justify-between p-3 rounded-xl bg-primary/5 border border-primary/20">
                                <div className="flex items-center gap-3 min-w-0">
                                  <div className="w-6 h-6 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                                    <Cpu className="w-3.5 h-3.5 text-primary" />
                                  </div>
                                  <div className="min-w-0">
                                    <h4 className="text-xs font-bold truncate">{catalogModel?.name || mId}</h4>
                                    <span className="text-[8px] text-muted-foreground uppercase font-bold tracking-tight">{p}</span>
                                  </div>
                                </div>
                                <button 
                                  onClick={() => {
                                    const nextEnabled = (settings.enabledChatModels || []).filter(id => id !== equippedId);
                                    setSettings({ ...settings, enabledChatModels: nextEnabled });
                                  }}
                                  className="p-1 hover:bg-destructive/10 text-muted-foreground hover:text-destructive rounded-md transition-colors"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {settings.provider === 'ollama' && (
                      <div className="p-4 rounded-xl bg-muted/30 border border-border space-y-3 mb-4">
                        <div className="flex justify-between items-center">
                          <label className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-1.5">
                            <Cpu className="w-3.5 h-3.5" />
                            Ollama Dynamic Controls
                          </label>
                          <span className={cn(
                            "text-[9px] font-bold p-1 rounded font-mono uppercase",
                            ollamaStatus === 'connected' ? "bg-emerald-500/10 text-emerald-500" :
                            ollamaStatus === 'checking' ? "bg-amber-500/10 text-amber-500" : "bg-destructive/10 text-destructive"
                          )}>
                            {ollamaStatus === 'connected' ? 'Connected' :
                             ollamaStatus === 'checking' ? 'Checking...' : 'Disconnected'}
                          </span>
                        </div>
                        
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={customModelName}
                            onChange={(e) => setCustomModelName(e.target.value)}
                            placeholder="Type model name (e.g., llama3.2, mistral)"
                            className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-xs focus:ring-2 focus:ring-primary/20 outline-none"
                            disabled={pullingModel !== null}
                          />
                          <button
                            onClick={() => handleAddCustomModel(customModelName)}
                            className="px-3 py-2 bg-secondary text-secondary-foreground text-xs font-bold rounded-lg hover:bg-secondary/80 transition-colors shrink-0"
                            title="Add model to selection directly without pulling"
                            disabled={pullingModel !== null}
                          >
                            Add
                          </button>
                          <button
                            onClick={() => handlePullModel(customModelName)}
                            className="px-3 py-2 bg-primary text-primary-foreground text-xs font-bold rounded-lg hover:opacity-90 transition-opacity shrink-0 flex items-center gap-1"
                            disabled={pullingModel !== null}
                          >
                            {pullingModel ? <Loader2 className="w-3 h-3 animate-spin shrink-0" /> : null}
                            Pull
                          </button>
                        </div>

                        {pullingModel && (
                          <div className="space-y-1 bg-background/50 p-2.5 rounded border border-border">
                            <div className="flex justify-between text-[10px] items-center">
                              <span className="font-bold text-primary">Pulling {pullingModel}...</span>
                              <span className="font-mono text-muted-foreground text-[9px]">{pullProgress}</span>
                            </div>
                            <div className="w-full bg-muted rounded-full h-1.5 overflow-hidden">
                              <div 
                                className="bg-primary h-full transition-all duration-300"
                                style={{ width: pullProgress.includes('%') ? pullProgress.match(/\((\d+)%\)/)?.[1] + '%' : '30%' }}
                              />
                            </div>
                          </div>
                        )}

                        {ollamaStatus === 'error' && (
                          <p className="text-[10px] text-destructive leading-normal border border-destructive/10 bg-destructive/5 p-2 rounded">
                            Could not reach Ollama at <strong>{settings.ollamaUrl || 'http://127.0.0.1:11434'}</strong>. Ensure it's running with CORS enabled (e.g. <code>OLLAMA_ORIGINS="*" ollama serve</code>).
                          </p>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-between px-1">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Available Models</span>
                      <span className="text-[10px] font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                        {displayedChatModels.length} Found
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 mt-4 font-sans">
                    {displayedChatModels.length > 0 ? (
                      displayedChatModels.map(model => {
                      const equippedId = `${settings.provider}:${model.id}`;
                      const isEnabled = (settings.enabledChatModels || []).includes(equippedId);
                      const isVision = (model as any).hasVision;
                      
                      // Determine the display provider
                      let displayProvider;
                      if (settings.provider === 'webllm') {
                        displayProvider = 'WebLLM';
                      } else if (settings.provider === 'ollama') {
                        displayProvider = 'Ollama';
                      } else if (settings.provider === 'openai') {
                        displayProvider = 'OpenAI Compatible';
                      } else {
                        displayProvider = model.provider === 'google' 
                          ? (settings.provider === 'google' ? 'Gemini API' : 'Puter.js')
                          : 'Puter.js';
                      }

                      return (
                        <Tooltip key={model.id} content={`Max Context: ${model.maxContext.toLocaleString()} tokens`} position="top" className="w-full">
                          <div 
                            onClick={() => {
                              const equippedId = `${settings.provider}:${model.id}`;
                              const currentEnabled = settings.enabledChatModels || [];
                              const isEnabled = currentEnabled.includes(equippedId);
                              
                              let nextEnabled;
                              if (isEnabled) {
                                nextEnabled = currentEnabled.filter(id => id !== equippedId);
                              } else {
                                nextEnabled = [...currentEnabled, equippedId];
                              }

                              setSettings({ 
                                ...settings, 
                                enabledChatModels: nextEnabled,
                                puterModel: isEnabled ? (settings.puterModel === equippedId ? (nextEnabled[0] || '') : settings.puterModel) : equippedId
                              });
                            }}
                            className={cn(
                              "group p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between w-full",
                              isEnabled
                                ? "border-primary bg-primary/5 shadow-sm" 
                                : "border-border hover:border-primary/50 hover:bg-muted/30"
                            )}
                          >
                            <div className="flex items-center gap-4 min-w-0">
                              <div className={cn(
                                "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-105",
                                isEnabled
                                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                                  : "bg-muted text-muted-foreground"
                              )}>
                                <Cpu className="w-5 h-5" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <h3 className="text-sm font-bold truncate">{model.name}</h3>
                                  {isEnabled && <Check className="w-3.5 h-3.5 text-primary" />}
                                </div>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className={cn(
                                    "text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-tighter border",
                                    displayProvider === 'WebLLM'
                                      ? "bg-purple-500/10 text-purple-500 border-purple-500/20"
                                      : displayProvider === 'Gemini API' 
                                      ? "bg-orange-500/10 text-orange-500 border-orange-500/20" 
                                      : "bg-blue-500/10 text-blue-500 border-blue-500/20"
                                  )}>
                                    {displayProvider}
                                  </span>
                                  {isVision && (
                                    <span className="text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-tighter bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                                      Visual
                                    </span>
                                  )}
                                  <span className="text-[9px] text-muted-foreground opacity-60">
                                    CTX: {(model.maxContext / 1000)}k
                                  </span>
                                </div>
                                {((model as any).inputPrice || (model as any).outputPrice) && (
                                  <div className="text-[10px] text-muted-foreground mt-1 font-medium flex items-center gap-1 opacity-80">
                                    <span className="text-emerald-500">In:</span> {(model as any).inputPrice} 
                                    <span className="mx-1">•</span> 
                                    <span className="text-emerald-500">Out:</span> {(model as any).outputPrice}
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {settings.provider === 'webllm' && (
                                <div className="flex items-center gap-2">
                                  {loadedWebLlmModels[model.id] ? (
                                    <>
                                      <button
                                        onClick={(e) => handleDeleteCache(model.id, e)}
                                        className="px-2 py-1 rounded border border-destructive/20 text-destructive hover:bg-destructive text-[9px] hover:text-white uppercase font-bold tracking-widest transition-colors flex items-center gap-1"
                                      >
                                        <Trash2 className="w-3 h-3" />
                                        Delete Cache
                                      </button>
                                      {engineLoadedModelId === model.id ? (
                                        <div className="px-2 py-1 rounded border border-green-500/20 text-green-500 bg-green-500/10 text-[9px] uppercase tracking-widest font-bold flex items-center gap-1">
                                          <ShieldCheck className="w-3 h-3" />
                                          Loaded
                                        </div>
                                      ) : (
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            onLoadModel(model.id, equippedId);
                                          }}
                                          disabled={!!downloadingModelId}
                                          className="px-2 py-1 rounded border border-primary/20 text-primary hover:bg-primary text-[9px] hover:text-white uppercase font-bold tracking-widest transition-colors flex items-center gap-1"
                                        >
                                          {downloadingModelId === model.id ? (
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                          ) : (
                                            <Zap className="w-3 h-3" />
                                          )}
                                          Load
                                        </button>
                                      )}
                                      <div className="px-2 py-1 rounded border border-emerald-500/20 text-emerald-500 bg-emerald-500/10 text-[9px] uppercase tracking-widest font-bold">
                                        Cached
                                      </div>
                                    </>
                                  ) : (
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        onLoadModel(model.id, equippedId);
                                      }}
                                      disabled={!!downloadingModelId}
                                      className={cn(
                                        "px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all border",
                                        "bg-primary text-primary-foreground border-primary hover:scale-105 shadow-md shadow-primary/20",
                                        downloadingModelId === model.id && "opacity-50 cursor-wait"
                                      )}
                                    >
                                      {downloadingModelId === model.id ? "Downloading..." : "Download"}
                                    </button>
                                  )}
                                </div>
                              )}
                              <div className={cn(
                                "w-5 h-5 rounded-full border flex items-center justify-center transition-colors",
                                isEnabled ? "border-primary bg-primary" : "border-border"
                              )}>
                                {isEnabled && <Check className="w-3 h-3 text-white" />}
                              </div>
                            </div>
                          </div>
                        </Tooltip>
                      );
                    })
                  ) : (
                    <div className="p-8 text-center border-2 border-dashed border-border rounded-2xl">
                      <Cpu className="w-8 h-8 text-muted-foreground/20 mx-auto mb-2" />
                      <p className="text-xs text-muted-foreground font-medium">No models available for this provider</p>
                    </div>
                  )}

                  {/* Puter.js models are now filtered through the main list */}
                </div>
              </div>
            )}
            </div>

            <div className="p-4 sm:p-6 border-t border-border bg-muted/30">
               {!!downloadingModelId && (
                 <div className="mb-4 space-y-2">
                   <div className="flex items-center justify-between">
                     <span className="text-[10px] font-bold uppercase tracking-widest text-primary">Downloading WebLLM Engine...</span>
                     <Loader2 className="w-4 h-4 text-primary animate-spin" />
                   </div>
                   <div className="text-[10px] text-muted-foreground font-mono bg-background/50 p-2 rounded-lg border border-border/50 break-words">
                     {webLlmProgress || "Initializing..."}
                   </div>
                 </div>
               )}
               <div className="flex items-center justify-between gap-4">
                 <div className="hidden sm:block text-[10px] text-muted-foreground uppercase font-bold tracking-widest pl-2">
                    {step === 'model' && `${(settings.enabledChatModels || []).length} models equipped`}
                    {step !== 'model' && `Step ${step === 'provider' ? '1' : '2'} of 3`}
                 </div>
                 <button 
                  onClick={handleFinishSetup}
                  className={cn(
                    "w-full sm:w-auto px-8 py-3 rounded-xl font-bold text-sm transition-all shadow-lg border",
                    (step === 'model' && (settings.enabledChatModels || []).length > 0 && !downloadingModelId) 
                      ? "bg-primary text-primary-foreground border-primary shadow-primary/20 hover:scale-102"
                      : "bg-muted text-muted-foreground border-border/50 cursor-not-allowed opacity-50"
                  )}
                  disabled={
                    (step === 'model' && (settings.enabledChatModels || []).length === 0) || !!downloadingModelId
                  }
                >
                  {downloadingModelId ? "Downloading Engine..." : step === 'model' ? "Save & Close" : "Continue"}
                </button>
               </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
