import { RefreshCw, Database, Cloud, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SyncConflictModalProps {
  isOpen: boolean;
  localCount: number;
  remoteCount: number;
  onResolve: (action: 'keep_local' | 'overwrite_cloud' | 'merge') => void;
}

export function SyncConflictModal({ isOpen, localCount, remoteCount, onResolve }: SyncConflictModalProps) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md select-none">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ type: 'spring', duration: 0.4 }}
          className="bg-slate-900 border border-slate-800 text-slate-100 rounded-3xl max-w-lg w-full shadow-2xl p-6 sm:p-8 flex flex-col space-y-5"
        >
          {/* Header */}
          <div className="flex items-center gap-3.5 border-b border-slate-800 pb-4">
            <div className="relative flex items-center justify-center w-11 h-11 bg-amber-500/10 text-amber-400 rounded-2xl">
              <AlertTriangle className="w-5.5 h-5.5" />
            </div>
            <div>
              <h2 className="text-lg font-bold tracking-tight text-white">Google Drive Backup Out-Of-Sync</h2>
              <p className="text-xs text-slate-400 font-mono">RESOLVE SYNCHRONIZATION CONFLICT</p>
            </div>
          </div>

          {/* Description Block */}
          <div className="space-y-4 text-sm leading-relaxed text-slate-300">
            <p className="text-xs text-slate-400">
              A difference has been detected between your local browser database and your recent Google Drive backup. Choose how you would like to handle this conflict.
            </p>

            {/* Statistics comparison */}
            <div className="grid grid-cols-2 gap-3 bg-slate-950/40 p-4 rounded-2xl border border-slate-800/60">
              <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/40 border border-slate-800">
                <Database className="w-5 h-5 text-indigo-400 mb-1" />
                <span className="text-xs text-slate-400 font-medium">Local Browser</span>
                <span className="text-lg font-extrabold text-indigo-200 mt-1">{localCount} {localCount === 1 ? 'chat' : 'chats'}</span>
              </div>
              <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/40 border border-slate-800">
                <Cloud className="w-5 h-5 text-sky-400 mb-1" />
                <span className="text-xs text-slate-400 font-medium font-sans">Google Drive</span>
                <span className="text-lg font-extrabold text-sky-200 mt-1">{remoteCount} {remoteCount === 1 ? 'chat' : 'chats'}</span>
              </div>
            </div>

            {/* Choices descriptions */}
            <div className="space-y-3 pt-1 max-h-60 overflow-y-auto pr-1">
              {/* Option 1: Overwrite with Cloud */}
              <button
                onClick={() => onResolve('overwrite_cloud')}
                className="w-full text-left p-3.5 rounded-2xl bg-slate-900/30 hover:bg-sky-500/10 border border-slate-800 hover:border-sky-500/30 transition-all duration-200 cursor-pointer group"
              >
                <div className="flex items-center gap-2.5 font-bold text-sky-400 text-sm mb-1 group-hover:text-sky-300">
                  <Cloud className="w-4 h-4 shrink-0" />
                  <span>Overwrite Local with Cloud ({remoteCount} Chats)</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal pl-6">
                  Replace all browser chats with your Google Drive backup. Best if your browser's data is outdated.
                </p>
              </button>

              {/* Option 2: Keep Local */}
              <button
                onClick={() => onResolve('keep_local')}
                className="w-full text-left p-3.5 rounded-2xl bg-slate-900/30 hover:bg-indigo-500/10 border border-slate-800 hover:border-indigo-500/30 transition-all duration-200 cursor-pointer group"
              >
                <div className="flex items-center gap-2.5 font-bold text-indigo-400 text-sm mb-1 group-hover:text-indigo-300">
                  <Database className="w-4 h-4 shrink-0" />
                  <span>Keep Local State ({localCount} Chats)</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal pl-6">
                  Overwrite Google Drive with your local browser database. Recommended if you did offline edits.
                </p>
              </button>

              {/* Option 3: Merge Side-by-Side */}
              <button
                onClick={() => onResolve('merge')}
                className="w-full text-left p-3.5 rounded-2xl bg-teal-950/20 hover:bg-teal-500/10 border border-teal-900/30 hover:border-teal-500/30 transition-all duration-200 cursor-pointer group"
              >
                <div className="flex items-center gap-2.5 font-bold text-teal-400 text-sm mb-1 group-hover:text-teal-300">
                  <RefreshCw className="w-4 h-4 shrink-0" />
                  <span>Merge Both Side-by-Side</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal pl-6">
                  Keeps everything. Merges missing chats and creates duplicate copies for overlapping items so you lose absolutely no history.
                </p>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
