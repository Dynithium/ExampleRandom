import React, { useState, useRef, useEffect, useCallback } from 'react';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import { 
  Play, 
  Terminal, 
  RotateCcw, 
  Download, 
  Copy, 
  Check, 
  Maximize2, 
  Minimize2, 
  X,
  FileCode,
  Sparkles,
  Wand2,
  ChevronDown,
  User,
  Bot,
  ArrowRight,
  Trash2,
  PlusCircle,
  Palette,
  CheckSquare,
  Info,
  FolderOpen,
  FilePlus2,
  AlignLeft,
  GitCommit,
  Circle,
  CheckCircle2,
  Loader,
  Layout,
  AlertTriangle,
  Plus,
  Mic,
  Square
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, cleanMessage } from '../utils';
import { Tooltip } from './Tooltip';
import { getCompletion } from '../services/llm';
import { executePythonCode } from '../services/pythonSandbox';
import { Settings } from '../db';
import { VoiceInterface } from './VoiceInterface';

interface PythonPlaygroundProps {
  initialCode?: string;
  onRun: (code: string) => Promise<{ stdout: string, plot: string | null }>;
  isOpen: boolean;
  onClose: () => void;
  settings: Settings;
  chatModels: any[];
  getModelInfo: (id: string) => any;
  initialProjectId?: string;
}

export const PythonPlayground: React.FC<PythonPlaygroundProps> = ({ 
  initialCode = '# Welcome to the Python Playground\nprint("Hello from Python!")\n\n# Try plotting something\nimport matplotlib.pyplot as plt\nimport numpy as np\n\nx = np.linspace(0, 10, 100)\ny = np.sin(x)\n\nplt.plot(x, y, color="indigo")\nplt.title("Sine Wave")\nplt.show()',
  isOpen,
  onClose,
  settings,
  chatModels,
  getModelInfo,
  initialProjectId
}) => {
  // Global Project Registry structures loaded from local storage for python playground if available
  const [projects, setProjects] = useState<Record<string, { id: string; name: string; description: string; lastModified: number; fs: Record<string, string> }>>(() => {
    try {
      const stored = localStorage.getItem("gemini_python_projects");
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);

  useEffect(() => {
    if (initialProjectId && projects[initialProjectId]) {
      // Find the project and launch it
      const proj = projects[initialProjectId];
      if (proj && proj.fs) {
        setActiveProjectId(initialProjectId);
        setVirtualFS(proj.fs);
        const firstFile = Object.keys(proj.fs)[0] || 'main.py';
        setActiveFileName(firstFile);
      }
    }
  }, [initialProjectId]);

  // Custom non-blocking Confirm Dialog state to bypass iframe modal limitations
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    message: string;
    onConfirm: () => void;
  } | null>(null);

  // Active files and folders inside workspace sandbox
  const [virtualFS, setVirtualFS] = useState<Record<string, string>>({
    'main.py': initialCode,
    'helper.py': `# Supplementary Python library\n\ndef check_prime(n):\n    if n < 2: return False\n    for i in range(2, int(n**0.5) + 1):\n        if n % i == 0:\n            return False\n    return True`
  });

  const [activeFileName, setActiveFileName] = useState<string>('main.py');
  const [output, setOutput] = useState<string>('');
  const [plot, setPlot] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [activeTab, setActiveTab] = useState<'console' | 'plot' | 'pygame'>('console');
  const [selectedModel, setSelectedModel] = useState(() => {
    if (settings.enabledChatModels && settings.enabledChatModels.length > 0) {
      if (settings.puterModel && settings.enabledChatModels.includes(settings.puterModel)) {
        return settings.puterModel;
      }
      return settings.enabledChatModels[0];
    }
    return settings.puterModel || 'puter:gemini-3.5-flash';
  });
  const [showVibe, setShowVibe] = useState(true);
  const [vibePrompt, setVibePrompt] = useState('');
  const [isVibing, setIsVibing] = useState(false);
  const [vibeSuggestion, setVibeSuggestion] = useState<{ filepath: string; content: string }[] | null>(null);
  const [vibeMessages, setVibeMessages] = useState<{ role: 'user' | 'assistant', content: string }[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  
  const [isMonacoLoaded, setIsMonacoLoaded] = useState(false);
  
  // Multi-Agent Pipeline tracking progress states
  const [isMultiAgentMode, setIsMultiAgentMode] = useState(false);
  const [multiAgentStep, setMultiAgentStep] = useState<number | null>(null); // null means idle, index 0 to 4 shows progress
  const [multiAgentReport, setMultiAgentReport] = useState<string>('');

  // Modals visibility state
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [showRenameFileModal, setShowRenameFileModal] = useState(false);
  const [renameOldName, setRenameOldName] = useState('');
  const [renameNewName, setRenameNewName] = useState('');
  
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [newProjectTemplate, setNewProjectTemplate] = useState('sinewave');

  // Human in the Loop configuration
  const [hitlEnabled, setHitlEnabled] = useState(true);

  // Persistent editor reference to inject changes directly
  const editorRef = useRef<any>(null);
  const editorContainerRef = useRef<HTMLDivElement>(null);

  const templates = {
    sinewave: {
      'main.py': `# Sine Wave Chart Visualizer\nimport matplotlib.pyplot as plt\nimport numpy as np\n\nx = np.linspace(0, 10, 100)\ny = np.sin(x)\n\nplt.plot(x, y, color="indigo", linewidth=2)\nplt.title("Matplotlib Wave Function")\nplt.grid(True)\nplt.show()`,
      'helper.py': `# Supplementary library`
    },
    barchart: {
      'main.py': `# Complete NumPy Multi-Bar Chart\nimport matplotlib.pyplot as plt\nimport numpy as np\n\ncategories = ["A", "B", "C", "D", "E"]\nvalues = [15, 24, 30, 8, 12]\n\nplt.bar(categories, values, color="teal")\nplt.title("Categorical Analytics")\nplt.xlabel("Sample Groups")\nplt.ylabel("Scores")\nplt.show()`,
      'helper.py': `# Supplementary library`
    },
    pygame: {
      'main.py': `# Interactive Keyboard Canvas\nimport pygame\nimport sys\n\npygame.init()\nscreen = pygame.display.set_mode((400, 400))\nclock = pygame.time.Clock()\nx, y = 200, 200\n\nprint("Launching game loop inside visual sandbox...")\nfor i in range(120):\n    screen.fill((20, 20, 30))\n    pygame.draw.circle(screen, (99, 102, 241), (x, y), 35)\n    pygame.display.flip()\n    x += 1\n    clock.tick(30)\n\nprint("Animation run complete.")`
    }
  };

  const getLanguageFromExtension = (filename: string) => {
    if (filename.endsWith('.py')) return 'python';
    if (filename.endsWith('.json')) return 'json';
    return 'plaintext';
  };

  // RequireJS/Monaco loader helper
  useEffect(() => {
    const loadMonaco = () => {
      const windowWithRequire = window as any;
      if (windowWithRequire.require) {
        windowWithRequire.require.config({ 
          paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.39.0/min/vs' }
        });

        if (windowWithRequire.define && windowWithRequire.define.amd) {
          windowWithRequire.define('jszip', [], () => (window as any).JSZip);
        }

        windowWithRequire.require(['vs/editor/editor.main'], () => {
          setIsMonacoLoaded(true);
        });
      }
    };

    if (!(window as any).require) {
      const script = document.createElement('script');
      script.src = "https://cdnjs.cloudflare.com/ajax/libs/require.js/2.3.6/require.min.js";
      script.async = true;
      script.onload = loadMonaco;
      document.body.appendChild(script);
    } else {
      loadMonaco();
    }
  }, []);

  // Sync editor with active file
  useEffect(() => {
    if (isMonacoLoaded && editorContainerRef.current) {
      const monaco = (window as any).monaco;
      
      // Define a pure black background theme
      monaco.editor.defineTheme('pythonBlack', {
        base: 'vs-dark',
        inherit: true,
        rules: [
          { token: 'comment', foreground: '5c6370', fontStyle: 'italic' },
          { token: 'keyword', foreground: 'c678dd' },
          { token: 'string', foreground: '98c379' },
          { token: 'number', foreground: 'd19a66' }
        ],
        colors: {
          'editor.background': '#000000',
          'editor.lineHighlightBackground': '#111111',
          'editorLineNumber.foreground': '#5c6370'
        }
      });

      if (!editorRef.current) {
        editorRef.current = monaco.editor.create(editorContainerRef.current, {
          value: virtualFS[activeFileName] || '',
          language: getLanguageFromExtension(activeFileName),
          theme: 'pythonBlack',
          automaticLayout: true,
          fontSize: 13,
          tabSize: 4,
          minimap: { enabled: true },
          autoIndent: 'full',
          formatOnPaste: true,
          formatOnType: true,
          wordWrap: 'on'
        });

        editorRef.current.onDidChangeModelContent(() => {
          const val = editorRef.current.getValue();
          setVirtualFS(prev => ({ ...prev, [activeFileName]: val }));
        });
      } else {
        const currentModel = editorRef.current.getModel();
        if (currentModel) {
          if (editorRef.current.getValue() !== (virtualFS[activeFileName] || '')) {
            editorRef.current.setValue(virtualFS[activeFileName] || '');
          }
          monaco.editor.setModelLanguage(currentModel, getLanguageFromExtension(activeFileName));
        }
        monaco.editor.setTheme('pythonBlack');
      }
    }
  }, [isMonacoLoaded, activeFileName, activeProjectId]);

  // Sync projects state and save local changes when virtualFS updates
  useEffect(() => {
    if (activeProjectId && projects[activeProjectId]) {
      const updatedProjects = { ...projects };
      updatedProjects[activeProjectId].fs = virtualFS;
      setProjects(updatedProjects);
      localStorage.setItem("gemini_python_projects", JSON.stringify(updatedProjects));
    }
  }, [virtualFS, activeProjectId]);

  const launchProjectIDE = (projId: string) => {
    setActiveProjectId(projId);
    const proj = projects[projId];
    if (proj && proj.fs) {
      setVirtualFS(proj.fs);
      const firstFile = Object.keys(proj.fs)[0] || 'main.py';
      setActiveFileName(firstFile);
    }
  };

  const loadTemplate = (key: keyof typeof templates) => {
    const templateFS = templates[key];
    setVirtualFS(templateFS);
    const firstFile = Object.keys(templateFS)[0];
    setActiveFileName(firstFile);

    if (activeProjectId && projects[activeProjectId]) {
      const updatedProjects = { ...projects };
      updatedProjects[activeProjectId].fs = templateFS;
      setProjects(updatedProjects);
      localStorage.setItem("gemini_python_projects", JSON.stringify(updatedProjects));
    }
  };

  const handleRun = async () => {
    setIsRunning(true);
    setOutput('Loading Pyodide Runtime & Libraries...\n');
    setPlot(null);

    // Assembly imports to load custom helper modules before main execution
    let fullExecutionCode = "";
    Object.keys(virtualFS).forEach(filepath => {
      if (filepath !== 'main.py' && filepath.endsWith('.py')) {
        const modName = filepath.replace('.py', '');
        fullExecutionCode += `# --- Module: ${filepath} ---\nwith open('${filepath}', 'w') as f:\n    f.write("""${virtualFS[filepath].replace(/"""/g, '\\"\\"\\""')}""")\n\n`;
      }
    });
    fullExecutionCode += virtualFS['main.py'] || '';

    try {
      const result = await executePythonCode(fullExecutionCode, (agent, text) => {
        setOutput(prev => prev + `[${agent}] ${text}\n`);
      });

      setOutput(result.stdout || 'Code finished executing with clean returns.');
      if (result.plot) {
        setPlot(result.plot);
        setActiveTab('plot');
      } else if (virtualFS['main.py']?.includes('pygame')) {
        setActiveTab('pygame');
      } else {
        setActiveTab('console');
      }
    } catch (e: any) {
      setOutput(`Python Error Exception caught: ${e.message || e}`);
      setActiveTab('console');
    } finally {
      setIsRunning(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(virtualFS[activeFileName] || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([virtualFS[activeFileName] || ''], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Modern Multi-Agent design runner
  const handleOrchestratedVibe = async (userPrompt: string) => {
    abortControllerRef.current = new AbortController();
    setMultiAgentStep(1);
    setMultiAgentReport('Milestone 1: Mapping workspace variables and orchestrating script targets...');
    
    let workspaceContext = "";
    Object.keys(virtualFS).forEach(file => {
      workspaceContext += `\n--- FILE PATH: ${file} ---\n${virtualFS[file]}\n`;
    });

    try {
      const orchestratorInstruction = `You are a Lead Project Orchestrator.
Analyze the user goal and create a detailed multi-agent plan detailing exactly what updates, helper classes, or formulas are required.

Return a structured JSON with:
{
  "milestones": ["Milestone 1:...", "Milestone 2:...", "Milestone 3:..."],
  "architectPrompt": "Instructions emphasizing numeric constraints, layout constraints, formulas, or visualizations",
  "developerPrompt": "Instructions prioritizing variables, matplotlib rendering, numpy equations, and python function models"
}`;

      const orchResponse = await getCompletion({
        messages: [
          { role: 'system', content: orchestratorInstruction },
          { role: 'user', content: `Goal: ${userPrompt}\n\nWorkspace:\n${workspaceContext}` }
        ],
        config: { temperature: 0.5, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const orchText = orchResponse.choices[0]?.message?.content || '';
      const planJSON = JSON.parse(orchText.slice(orchText.indexOf('{'), orchText.lastIndexOf('}') + 1));

      setMultiAgentStep(2);
      setMultiAgentReport('Milestone 2: Structuring algorithm models & validation schema constraints...');

      const architectInstruction = `You are an expert Math Analyst & Architect.
Formulate a system design based on these planning instructions:
${planJSON.architectPrompt}

Current Workspace:
${workspaceContext}`;

      const archResponse = await getCompletion({
        messages: [
          { role: 'system', content: architectInstruction },
          { role: 'user', content: `Refine architecture design layout for Python script implementation.` }
        ],
        config: { temperature: 0.4, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const designBrief = archResponse.choices[0]?.message?.content || '';

      setMultiAgentStep(3);
      setMultiAgentReport('Milestone 3: Translating equation vectors and executing script updates...');

      const devInstruction = `You are a Senior Python Engineer.
Modify the workspace files based on previous planning instructions and architect design specifications:
${planJSON.developerPrompt}

Architect specs:
${designBrief}

Workspace context:
${workspaceContext}

Return ONLY a valid, parseable JSON conforming to this schema (no markdown formatting, just raw JSON array output):
{
  "files": [
    {
      "filepath": "main.py",
      "action": "write",
      "content": "Full corrected, pristine code for main.py here..."
    }
  ]
}`;

      const devResponse = await getCompletion({
        messages: [
          { role: 'system', content: devInstruction },
          { role: 'user', content: `Implement all requested algorithmic python developments.` }
        ],
        config: { temperature: 0.3, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const devText = devResponse.choices[0]?.message?.content || '';
      const devJSON = JSON.parse(devText.slice(devText.indexOf('{'), devText.lastIndexOf('}') + 1));

      setMultiAgentStep(4);
      setMultiAgentReport('Milestone 4: Performing code formatting checks...');

      const qcInstruction = `You are an expert Quality Assurance Engineer.
Review the developer files below, audit for indentation correctness, syntax robustness, and import issues (numpy, matplotlib.pyplot, etc.).

Developer Code:
${JSON.stringify(devJSON)}

Return ONLY a valid parseable JSON conforming to:
{
  "explanation": "Report on alignment, clean formatting corrections, and algorithmic optimizations applied",
  "files": [
    {
      "filepath": "main.py",
      "action": "write",
      "content": "Formatted pristine script content here..."
    }
  ]
}`;

      const qcResponse = await getCompletion({
        messages: [
          { role: 'system', content: qcInstruction },
          { role: 'user', content: `Developer Code: ${JSON.stringify(devJSON)}\n\nOriginal Context:\n${workspaceContext}` }
        ],
        config: { temperature: 0.2, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const qcText = qcResponse.choices[0]?.message?.content || '';
      const qcJSON = JSON.parse(qcText.slice(qcText.indexOf('{'), qcText.lastIndexOf('}') + 1));

      // Assemble initial target File System proposed by the pipeline
      let currentFS = { ...virtualFS };
      qcJSON.files.forEach((f: any) => {
        if (f.action === 'write') currentFS[f.filepath] = f.content;
      });

      setMultiAgentStep(4);
      setMultiAgentReport('Executing Python code and verifying algorithm validity...');

      let healingAttempts = 0;
      const MAX_HEALING_ATTEMPTS = 3;
      let errorsFound = true;

      while (errorsFound && healingAttempts < MAX_HEALING_ATTEMPTS) {
        // Construct the full execution Python code of proposed FS state
        let fullExecutionCode = "";
        Object.keys(currentFS).forEach(filepath => {
          if (filepath !== 'main.py' && filepath.endsWith('.py')) {
            fullExecutionCode += `# --- Module: ${filepath} ---\nwith open('${filepath}', 'w') as f:\n    f.write("""${currentFS[filepath].replace(/"""/g, '\\"\\"\\""')}""")\n\n`;
          }
        });
        fullExecutionCode += currentFS['main.py'] || '';

        try {
          await executePythonCode(fullExecutionCode, (agent, text) => {
            // Silence console during auto-validation
          });
          errorsFound = false; // Runs perfectly!
        } catch (pyErr: any) {
          healingAttempts++;
          const errorMsg = pyErr.message || String(pyErr);
          setMultiAgentReport(`Python crash detected (Attempt ${healingAttempts}/${MAX_HEALING_ATTEMPTS}). Self-healing...`);

          const healInstruction = `You are a self-healing python debugger. The workspace code crashed during WebAssembly pyodide runtime execution.
Read the exception message, locate the invalid modules or coding bugs, and correct the files.

Make sure you respect the limits of the Pyodide/Emscripten browser sandbox you are in.
[PYTHON SANDBOX LIMITATIONS]:
- Runs in Pyodide, a WebAssembly-based Python engine inside the browser.
- Pre-installed libraries: numpy, pandas, matplotlib, micropip, pygame-ce (with HTML canvas emscripten support).
- Core restrictions:
  1. No real local filesystem access outside Pyodide's virtual environment.
  2. No system/subprocess shell commands (e.g. subprocess, os.system, os.popen, sh).
  3. No Tkinter/standard desktop GUI access (pygame is emulation-supported, but Tkinter will fail).
  4. No persistent server frameworks, async TCP socket listeners, or background server workers (no real FastAPI/Flask servers binding to network ports).

Return ONLY structured JSON conforming to:
{
  "explanation": "Summarized debug fix explanation",
  "files": [
    {
      "filepath": "main.py",
      "action": "write",
      "content": "Fully corrected exact file code..."
    }
  ]
}`;

          const healResponse = await getCompletion({
            messages: [
              { role: 'system', content: healInstruction },
              { role: 'user', content: `Goal: ${userPrompt}\n\nWorkspace State:\n${JSON.stringify(currentFS)}\n\nRuntime Python Exception Caught:\n${errorMsg}` }
            ],
            config: { temperature: 0.1, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
            settings
          });

          const healContentText = healResponse.choices[0]?.message?.content || '';
          try {
            const healJSON = JSON.parse(healContentText.slice(healContentText.indexOf('{'), healContentText.lastIndexOf('}') + 1));
            if (healJSON.files && healJSON.files.length > 0) {
              healJSON.files.forEach((f: any) => {
                if (f.action === 'write') currentFS[f.filepath] = f.content;
              });
            }
          } catch (errParse) {
            console.error("Failed to parse heal JSON in python pipeline", errParse);
            break;
          }
        }
      }

      setMultiAgentStep(null);
      setMultiAgentReport('Streaming finalized changes...');

      if (hitlEnabled) {
        const suggestionList = Object.keys(currentFS).map(path => ({
          filepath: path,
          action: 'write' as const,
          content: currentFS[path]
        }));
        setVibeSuggestion(suggestionList);
        setVibeMessages(prev => [...prev, { 
          role: 'assistant', 
          content: `📋 **Multi-Agent Pyodide Pipeline Completed!**\n\n${qcJSON.explanation}\n\n*Evaluation: ${healingAttempts > 0 ? `Resolved Python runtime exceptions after applying ${healingAttempts} healing correction loop(s).` : 'Python scripts validate cleanly on Pyodide run with no exceptions.'}*` 
        }]);
      } else {
        setVirtualFS(currentFS);
        if (activeProjectId && projects[activeProjectId]) {
          const updatedProjects = { ...projects };
          updatedProjects[activeProjectId].fs = currentFS;
          setProjects(updatedProjects);
          localStorage.setItem("gemini_python_projects", JSON.stringify(updatedProjects));
        }
        setVibeMessages(prev => [...prev, { 
          role: 'assistant', 
          content: `${qcJSON.explanation}\n\n*Evaluation: ${healingAttempts > 0 ? `Successfully corrected runtime crashes in ${healingAttempts} loop(s).` : 'Code verification completed; scripts are running seamlessly.'}*` 
        }]);
      }

    } catch (e: any) {
      setVibeMessages(prev => [...prev, { role: 'assistant', content: `Workflow exception occurred: ${e.message}` }]);
    } finally {
      setMultiAgentStep(null);
    }
  };

  const handleStopVibe = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsVibing(false);
    setMultiAgentStep(null);
    setVibeMessages(prev => [...prev, { role: 'assistant', content: '🛑 AI Generation stopped.' }]);
  };

  const handleVibe = async () => {
    if (!vibePrompt.trim()) return;
    const userMsg = vibePrompt.trim();
    setVibeMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setVibePrompt('');
    abortControllerRef.current = new AbortController();
    setIsVibing(true);

    if (isMultiAgentMode) {
      await handleOrchestratedVibe(userMsg);
      setIsVibing(false);
      return;
    }

    try {
      let workspaceContext = "";
      Object.keys(virtualFS).forEach(file => {
        workspaceContext += `\n--- FILE PATH: ${file} ---\n${virtualFS[file]}\n`;
      });

      const systemPrompt = `You are an expert fullstack python code architect working inside a multi-file browser IDE.
Analyze active workspace files, then generate modifications, create new files, or delete existing modules based on directions.

Current Workspace State:
${workspaceContext}

Return ONLY a valid, parseable JSON conforming to this schema (no markdown formatting wrapping JSON, just raw json):
{
  "explanation": "Conversational report detailing modified elements and why",
  "files": [
    {
      "filepath": "main.py",
      "action": "write",
      "content": "Entire, pristine rewrite of that specific file code here..."
    }
  ]
}`;

      const res = await getCompletion({
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMsg }
        ],
        config: { temperature: 0.3, modelOverride: selectedModel, signal: abortControllerRef.current?.signal },
        settings
      });

      const content = res.choices[0]?.message?.content || '';
      const cleaned = content.slice(content.indexOf('{'), content.lastIndexOf('}') + 1);
      const result = JSON.parse(cleaned);

      if (hitlEnabled) {
        setVibeSuggestion(result.files);
        setVibeMessages(prev => [...prev, { role: 'assistant', content: result.explanation || "Files modified." }]);
      } else {
        const finalFS = { ...virtualFS };
        result.files.forEach((f: any) => {
          if (f.action === 'write') finalFS[f.filepath] = f.content;
        });
        setVirtualFS(finalFS);
        setVibeMessages(prev => [...prev, { role: 'assistant', content: result.explanation }]);
      }

    } catch (error: any) {
      console.error('Vibe error:', error);
      setVibeMessages(prev => [...prev, { role: 'assistant', content: `Error during build routine: ${error.message || 'Execution error'}` }]);
    } finally {
      setIsVibing(false);
    }
  };

  const acceptVibe = () => {
    if (vibeSuggestion) {
      const finalFS = { ...virtualFS };
      vibeSuggestion.forEach(f => {
        if (f.content) finalFS[f.filepath] = f.content;
      });
      setVirtualFS(finalFS);
      setVibeSuggestion(null);
    }
  };

  const discardVibe = () => {
    setVibeSuggestion(null);
  };

  const handleAddNewFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFileName.trim()) return;
    const name = newFileName.trim();
    if (virtualFS[name]) {
      alert("A module already exists with that name.");
      return;
    }
    setVirtualFS(prev => ({ ...prev, [name]: '' }));
    setActiveFileName(name);
    setNewFileName('');
    setShowNewFileModal(false);
  };

  const handleDeleteFile = (name: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDialog({
      title: "Delete Module",
      message: `Are you sure you want to delete module "${name}"? This action cannot be undone.`,
      onConfirm: () => {
        setVirtualFS(prev => {
          const next = { ...prev };
          delete next[name];
          if (activeFileName === name) setActiveFileName(Object.keys(next)[0] || 'main.py');
          return next;
        });
      }
    });
  };

  const handleRenameFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameNewName.trim() || renameNewName === renameOldName) return;
    const oldName = renameOldName;
    const newName = renameNewName.trim();
    if (virtualFS[newName]) {
      alert("Conflict naming module.");
      return;
    }
    setVirtualFS(prev => {
      const next = { ...prev };
      next[newName] = next[oldName];
      delete next[oldName];
      return next;
    });
    if (activeFileName === oldName) setActiveFileName(newName);
    setShowRenameFileModal(false);
  };

  const handleCreateNewProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName.trim()) return;
    const projId = 'proj_' + Date.now();
    const templateFS = templates[newProjectTemplate as keyof typeof templates] || templates.sinewave;
    
    const newProj = {
      id: projId,
      name: newProjectName.trim(),
      description: newProjectDesc.trim() || 'Starting template setup',
      lastModified: Date.now(),
      fs: templateFS
    };

    const updatedProjects = { ...projects, [projId]: newProj };
    setProjects(updatedProjects);
    localStorage.setItem("gemini_python_projects", JSON.stringify(updatedProjects));

    setActiveProjectId(projId);
    setVirtualFS(templateFS);
    setActiveFileName(Object.keys(templateFS)[0]);
    
    setNewProjectName('');
    setNewProjectDesc('');
    setShowNewProjectModal(false);
  };

  const handleDeleteProject = (projId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDialog({
      title: "Delete Python Application",
      message: "Are you completely sure you want to permanently delete this sandbox application? All workspace files inside it will be lost.",
      onConfirm: () => {
        const updatedProjects = { ...projects };
        delete updatedProjects[projId];
        setProjects(updatedProjects);
        localStorage.setItem("gemini_python_projects", JSON.stringify(updatedProjects));

        if (activeProjectId === projId) {
          setActiveProjectId(null);
        }
      }
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ 
          opacity: 1, 
          scale: 1, 
          y: 0,
          width: isMaximized ? '100%' : '95%',
          height: isMaximized ? '100%' : '92%',
          maxWidth: isMaximized ? 'none' : '1550px'
        }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className={cn(
          "bg-card border border-border shadow-2xl flex flex-col overflow-hidden transition-all duration-300 h-full",
          isMaximized ? "rounded-none" : "rounded-3xl"
        )}
      >
        {/* Header */}
        <div className="p-4 border-b border-border flex items-center justify-between bg-muted/45 shrink-0 select-none">
          <div className="flex items-center gap-3">
            {activeProjectId && (
              <button 
                onClick={() => setActiveProjectId(null)}
                className="p-1.5 hover:bg-accent rounded-lg text-muted-foreground hover:text-foreground transition flex items-center justify-center border border-border"
                title="Back to Dashboard"
              >
                <ChevronDown className="w-4 h-4 rotate-90" />
              </button>
            )}
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold tracking-tight">
                  {activeProjectId ? projects[activeProjectId]?.name : "Python Playground"}
                </h2>
                <span className="text-[10px] bg-blue-950 text-blue-400 font-extrabold px-2 py-0.5 rounded border border-blue-900 font-mono">PLAYGROUND ENGINE</span>
              </div>
              <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest leading-none mt-1">
                {activeProjectId ? "Sandbox Workspace" : "Python Scripts & Algorithms"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {activeProjectId && (
              <>
                <button 
                  onClick={() => setShowVibe(!showVibe)}
                  className={cn(
                    "flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border",
                    showVibe ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20" : "bg-muted/50 border-border hover:bg-accent text-muted-foreground"
                  )}
                >
                  <Sparkles className={cn("w-3.5 h-3.5", showVibe && "animate-pulse")} />
                  AI Copilot
                </button>
              </>
            )}

            <div className="h-4 w-px bg-border mx-1" />
            <Tooltip content="Close Sandbox">
              <button onClick={onClose} className="p-2 hover:bg-destructive/10 hover:text-destructive rounded-xl text-muted-foreground transition-colors">
                <X className="w-5 h-5" />
              </button>
            </Tooltip>
          </div>
        </div>

        {/* Dynamic Display */}
        <div className="flex-1 flex overflow-hidden relative">

          {/* SCREEN A: PROJECTS GRID (Home Dashboard) */}
          <AnimatePresence>
            {!activeProjectId && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-zinc-950 flex flex-col p-8 overflow-y-auto"
              >
                <div className="max-w-6xl mx-auto w-full mb-8">
                  <div className="bg-gradient-to-r from-zinc-900 to-blue-950/40 border border-zinc-850 rounded-2xl p-6 md:p-8 relative overflow-hidden shadow-2xl">
                    <div className="absolute -right-16 -top-16 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
                    <div className="max-w-2xl relative z-10">
                      <span className="bg-blue-500/15 text-blue-400 text-[10px] font-extrabold tracking-widest uppercase px-3 py-1 rounded-full border border-blue-500/20">
                        ⚡ Web Playground Studio
                      </span>
                      <h2 className="text-3xl font-extrabold text-zinc-100 tracking-tight mt-3 mb-2">
                        Decompile, Run, or Map Python Algorithms
                      </h2>
                      <p className="text-xs text-zinc-400 leading-relaxed font-medium">
                        Analyze formulas or plot complex graphics. Python executes locally inside high-performance sandbox runtimes.
                      </p>
                      <div className="flex gap-3 mt-6">
                        <button 
                          onClick={() => setShowNewProjectModal(true)}
                          className="flex items-center space-x-2 bg-primary hover:bg-primary/95 text-primary-foreground text-xs font-semibold px-4 py-2.5 rounded-xl transition shadow-lg shadow-primary/15"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Create Python Application</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="max-w-6xl mx-auto w-full flex-1 flex flex-col">
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-3 mb-6">
                    <h3 className="font-bold text-sm tracking-wide uppercase text-zinc-400 flex items-center gap-2">
                      <FolderOpen className="w-4 h-4 text-blue-400" />
                      Python Projects Inventory ({Object.keys(projects).length})
                    </h3>
                  </div>

                  {Object.keys(projects).length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center py-20 text-center animate-fade-in">
                      <p className="text-zinc-500 text-xs italic mb-4">No Python projects loaded yet.</p>
                      <button 
                        onClick={() => setShowNewProjectModal(true)}
                        className="bg-zinc-900 border border-zinc-805 text-zinc-400 px-4 py-2 text-xs font-bold rounded-xl hover:bg-zinc-850"
                      >
                        Create Custom Script
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                      {Object.values(projects).map(p => (
                        <div key={p.id} className="bg-zinc-900/50 border border-zinc-850 p-5 rounded-2xl flex flex-col justify-between hover:border-zinc-700 transition">
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-bold text-sm text-foreground truncate mr-2">{p.name}</h4>
                              <button 
                                onClick={(e) => handleDeleteProject(p.id, e)} 
                                className="p-1 hover:bg-destructive/10 text-muted-foreground hover:text-destructive rounded-lg transition"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                            <p className="text-xs text-muted-foreground leading-normal mb-4 line-clamp-2">{p.description}</p>
                          </div>
                          <div className="flex justify-between items-center pt-3 border-t border-zinc-800">
                            <span className="text-[10px] text-zinc-500 font-bold font-mono">{Object.keys(p.fs || {}).length} files</span>
                            <button 
                              onClick={() => launchProjectIDE(p.id)}
                              className="px-3.5 py-1.5 bg-primary/10 hover:bg-primary hover:text-primary-foreground text-primary border border-primary/20 rounded-xl text-xs font-bold transition flex items-center gap-1"
                            >
                              Open Studio
                              <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* SCREEN B: ACTIVE WORKSPACE RENDERS */}
          {activeProjectId && (
            <div className="flex-1 flex overflow-hidden w-full h-full">

              <AnimatePresence>
                {showVibe && (
                  <motion.div 
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: isMaximized ? 420 : 350, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    className="border-r border-border bg-card flex flex-col overflow-hidden z-30 h-full"
                  >
                    <div className="p-4 border-b border-border flex items-center justify-between bg-primary/5 select-none shrink-0">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-primary" />
                        <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground font-sans">AI Copilot</span>
                      </div>
                      <button onClick={() => setShowVibe(false)} className="p-1 hover:bg-muted rounded-md text-muted-foreground">
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="px-4 py-2.5 border-b border-border bg-muted/20 flex flex-col gap-2 shrink-0">
                      <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                        <button 
                          type="button"
                          onClick={() => setIsMultiAgentMode(!isMultiAgentMode)}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1 bg-zinc-900/60 hover:bg-zinc-800/80 border text-[10px] font-medium rounded-full transition-colors h-7 cursor-pointer select-none shadow-sm",
                            isMultiAgentMode 
                              ? "border-indigo-500/40 text-indigo-400 bg-indigo-500/5 hover:bg-indigo-500/10" 
                              : "border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-zinc-300"
                          )}
                        >
                          <span className={cn("h-1.5 w-1.5 rounded-full", isMultiAgentMode ? "bg-indigo-400 animate-pulse" : "bg-zinc-500")} />
                          <span>{isMultiAgentMode ? "Multi-Agent" : "Single Agent"}</span>
                          <ChevronDown className="w-3 h-3 text-zinc-500" />
                        </button>
                      </div>

                      {multiAgentStep !== null && (
                        <div className="p-3 bg-zinc-950 rounded-xl space-y-2 border border-zinc-800">
                          <div className="flex justify-between items-center text-[10px] font-bold uppercase text-brand-400">
                            <span className="flex items-center gap-1">
                              <Loader className="w-3 h-3 animate-spin text-primary" />
                              {multiAgentReport}
                            </span>
                            <span>{Math.round((multiAgentStep / 4) * 100)}%</span>
                          </div>
                          <div className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden border border-zinc-850">
                            <div style={{ width: `${(multiAgentStep / 4) * 100}%` }} className="bg-brand-500 h-full transition-all duration-300" />
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-background/50">
                      {vibeMessages.length === 0 && (
                        <div className="flex flex-col items-center justify-center h-full text-center gap-4 py-10 opacity-50 select-none">
                          <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                            <Wand2 className="w-6 h-6 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-xs font-bold uppercase tracking-widest text-foreground">AI Assistant Chat</p>
                            <p className="text-[10px] max-w-[200px] leading-normal mx-auto text-muted-foreground">Ask me to modify files, refine formulas, or build analysis equations inside visual sandbox environments.</p>
                          </div>
                        </div>
                      )}
                      
                      {vibeMessages.map((msg, i) => (
                        <div key={i} className={cn(
                          "flex gap-3.5",
                          msg.role === 'user' ? "flex-row-reverse" : "flex-row"
                        )}>
                          <div className={cn(
                            "w-7 h-7 rounded-lg flex items-center justify-center shrink-0 shadow-sm",
                            msg.role === 'user' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                          )}>
                            {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-blue-400" />}
                          </div>
                          <div className={cn(
                            "flex flex-col gap-1 max-w-[85%] min-w-0",
                            msg.role === 'user' ? "items-end" : "items-start"
                          )}>
                            <div className={cn(
                              "p-3.5 rounded-2xl text-xs leading-relaxed shadow-sm block-overflow",
                              msg.role === 'user' ? "bg-primary text-primary-foreground rounded-tr-none" : "bg-card border border-border rounded-tl-none text-slate-200"
                            )}>
                              {msg.role === 'user' ? (
                                msg.content
                              ) : (
                                <div className="markdown-body text-xs prose prose-invert max-w-none">
                                  <Markdown
                                    remarkPlugins={[remarkMath, remarkGfm]}
                                    rehypePlugins={[[rehypeKatex, { output: 'html', throwOnError: false }]]}
                                  >
                                    {cleanMessage(msg.content)}
                                  </Markdown>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                      {isVibing && multiAgentStep === null && (
                        <div className="flex flex-col items-start gap-2">
                          <div className="bg-muted border border-border rounded-xl rounded-tl-none p-4 max-w-[90%] shadow-sm flex items-center gap-3">
                            <RotateCcw className="w-4 h-4 animate-spin text-primary" />
                            <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground animate-pulse font-sans">AI is editing code...</span>
                          </div>
                        </div>
                      )}
                      <div ref={chatEndRef} />
                    </div>

                    {/* Vibe input panel (aligned with normal chat style) */}
                    <div className="p-4 border-t border-border bg-background shrink-0">
                      <div className={cn(
                        "flex flex-col relative transition-all duration-200 border-2 rounded-2xl bg-card border-border/80 shadow-md",
                        "focus-within:border-primary/40 focus-within:shadow-[0_0_15px_rgba(var(--primary),0.04)] hover:border-primary/20"
                      )}>
                        {/* Top action accessories */}
                        <div className="flex items-center justify-between px-3 py-1.5 border-b border-border/30 bg-muted/10 text-[9px] font-bold text-muted-foreground select-none">
                          {/* Model selector dropdown */}
                          <div className="relative flex items-center gap-1 z-10">
                            <Sparkles className="w-2.5 h-2.5 text-primary" />
                            <select 
                              value={selectedModel} 
                              onChange={(e) => setSelectedModel(e.target.value)}
                              className="appearance-none bg-transparent hover:text-foreground font-black uppercase text-[9px] focus:outline-none cursor-pointer text-muted-foreground pr-3"
                            >
                              {(settings.enabledChatModels || []).map(equippedId => {
                                const { modelId, provider, catalogModel } = getModelInfo(equippedId);
                                const displayName = catalogModel?.name || modelId;
                                return (
                                  <option key={equippedId} value={equippedId} className="bg-popover text-foreground">
                                    {provider.toUpperCase()}: {displayName.length > 24 ? displayName.substring(0, 24).toUpperCase() + '...' : displayName.toUpperCase()}
                                  </option>
                                );
                              })}
                            </select>
                            <ChevronDown className="absolute right-0 top-1/2 -translate-y-1/2 w-2.5 h-2.5 opacity-50 pointer-events-none" />
                          </div>

                          {/* HITL activation checkbox */}
                          <div 
                            className="flex items-center gap-1.5 cursor-pointer hover:text-foreground active:opacity-80 transition-colors"
                            onClick={() => setHitlEnabled(!hitlEnabled)}
                          >
                            <span>QA VERIFICATION</span>
                            <input 
                              type="checkbox" 
                              checked={hitlEnabled}
                              onChange={(e) => setHitlEnabled(e.target.checked)}
                              onClick={(e) => e.stopPropagation()}
                              className="w-2.5 h-2.5 rounded bg-muted border-border text-primary cursor-pointer focus:ring-0"
                            />
                          </div>
                        </div>

                        {/* Text input area and Send button */}
                        <div className="flex items-end p-2 gap-2 w-full">
                          <textarea 
                            value={vibePrompt}
                            onChange={(e) => setVibePrompt(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleVibe();
                              }
                            }}
                            placeholder={isVibing ? "AI planning in progress..." : "Instruct AI Code Assistant..."}
                            disabled={isVibing}
                            rows={1}
                            className="flex-1 bg-transparent border-none focus:ring-0 resize-none py-2 text-xs max-h-32 min-h-[36px] overflow-y-auto custom-scrollbar focus:outline-none text-slate-200 placeholder:text-muted-foreground/50"
                          />
                          {isVibing ? (
                            <Tooltip content="Stop Generation">
                              <motion.button 
                                type="button"
                                initial={{ scale: 0.8, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                onClick={handleStopVibe}
                                className="p-2 rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-all shadow-md shrink-0 mb-0.5 cursor-pointer flex items-center justify-center animate-pulse"
                              >
                                <Square className="w-3.5 h-3.5 fill-current" />
                              </motion.button>
                            </Tooltip>
                          ) : (
                            <Tooltip content={vibePrompt.trim() ? "Send Instruction" : "Voice Input"}>
                              <button 
                                onClick={() => vibePrompt.trim() ? handleVibe() : setIsVoiceOpen(true)}
                                className={cn(
                                  "p-2 rounded-xl transition-all shadow-md shrink-0 mb-0.5 cursor-pointer flex items-center justify-center",
                                  vibePrompt.trim() 
                                    ? "bg-primary text-primary-foreground hover:opacity-90" 
                                    : "bg-muted text-muted-foreground hover:bg-accent"
                                )}
                              >
                                {vibePrompt.trim() ? <ArrowRight className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                              </button>
                            </Tooltip>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Central editor structure */}
              <div className="flex-1 flex flex-col min-w-0 bg-background relative h-full">
                
                {/* Visualizer output comparison drawer overlay */}
                <AnimatePresence>
                  {vibeSuggestion && (
                    <motion.div 
                      initial={{ opacity: 0, y: -20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="absolute inset-x-0 top-0 bg-zinc-900 border-b border-zinc-800 p-4 z-40 flex flex-col gap-3 shadow-2xl"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Wand2 className="w-4 h-4 text-indigo-400 animate-pulse" />
                          <h4 className="text-xs font-extrabold uppercase tracking-widest text-zinc-300">AI Proposed Code Changes</h4>
                        </div>
                        <div className="flex items-center gap-2">
                          <button onClick={discardVibe} className="p-1 hover:bg-zinc-850 rounded-md text-muted-foreground"><X className="w-4 h-4" /></button>
                        </div>
                      </div>
                      <p className="text-[11px] text-zinc-400">AI has formulated enhancements for the active workspace. Would you like to check and commit these changes?</p>
                      <div className="flex justify-start gap-2.5">
                        <button 
                          onClick={acceptVibe}
                          className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg text-xs transition shadow-lg shadow-indigo-600/15"
                        >
                          Commit Changes
                        </button>
                        <button 
                          onClick={discardVibe}
                          className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-750 text-zinc-300 border border-zinc-700 rounded-lg text-xs transition"
                        >
                          Discard Changes
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex-1 flex overflow-hidden min-w-0">

                  {/* Left Side: Code Directory Explorer Toolbar */}
                  <div className="w-52 border-r border-border bg-card flex flex-col shrink-0">
                    <div className="p-3 border-b border-border flex items-center justify-between select-none">
                      <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Files</span>
                      <button 
                        onClick={() => setShowNewFileModal(true)}
                        className="p-1 hover:bg-muted text-muted-foreground hover:text-foreground rounded transition"
                      >
                        <FilePlus2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar">
                      {Object.keys(virtualFS).map(name => (
                        <div 
                          key={name}
                          onClick={() => setActiveFileName(name)}
                          className={cn(
                            "group flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs cursor-pointer select-none font-mono transition-all",
                            activeFileName === name 
                              ? "bg-primary/10 text-primary border border-primary/20 font-semibold" 
                              : "text-muted-foreground hover:bg-muted hover:text-foreground"
                          )}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <FileCode className={cn("w-3.5 h-3.5", activeFileName === name ? "text-primary" : "text-muted-foreground/60")} />
                            <span className="truncate">{name}</span>
                          </div>

                          <div className="hidden group-hover:flex items-center gap-1">
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                setRenameOldName(name);
                                setRenameNewName(name);
                                setShowRenameFileModal(true);
                              }}
                              className="text-zinc-500 hover:text-indigo-400 p-0.5"
                            >
                              <Sparkles className="w-3 h-3" />
                            </button>
                            {name !== 'main.py' && (
                              <button 
                                onClick={(e) => handleDeleteFile(name, e)}
                                className="text-zinc-500 hover:text-rose-500 p-0.5"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Center Grid: Editor & Visualizer Split */}
                  <div className="flex-1 flex flex-col min-w-0">
                    
                    {/* Monaco Editor Canvas Wrapper */}
                    <div className="flex-1 relative border-b border-border min-h-0 bg-black">
                      <div ref={editorContainerRef} className="absolute inset-0 w-full h-full" />
                    </div>

                    {/* Interactive Editor control pane */}
                    <div className="p-3 bg-muted/30 border-b border-border flex items-center justify-between shrink-0 select-none">
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={handleRun}
                          disabled={isRunning}
                          className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition flex items-center gap-1.5 shadow-lg shadow-emerald-600/10 active:scale-95 disabled:opacity-50"
                        >
                          {isRunning ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                          Run Code
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button 
                          onClick={handleCopy}
                          className="p-1.5 hover:bg-accent rounded-lg text-muted-foreground hover:text-foreground transition flex items-center gap-1 text-[11px] font-bold"
                          title="Copy Active Code"
                        >
                          {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                          Copy
                        </button>
                        <button 
                          onClick={handleDownload}
                          className="p-1.5 hover:bg-accent rounded-lg text-muted-foreground hover:text-foreground transition flex items-center gap-1 text-[11px] font-bold"
                          title="Download Module"
                        >
                          <Download className="w-3.5 h-3.5" />
                          Download
                        </button>
                      </div>
                    </div>

                    {/* Bottom Console Sandbox Output panel */}
                    <div className="h-64 flex flex-col bg-[#0b0f19] text-zinc-300 relative shrink-0 min-w-0">
                      <div className="flex items-center justify-between px-3 py-1.5 bg-[#121824] border-b border-zinc-800 select-none">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 leading-none">Visualizer & Run Console</span>
                        <div className="flex gap-1">
                          <button 
                            onClick={() => setActiveTab('console')} 
                            className={cn("px-2 py-0.5 rounded text-[10px] font-extrabold uppercase transition", activeTab === 'console' ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300")}
                          >
                            Console Output
                          </button>
                          <button 
                            onClick={() => setActiveTab('plot')} 
                            className={cn("px-2 py-0.5 rounded text-[10px] font-extrabold uppercase transition flex items-center gap-1", activeTab === 'plot' ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300")}
                          >
                            Matplotlib Charts {plot && <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />}
                          </button>
                          <button 
                            onClick={() => setActiveTab('pygame')} 
                            className={cn("px-2 py-0.5 rounded text-[10px] font-extrabold uppercase transition", activeTab === 'pygame' ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300")}
                          >
                            Interactive Pygame
                          </button>
                        </div>
                      </div>

                      <div className="flex-1 overflow-auto p-4 custom-scrollbar min-w-0">
                        {activeTab === 'console' && (
                          <pre className="font-mono text-xs leading-relaxed text-zinc-300 whitespace-pre-wrap select-text selection:bg-indigo-500/25">
                            {output || "Output stream initialized. Click 'Run Code' above inside the editor loop."}
                          </pre>
                        )}

                        {activeTab === 'plot' && (
                          <div className="w-full h-full flex flex-col items-center justify-center relative">
                            {plot ? (
                              <img 
                                src={plot} 
                                alt="Python Matplotlib Export Output" 
                                className="max-w-full max-h-full rounded-lg border border-zinc-900 object-contain shadow-2xl bg-white" 
                                referrerPolicy="no-referrer"
                              />
                            ) : (
                              <div className="flex flex-col items-center gap-2.5 opacity-50 select-none text-center">
                                <Palette className="w-8 h-8 text-indigo-400" />
                                <span className="text-[11px] font-semibold text-zinc-400">Generate a chart with `plt.show()` inside main.app block</span>
                              </div>
                            )}
                          </div>
                        )}

                        {activeTab === 'pygame' && (
                          <div className="w-full h-full flex flex-col items-center justify-center relative bg-black rounded-lg">
                            <div className="text-center space-y-2 max-w-sm px-4">
                              <Play className="w-8 h-8 mx-auto text-indigo-400 animate-bounce" />
                              <h4 className="text-xs font-semibold text-zinc-300">Pygame-CE Canvas Port</h4>
                              <p className="text-[10px] text-zinc-550 leading-normal">Our Pyodide canvas adapter pipelines Pygame event listeners directly overlaying the environment screen. Coordinates and cycles are captured locally in the active frame.</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                  </div>

                </div>

              </div>

            </div>
          )}

        </div>

      </motion.div>

      {/* MODALS */}
      
      {/* Create New Project Modal */}
      <AnimatePresence>
        {showNewProjectModal && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card border border-border rounded-2xl w-full max-w-md p-6 shadow-2xl relative"
            >
              <button 
                onClick={() => setShowNewProjectModal(false)}
                className="absolute top-4 right-4 p-1.5 hover:bg-muted rounded-lg text-muted-foreground"
              >
                <X className="w-4 h-4" />
              </button>
              <h3 className="text-sm font-black uppercase tracking-widest text-foreground mb-4">Create Python Application</h3>
              <form onSubmit={handleCreateNewProject} className="space-y-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1">Application Name</label>
                  <input 
                    type="text" 
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    required
                    placeholder="e.g. My Algorithm Model"
                    className="w-full bg-muted border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1">Description</label>
                  <input 
                    type="text" 
                    value={newProjectDesc}
                    onChange={(e) => setNewProjectDesc(e.target.value)}
                    placeholder="e.g. Data visualization of numpy formulas"
                    className="w-full bg-muted border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-muted-foreground mb-1">Starter Blueprint Preset</label>
                  <select 
                    value={newProjectTemplate}
                    onChange={(e) => setNewProjectTemplate(e.target.value)}
                    className="w-full bg-muted border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="sinewave">Matplotlib Sine Wave</option>
                    <option value="barchart">NumPy Categorical Bar Chart</option>
                    <option value="pygame">Interactive Pygame Drawing</option>
                  </select>
                </div>
                <div className="flex justify-end gap-2.5 pt-2">
                  <button 
                    type="button" 
                    onClick={() => setShowNewProjectModal(false)}
                    className="px-4 py-1.5 bg-muted text-muted-foreground rounded-xl text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition"
                  >
                    Create Workspace
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* New File Modal */}
      <AnimatePresence>
        {showNewFileModal && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 shadow-2xl relative"
            >
              <button 
                onClick={() => setShowNewFileModal(false)}
                className="absolute top-4 right-4 p-1.5 hover:bg-muted rounded-lg text-muted-foreground"
              >
                <X className="w-4 h-4" />
              </button>
              <h3 className="text-sm font-black uppercase tracking-widest text-foreground mb-3">Add Python Module</h3>
              <form onSubmit={handleAddNewFile} className="space-y-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1">Filename</label>
                  <input 
                    type="text" 
                    value={newFileName}
                    onChange={(e) => setNewFileName(e.target.value)}
                    placeholder="e.g. data_models.py"
                    required
                    className="w-full bg-muted border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:outline-none"
                  />
                </div>
                <div className="flex justify-end gap-2.5">
                  <button 
                    type="button" 
                    onClick={() => setShowNewFileModal(false)}
                    className="px-3.5 py-1.5 bg-muted text-muted-foreground rounded-xl text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-3.5 py-1.5 bg-indigo-600 text-white font-bold rounded-xl text-xs transition animate-pulse"
                  >
                    Add File
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Rename File Modal */}
      <AnimatePresence>
        {showRenameFileModal && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 shadow-2xl relative"
            >
              <button 
                onClick={() => setShowRenameFileModal(false)}
                className="absolute top-4 right-4 p-1.5 hover:bg-muted rounded-lg text-muted-foreground"
              >
                <X className="w-4 h-4" />
              </button>
              <h3 className="text-sm font-black uppercase tracking-widest text-foreground mb-3">Rename Module</h3>
              <form onSubmit={handleRenameFile} className="space-y-4">
                <div>
                  <label className="block text-xs text-muted-foreground mb-1">New Filename</label>
                  <input 
                    type="text" 
                    value={renameNewName}
                    onChange={(e) => setRenameNewName(e.target.value)}
                    required
                    className="w-full bg-muted border border-border rounded-xl px-3 py-2 text-xs text-foreground focus:outline-none"
                  />
                </div>
                <div className="flex justify-end gap-2.5">
                  <button 
                    type="button" 
                    onClick={() => setShowRenameFileModal(false)}
                    className="px-3.5 py-1.5 bg-muted text-muted-foreground rounded-xl text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="px-3.5 py-1.5 bg-indigo-600 text-white font-bold rounded-xl text-xs transition"
                  >
                    Save Rename
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Custom Confirm Dialog Overlay */}
      <AnimatePresence>
        {confirmDialog && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-background/80 backdrop-blur-md overflow-hidden">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-border w-full max-w-sm rounded-2xl p-6 shadow-2xl relative"
            >
              <div className="flex items-center gap-3 text-destructive mb-3 select-none">
                <AlertTriangle className="w-5 h-5 shrink-0" />
                <h3 className="font-bold text-sm tracking-tight">{confirmDialog.title}</h3>
              </div>
              <p className="text-xs text-muted-foreground leading-normal mb-5">
                {confirmDialog.message}
              </p>
              <div className="flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setConfirmDialog(null)}
                  className="px-3.5 py-1.5 rounded-lg border border-border hover:bg-accent text-xs font-semibold transition text-foreground"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    confirmDialog.onConfirm();
                    setConfirmDialog(null);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-destructive text-destructive-foreground hover:bg-destructive/90 text-xs font-semibold transition shadow-lg shadow-destructive/15"
                >
                  Confirm Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Voice Input Interface overlay */}
      <AnimatePresence>
        {isVoiceOpen && (
          <VoiceInterface 
            onTranscript={(text) => {
              setVibePrompt(text);
              setIsVoiceOpen(false);
            }}
            onClose={() => setIsVoiceOpen(false)}
          />
        )}
      </AnimatePresence>

    </div>
  );
};
