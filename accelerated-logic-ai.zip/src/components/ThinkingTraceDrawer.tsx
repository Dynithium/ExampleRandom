import React, { useRef, useEffect } from 'react';
import { 
  X, 
  Cpu, 
  Terminal, 
  Code, 
  ShieldCheck, 
  Sparkles, 
  Search, 
  GitBranch, 
  Database,
  CheckCircle2, 
  Loader2, 
  Copy, 
  Check, 
  Activity, 
  Infinity as InfinityIcon,
  HelpCircle,
  Clock,
  ExternalLink,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils';

interface ThinkingStep {
  agent: string;
  text: string;
  timestamp?: number;
}

interface ThinkingTraceDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  thinkingProcess: ThinkingStep[];
  isGenerating: boolean;
  mode: 'single' | 'multi';
  infinityEnabled: boolean;
  infinitySettings?: {
    enabled: boolean;
    maxAttempts: number;
    strictness: number;
  };
}

export const ThinkingTraceDrawer: React.FC<ThinkingTraceDrawerProps> = ({
  isOpen,
  onClose,
  thinkingProcess,
  isGenerating,
  mode,
  infinityEnabled,
  infinitySettings
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [copiedIndex, setCopiedIndex] = React.useState<number | null>(null);

  useEffect(() => {
    if (containerRef.current && isGenerating) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [thinkingProcess, isGenerating]);

  const handleExportTrace = () => {
    if (thinkingProcess.length === 0) return;
    
    let md = `# Reasoning Trace Report\n`;
    md += `**Date**: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}\n`;
    md += `**Execution Mode**: ${mode === 'multi' ? 'Multi-Agent Pipeline' : 'Single Agent'}\n`;
    md += `**Total Steps**: ${thinkingProcess.length}\n`;
    if (infinityEnabled && infinitySettings) {
      md += `**Critic Autonomy Settings**: Limit ${infinitySettings.maxAttempts} attempts, Strictness ${infinitySettings.strictness}\n`;
    }
    md += `\n---\n\n`;

    thinkingProcess.forEach((step, idx) => {
      md += `### Step ${idx + 1}: ${step.agent}\n`;
      md += `*Timestamp*: ${new Date(step.timestamp || Date.now()).toLocaleTimeString()}\n\n`;
      md += `\`\`\`text\n${step.text}\n\`\`\`\n\n`;
      md += `---\n\n`;
    });

    md += `\n*Exported from Accelerated Logic private AI platform.*`;

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `reasoning-trace-${new Date().toISOString().split('T')[0]}.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const getAgentIcon = (agent: string) => {
    const a = agent.toLowerCase();
    if (a.includes('orch') || a.includes('architect') || a.includes('director') || a.includes('router')) {
      return <GitBranch className="w-4 h-4 text-indigo-400" />;
    }
    if (a.includes('coder') || a.includes('lead developer') || a.includes('programmer')) {
      return <Code className="w-4 h-4 text-emerald-400" />;
    }
    if (a.includes('auditor') || a.includes('security') || a.includes('editor') || a.includes('fact checker') || a.includes('reviewer') || a.includes('critic')) {
      return <ShieldCheck className="w-4 h-4 text-amber-400" />;
    }
    if (a.includes('finalizer') || a.includes('assembler')) {
      return <Sparkles className="w-4 h-4 text-purple-400" />;
    }
    if (a.includes('search')) {
      return <Search className="w-4 h-4 text-sky-400" />;
    }
    if (a.includes('database') || a.includes('sqlite') || a.includes('local storage')) {
      return <Database className="w-4 h-4 text-teal-400" />;
    }
    return <Cpu className="w-4 h-4 text-blue-400" />;
  };

  const getAgentBg = (agent: string) => {
    const a = agent.toLowerCase();
    if (a.includes('orch') || a.includes('architect') || a.includes('director') || a.includes('router')) {
      return 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400';
    }
    if (a.includes('coder') || a.includes('lead developer') || a.includes('programmer')) {
      return 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400';
    }
    if (a.includes('auditor') || a.includes('security') || a.includes('editor') || a.includes('fact checker') || a.includes('critic')) {
      return 'bg-amber-500/10 border-amber-500/20 text-amber-400';
    }
    if (a.includes('finalizer')) {
      return 'bg-purple-500/10 border-purple-500/20 text-purple-400';
    }
    if (a.includes('search')) {
      return 'bg-sky-500/10 border-sky-500/20 text-sky-400';
    }
    return 'bg-blue-500/10 border-blue-500/20 text-blue-400';
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Extract workflow stages based on running processes
  const stages = [
    { name: 'Plan', id: 'orch', active: thinkingProcess.some(p => p.agent.toLowerCase().includes('orch') || p.agent.toLowerCase().includes('router')) },
    { name: 'Implement', id: 'coder', active: thinkingProcess.some(p => p.agent.toLowerCase().includes('coder') || p.agent.toLowerCase().includes('analyst') || p.agent.toLowerCase().includes('writer')) },
    { name: 'Audit', id: 'auditor', active: thinkingProcess.some(p => p.agent.toLowerCase().includes('auditor') || p.agent.toLowerCase().includes('editor') || p.agent.toLowerCase().includes('fact checker')) },
    { name: 'Finalize', id: 'finalizer', active: thinkingProcess.some(p => p.agent.toLowerCase().includes('finalizer')) },
  ];

  const activeStageIndex = isGenerating 
    ? thinkingProcess.length > 0 
      ? (() => {
          const lastAgent = thinkingProcess[thinkingProcess.length - 1].agent.toLowerCase();
          if (lastAgent.includes('orch') || lastAgent.includes('router')) return 0;
          if (lastAgent.includes('coder') || lastAgent.includes('analyst') || lastAgent.includes('writer')) return 1;
          if (lastAgent.includes('auditor') || lastAgent.includes('editor') || lastAgent.includes('fact checker')) return 2;
          if (lastAgent.includes('finalizer')) return 3;
          return 1; // Fallback to coding/reasoning
        })()
      : 0
    : -1;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black z-50 backdrop-blur-xs"
          />

          {/* Drawer Body */}
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 220 }}
            className="fixed top-0 right-0 h-full w-full max-w-md sm:max-w-lg bg-card border-l border-border z-50 flex flex-col shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-border bg-muted/20 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className={cn(
                  "p-2 rounded-xl flex items-center justify-center border",
                  isGenerating ? "bg-primary/10 border-primary/30 animate-pulse text-primary" : "bg-muted border-border text-muted-foreground"
                )}>
                  <Activity className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold leading-none tracking-tight">Reasoning Trace</h3>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    {isGenerating ? "Live model reasoning active" : "Historical run log"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                {thinkingProcess.length > 0 && (
                  <button 
                    onClick={handleExportTrace}
                    className="p-1.5 hover:bg-emerald-500/10 text-emerald-400 hover:text-emerald-300 rounded-lg transition-all flex items-center gap-1 text-[11px] font-bold cursor-pointer border border-emerald-500/20"
                    title="Export Trace report to Markdown"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export</span>
                  </button>
                )}
                <button 
                  onClick={onClose}
                  className="p-1.5 hover:bg-accent rounded-lg text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Orchestration Stage Pipeline Map */}
            {mode === 'multi' && (
              <div className="px-4 py-3 bg-muted/10 border-b border-border/60 shrink-0">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Pipeline Orchestrator</span>
                  <div className="flex items-center gap-1.5">
                    {infinityEnabled && (
                      <span className="flex items-center gap-1 text-[9px] font-black uppercase tracking-widest text-[#a855f7] bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
                        <InfinityIcon className="w-3 h-3 animate-spin duration-3000" />
                        Infinity Active
                      </span>
                    )}
                    <span className={cn(
                      "text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded border",
                      isGenerating 
                        ? "text-primary bg-primary/10 border-primary/20 animate-pulse" 
                        : "text-muted-foreground bg-muted border-border/60"
                    )}>
                      {isGenerating ? "Orchestrating" : "Idle"}
                    </span>
                  </div>
                </div>

                <div className="relative flex items-center justify-between px-2 pt-1 pb-2">
                  {/* Pipeline connecting line */}
                  <div className="absolute top-5 left-8 right-8 h-[2px] bg-border z-0">
                    <div 
                      className="h-full bg-primary transition-all duration-500"
                      style={{ 
                        width: `${
                          activeStageIndex === -1 ? 100 : 
                          activeStageIndex === 0 ? 15 : 
                          activeStageIndex === 1 ? 45 : 
                          activeStageIndex === 2 ? 75 : 
                          100
                        }%` 
                      }}
                    />
                  </div>

                  {stages.map((stage, idx) => {
                    const isPassed = !isGenerating || idx < activeStageIndex;
                    const isActive = isGenerating && idx === activeStageIndex;
                    
                    return (
                      <div key={stage.id} className="flex flex-col items-center gap-1.5 relative z-10 shrink-0">
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center border transition-all duration-300 shadow-sm",
                          isActive 
                            ? "bg-primary text-primary-foreground border-primary scale-110 shadow-primary/20 ring-4 ring-primary/10"
                            : isPassed 
                              ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/40" 
                              : "bg-background text-muted-foreground border-border"
                        )}>
                          {isPassed && !isActive ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : isActive ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <span className="text-[10px] font-bold">{idx + 1}</span>
                          )}
                        </div>
                        <span className={cn(
                          "text-[9px] font-bold uppercase tracking-widest",
                          isActive ? "text-primary font-black" : isPassed ? "text-foreground" : "text-muted-foreground"
                        )}>
                          {stage.name}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Logs Timeline Body */}
            <div 
              ref={containerRef}
              className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 custom-scrollbar bg-zinc-950/30"
            >
              {thinkingProcess.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-3">
                  <div className="w-12 h-12 rounded-full border border-dashed border-border flex items-center justify-center text-muted-foreground/40">
                    <HelpCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">No Reasoning Live</h5>
                    <p className="text-[11px] text-muted-foreground/60 max-w-[240px] mt-1">
                      Reasoning traces are generated when model executions begin. Ask a query to watch agents work.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="relative border-l border-border/60 pl-4 py-1 space-y-5">
                  {thinkingProcess.map((step, idx) => {
                    const isLast = idx === thinkingProcess.length - 1;
                    const isStepActive = isGenerating && isLast;
                    
                    return (
                      <motion.div 
                        key={idx}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className={cn(
                          "relative rounded-xl border p-3 sm:p-4 bg-card/60 shadow-xs transition-all",
                          isStepActive 
                            ? "border-primary/50 shadow-sm shadow-primary/5 ring-1 ring-primary/20" 
                            : "border-border/60 hover:border-border"
                        )}
                      >
                        {/* Timeline node marker */}
                        <div className={cn(
                          "absolute -left-[27px] top-4.5 w-3.5 h-3.5 rounded-full border bg-background flex items-center justify-center",
                          isStepActive ? "border-primary text-primary" : "border-border text-muted-foreground"
                        )}>
                          {isStepActive ? (
                            <div className="w-1.5 h-1.5 rounded-full bg-primary animate-ping" />
                          ) : (
                            <div className="w-1 h-1 rounded-full bg-muted-foreground" />
                          )}
                        </div>

                        {/* Card Header */}
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <div className={cn("p-1.5 rounded-lg border", getAgentBg(step.agent))}>
                              {getAgentIcon(step.agent)}
                            </div>
                            <span className="text-xs font-bold tracking-tight text-foreground">
                              {step.agent}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[9px] font-mono text-muted-foreground flex items-center gap-1">
                              <Clock className="w-2.5 h-2.5" />
                              {new Date(step.timestamp || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                            </span>
                            <button 
                              onClick={() => handleCopy(step.text, idx)}
                              className="p-1 hover:bg-accent rounded text-muted-foreground hover:text-foreground transition-all"
                              title="Copy details"
                            >
                              {copiedIndex === idx ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                            </button>
                          </div>
                        </div>

                        {/* Detail text */}
                        <div className="text-xs text-muted-foreground leading-relaxed font-mono whitespace-pre-wrap select-text break-words bg-black/20 p-2.5 rounded-lg border border-border/40 max-h-[220px] overflow-y-auto custom-scrollbar">
                          {step.text}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Drawer Statistics Footer */}
            <div className="p-4 sm:p-5 border-t border-border bg-muted/30 flex items-center justify-between text-[11px] font-semibold text-muted-foreground select-none shrink-0">
              <span className="flex items-center gap-1">
                Steps: <span className="text-foreground font-bold font-mono bg-background px-1.5 py-0.5 rounded border border-border">{thinkingProcess.length}</span>
              </span>
              {infinityEnabled && infinitySettings && (
                <span className="flex items-center gap-1">
                  Critic Limit: <span className="text-foreground font-bold font-mono bg-background px-1.5 py-0.5 rounded border border-purple-500/20 text-[#a855f7]">{infinitySettings.maxAttempts}</span>
                </span>
              )}
              {isGenerating ? (
                <span className="flex items-center gap-1.5 text-primary">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  Streaming Thoughts...
                </span>
              ) : (
                <span className="flex items-center gap-1.5 text-muted-foreground">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                  Completed
                </span>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
