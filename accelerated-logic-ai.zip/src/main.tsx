import './patch-gpu';
import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// --- Anti-Theft & Code Protection Systems ---
if (typeof window !== 'undefined') {
  // 1. Disable standard context menu (right-click)
  document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
  }, { capture: true });

  // 2. Intercept DevTools and View-Source hotkeys
  document.addEventListener('keydown', (e) => {
    // Disable F12
    if (e.key === 'F12') {
      e.preventDefault();
      return false;
    }

    // Disable Ctrl+Shift+I / J / C (Windows/Linux) or Cmd+Opt+I / J / C (Mac)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && ['I', 'i', 'J', 'j', 'C', 'c'].includes(e.key)) {
      e.preventDefault();
      return false;
    }

    // Disable Cmd+Opt+I / J / C (Mac alternative mappings)
    if (e.altKey && (e.ctrlKey || e.metaKey) && ['I', 'i', 'J', 'j', 'C', 'c'].includes(e.key)) {
      e.preventDefault();
      return false;
    }

    // Disable Ctrl+U / Cmd+U (View Source)
    if ((e.ctrlKey || e.metaKey) && ['U', 'u'].includes(e.key)) {
      e.preventDefault();
      return false;
    }

    // Disable Ctrl+S / Cmd+S (Save Page)
    if ((e.ctrlKey || e.metaKey) && ['S', 's'].includes(e.key)) {
      e.preventDefault();
      return false;
    }
  }, { capture: true });

  // 3. Output prominent warnings to DevTools console in case they open it through menus
  const warnDevs = () => {
    console.clear();
    console.log(
      "%cSTOP %c- ACCELERATED LOGIC PROPRIETARY SOFTWARE", 
      "color: #ef4444; font-size: 32px; font-weight: 800; font-family: monospace; text-shadow: 2px 2px 0px #000;",
      "color: #3b82f6; font-size: 16px; font-weight: 700; font-family: monospace;"
    );
    console.log(
      "%cAll source code, design, and user interfaces are proprietary and copyrighted. Local copying or reverse-engineering is strictly illegal.",
      "color: #94a3b8; font-size: 12px; font-family: monospace;"
    );
  };
  warnDevs();
  setInterval(warnDevs, 5000);
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
