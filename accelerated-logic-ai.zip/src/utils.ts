/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker?url';

if (typeof window !== 'undefined') {
  pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;
}

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const TOKEN_REDUCTION_WORDS = [
  'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'with', 'by', 'from', 'up', 'down', 'out', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', 'should', 'now'
];

export function reduceTokens(text: string, amount: number): string {
  if (amount <= 0) return text;
  const words = text.split(/\s+/);
  const filtered = words.filter(word => {
    const lower = word.toLowerCase().replace(/[^a-z]/g, '');
    if (TOKEN_REDUCTION_WORDS.includes(lower)) {
      return Math.random() > (amount / 100);
    }
    return true;
  });
  return filtered.join(' ');
}

export const MIME_MAP: Record<string, string> = {
  'jpg': 'image/jpeg',
  'jpeg': 'image/jpeg',
  'png': 'image/png',
  'gif': 'image/gif',
  'webp': 'image/webp',
  'svg': 'image/svg+xml',
  'pdf': 'application/pdf',
  'txt': 'text/plain',
  'md': 'text/markdown',
  'html': 'text/html',
  'css': 'text/css',
  'js': 'text/javascript',
  'ts': 'text/typescript',
  'tsx': 'text/typescript',
  'json': 'application/json',
  'py': 'text/x-python',
  'rs': 'text/x-rust',
  'go': 'text/x-go',
  'c': 'text/x-c',
  'cpp': 'text/x-c++',
  'java': 'text/x-java',
  'mp4': 'video/mp4'
};

export const isImageFile = (fileType: string, extension: string) => 
  fileType.startsWith('image/') || ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension || '');

export const isPdfFile = (fileType: string, extension: string) => 
  fileType === 'application/pdf' || extension === 'pdf';

export const isKnownBinaryFile = (extension: string) => {
  const binaryExtensions = ['exe', 'zip', 'rar', '7z', 'tar', 'gz', 'mp3', 'mp4', 'mov', 'avi', 'wav', 'dmg', 'iso', 'bin'];
  return binaryExtensions.includes(extension || '');
};

export const cleanMessage = (content: string) => {
  if (!content) return '';
  let cleaned = content
    .replace(/<python_tool>([\s\S]*?)<\/python_tool>/ig, (match, code) => {
      if (!code.trim()) return '';
      const cleanCode = code
        .replace(/^```python\s*/i, '')
        .replace(/^```\s*/i, '')
        .replace(/```\s*$/i, '')
        .trim();
      return `\n\`\`\`python\n${cleanCode}\n\`\`\`\n`;
    })
    .replace(/<image_gen\s+([^>]*?)\/?>/ig, '')
    .replace(/\[PYTHON:\s*([\s\S]*?)(?:\]|$)/ig, '') // Cleanup old format
    .replace(/\[CANVAS:\s*[\s\S]*?\]/gi, '')
    .replace(/\[\/CANVAS\]/gi, '')
    .replace(/\[GENERATE_IMAGE:[\s\S]*?\]/gi, '')
    .replace(/<(?:thinking|think|thought)>[\s\S]*?(?:<\/(?:thinking|think|thought)>|$)/ig, '');

  // LaTeX Normalization: Convert escaped brackets/parentheses to standard dollar delimiters
  cleaned = cleaned
    .replace(/\\\[/g, '$$$$')
    .replace(/\\\]/g, '$$$$')
    .replace(/\\\(/g, '$')
    .replace(/\\\)/g, '$');

  // Fix for un-delimited \boxed and other common LaTeX blocks 
  // that LLMs sometimes output without $ or $$
  cleaned = cleaned.replace(/(?<!\$|\\)(\\boxed\{[^{}]*\})(?!\$)/g, '$$$1$$');

  return cleaned.trim();
};

export const ensureClosedThinkingTags = (content: string): string => {
  if (!content) return '';
  const openThink = content.match(/<(thinking|think|thought)>/i);
  if (openThink) {
    const tagName = openThink[1].toLowerCase();
    const closeRegex = new RegExp(`<\/${tagName}>`, 'i');
    if (!closeRegex.test(content)) {
      return content + `\n</${tagName}>`;
    }
  }
  return content;
};

export const extractModelThinking = (content: string): string | null => {
  if (!content) return null;
  const match = content.match(/<(?:thinking|think|thought)>([\s\S]*?)(?:<\/(?:thinking|think|thought)>|$)/i);
  return match ? match[1] : null;
};

export const extractTextFromPdfBase64 = async (base64Content: string): Promise<string> => {
  try {
    const cleanBase64 = base64Content.includes(',') ? base64Content.split(',')[1] : base64Content;
    const binaryString = window.atob(cleanBase64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const loadingTask = pdfjsLib.getDocument({ data: bytes });
    const pdf = await loadingTask.promise;
    let extractedText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContentPage = await page.getTextContent();
      const pageText = textContentPage.items.map((item: any) => (item as any).str).join(' ');
      extractedText += `--- Page ${i} ---\n${pageText}\n\n`;
    }
    return extractedText.trim();
  } catch (error) {
    console.error("Error extracting text from PDF base64:", error);
    return `[Failed to extract plain text from PDF document]`;
  }
};

export function sanitizeBaseUrl(url: string): string {
  let cleaned = (url || '').trim();
  // If it's formatted as [description](url) or similar markdown, match the URL part inside the parentheses
  const markdownUrlRegex = /\[.*?\]\((.*?)\)/;
  const match = cleaned.match(markdownUrlRegex);
  if (match && match[1]) {
    cleaned = match[1].trim();
  }
  
  // Strip starting/ending brackets/braces/quotes if user was messy
  cleaned = cleaned.replace(/^[\[\("'`\s]+|[\]\)"'`\s]+$/g, '');
  
  // Strip trailing backslashes/slashes
  cleaned = cleaned.replace(/\/+$/, '');
  
  return cleaned;
}

