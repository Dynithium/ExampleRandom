import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, X, Play, Pause, RefreshCw, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface VoiceInterfaceProps {
  onTranscript: (text: string) => void;
  onClose: () => void;
}

export const VoiceInterface: React.FC<VoiceInterfaceProps> = ({ onTranscript, onClose }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const recognitionRef = useRef<any>(null);
  const isListeningRef = useRef(false);
  const accumulatedTranscriptRef = useRef('');

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setIsSupported(false);
      return;
    }

    recognitionRef.current = new SpeechRecognition();
    recognitionRef.current.continuous = true;
    recognitionRef.current.interimResults = true;
    recognitionRef.current.lang = 'en-US';

    recognitionRef.current.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      if (finalTranscript) {
        accumulatedTranscriptRef.current += finalTranscript + ' ';
      }

      setTranscript(accumulatedTranscriptRef.current + interimTranscript);
    };

    recognitionRef.current.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      if (event.error === 'not-allowed') {
        isListeningRef.current = false;
        setIsListening(false);
        setError('Permission Denied: Please allow microphone access in your browser settings.');
      } else if (event.error === 'network') {
        setError('Network Error: Please check your internet connection.');
      } else {
        setError(`Error: ${event.error}`);
      }
    };

    recognitionRef.current.onend = () => {
      if (isListeningRef.current) {
        try {
          recognitionRef.current?.start();
        } catch (e) {
          console.error("Failed to restart recognition", e);
          isListeningRef.current = false;
          setIsListening(false);
        }
      } else {
        setIsListening(false);
      }
    };

    return () => {
      isListeningRef.current = false;
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const toggleListening = () => {
    setError(null);
    if (isListeningRef.current) {
      isListeningRef.current = false;
      setIsListening(false);
      recognitionRef.current?.stop();
      if (transcript.trim()) {
        onTranscript(transcript.trim());
      }
      setTranscript('');
      accumulatedTranscriptRef.current = '';
    } else {
      setTranscript('');
      accumulatedTranscriptRef.current = '';
      isListeningRef.current = true;
      setIsListening(true);
      try {
        recognitionRef.current?.start();
      } catch (e) {
        console.error(e);
      }
    }
  };

  const speak = (text: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.onstart = () => {
      setIsSpeaking(true);
      setIsPaused(false);
    };
    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };
    utterance.onerror = () => {
      setIsSpeaking(false);
      setIsPaused(false);
    };
    window.speechSynthesis.speak(utterance);
  };

  const togglePauseSpeaking = () => {
    if (!window.speechSynthesis) return;
    if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      window.speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  if (!isSupported) {
    return (
      <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8 text-center space-y-4 max-w-md">
          <div className="p-4 bg-red-500/10 rounded-2xl inline-block">
            <MicOff className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-xl font-bold text-white">Speech Recognition Not Supported</h2>
          <p className="text-sm text-zinc-400">Your browser doesn't support the Web Speech API. Please try a modern browser like Chrome or Edge.</p>
          <button onClick={onClose} className="w-full py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-colors">Close</button>
        </div>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[100] w-full max-w-lg px-4"
    >
      <div className="bg-zinc-900/90 backdrop-blur-xl border border-zinc-800 rounded-[2.5rem] p-6 shadow-2xl flex flex-col items-center gap-6">
        {/* Visualizer Simulation */}
        <div className="flex items-center justify-center gap-1 h-12 w-full">
          {Array.from({ length: 24 }).map((_, i) => (
            <motion.div
              key={i}
              animate={{ 
                height: isListening ? [8, 32, 12, 40, 8][(i + Math.floor(Date.now()/100)) % 5] : 4,
                opacity: isListening ? 1 : 0.3
              }}
              transition={{ duration: 0.5, repeat: Infinity, ease: "easeInOut" }}
              className="w-1.5 bg-purple-500 rounded-full"
            />
          ))}
        </div>

        {/* Transcript Area */}
        <div className="w-full min-h-[60px] max-h-[120px] overflow-y-auto text-center px-4">
          {error ? (
            <p className="text-sm text-red-400 font-medium">
              {error}
              <br />
              <span className="text-[10px] text-zinc-500 uppercase mt-2 block">
                Tip: Try opening the app in a new tab if permissions are blocked.
              </span>
            </p>
          ) : (
            <p className={`text-lg font-medium transition-colors ${transcript ? 'text-white' : 'text-zinc-600'}`}>
              {transcript || (isListening ? "Listening..." : "Tap the mic to start speaking")}
            </p>
          )}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-6">
          <button 
            onClick={onClose}
            className="p-4 bg-zinc-800 hover:bg-zinc-700 rounded-full text-zinc-400 hover:text-white transition-all"
          >
            <X className="w-6 h-6" />
          </button>

          <button 
            onClick={toggleListening}
            className={`p-8 rounded-full transition-all relative group ${
              isListening 
                ? 'bg-red-500 shadow-[0_0_30px_rgba(239,68,68,0.4)]' 
                : 'bg-purple-600 shadow-[0_0_30px_rgba(147,51,234,0.4)] hover:scale-105'
            }`}
          >
            {isListening ? <MicOff className="w-8 h-8 text-white" /> : <Mic className="w-8 h-8 text-white" />}
            <div className="absolute inset-0 rounded-full border-4 border-white/20 animate-ping opacity-0 group-hover:opacity-100" />
          </button>

          {isSpeaking && (
            <button 
              onClick={togglePauseSpeaking}
              className={`p-4 bg-zinc-800 hover:bg-zinc-700 rounded-full transition-all ${isPaused ? 'text-green-400' : 'text-zinc-400'}`}
              title={isPaused ? "Resume" : "Pause"}
            >
              {isPaused ? <Play className="w-6 h-6" /> : <Pause className="w-6 h-6" />}
            </button>
          )}

          <button 
            onClick={() => {
              if (isSpeaking) {
                window.speechSynthesis.cancel();
                setIsSpeaking(false);
                setIsPaused(false);
              } else {
                speak(transcript || "Hello, I am your assistant. How can I help you today?");
              }
            }}
            className={`p-4 bg-zinc-800 hover:bg-zinc-700 rounded-full transition-all ${isSpeaking ? 'text-red-400' : 'text-zinc-400'}`}
          >
            {isSpeaking ? <VolumeX className="w-6 h-6 animate-pulse" /> : <Volume2 className="w-6 h-6" />}
          </button>
        </div>

        {/* Status */}
        <div className="flex items-center gap-2 px-4 py-1.5 bg-zinc-950 rounded-full border border-zinc-800">
          <div className={`w-2 h-2 rounded-full ${isListening ? 'bg-red-500 animate-pulse' : 'bg-zinc-700'}`} />
          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">
            {isListening ? "Voice Active" : "Voice Standby"}
          </span>
        </div>
      </div>
    </motion.div>
  );
};
