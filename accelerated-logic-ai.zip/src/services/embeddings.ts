import { pipeline, env } from '@xenova/transformers';
import { getModelInfo } from '../models';

// Configure Transformers.js to prevent it from loading files from the local relative path (which triggers the SPA router's index.html fallback and results in invalid JSON syntax errors)
if (typeof env !== 'undefined') {
  env.allowLocalModels = false;
  env.localModelPath = 'https://hf-mirror.com/';
  env.remoteHost = 'https://hf-mirror.com/';
}

// Interface definitions
export interface ModelMetrics {
  intelligence: number; // 0-100 (Overall analytical depth)
  coding: number;       // 0-100
  math: number;         // 0-100
  science: number;      // 0-100
  writing: number;      // 0-100
  qa: number;           // 0-100
}

export interface ModelProfile {
  id: string;
  difficultyTier: 'easy' | 'medium' | 'hard';
  specialization: ('coding' | 'math' | 'science' | 'writing' | 'qa')[];
  metrics: ModelMetrics;
}

// Map of canonical model profiles
export const MODEL_PROFILES: { [modelId: string]: Omit<ModelProfile, 'id'> } = {
  'gemini-3.5-flash': {
    difficultyTier: 'medium',
    specialization: ['qa', 'writing'],
    metrics: { intelligence: 82, coding: 78, math: 80, science: 81, writing: 85, qa: 88 }
  },
  'gemini-3.1-flash-lite': {
    difficultyTier: 'easy',
    specialization: ['qa', 'writing'],
    metrics: { intelligence: 78, coding: 74, math: 75, science: 76, writing: 82, qa: 84 }
  },
  'gemma-4-31b-it': {
    difficultyTier: 'medium',
    specialization: ['qa', 'writing'],
    metrics: { intelligence: 78, coding: 70, math: 72, science: 75, writing: 80, qa: 82 }
  },
  'gemma-4-26b-a4b-it': {
    difficultyTier: 'medium',
    specialization: ['qa', 'writing'],
    metrics: { intelligence: 76, coding: 68, math: 70, science: 74, writing: 78, qa: 80 }
  },
  'gpt-5.5': {
    difficultyTier: 'hard',
    specialization: ['coding', 'math', 'science', 'writing', 'qa'],
    metrics: { intelligence: 98, coding: 97, math: 99, science: 98, writing: 96, qa: 98 }
  },
  'grok-4.3': {
    difficultyTier: 'hard',
    specialization: ['science', 'math', 'qa'],
    metrics: { intelligence: 95, coding: 92, math: 94, science: 96, writing: 94, qa: 95 }
  },
  'claude-opus-4.8': {
    difficultyTier: 'hard',
    specialization: ['coding', 'writing', 'qa'],
    metrics: { intelligence: 99, coding: 99, math: 98, science: 99, writing: 98, qa: 99 }
  },
  'qwen/qwen3.7-plus': {
    difficultyTier: 'medium',
    specialization: ['coding', 'math', 'science', 'writing', 'qa'],
    metrics: { intelligence: 92, coding: 88, math: 90, science: 90, writing: 90, qa: 91 }
  },
  'deepseek-v4-pro': {
    difficultyTier: 'hard',
    specialization: ['coding', 'math', 'science'],
    metrics: { intelligence: 97, coding: 98, math: 97, science: 96, writing: 90, qa: 95 }
  },
  'poolside/laguna-m.1:free': {
    difficultyTier: 'medium',
    specialization: ['coding'],
    metrics: { intelligence: 80, coding: 85, math: 75, science: 72, writing: 65, qa: 74 }
  },
  'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free': {
    difficultyTier: 'hard',
    specialization: ['math', 'science'],
    metrics: { intelligence: 88, coding: 82, math: 90, science: 89, writing: 75, qa: 83 }
  },
  'qwen3.5:9b': {
    difficultyTier: 'medium',
    specialization: ['coding', 'math', 'qa'],
    metrics: { intelligence: 75, coding: 74, math: 72, science: 73, writing: 74, qa: 78 }
  },
  'qwen3.5:2b': {
    difficultyTier: 'easy',
    specialization: ['qa', 'writing'],
    metrics: { intelligence: 60, coding: 52, math: 48, science: 50, writing: 62, qa: 65 }
  },
  'qwen3.5:0.8b': {
    difficultyTier: 'easy',
    specialization: ['qa'],
    metrics: { intelligence: 50, coding: 38, math: 35, science: 40, writing: 50, qa: 58 }
  }
};

// Returns profile for any equipped ID, resolving provider & LLM name
export function getModelProfile(equippedId: string): ModelProfile {
  const { modelId, provider } = getModelInfo(equippedId);
  const matched = MODEL_PROFILES[modelId];
  if (matched) {
    return { id: equippedId, ...matched };
  }

  // Dynamic fallback heuristics for unrecognized, WebLLM or newly loaded models
  const mLower = modelId.toLowerCase();
  let difficultyTier: 'easy' | 'medium' | 'hard' = 'medium';
  let specialization: ('coding' | 'math' | 'science' | 'writing' | 'qa')[] = ['qa'];
  let intelligence = 72;
  let coding = 65;
  let math = 60;
  let science = 65;
  let writing = 72;
  let qa = 75;

  if (provider === 'webllm' || mLower.includes('0.8b') || mLower.includes('1.5b') || mLower.includes('2b')) {
    difficultyTier = 'easy';
    intelligence = 55;
    coding = 45;
    math = 40;
    science = 45;
    writing = 58;
    qa = 62;
  } else if (mLower.includes('7b') || mLower.includes('8b') || mLower.includes('9b') || mLower.includes('14b')) {
    difficultyTier = 'medium';
    intelligence = 75;
    coding = 70;
    math = 68;
    science = 72;
    writing = 74;
    qa = 76;
    specialization.push('writing');
  } else if (mLower.includes('coder') || mLower.includes('code')) {
    specialization = ['coding'];
    coding = 88;
    intelligence = 80;
  } else if (mLower.includes('math') || mLower.includes('reason') || mLower.includes('opus') || mLower.includes('gpt-4') || mLower.includes('gemini-2') || mLower.includes('pro')) {
    difficultyTier = 'hard';
    intelligence = 92;
    coding = 90;
    math = 92;
    science = 90;
    writing = 88;
    qa = 92;
    specialization = ['coding', 'math', 'science', 'writing', 'qa'];
  }

  return {
    id: equippedId,
    difficultyTier,
    specialization,
    metrics: { intelligence, coding, math, science, writing, qa }
  };
}

// Representative vector math reference samples for classifying user demands
export const SAMPLES = {
  hard_code: [
    "Write a Python script to parse a CSV file, calculate summary statistics, and plot the distribution using matplotlib.",
    "Design complete TypeScript types and state handlers to manage a nested tree structure for a file explorer.",
    "Implement an optimized binary search tree in JavaScript with insert, delete, and balancing methods.",
    "Write a robust SQL query to calculate month-over-month sales growth, handling zero-division edge cases."
  ],
  hard_math_science: [
    "Solve this calculus problem: find the limit of (sin x) / x as x approaches 0, and explain the proof.",
    "Derive the mathematical formula for the quadratic solver and prove its validity.",
    "Given a matrix A, find its eigenvalues and eigenvectors and show step-by-step calculations.",
    "Perform a statistical hypothesis test to compare two groups of conversion rates, calculating p-value."
  ],
  creative_writing: [
    "Draft an elegant and polite email to a client explaining why the project launch is delayed.",
    "Write a short sci-fi story about a spacecraft landing on an icy moon of Jupiter.",
    "Summarize this long report into three high-level bullets suitable for executive presentation.",
    "Compose a beautiful, rhythmic poem describing a quiet walk in an autumn forest."
  ],
  simple_qa: [
    "Hi there, who are you? Tell me about your capabilities.",
    "What is the capital of France, and what is its most famous landmark?",
    "Can you tell me a funny joke or a witty riddle?",
    "Explain the difference between a solar eclipse and a lunar eclipse in plain language."
  ]
};

// Cache for model pipeline and pre-computed reference embeddings
let pipelineInstance: any = null;
let sampleEmbeddingsCache: { [category: string]: number[][] } | null = null;

// Cosine Similarity between 2 1D vectors
export function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) return 0;
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// Fast feature extraction using Transformers.js
async function getEmbedding(text: string, extractor: any): Promise<number[]> {
  const result = await extractor(text, { pooling: 'mean', normalize: true });
  return Array.from(result.data) as number[];
}

export async function initAutoSelectorEmbeddings(onStatusUpdate?: (text: string) => void) {
  if (sampleEmbeddingsCache) return;
  
  // Disable local models so we only download remote files and don't trip index.html fallback
  env.allowLocalModels = false;
  env.localModelPath = 'https://hf-mirror.com/';
  env.remoteHost = 'https://hf-mirror.com/';
  
  if (onStatusUpdate) onStatusUpdate("Downloading tiny 23MB embedding model (all-MiniLM-L6-v2) to browser...");
  pipelineInstance = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
  
  if (onStatusUpdate) onStatusUpdate("Computing semantic vectors for task reference samples...");
  
  const cache: { [category: string]: number[][] } = {};
  for (const [category, prompts] of Object.entries(SAMPLES)) {
    cache[category] = [];
    for (const prompt of prompts) {
      const vec = await getEmbedding(prompt, pipelineInstance);
      cache[category].push(vec);
    }
  }
  
  sampleEmbeddingsCache = cache;
  if (onStatusUpdate) onStatusUpdate("Semantic mapping network successfully initialized!");
}

export interface MatchResult {
  classifiedDifficulty: 'easy' | 'medium' | 'hard';
  classifiedSpecialty: 'coding' | 'math' | 'writing' | 'qa';
  similarityScores: {
    codeSimilarity: number;
    mathSimilarity: number;
    creativeSimilarity: number;
    simpleSimilarity: number;
  };
  recommendedModelId: string;
  routerExplanation: string;
}

export async function matchPromptToOptimalModel(
  prompt: string,
  equippedModelIds: string[],
  onStatusUpdate?: (text: string) => void
): Promise<MatchResult> {
  // Ensure the model is loaded and samples are cached
  if (!pipelineInstance || !sampleEmbeddingsCache) {
    await initAutoSelectorEmbeddings(onStatusUpdate);
  }

  if (onStatusUpdate) onStatusUpdate("Tokenizing user prompt and calculating semantic vector...");
  const promptVec = await getEmbedding(prompt, pipelineInstance);

  // Compute similarities against sample vectors
  const getAvgMaxSimilarity = (category: keyof typeof SAMPLES): { max: number; avg: number } => {
    const vectors = sampleEmbeddingsCache![category] || [];
    let max = -1;
    let sum = 0;
    for (const vec of vectors) {
      const sim = cosineSimilarity(promptVec, vec);
      if (sim > max) max = sim;
      sum += sim;
    }
    return { max, avg: vectors.length > 0 ? sum / vectors.length : 0 };
  };

  const codeStats = getAvgMaxSimilarity('hard_code');
  const mathStats = getAvgMaxSimilarity('hard_math_science');
  const creativeStats = getAvgMaxSimilarity('creative_writing');
  const simpleStats = getAvgMaxSimilarity('simple_qa');

  // Find the closest domain and difficulty tier
  const maxSimilarity = Math.max(codeStats.max, mathStats.max, creativeStats.max, simpleStats.max);
  
  let classifiedSpecialty: 'coding' | 'math' | 'writing' | 'qa' = 'qa';
  if (maxSimilarity === codeStats.max && codeStats.max > 0.4) {
    classifiedSpecialty = 'coding';
  } else if (maxSimilarity === mathStats.max && mathStats.max > 0.4) {
    classifiedSpecialty = 'math';
  } else if (maxSimilarity === creativeStats.max && creativeStats.max > 0.4) {
    classifiedSpecialty = 'writing';
  }

  // Mathematical classification vector weights for the final difficulty level
  // Hard asks contain math or coding similarities, Simple contains chit-chat/greetings
  let classifiedDifficulty: 'easy' | 'medium' | 'hard' = 'medium';
  if (codeStats.max > 0.45 || mathStats.max > 0.45 || (prompt.length > 300 && (codeStats.max > 0.35 || mathStats.max > 0.35))) {
    classifiedDifficulty = 'hard';
  } else if (simpleStats.max > 0.55 && codeStats.max < 0.3 && mathStats.max < 0.3 && prompt.length < 150) {
    classifiedDifficulty = 'easy';
  } else if (creativeStats.max > 0.45) {
    classifiedDifficulty = 'medium';
  }

  // Fallback check if prompt is extremely short
  if (prompt.trim().length < 25) {
    classifiedDifficulty = 'easy';
    classifiedSpecialty = 'qa';
  }

  if (onStatusUpdate) {
    onStatusUpdate(`Domain classified as [${classifiedSpecialty.toUpperCase()}] running on [${classifiedDifficulty.toUpperCase()}] tier.`);
  }

  // Now, let us score each EQUIPPED model
  let bestModelId = equippedModelIds[0] || 'puter:gemini-3.5-flash';
  let bestScore = -9999;
  const evaluatedScores: { modelId: string; score: number; reason: string }[] = [];

  for (const eqId of equippedModelIds) {
    const profile = getModelProfile(eqId);
    
    // Core base score: Intelligence metric (35% weight)
    let score = profile.metrics.intelligence * 0.35;

    // Specialization matcher bonus (45% weight)
    if (classifiedSpecialty === 'coding') {
      score += profile.metrics.coding * 0.45;
    } else if (classifiedSpecialty === 'math') {
      score += profile.metrics.math * 0.45;
    } else if (classifiedSpecialty === 'writing') {
      score += profile.metrics.writing * 0.45;
    } else {
      score += profile.metrics.qa * 0.45;
    }

    // Alignment of difficulty tier
    const isLocalOrWebLlm = eqId.toLowerCase().includes('webllm') || eqId.toLowerCase().includes('ollama');
    
    if (classifiedDifficulty === 'easy') {
      // For simple questions, we reward easy models with efficiency and low-latency bonuses
      if (profile.difficultyTier === 'easy') {
        score += 35; // Latency efficiency benefit
      } else if (profile.difficultyTier === 'hard') {
        score -= 20; // De-prioritize overkill expensive models for routine greetings
      }
    } else if (classifiedDifficulty === 'hard') {
      // Must prioritize highly analytical high-intelligence profiles
      if (profile.difficultyTier === 'hard') {
        score += 30; // High intelligence match
      } else if (profile.difficultyTier === 'easy') {
        score -= 40; // Avoid local low-parameter models failing complex code/logic
      }
    }

    evaluatedScores.push({ modelId: eqId, score, reason: `base_intel=${profile.metrics.intelligence}, tier=${profile.difficultyTier}` });

    if (score > bestScore) {
      bestScore = score;
      bestModelId = eqId;
    }
  }

  const cleanBestModelName = getModelInfo(bestModelId).catalogModel?.name || bestModelId;
  const routerExplanation = `Math match similarity is ${mathStats.max.toFixed(2)}, Coding match similarity is ${codeStats.max.toFixed(2)}. Selected most optimal configured model "${cleanBestModelName}" to handle this ${classifiedDifficulty} ${classifiedSpecialty} request.`;

  return {
    classifiedDifficulty,
    classifiedSpecialty,
    similarityScores: {
      codeSimilarity: codeStats.max,
      mathSimilarity: mathStats.max,
      creativeSimilarity: creativeStats.max,
      simpleSimilarity: simpleStats.max
    },
    recommendedModelId: bestModelId,
    routerExplanation
  };
}
