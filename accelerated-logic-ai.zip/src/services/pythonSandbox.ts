/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PythonExecutionResult {
  stdout: string;
  plot: string | null;
}

export const executePythonCode = async (
  fullCode: string,
  log: (agent: string, text: string) => void
): Promise<PythonExecutionResult> => {
  try {
    log('Python Tool', 'Initializing Pyodide & Libraries...');
    
    // @ts-ignore
    if (!window.pyodide) {
      // @ts-ignore
      window.pyodide = await window.loadPyodide({
        stdin: () => {
          const res = window.prompt("Python input:");
          return res !== null ? res + "\n" : "\n";
        }
      });
      // @ts-ignore
      const pyodide = window.pyodide;
      await pyodide.loadPackage(['micropip', 'matplotlib', 'numpy', 'pandas']);
      const micropip = pyodide.pyimport("micropip");
      
      // Pre-load common libraries if needed or detect from code
      if (fullCode.includes('import pygame') || fullCode.includes('from pygame')) {
        log('Python Tool', 'Installing pygame-ce...');
        await micropip.install('pygame-ce');
      }
    }
    // @ts-ignore
    const pyodide = window.pyodide;
    
    log('Python Tool', 'Configuring environment...');
    
    // Setup plot capture, stdout redirection, and canvas for pygame
    await pyodide.runPythonAsync(`
import sys
import io
import base64
import matplotlib
import os

# Set environment variables for headless or browser execution
os.environ['SDL_VIDEODRIVER'] = 'dummy' if not sys.platform == 'emscripten' else 'emscripten'

matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Clear previous state
plt.clf()
plt.close('all')

# Global to store plots
_captured_plots = []

def _capture_current_plot():
    if len(plt.get_fignums()) > 0:
        buf = io.BytesIO()
        plt.savefig(buf, format='png', bbox_inches='tight', dpi=100)
        _captured_plots.append(base64.b64encode(buf.getvalue()).decode('utf-8'))
        buf.close()
        plt.close('all')

def custom_show(*args, **kwargs):
    _capture_current_plot()

plt.show = custom_show
plt.ioff()

sys.stdout = io.StringIO()

# Tkinter Shim/Warning
class TkinterShim:
    def __init__(self): self.Tk = self.Toplevel = self.Label = self.Button = self._mock
    def _mock(self, *args, **kwargs):
        print("Note: Tkinter is not fully supported in the browser. Using Pygame or Matplotlib is recommended for GUIs.")
        return self
    def mainloop(self): pass
    def title(self, t): pass
    def geometry(self, g): pass
    def pack(self, **kwargs): pass

sys.modules['tkinter'] = TkinterShim()
    `);
    
    // Check if pygame is used and show canvas
    if (fullCode.includes('import pygame') || fullCode.includes('from pygame')) {
      const canvasContainer = document.getElementById('python-canvas-container');
      if (canvasContainer) {
        canvasContainer.style.display = 'flex';
        // @ts-ignore
        pyodide.setCanvas2D('canvas');
      }
    } else {
      const canvasContainer = document.getElementById('python-canvas-container');
      if (canvasContainer) canvasContainer.style.display = 'none';
    }

    log('Python Tool', 'Executing code...');
    
    await pyodide.runPythonAsync(fullCode);
    
    // Final capture check if not already captured via show()
    await pyodide.runPythonAsync("_capture_current_plot()");
    
    const stdout = pyodide.runPython("sys.stdout.getvalue()");
    const plots = pyodide.runPython("_captured_plots");
    
    let plotBase64 = null;
    if (plots && plots.length > 0) {
      plotBase64 = `data:image/png;base64,${plots[0]}`;
    }
    
    return { stdout: stdout || "(Execution successful, no output)", plot: plotBase64 };
  } catch (e: any) {
    return { stdout: `Python Error: ${e.message}`, plot: null };
  }
};
