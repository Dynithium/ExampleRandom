/**
 * Google Drive Backup Service using Google Identity Services (GIS)
 * Saves/overwrites 'my_ai_chats.json' inside the user's hidden appDataFolder.
 */

import { Chat } from '../db';

const CLIENT_ID = '954868802105-im6kj8nd51k9ntlamfbho56p2ckcu5ba.apps.googleusercontent.com';
const SCOPE = 'https://www.googleapis.com/auth/drive.appdata https://www.googleapis.com/auth/userinfo.email';

let cachedToken: string | null = null;
let googleAuthCallback: ((token: string) => void) | null = null;
let googleAuthErrorCallback: ((err: any) => void) | null = null;
let tokenClient: any = null;
let onTokenExpiredCallback: (() => void) | null = null;

let lastSilentConnectAttempt = 0;
let silentAuthFailedCount = 0;

async function fetchAndStoreUserEmail(token: string) {
  try {
    // Attempt 1: Google Drive about API (fully authorized with drive scopes)
    const response = await fetch('https://www.googleapis.com/drive/v3/about?fields=user', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    if (response.ok) {
      const data = await response.json();
      if (data?.user?.emailAddress) {
        localStorage.setItem('gdrive_user_email', data.user.emailAddress);
        console.log('[Google Drive] Saved user email hint:', data.user.emailAddress);
        return;
      }
    }

    // Attempt 2: Userinfo endpoint (fallback)
    const uiResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    if (uiResponse.ok) {
      const data = await uiResponse.json();
      if (data?.email) {
        localStorage.setItem('gdrive_user_email', data.email);
        console.log('[Google Drive] Saved user email hint (from userinfo):', data.email);
      }
    }
  } catch (err) {
    console.warn('[Google Drive] Failed to retrieve user email for login hint:', err);
  }
}

export function registerTokenExpiredCallback(callback: () => void) {
  onTokenExpiredCallback = callback;
}

export function handlePossible401(response: Response) {
  if (response.status === 401) {
    console.warn("Google Drive API returned 401: Token expired or revoked.");
    setDriveToken(null);
    if (onTokenExpiredCallback) {
      onTokenExpiredCallback();
    }
  }
}

// Clean the chat log for backup - only keep text content and text of files (exclude images/binaries)
export function sanitizeChatsForBackup(chats: Chat[]): any[] {
  return chats.map(chat => ({
    id: chat.id,
    title: chat.title,
    createdAt: chat.createdAt,
    messages: chat.messages.map(msg => {
      const cleaned: any = {
        role: msg.role,
        content: msg.content,
        timestamp: msg.timestamp || Date.now()
      };
      
      // Keep only text files, no base64 images or binary contents
      if (msg.attachedFiles && msg.attachedFiles.length > 0) {
        cleaned.attachedFiles = msg.attachedFiles.map(file => ({
          name: file.name,
          type: file.type,
          text: file.extractedText || (file.type.startsWith('text/') ? file.content : undefined)
        })).filter(f => f.text !== undefined || f.name);
      }
      return cleaned;
    })
  }));
}

// In-memory token getter with local storage and expiration check
export function getDriveToken(): string | null {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('gdrive_access_token');
    const expiresAtStr = localStorage.getItem('gdrive_token_expires_at');
    const wasConnected = localStorage.getItem('gdrive_connected') === 'true';

    if (token && expiresAtStr) {
      const expiresAt = parseInt(expiresAtStr, 10);
      const now = Date.now();
      
      if (now < expiresAt) {
        // If it's about to expire in the next 10 minutes, trigger a background silent renewal!
        // This ensures the token is ALWAYS active and never gaps, giving a "signed in forever" feel while on the site
        if (expiresAt - now < 10 * 60 * 1000) {
          if (now - lastSilentConnectAttempt > 30000 && silentAuthFailedCount < 2) {
            lastSilentConnectAttempt = now;
            console.log('[Google Drive] Sync token is expiring soon. Prefetching fresh token silently in background...');
            connectGoogleDriveSilently();
          }
        }
        cachedToken = token;
        return cachedToken;
      } else {
        // Expired! Clear specific keys so we don't return an expired token
        cachedToken = null;
        localStorage.removeItem('gdrive_access_token');
        localStorage.removeItem('gdrive_token_expires_at');
        
        // Auto-reconnect silently if we're supposed to be connected
        if (wasConnected && now - lastSilentConnectAttempt > 20000 && silentAuthFailedCount < 2) {
          lastSilentConnectAttempt = now;
          console.log('[Google Drive] Stored sync token expired. Re-authenticating silently...');
          connectGoogleDriveSilently();
        }
      }
    } else if (wasConnected) {
      // Marked as connected but no token. Auto-reconnect silently!
      const now = Date.now();
      if (now - lastSilentConnectAttempt > 20000 && silentAuthFailedCount < 2) {
        lastSilentConnectAttempt = now;
        console.log('[Google Drive] Connected but no token found in storage. Restoring silently...');
        connectGoogleDriveSilently();
      }
    }
  }
  return null;
}

// Explicitly set the token with expiration persistence
export function setDriveToken(token: string | null, expiresInSeconds?: number) {
  cachedToken = token;
  if (token) {
    localStorage.setItem('gdrive_connected', 'true');
    localStorage.setItem('gdrive_access_token', token);
    const lifeSeconds = expiresInSeconds && typeof expiresInSeconds === 'number' ? expiresInSeconds : 3600;
    const expiresAt = Date.now() + lifeSeconds * 1000;
    localStorage.setItem('gdrive_token_expires_at', String(expiresAt));
  } else {
    localStorage.removeItem('gdrive_connected');
    localStorage.removeItem('gdrive_access_token');
    localStorage.removeItem('gdrive_token_expires_at');
    localStorage.removeItem('gdrive_user_email');
  }
}

// Initialize the GIS Token Client
export function initGoogleDriveAuth(onSuccess: (token: string) => void, onFailure?: (err: any) => void) {
  if (typeof window === 'undefined') return;

  googleAuthCallback = onSuccess;
  if (onFailure) {
    googleAuthErrorCallback = onFailure;
  }

  const initClient = () => {
    try {
      if (!(window as any).google?.accounts?.oauth2) {
        console.warn('Google Identity Services script not fully loaded yet. Retrying in 500ms...');
        setTimeout(initClient, 500);
        return;
      }

      tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPE,
        callback: (resp: any) => {
          if (resp?.error) {
            console.error('Google OAuth error:', resp.error);
            silentAuthFailedCount++;
            if (googleAuthErrorCallback) {
              googleAuthErrorCallback(resp);
            }
            return;
          }
          if (resp?.access_token) {
            silentAuthFailedCount = 0; // Reset failure count on success!
            setDriveToken(resp.access_token, resp.expires_in);
            
            // NEW: Fetch and cache user email for login hint
            fetchAndStoreUserEmail(resp.access_token);

            if (googleAuthCallback) {
              googleAuthCallback(resp.access_token);
            }
          }
        },
      });

      console.log('Google Sign-In Token Client initialized successfully.');

      // Check if we already have a valid stored token on startup and fire callback immediately!
      const existingToken = getDriveToken();
      if (existingToken && googleAuthCallback) {
        console.log('Restoring existing valid Google access token from localStorage');
        fetchAndStoreUserEmail(existingToken);
        googleAuthCallback(existingToken);
      }
    } catch (err) {
      console.error('Failed to initialize Google Identity Services client:', err);
    }
  };

  initClient();
}

// Trigger Google Popup for authorization
export function connectGoogleDrive(forceConsent: boolean = false) {
  if (!tokenClient) {
    initGoogleDriveAuth(() => {});
  }
  
  const options = forceConsent ? { prompt: 'consent' } : {};
  
  if (tokenClient) {
    tokenClient.requestAccessToken(options);
  } else {
    // Fallback if not ready yet
    setTimeout(() => {
      if (tokenClient) {
        tokenClient.requestAccessToken(options);
      } else {
        alert('Google Sign-In is initializing. Please try again in 2 seconds.');
      }
    }, 1000);
  }
}

// Silent token request if already authorized, retrying until tokenClient is ready
export function connectGoogleDriveSilently() {
  const trySilent = () => {
    if (tokenClient) {
      try {
        console.log('Attempting Google Drive silent connect/token renewal...');
        const userEmail = localStorage.getItem('gdrive_user_email');
        if (userEmail) {
          console.log('[Google Drive] Requesting silent access token with user hint:', userEmail);
          tokenClient.requestAccessToken({ prompt: '', hint: userEmail });
        } else {
          console.log('[Google Drive] Requesting silent access token (no user hint cached)');
          tokenClient.requestAccessToken({ prompt: '' });
        }
      } catch (err) {
        console.warn('Google Drive silent connect failed:', err);
      }
    } else {
      setTimeout(trySilent, 500);
    }
  };
  trySilent();
}

// Check if file my_ai_chats.json exists in appDataFolder, return fileId or null
export async function findBackupFile(token: string): Promise<string | null> {
  try {
    const response = await fetch(
      'https://www.googleapis.com/drive/v3/files?q=name%3D%27my_ai_chats.json%27+and+%27appDataFolder%27+in+parents&spaces=appDataFolder',
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
    if (!response.ok) {
      handlePossible401(response);
      throw new Error(`Drive list failed: ${response.statusText}`);
    }
    const data = await response.json();
    if (data.files && data.files.length > 0) {
      return data.files[0].id;
    }
  } catch (error) {
    console.error('Error finding backup file in Google Drive:', error);
  }
  return null;
}

// Save or overwrite my_ai_chats.json in appDataFolder
export async function saveChatsToGoogleDrive(chats: Chat[], token: string): Promise<boolean> {
  try {
    const cleaned = sanitizeChatsForBackup(chats);
    const fileId = await findBackupFile(token);

    if (fileId) {
      // Overwrite content
      const url = `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`;
      const response = await fetch(url, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(cleaned, null, 2)
      });
      if (!response.ok) {
        handlePossible401(response);
        throw new Error(`Patch failed: ${response.statusText}`);
      }
      return true;
    } else {
      // Create new file
      const boundary = '314159265358979323846';
      const delimiter = `\r\n--${boundary}\r\n`;
      const closeDelim = `\r\n--${boundary}--`;

      const metadata = {
        name: 'my_ai_chats.json',
        parents: ['appDataFolder']
      };

      const multipartRequestBody =
        delimiter +
        'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
        JSON.stringify(metadata) +
        delimiter +
        'Content-Type: application/json\r\n\r\n' +
        JSON.stringify(cleaned, null, 2) +
        closeDelim;

      const url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: multipartRequestBody
      });

      if (!response.ok) {
        handlePossible401(response);
        throw new Error(`Post failed: ${response.statusText}`);
      }
      return true;
    }
  } catch (error) {
    console.error('Failed silently saving/overwriting chat logs to Google Drive AppDataFolder:', error);
    return false;
  }
}

// Fetch the backup file from appDataFolder
export async function fetchChatsFromGoogleDrive(token: string): Promise<any[] | null> {
  try {
    const fileId = await findBackupFile(token);
    if (!fileId) return null;

    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    if (!response.ok) {
      handlePossible401(response);
      throw new Error(`Drive download failed: ${response.statusText}`);
    }
    const data = await response.json();
    if (Array.isArray(data)) {
      return data;
    }
  } catch (error) {
    console.error('Failed downloading chat logs from Google Drive AppDataFolder:', error);
  }
  return null;
}

// Check if file exists by name in appDataFolder, return fileId or null
export async function findFileByNameInAppData(name: string, token: string): Promise<string | null> {
  try {
    const response = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=name%3D%27${encodeURIComponent(name)}%27+and+%27appDataFolder%27+in+parents&spaces=appDataFolder`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
    if (!response.ok) {
      handlePossible401(response);
      throw new Error(`Drive list for ${name} failed: ${response.statusText}`);
    }
    const data = await response.json();
    if (data.files && data.files.length > 0) {
      return data.files[0].id;
    }
  } catch (error) {
    console.error(`Error finding ${name} file in Google Drive:`, error);
  }
  return null;
}

// Save or overwrite a specific file in appDataFolder
export async function saveFileToGoogleDrive(name: string, data: any, token: string): Promise<boolean> {
  try {
    const fileId = await findFileByNameInAppData(name, token);

    if (fileId) {
      // Overwrite content
      const url = `https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`;
      const response = await fetch(url, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data, null, 2)
      });
      if (!response.ok) {
        handlePossible401(response);
        throw new Error(`Patch failed for ${name}: ${response.statusText}`);
      }
      return true;
    } else {
      // Create new file
      const boundary = '314159265358979323846';
      const delimiter = `\r\n--${boundary}\r\n`;
      const closeDelim = `\r\n--${boundary}--`;

      const metadata = {
        name,
        parents: ['appDataFolder']
      };

      const multipartRequestBody =
        delimiter +
        'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
        JSON.stringify(metadata) +
        delimiter +
        'Content-Type: application/json\r\n\r\n' +
        JSON.stringify(data, null, 2) +
        closeDelim;

      const url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: multipartRequestBody
      });

      if (!response.ok) {
        handlePossible401(response);
        throw new Error(`Post failed for ${name}: ${response.statusText}`);
      }
      return true;
    }
  } catch (error) {
    console.error(`Failed saving ${name} to Google Drive AppDataFolder:`, error);
    return false;
  }
}

// Fetch a specific file from appDataFolder
export async function fetchFileFromGoogleDrive(name: string, token: string): Promise<any | null> {
  try {
    const fileId = await findFileByNameInAppData(name, token);
    if (!fileId) return null;

    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    if (!response.ok) {
      handlePossible401(response);
      throw new Error(`Drive download for ${name} failed: ${response.statusText}`);
    }
    return await response.json();
  } catch (error) {
    console.error(`Failed downloading ${name} from Google Drive AppDataFolder:`, error);
  }
  return null;
}

