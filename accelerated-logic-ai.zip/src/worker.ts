import "./patch-gpu";
import * as webllm from "@mlc-ai/web-llm";

/**
 * Worker for WebLLM to keep the UI responsive.
 */
let engine: any = null;

const handler = new webllm.WebWorkerMLCEngineHandler();

self.onmessage = (msg: MessageEvent) => {
  handler.onmessage(msg);
};
