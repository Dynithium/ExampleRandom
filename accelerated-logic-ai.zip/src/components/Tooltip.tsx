import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils';

interface TooltipProps {
  content: string;
  children: React.ReactNode;
  position?: 'top' | 'bottom' | 'left' | 'right';
  align?: 'start' | 'end' | 'center';
  className?: string;
  delay?: number;
}

export const Tooltip = ({ 
  content, 
  children, 
  position = 'top', 
  align = 'center',
  className,
  delay = 300 
}: TooltipProps) => {
  const [isVisible, setIsVisible] = useState(false);
  const [timer, setTimer] = useState<NodeJS.Timeout | null>(null);

  const handleMouseEnter = () => {
    const timeout = setTimeout(() => setIsVisible(true), delay);
    setTimer(timeout);
  };

  const handleMouseLeave = () => {
    if (timer) clearTimeout(timer);
    setIsVisible(false);
  };

  const positions = {
    top: {
      center: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
      start: 'bottom-full left-0 mb-2',
      end: 'bottom-full right-0 mb-2',
    },
    bottom: {
      center: 'top-full left-1/2 -translate-x-1/2 mt-2',
      start: 'top-full left-0 mt-2',
      end: 'top-full right-0 mt-2',
    },
    left: {
      center: 'right-full top-1/2 -translate-y-1/2 mr-2',
      start: 'right-full top-0 mr-2',
      end: 'right-full bottom-0 mr-2',
    },
    right: {
      center: 'left-full top-1/2 -translate-y-1/2 ml-2',
      start: 'left-full top-0 ml-2',
      end: 'left-full bottom-0 ml-2',
    },
  };

  const arrows = {
    top: {
      center: 'bottom-[-4px] left-1/2 -translate-x-1/2 border-t-card border-l-transparent border-r-transparent border-b-transparent',
      start: 'bottom-[-4px] left-4 border-t-card border-l-transparent border-r-transparent border-b-transparent',
      end: 'bottom-[-4px] right-4 border-t-card border-l-transparent border-r-transparent border-b-transparent',
    },
    bottom: {
      center: 'top-[-4px] left-1/2 -translate-x-1/2 border-b-card border-l-transparent border-r-transparent border-t-transparent',
      start: 'top-[-4px] left-4 border-b-card border-l-transparent border-r-transparent border-t-transparent',
      end: 'top-[-4px] right-4 border-b-card border-l-transparent border-r-transparent border-t-transparent',
    },
    left: {
      center: 'right-[-4px] top-1/2 -translate-y-1/2 border-l-card border-t-transparent border-b-transparent border-r-transparent',
      start: 'right-[-4px] top-2 border-l-card border-t-transparent border-b-transparent border-r-transparent',
      end: 'right-[-4px] bottom-2 border-l-card border-t-transparent border-b-transparent border-r-transparent',
    },
    right: {
      center: 'left-[-4px] top-1/2 -translate-y-1/2 border-r-card border-t-transparent border-b-transparent border-l-transparent',
      start: 'left-[-4px] top-2 border-r-card border-t-transparent border-b-transparent border-l-transparent',
      end: 'left-[-4px] bottom-2 border-r-card border-t-transparent border-b-transparent border-l-transparent',
    },
  };

  const isMultiline = content.includes('\n');

  return (
    <div 
      className={cn("relative inline-block", className)}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {children}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: position === 'top' ? 4 : position === 'bottom' ? -4 : 0 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: position === 'top' ? 4 : position === 'bottom' ? -4 : 0 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className={cn(
              "absolute z-[100] px-3 py-1.5 bg-card border border-border text-[10px] sm:text-xs font-medium text-foreground rounded-lg shadow-xl pointer-events-none",
              isMultiline 
                ? "whitespace-pre-line text-left tracking-normal leading-relaxed max-w-[280px] sm:max-w-[340px] min-w-[220px]" 
                : "whitespace-nowrap",
              positions[position][align]
            )}
          >
            {content}
            <div className={cn("absolute border-4", arrows[position][align])} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
