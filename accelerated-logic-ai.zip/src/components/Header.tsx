import { PanelLeftClose, PanelLeftOpen, Sparkles, ChevronDown, Trash2, Settings as Gear, Brain, Cloud, CloudOff, RefreshCw, Check } from "lucide-react";
import { cn } from "../utils";
import { Tooltip } from "./Tooltip";
import { getModelInfo } from "../models";
import { Settings, Chat, AppFile } from "../db";

interface HeaderProps {
  isSidebarOpen: boolean;
  setIsSidebarOpen: (isOpen: boolean) => void;
  currentChat: Chat | undefined;
  currentChatId: string | null;
  isMobile: boolean;
  settings: Settings;
  setIsModelOrganizerOpen: (isOpen: boolean) => void;
  setIsSettingsOpen: (isOpen: boolean) => void;
  setIsMemoryManagerOpen: (isOpen: boolean) => void;
  handleDeleteChat: (id: string) => void;
  isDriveConnected: boolean;
  isDriveSessionExpired?: boolean;
  onConnectDrive: () => void;
  isSyncingDrive: boolean;
  syncIndicatorStatus: 'idle' | 'syncing' | 'saved' | 'error';
}

export function Header({
  isSidebarOpen,
  setIsSidebarOpen,
  currentChat,
  currentChatId,
  isMobile,
  settings,
  setIsModelOrganizerOpen,
  setIsSettingsOpen,
  setIsMemoryManagerOpen,
  handleDeleteChat,
  isDriveConnected,
  isDriveSessionExpired,
  onConnectDrive,
  isSyncingDrive,
  syncIndicatorStatus,
}: HeaderProps) {
  const isRunningInIframe = typeof window !== 'undefined' && window.self !== window.top;
  const expiredTitle = isRunningInIframe
    ? "Google Drive session expired. Since you are inside the AI Studio preview iframe, browsers block silent backgrounds. Click to reconnect instantly, or open in a new tab!"
    : "Google Drive backup token has expired. Click to quickly refresh your session and resume automatic background backup.";

  // Dynamically compute the perfect 14-tooth gear path for the header logo
  const numTeeth = 14;
  const cx = 50, cy = 50;
  const radius = 35;
  const innerRadius = radius * 0.82;
  const step = (Math.PI * 2) / numTeeth;
  let gearPath = "";
  for (let i = 0; i < numTeeth; i++) {
    const startAngle = i * step;
    const a1 = startAngle;
    const a2 = startAngle + step * 0.32;
    const a3 = startAngle + step * 0.50;
    const a4 = startAngle + step * 0.82;

    const x1 = (cx + Math.cos(a1) * radius).toFixed(2);
    const y1 = (cy + Math.sin(a1) * radius).toFixed(2);
    const x2 = (cx + Math.cos(a2) * radius).toFixed(2);
    const y2 = (cy + Math.sin(a2) * radius).toFixed(2);
    const x3 = (cx + Math.cos(a3) * innerRadius).toFixed(2);
    const y3 = (cy + Math.sin(a3) * innerRadius).toFixed(2);
    const x4 = (cx + Math.cos(a4) * innerRadius).toFixed(2);
    const y4 = (cy + Math.sin(a4) * innerRadius).toFixed(2);

    if (i === 0) {
      gearPath += `M ${x1} ${y1} `;
    } else {
      gearPath += `L ${x1} ${y1} `;
    }
    gearPath += `L ${x2} ${y2} L ${x3} ${y3} L ${x4} ${y4} `;
  }
  gearPath += "Z";

  return (
    <header className="h-14 border-b border-border flex items-center justify-between px-2 sm:px-4 bg-background/80 backdrop-blur-md z-10">
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        <button 
          id="tour-sidebar-toggle"
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className={cn(
            "p-2 hover:bg-accent rounded-lg transition-all shrink-0",
            !isSidebarOpen && "bg-primary text-white hover:bg-primary/90 shadow-md"
          )}
          title={isSidebarOpen ? "Collapse Sidebar" : "Open Sidebar"}
        >
          {isSidebarOpen ? <PanelLeftClose className="w-5 h-5" /> : <PanelLeftOpen className="w-5 h-5" />}
        </button>
        <div className="flex flex-col min-w-0">
          <span className="text-sm font-semibold truncate max-w-[120px] sm:max-w-[200px]">
            {currentChat?.title || 'Accelerated Logic'}
          </span>
          <span className="text-[9px] sm:text-[10px] text-muted-foreground uppercase tracking-widest font-bold truncate">
            Private AI Platform
          </span>
        </div>
      </div>

      <div className="flex items-center gap-1 sm:gap-2">
         {/* Google Drive Connection Button / Status */}
        {isDriveConnected ? (
          isDriveSessionExpired ? (
            <button
              id="tour-gdrive"
              onClick={onConnectDrive}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-xl text-xs font-semibold cursor-pointer shadow-[0_0_8px_rgba(245,158,11,0.1)] transition-all duration-300"
              title={expiredTitle}
            >
              <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span className="leading-none hidden sm:inline">Session Expired (Reconnect)</span>
              <span className="leading-none sm:hidden">Reconnect</span>
            </button>
          ) : (
            <div 
              id="tour-gdrive"
              className={cn(
                "flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold cursor-default transition-all duration-300",
                syncIndicatorStatus === 'syncing' && "bg-amber-500/10 border border-amber-500/30 text-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.1)]",
                syncIndicatorStatus === 'saved' && "bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.15)]",
                syncIndicatorStatus === 'error' && "bg-rose-500/10 border border-rose-500/30 text-rose-400 animate-shake",
                (syncIndicatorStatus === 'idle' || !syncIndicatorStatus) && "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
              )}
              title="Google Drive backup is connected and actively monitoring browser changes."
            >
              {syncIndicatorStatus === 'syncing' ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : syncIndicatorStatus === 'saved' ? (
                <Check className="w-3.5 h-3.5 text-emerald-400" />
              ) : syncIndicatorStatus === 'error' ? (
                <CloudOff className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              ) : (
                <Cloud className="w-3.5 h-3.5 text-emerald-400" />
              )}
              <span className="hidden leading-none sm:inline">
                {syncIndicatorStatus === 'syncing' && "Syncing..."}
                {syncIndicatorStatus === 'saved' && "Changes Saved"}
                {syncIndicatorStatus === 'error' && "Sync Error"}
                {(syncIndicatorStatus === 'idle' || !syncIndicatorStatus) && "Synced to Drive"}
              </span>
            </div>
          )
        ) : (
          <button
            id="tour-gdrive"
            onClick={onConnectDrive}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 hover:scale-[1.02] active:scale-[0.98] text-white rounded-xl text-xs font-semibold shadow-md shadow-blue-500/10 transition-all duration-200 cursor-pointer"
            title="Authenticate with Google Identity Services to save chats to your Google Drive App Sandbox."
          >
            <span className="leading-none">Sign In</span>
          </button>
        )}

        <button 
          id="tour-settings"
          onClick={() => setIsSettingsOpen(true)}
          className="p-2 hover:bg-accent rounded-lg transition-colors"
          title="Settings"
        >
          <Gear className="w-5 h-5" />
        </button>
        {currentChatId && !isMobile && (
          <button 
            onClick={() => handleDeleteChat(currentChatId!)}
            className="p-2 hover:bg-destructive/10 text-muted-foreground hover:text-destructive rounded-lg transition-colors"
            title="Delete Current Chat"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        )}
      </div>
    </header>
  );
}
