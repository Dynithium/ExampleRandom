import React, { useState } from 'react';
import { Terminal, Copy, Check, Play, Loader2, X, Monitor, Wand2, FolderPlus, Download } from 'lucide-react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

export const CodeBlock = ({ 
  code, 
  language, 
  props, 
  setActiveCodePreview, 
  onFixError, 
  isGenerating, 
  onSaveToFile 
}: any) => {
  const [copied, setCopied] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [fileName, setFileName] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getDownloadFileName = () => {
    const defaultName = getDefaultFileName();
    if (defaultName !== 'document.txt') return defaultName;
    
    // Check extra languages that might not be in getDefaultFileName
    const lang = String(language).toLowerCase();
    if (lang === 'sql') return 'query.sql';
    if (lang === 'sh' || lang === 'bash' || lang === 'shell') return 'script.sh';
    if (lang === 'rust' || lang === 'rs') return 'main.rs';
    if (lang === 'cpp' || lang === 'c++') return 'main.cpp';
    if (lang === 'c') return 'main.c';
    if (lang === 'java') return 'Main.java';
    if (lang === 'go') return 'main.go';
    if (lang === 'yaml' || lang === 'yml') return 'config.yaml';
    if (lang === 'toml') return 'config.toml';
    if (lang === 'dockerfile' || lang === 'docker') return 'Dockerfile';
    return 'document.txt';
  };

  const handleDownload = () => {
    const fn = getDownloadFileName();
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fn;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2000);
  };

  const isDiff = code.includes('<<<<') && code.includes('====') && code.includes('>>>>');
  const displayLanguage = language === 'python_tool' ? 'python' : language;

  const onApplyPatch = () => {
    if (setActiveCodePreview) {
      setActiveCodePreview({ code, language, isPatch: true });
    }
  };

  const handleRun = async () => {
    if (['html', 'javascript', 'typescript', 'react', 'jsx', 'tsx'].includes(language)) {
      setActiveCodePreview({ code, language });
    }
  };

  const getDefaultFileName = () => {
    const lang = String(language).toLowerCase();
    if (lang === 'html') return 'index.html';
    if (lang === 'python' || lang === 'python_tool') return 'main.py';
    if (lang === 'javascript' || lang === 'js') return 'script.js';
    if (lang === 'typescript' || lang === 'ts') return 'script.ts';
    if (lang === 'react' || lang === 'jsx') return 'app.jsx';
    if (lang === 'tsx') return 'app.tsx';
    if (lang === 'css') return 'styles.css';
    if (lang === 'json') return 'data.json';
    if (lang === 'markdown' || lang === 'md') return 'readme.md';
    return 'document.txt';
  };

  const handleStartSave = () => {
    setFileName(getDefaultFileName());
    setIsSaving(true);
    setSaveSuccess(false);
  };

  const handleConfirmSave = async () => {
    if (!fileName.trim() || !onSaveToFile) return;
    const resolvedName = fileName.trim();
    
    // Determine the type
    let fileType = 'text/plain';
    const ext = resolvedName.split('.').pop()?.toLowerCase();
    if (ext === 'html') fileType = 'text/html';
    else if (ext === 'py') fileType = 'text/x-python';
    else if (ext === 'js' || ext === 'jsx') fileType = 'text/javascript';
    else if (ext === 'ts' || ext === 'tsx') fileType = 'text/typescript';
    else if (ext === 'css') fileType = 'text/css';
    else if (ext === 'json') fileType = 'application/json';
    else if (ext === 'md') fileType = 'text/markdown';

    await onSaveToFile(resolvedName, code, fileType);
    setSaveSuccess(true);
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(false);
    }, 1500);
  };

  return (
    <div id={`code-block-${language}-${Math.random().toString(36).slice(2, 6)}`} className="my-4 rounded-xl overflow-hidden border border-border bg-zinc-950 shadow-sm group/code">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between px-4 py-2 bg-zinc-900/50 border-b border-border gap-2">
        <div className="flex items-center justify-between sm:justify-start gap-2 w-full sm:w-auto">
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-zinc-500" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">{displayLanguage}</span>
            {isDiff && (
              <span className="text-[8px] bg-primary/20 text-primary px-1.5 py-0.5 rounded font-black tracking-widest uppercase">Diff</span>
            )}
          </div>
          
          {/* Mobile status banner inside code block if saving */}
          {saveSuccess && (
            <span className="text-[9px] bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded animate-bounce">
              {['html'].includes(language) || fileName.toLowerCase().endsWith('.html') || fileName.toLowerCase().endsWith('.htm') ? 'Saved as Sandbox App!' : 'Saved to Workspace Files!'}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {isSaving ? (
            <div className="flex items-center gap-1.5 bg-zinc-950 border border-border rounded-lg p-0.5 animate-in fade-in slide-in-from-right-2 duration-200">
              <input 
                type="text" 
                value={fileName}
                onChange={(e) => setFileName(e.target.value)}
                placeholder="filename..."
                className="bg-transparent border-none text-[10px] font-mono text-zinc-200 outline-none w-28 sm:w-40 px-2 py-0.5 focus:ring-0"
                disabled={saveSuccess}
              />
              {saveSuccess ? (
                <span className="p-1 text-emerald-500">
                  <Check className="w-3.5 h-3.5" />
                </span>
              ) : (
                <>
                  <button 
                    onClick={handleConfirmSave}
                    className="p-1 hover:bg-zinc-800 rounded text-emerald-500 hover:text-emerald-400"
                    title="Confirm Save"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                  <button 
                    onClick={() => setIsSaving(false)}
                    className="p-1 hover:bg-zinc-800 rounded text-zinc-400 hover:text-white"
                    title="Cancel"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </>
              )}
            </div>
          ) : (
            <>
              {onSaveToFile && (
                <button 
                  onClick={handleStartSave}
                  className="p-1.5 hover:bg-zinc-800 rounded-md text-zinc-400 hover:text-white transition-colors"
                  title="Save to App Files"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                </button>
              )}
              {isDiff && (
                <button 
                  onClick={onApplyPatch}
                  className="p-1.5 hover:bg-primary/20 rounded-md text-primary transition-colors flex items-center gap-1"
                  title="Apply Surgical Edits"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase tracking-widest hidden sm:inline">Apply Patch</span>
                </button>
              )}
              <button 
                onClick={handleCopy}
                className="p-1.5 hover:bg-zinc-800 rounded-md text-zinc-400 hover:text-white transition-colors"
                title="Copy Code"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
              <button 
                onClick={handleDownload}
                className="p-1.5 hover:bg-zinc-800 rounded-md text-zinc-400 hover:text-white transition-colors flex items-center justify-center animate-in fade-in zoom-in duration-300"
                title={`Download File (${getDownloadFileName()})`}
              >
                {downloaded ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Download className="w-3.5 h-3.5" />}
              </button>
              {!isGenerating && ['html', 'javascript', 'typescript', 'react', 'jsx', 'tsx'].includes(language) && (
                <button 
                  onClick={handleRun}
                  className="p-1.5 hover:bg-zinc-800 rounded-md text-zinc-400 hover:text-white transition-colors animate-in fade-in zoom-in duration-300"
                  title="Preview Code"
                >
                  {['html', 'react', 'jsx', 'tsx'].includes(language) ? <Monitor className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                </button>
              )}
            </>
          )}
        </div>
      </div>
      <div className="relative max-h-[600px] overflow-auto custom-scrollbar">
        <SyntaxHighlighter
          style={vscDarkPlus}
          language={displayLanguage}
          PreTag="div"
          customStyle={{ 
            margin: 0, 
            padding: '1rem', 
            background: 'transparent', 
            fontSize: '13px',
            lineHeight: '1.6'
          }}
          {...props}
        >
          {code}
        </SyntaxHighlighter>
      </div>
    </div>
  );
};
