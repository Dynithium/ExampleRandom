import { useEffect, useRef, useState } from 'react';

interface LandingPageProps {
  onLaunch: () => void;
}

export function LandingPage({ onLaunch }: LandingPageProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [speedBoost, setSpeedBoost] = useState<number>(0);
  const boostRef = useRef<number>(0);
  const [isAppearedMap, setIsAppearedMap] = useState<Record<number, boolean>>({});

  // Elements shown
  const [brandVisible, setBrandVisible] = useState(false);
  const [haloVisible, setHaloVisible] = useState(false);

  // Sub-routes state management
  const [currentSubView, setCurrentSubView] = useState<'home' | 'privacy' | 'about' | 'contact'>(() => {
    const path = window.location.pathname;
    if (path === '/privacy') return 'privacy';
    if (path === '/about') return 'about';
    if (path === '/contact') return 'contact';
    return 'home';
  });

  const navigateTo = (view: 'home' | 'privacy' | 'about' | 'contact', event?: React.MouseEvent) => {
    if (event) {
      event.preventDefault();
    }
    const path = view === 'home' ? '/' : `/${view}`;
    window.history.pushState(null, '', path);
    setCurrentSubView(view);
  };

  useEffect(() => {
    const handlePop = () => {
      const path = window.location.pathname;
      if (path === '/privacy') {
        setCurrentSubView('privacy');
      } else if (path === '/about') {
        setCurrentSubView('about');
      } else if (path === '/contact') {
        setCurrentSubView('contact');
      } else {
        setCurrentSubView('home');
      }
    };
    window.addEventListener('popstate', handlePop);
    return () => window.removeEventListener('popstate', handlePop);
  }, []);

  const startEntranceRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrameId: number | null = null;
    let startTime: number | null = null;
    const ENTRANCE = 1800;
    let idle = 0;

    const BLUE = '#3b82f6';
    const BLUE_DIM = 'rgba(59,130,246,0.25)';

    function easeOutBack(x: number) {
      const c1 = 1.6, c2 = c1 + 1;
      return 1 + c2 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
    }
    
    function easeOutQuint(x: number) {
      return 1 - Math.pow(1 - x, 5);
    }

    function resize() {
      const size = Math.min(window.innerWidth * 0.55, window.innerHeight * 0.38, 300);
      canvas.width = size * window.devicePixelRatio;
      canvas.height = size * window.devicePixelRatio;
      canvas.style.width = size + 'px';
      canvas.style.height = size + 'px';
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    }

    function drawSwoosh(cx: number, cy: number, r: number, a1: number, a2: number, lw: number, grad: CanvasGradient) {
      ctx.save();
      ctx.strokeStyle = grad;
      ctx.lineWidth = lw;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(cx, cy, r, a1, a2, false);
      ctx.stroke();
      ctx.restore();
    }

    function render(scale: number, rot: number, progress: number, idleV: number) {
      const w = canvas.width / window.devicePixelRatio;
      const h = canvas.height / window.devicePixelRatio;
      const cx = w / 2, cy = h / 2;
      const radius = w * 0.32 * scale;
      const numTeeth = 14;
      const toothDepth = radius * 0.18;
      const innerRadius = radius - toothDepth;
      const shaftRadius = radius * 0.28;

      ctx.clearRect(0, 0, w, h);
      if (scale <= 0.001) return;

      const sweepOffset = (1 - easeOutQuint(progress)) * Math.PI * 2;

      // Swooshes
      const swooshes = [
        { r: radius * 1.30, s: -Math.PI * 0.6 - sweepOffset + idleV, e: Math.PI * 0.5 - sweepOffset + idleV, w: 5 * scale, a: 0.95 * progress },
        { r: radius * 1.18, s: -Math.PI * 0.4 + sweepOffset + idleV * 0.7, e: Math.PI * 0.3 + sweepOffset + idleV * 0.7, w: 3 * scale, a: 0.60 * progress },
        { r: radius * 1.42, s: -Math.PI * 0.7 - sweepOffset * 0.5 + idleV * 1.2, e: Math.PI * 0.1 - sweepOffset * 0.5 + idleV * 1.2, w: 1.5 * scale, a: 0.35 * progress }
      ];

      swooshes.forEach(s => {
        if (s.r <= 0) return;
        const g = ctx.createLinearGradient(
          cx + Math.cos(s.s) * s.r, cy + Math.sin(s.s) * s.r,
          cx + Math.cos(s.e) * s.r, cy + Math.sin(s.e) * s.r
        );
        g.addColorStop(0, `rgba(59,130,246,${s.a * 0.05})`);
        g.addColorStop(0.6, `rgba(59,130,246,${s.a * 0.8})`);
        g.addColorStop(1, `rgba(147,197,253,${s.a})`);
        drawSwoosh(cx, cy, s.r, s.s, s.e, s.w, g);

        ctx.save();
        ctx.fillStyle = `rgba(59,130,246,${s.a})`;
        ctx.shadowColor = BLUE;
        ctx.shadowBlur = 10 * scale;
        ctx.beginPath();
        ctx.arc(cx + Math.cos(s.e) * s.r, cy + Math.sin(s.e) * s.r, s.w * 0.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Gear
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rot + idleV * 0.2);
      ctx.shadowColor = `rgba(59,130,246,${0.25 * progress})`;
      ctx.shadowBlur = 40 * scale;

      ctx.beginPath();
      const step = (Math.PI * 2) / numTeeth;
      for (let i = 0; i < numTeeth; i++) {
        const ang = i * step;
        ctx.lineTo(Math.cos(ang) * radius, Math.sin(ang) * radius);
        ctx.lineTo(Math.cos(ang + step * 0.32) * radius, Math.sin(ang + step * 0.32) * radius);
        ctx.lineTo(Math.cos(ang + step * 0.50) * innerRadius, Math.sin(ang + step * 0.50) * innerRadius);
        ctx.lineTo(Math.cos(ang + step * 0.82) * innerRadius, Math.sin(ang + step * 0.82) * innerRadius);
      }
      ctx.closePath();

      const gg = ctx.createRadialGradient(0, 0, shaftRadius, 0, 0, radius);
      gg.addColorStop(0, '#0f172a');
      gg.addColorStop(0.8, '#172554');
      gg.addColorStop(1, '#020617');
      ctx.fillStyle = gg;
      ctx.fill();

      ctx.shadowBlur = 0;
      ctx.strokeStyle = `rgba(59,130,246,${progress})`;
      ctx.lineWidth = 3.5 * scale;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, radius * 0.56, 0, Math.PI * 2);
      ctx.strokeStyle = BLUE_DIM;
      ctx.lineWidth = 1.5 * scale;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, shaftRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#111827';
      ctx.strokeStyle = BLUE;
      ctx.lineWidth = 3.5 * scale;
      ctx.fill();
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, shaftRadius * 0.45, 0, Math.PI * 2);
      ctx.fillStyle = '#030712';
      ctx.fill();

      ctx.restore();
    }

    function tick(ts: number) {
      if (!startTime) startTime = ts;
      const elapsed = ts - startTime;
      const progress = Math.min(1, elapsed / ENTRANCE);
      const scale = easeOutBack(progress);
      const rotation = -Math.PI * 3 * (1 - easeOutQuint(progress)) - 0.25;

      if (progress >= 1) {
        idle += 0.005 + boostRef.current * 0.015;
        boostRef.current *= 0.95;
      } else {
        idle = 0;
        boostRef.current = 0;
      }

      // Reveal brand text and halo after gear appears
      if (progress > 0.45) {
        setHaloVisible(true);
        setBrandVisible(true);
      } else {
        setHaloVisible(false);
        setBrandVisible(false);
      }

      render(scale, rotation, progress, idle);
      animFrameId = requestAnimationFrame(tick);
    }

    function startEntrance() {
      if (animFrameId) cancelAnimationFrame(animFrameId);
      startTime = null;
      idle = 0;
      boostRef.current = 0;
      setBrandVisible(false);
      setHaloVisible(false);
      animFrameId = requestAnimationFrame(tick);
    }

    startEntranceRef.current = startEntrance;

    window.addEventListener('resize', resize);
    resize();
    startEntrance();

    return () => {
      window.removeEventListener('resize', resize);
      if (animFrameId) {
        cancelAnimationFrame(animFrameId);
      }
    };
  }, [currentSubView]);

  // Features scroll reveal logic
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          const idx = Number(e.target.getAttribute('data-feature-idx'));
          setIsAppearedMap(prev => ({ ...prev, [idx]: true }));
        }
      });
    }, { threshold: 0.15 });

    const elements = document.querySelectorAll('.feature-card');
    elements.forEach(el => observer.observe(el));

    return () => {
      elements.forEach(el => observer.unobserve(el));
    };
  }, [currentSubView]);

  const handleMouseMove = () => {
    if (boostRef.current < 8) {
      boostRef.current += 0.2;
      setSpeedBoost(boostRef.current);
    }
  };

  const handleClickCanvas = () => {
    boostRef.current = 25;
    setSpeedBoost(25);
  };

  const triggerReplay = () => {
    if (startEntranceRef.current) {
      startEntranceRef.current();
    }
  };

  return (
    <div className="min-h-screen w-full relative z-[9999] bg-[#030712] text-[#f1f5f9] select-none overflow-y-auto overflow-x-hidden font-sans antialiased text-base">
      
      {/* Grid Noise Background */}
      <div className="fixed inset-0 pointer-events-none z-0 bg-[linear-gradient(rgba(59,130,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />

      {/* Deep Radial Atmosphere */}
      <div className="fixed inset-0 pointer-events-none z-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_0%,rgba(59,130,246,0.06)_0%,transparent_70%),radial-gradient(ellipse_40%_40%_at_50%_50%,rgba(59,130,246,0.04)_0%,transparent_80%)]" />

      {/* Top Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-[100] flex items-center justify-between px-6 sm:px-12 py-5 border-b border-[rgba(59,130,246,0.12)] bg-[#030712]/70 backdrop-blur-md">
        <div 
          onClick={(e) => navigateTo('home', e)}
          className="font-['Space_Grotesk'] text-[13px] font-semibold tracking-[0.28em] uppercase text-[#64748b] cursor-pointer hover:opacity-95 select-none"
        >
          <span className="text-[#3b82f6]">Accelerated</span>Logic
        </div>

        {/* Dynamic Nav Links in Header */}
        <div className="flex items-center gap-4 sm:gap-8 text-[11px] sm:text-[12px] font-['Space_Grotesk'] font-bold uppercase tracking-widest text-[#64748b]">
          <a
            href="https://acceleratedlogicai.com/about"
            onClick={(e) => navigateTo('about', e)}
            className={`transition-colors duration-250 hover:text-[#3b82f6] ${
              currentSubView === 'about' ? 'text-[#3b82f6]' : ''
            }`}
          >
            About Us
          </a>
          <a
            href="https://acceleratedlogicai.com/privacy"
            onClick={(e) => navigateTo('privacy', e)}
            className={`transition-colors duration-250 hover:text-[#3b82f6] ${
              currentSubView === 'privacy' ? 'text-[#3b82f6]' : ''
            }`}
          >
            Privacy Policy
          </a>
          <a
            href="https://acceleratedlogicai.com/contact"
            onClick={(e) => navigateTo('contact', e)}
            className={`transition-colors duration-250 hover:text-[#3b82f6] ${
              currentSubView === 'contact' ? 'text-[#3b82f6]' : ''
            }`}
          >
            Contact
          </a>

          <button
            onClick={onLaunch}
            className="hidden sm:inline-flex items-center justify-center px-4 py-1.5 font-['Space_Grotesk'] text-[10px] font-semibold tracking-widest uppercase text-white bg-[#3b82f6] hover:bg-[#3b82f6]/90 border-none rounded-[4px] cursor-pointer transition-all duration-300 shadow-[0_0_15px_rgba(59,130,246,0.25)]"
          >
            Launch
          </button>
        </div>
      </nav>

      {/* Conditional View Routing */}
      {currentSubView === 'home' ? (
        <>
          {/* Hero Section */}
          <section className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 py-20 pb-28">

            {/* Logo Mark */}
            <div className="relative cursor-pointer mb-10" id="logoWrap" onMouseMove={handleMouseMove} onClick={handleClickCanvas}>
              <div className={`absolute -inset-[30%] bg-[radial-gradient(ellipse_at_center,rgba(59,130,246,0.07)_0%,transparent_70%)] rounded-full transition-opacity duration-[1200ms] pointer-events-none ${haloVisible ? 'opacity-100' : 'opacity-0'}`} />
              <canvas ref={canvasRef} id="logoCanvas" className="relative z-10 transition-transform duration-300 ease-out active:scale-95" />
            </div>

            {/* Brand Name */}
            <p className={`font-['Space_Grotesk'] text-[13px] font-normal tracking-[0.32em] uppercase text-[#64748b] mb-4 transition-all duration-[1200ms] cubic-bezier(0.16,1,0.3,1) ${brandVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-[14px]'}`}>
              <span className="font-semibold text-[#3b82f6] tracking-[0.36em]">Accelerated</span>&nbsp;Logic
            </p>

            {/* Headline */}
            <h1 className="font-['Space_Grotesk'] text-[36px] sm:text-[6vw] lg:text-[72px] font-light leading-[1.08] tracking-tight text-center text-[#f1f5f9] max-w-[800px] mb-5 opacity-0 animate-[rise_0.9s_2.6s_cubic-bezier(0.16,1,0.3,1)_forwards]">
              Intelligence that<br />
              <em className="font-normal bg-gradient-to-r from-[#3b82f6] to-[#93c5fd] bg-clip-text text-transparent not-italic">Drives the World.</em>
            </h1>

            {/* Subline */}
            <p className="text-[14px] sm:text-[15px] font-normal leading-relaxed text-[#64748b] text-center max-w-[640px] mb-12 opacity-0 animate-[rise_0.9s_2.9s_cubic-bezier(0.16,1,0.3,1)_forwards]">
              Orchestrate AI Agents, Create Apps that Transform Industries, and more. All for <span className="bg-gradient-to-r from-[#3b82f6] to-[#60a5fa] bg-clip-text text-transparent font-semibold">free</span>.
            </p>

            {/* CTA Launch */}
            <div className="flex flex-col items-center gap-4 opacity-0 animate-[rise_0.9s_3.2s_cubic-bezier(0.16,1,0.3,1)_forwards]">
              <button
                onClick={() => {
                  boostRef.current = 35;
                  setTimeout(onLaunch, 300);
                }}
                className="group relative inline-flex items-center gap-3 px-12 py-[18px] font-['Space_Grotesk'] text-xs sm:text-sm font-semibold tracking-widest uppercase text-white bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] border-none rounded-[4px] cursor-pointer overflow-hidden transition-all duration-300 hover:scale-105 active:scale-95 shadow-[0_0_0_1px_rgba(59,130,246,0.4),0_8px_32px_rgba(59,130,246,0.25)] hover:shadow-[0_0_0_1px_rgba(59,130,246,0.6),0_16px_48px_rgba(59,130,246,0.35)]"
              >
                <span className="relative z-10 flex items-center gap-2">
                  Launch AcceleratedLogic
                  <svg className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3 8H13M13 8L9 4M13 8L9 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent transition-opacity duration-300 opacity-0 group-hover:opacity-100" />
              </button>
              <a
                href="#capabilities"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('capabilities')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-[12px] font-medium tracking-[0.1em] text-[#64748b] uppercase px-4 py-2 rounded-[4px] transition-colors duration-200 hover:text-[#3b82f6]"
              >
                Explore capabilities
              </a>
            </div>
          </section>

          {/* Decorative Divider */}
          <div className="w-full max-w-[800px] h-[1px] bg-gradient-to-r from-transparent via-[rgba(59,130,246,0.12)] to-transparent mx-auto relative z-10" />

          {/* Features capabilities Section */}
          <section id="capabilities" className="relative z-10 flex flex-col md:flex-row items-stretch justify-center gap-0 max-w-[860px] mx-auto px-6 pb-24 pt-12">
            
            {/* Capability 1 */}
            <div 
              data-feature-idx="1"
              className={`feature-card flex-1 p-12 border-b md:border-b-0 md:border-r border-[rgba(59,130,246,0.12)] transition-all duration-700 ease-out transform ${isAppearedMap[1] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
            >
              <svg className="w-8 h-8 text-[#3b82f6] opacity-80 mb-5" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="6" y="6" width="20" height="20" rx="4" stroke="currentColor" strokeWidth="1.5" />
                <path d="M11 12h10M11 16h10M11 20h6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              </svg>
              <p className="font-['Space_Grotesk'] text-sm font-semibold tracking-wider text-[#f1f5f9] mb-2.5">
                Multi-Agent Workspaces
              </p>
              <p className="text-[13px] leading-relaxed text-[#64748b] font-normal">
                Deploy, orchestrate, and trace collaborative teams of AI agents using an interactive, node-based prompt architecture.
              </p>
            </div>

            {/* Capability 2 */}
            <div 
              data-feature-idx="2"
              className={`feature-card flex-1 p-12 border-b md:border-b-0 md:border-r border-[rgba(59,130,246,0.12)] transition-all duration-700 ease-out transform delay-150 ${isAppearedMap[2] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
            >
              <svg className="w-8 h-8 text-[#3b82f6] opacity-80 mb-5" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="6" y="6" width="8" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.5" />
                <rect x="18" y="6" width="8" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.5" />
                <rect x="6" y="18" width="8" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.5" />
                <rect x="18" y="18" width="8" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.5" />
              </svg>
              <p className="font-['Space_Grotesk'] text-sm font-semibold tracking-wider text-[#f1f5f9] mb-2.5">
                Local Sandboxing
              </p>
              <p className="text-[13px] leading-relaxed text-[#64748b] font-normal">
                Execute code in real-time inside completely isolated client-side Python runtimes and premium HTML/CSS sandboxes.
              </p>
            </div>

            {/* Capability 3 */}
            <div 
              data-feature-idx="3"
              className={`feature-card flex-1 p-12 border-[rgba(59,130,246,0.12)] transition-all duration-700 ease-out transform delay-300 ${isAppearedMap[3] ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
            >
              <svg className="w-8 h-8 text-[#3b82f6] opacity-80 mb-5" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 4L28 10v12L16 28 4 22V10L16 4z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
                <path d="M16 16l12-6M16 16v12M16 16L4 10" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" opacity="0.5" />
              </svg>
              <p className="font-['Space_Grotesk'] text-sm font-semibold tracking-wider text-[#f1f5f9] mb-2.5">
                Cognitive Plugins & Skills
              </p>
              <p className="text-[13px] leading-relaxed text-[#64748b] font-normal">
                Equip agents with dynamic custom skills, local context injections, and personalized vector search databases on the fly.
              </p>
            </div>

          </section>
        </>
      ) : (
        <>
          {/* Sub views */}
          {currentSubView === 'privacy' && (
            <section className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 py-32">
              <div className="w-full max-w-2xl bg-[#090d16] border border-[rgba(59,130,246,0.15)] rounded-2xl p-8 sm:p-12 shadow-[0_0_50px_rgba(59,130,246,0.05)] relative overflow-hidden animate-[rise_0.6s_cubic-bezier(0.16,1,0.3,1)_forwards]">
                {/* Subtle visual glow */}
                <div className="absolute -top-32 -left-32 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
                <div className="absolute -bottom-32 -right-32 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
                
                <div className="relative z-10 space-y-6">
                  <div className="flex items-center gap-3 text-xs font-mono text-[#3b82f6]/80 tracking-widest uppercase">
                    <span>acceleratedlogicai.com/privacy</span>
                  </div>
                  
                  <h1 className="font-['Space_Grotesk'] text-3xl sm:text-4xl font-light tracking-tight text-[#f1f5f9]">
                    Privacy Policy
                  </h1>
                  
                  <div className="w-12 h-[2px] bg-gradient-to-r from-[#3b82f6] to-transparent" />
                  
                  <p className="text-sm sm:text-base leading-relaxed text-[#94a3b8] font-normal">
                    At Accelerated Logic, safeguarding user information is our highest priority. This document outlines our structural stance on privacy:
                  </p>
                  
                  <div className="p-6 bg-blue-500/5 border border-blue-500/10 rounded-xl">
                    <p className="text-[15px] sm:text-[16px] font-semibold text-[#f1f5f9] leading-relaxed">
                      We don't share any information with 3rd parties.
                    </p>
                  </div>

                  <p className="text-xs text-[#64748b] leading-relaxed">
                    All conversations, workspace histories, uploaded document tokens, sandbox configurations, and key credentials stay inside your local IndexedDB workspace database or authorized cloud syncing containers.
                  </p>

                  <div className="pt-6 flex flex-col sm:flex-row items-center gap-4">
                    <button 
                      onClick={onLaunch}
                      className="text-xs font-semibold tracking-wider font-['Space_Grotesk'] uppercase text-[#3b82f6] hover:underline hover:cursor-pointer"
                    >
                      Launch Platform →
                    </button>
                  </div>
                </div>
              </div>
            </section>
          )}

          {currentSubView === 'about' && (
            <section className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 py-32">
              <div className="w-full max-w-2xl bg-[#090d16] border border-[rgba(59,130,246,0.15)] rounded-2xl p-8 sm:p-12 shadow-[0_0_50px_rgba(59,130,246,0.05)] relative overflow-hidden animate-[rise_0.6s_cubic-bezier(0.16,1,0.3,1)_forwards]">
                <div className="absolute -top-32 -left-32 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
                <div className="absolute -bottom-32 -right-32 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
                
                <div className="relative z-10 space-y-6">
                  <div className="flex items-center gap-3 text-xs font-mono text-[#3b82f6]/80 tracking-widest uppercase">
                    <span>acceleratedlogicai.com/about</span>
                  </div>
                  
                  <h1 className="font-['Space_Grotesk'] text-3xl sm:text-4xl font-light tracking-tight text-[#f1f5f9]">
                    About Us
                  </h1>
                  
                  <div className="w-12 h-[2px] bg-gradient-to-r from-[#3b82f6] to-transparent" />
                  
                  <div className="p-6 bg-blue-500/5 border border-blue-500/10 rounded-xl">
                    <p className="text-[15px] sm:text-[16px] font-semibold text-[#f1f5f9] leading-relaxed">
                      We are a company, founded to creating accessible agentic frameworks that power the world.
                    </p>
                  </div>

                  <p className="text-xs sm:text-sm text-[#94a3b8] leading-relaxed font-normal">
                    Through advanced client-side micro-runtimes, local vector space embedding alignment, and customizable skill sets, our technology enables developers to model systems cleanly with rich modular feedback logs.
                  </p>

                  <div className="pt-6 flex flex-col sm:flex-row items-center gap-4">
                    <button 
                      onClick={onLaunch}
                      className="text-xs font-semibold tracking-wider font-['Space_Grotesk'] uppercase text-[#3b82f6] hover:underline hover:cursor-pointer"
                    >
                      Launch Platform →
                    </button>
                  </div>
                </div>
              </div>
            </section>
          )}

          {currentSubView === 'contact' && (
            <section className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 py-32">
              <div className="w-full max-w-2xl bg-[#090d16] border border-[rgba(59,130,246,0.15)] rounded-2xl p-8 sm:p-12 shadow-[0_0_50px_rgba(59,130,246,0.05)] relative overflow-hidden animate-[rise_0.6s_cubic-bezier(0.16,1,0.3,1)_forwards]">
                <div className="absolute -top-32 -left-32 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
                <div className="absolute -bottom-32 -right-32 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
                
                <div className="relative z-10 space-y-6">
                  <div className="flex items-center gap-3 text-xs font-mono text-[#3b82f6]/80 tracking-widest uppercase">
                    <span>acceleratedlogicai.com/contact</span>
                  </div>
                  
                  <h1 className="font-['Space_Grotesk'] text-3xl sm:text-4xl font-light tracking-tight text-[#f1f5f9]">
                    Contact Us
                  </h1>
                  
                  <div className="w-12 h-[2px] bg-gradient-to-r from-[#3b82f6] to-transparent" />
                  
                  <p className="text-sm sm:text-base leading-relaxed text-[#94a3b8] font-normal">
                    We welcome inquiries regarding custom framework setups, educational distribution, or licensing protocols.
                  </p>

                  <div className="p-6 bg-blue-500/5 border border-blue-500/10 rounded-xl space-y-2">
                    <span className="text-[10px] text-[#3b82f6] font-mono uppercase tracking-widest">Customer Support & Relations</span>
                    <div className="text-[15px] sm:text-[16px] font-semibold text-[#f1f5f9]">
                      Email: <a href="mailto:acceleratedlogicai@gmail.com" className="hover:underline text-[#3b82f6] font-mono">acceleratedlogicai@gmail.com</a>
                    </div>
                  </div>

                  <p className="text-xs text-[#64748b] leading-relaxed">
                    Our workspace admins analyze incoming queues regularly and resolve service tickets inside standard business intervals.
                  </p>

                  <div className="pt-6 flex flex-col sm:flex-row items-center gap-4">
                    <button 
                      onClick={onLaunch}
                      className="text-xs font-semibold tracking-wider font-['Space_Grotesk'] uppercase text-[#3b82f6] hover:underline hover:cursor-pointer"
                    >
                      Launch Platform →
                    </button>
                  </div>
                </div>
              </div>
            </section>
          )}
        </>
      )}

      {/* Footer */}
      <footer className="relative z-10 border-t border-[rgba(59,130,246,0.12)] px-12 py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-[10px] sm:text-[11px] tracking-widest uppercase text-[#64748b] text-center sm:text-left">
          &copy; 2026 Best Analytic Business Solutions Inc. All rights reserved.
        </p>

        {/* Footer legal links */}
        <div className="flex items-center gap-6 text-[10px] tracking-widest uppercase text-[#64748b]">
          <a href="https://acceleratedlogicai.com/about" onClick={(e) => navigateTo('about', e)} className="hover:text-[#3b82f6] transition-colors">About</a>
          <a href="https://acceleratedlogicai.com/privacy" onClick={(e) => navigateTo('privacy', e)} className="hover:text-[#3b82f6] transition-colors">Privacy</a>
          <a href="https://acceleratedlogicai.com/contact" onClick={(e) => navigateTo('contact', e)} className="hover:text-[#3b82f6] transition-colors">Contact</a>
        </div>
      </footer>

      {/* Styled Animations injection */}
      <style>{`
        @keyframes rise {
          from {
            opacity: 0;
            transform: translateY(14px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
