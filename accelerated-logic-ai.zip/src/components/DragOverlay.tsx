import { motion, AnimatePresence } from "motion/react";
import { Upload } from "lucide-react";

interface DragOverlayProps {
  isDragging: boolean;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent) => void;
}

export function DragOverlay({
  isDragging,
  onDragOver,
  onDragLeave,
  onDrop
}: DragOverlayProps) {
  return (
    <AnimatePresence>
      {isDragging && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onDrop={onDrop}
          className="fixed inset-0 z-[200] bg-primary/20 backdrop-blur-sm border-4 border-dashed border-primary rounded-3xl m-4 flex flex-col items-center justify-center gap-4 pointer-events-auto"
        >
          <div className="p-8 bg-background rounded-3xl shadow-2xl flex flex-col items-center gap-4 border border-border">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Upload className="w-8 h-8 text-primary animate-bounce" />
            </div>
            <div className="text-center">
              <h3 className="text-xl font-bold uppercase tracking-widest text-primary">Drop Content</h3>
              <p className="text-sm text-muted-foreground font-medium">Add files as session context</p>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
