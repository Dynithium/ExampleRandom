/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { openDB, IDBPDatabase } from 'idb';

const DB_NAME = 'accelerated_logic_db';
const DB_VERSION = 3;

export interface Memory {
  id: string;
  content: string;
  createdAt: number;
  updatedAt: number;
  sourceChatId?: string;
  category?: 'preferences' | 'personal' | 'project' | 'general';
  isActive: boolean;
}

export interface Chat {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  pinnedFileIds?: string[];
}

export type MASArchitecture = 'auto' | 'standard' | 'planning' | 'debate' | 'doc_analyzer';

export interface Message {
  role: 'user' | 'assistant' | 'system' | 'orchestrator' | 'auditor' | 'finalizer' | 'planner' | 'critic' | 'debater' | 'analyzer';
  content: string;
  agentName?: string;
  thinking?: string;
  thinkingSteps?: { agent: string, text: string }[];
  scratchpad?: string;
  timestamp: number;
  imageUrl?: string;
  attachedImages?: string[]; // Array of base64 strings or URLs
  attachedFiles?: AppFile[]; // Array of fully attached documents (text, pdf, images, binaries, etc)
  imageWidth?: number;
  imageHeight?: number;
  isImageLoading?: boolean;
  tps?: number;
  contextTokens?: number;
  contextLimit?: number;
  modelId?: string;
}

export interface AppFile {
  id: string;
  name: string;
  type: string;
  content: string; // Base64 or text
  createdAt: number;
  extractedText?: string;
}

export interface AgentConfig {
  id: string;
  name: string;
  systemPrompt: string;
  count: number;
  enabled: boolean;
  isFixed?: boolean;
  modelId?: string;
}

export interface SkillConfig {
  id: string;
  name: string;
  description: string;
  systemPrompt: string;
  enabled: boolean;
  type?: 'prompt' | 'persona';
  isPreset?: boolean;
  attachedFiles?: AppFile[];
}

export interface CustomOpenAIModel {
  id: string;
  name: string;
  modelId: string;
  baseUrl: string;
  apiKey: string;
}

export interface Settings {
  provider: 'puter' | 'google' | 'webllm' | 'ollama' | 'openai';
  puterModel?: string;
  geminiModel?: string;
  geminiApiKey?: string;
  ollamaUrl?: string;
  openaiApiKey?: string;
  openaiBaseUrl?: string;
  openaiModelId?: string;
  customOpenaiModels?: CustomOpenAIModel[];
  tokenReductionEnabled: boolean;
  tokenReductionAmount: number;
  summarizeEnabled: boolean;
  temperature: number;
  maxTokens: number;
  maxContext: number;
  systemPrompt: string;
  favorites: string[];
  masArchitecture: MASArchitecture;
  criticStrictness: number;
  toolsEnabled: {
    calculator: boolean;
    python: boolean;
    scratchpad: boolean;
  };
  // Image Settings
  imageModelId: string;
  imageGenerationEnabled: boolean;
  aspectRatio: string;
  resolution: string;
  autoEnhance: boolean;
  skills: SkillConfig[];
  enabledChatModels: string[];
  autoMemoryEnabled?: boolean;
  hasSeenTutorial?: boolean;
  chatFontSize?: 'sm' | 'base' | 'lg';
  chatFontFamily?: 'sans' | 'mono' | 'serif';
  chatDensity?: 'cozy' | 'spacious';
  promptQueueBackoff?: number;
  gdriveBackupSelector?: {
    chats: boolean;
    files: boolean;
    projects: boolean;
    skills: boolean;
    memories: boolean;
  };
}

let dbPromise: Promise<IDBPDatabase> | null = null;

export const getDB = () => {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db, oldVersion) {
        if (oldVersion < 1) {
          db.createObjectStore('chats', { keyPath: 'id' });
          db.createObjectStore('files', { keyPath: 'id' });
          db.createObjectStore('settings', { keyPath: 'id' });
          db.createObjectStore('agents', { keyPath: 'id' });
        }
        
        if (oldVersion < 2) {
          if (!db.objectStoreNames.contains('equipped_models')) {
            db.createObjectStore('equipped_models', { keyPath: 'id' });
          }
        }
        
        if (oldVersion < 3) {
          if (!db.objectStoreNames.contains('memories')) {
            db.createObjectStore('memories', { keyPath: 'id' });
          }
        }
      },
    });
  }
  return dbPromise;
};

export const saveEquippedModels = async (models: string[]) => {
  try {
    const idb = await getDB();
    const tx = idb.transaction('equipped_models', 'readwrite');
    await tx.store.put({ id: 'main', models });
    await tx.done;
  } catch (error) {
    console.error("Database saveEquippedModels error:", error);
  }
};

export const getEquippedModels = async (): Promise<string[]> => {
  try {
    const idb = await getDB();
    const data = await idb.get('equipped_models', 'main');
    return data?.models || [];
  } catch (error) {
    console.error("Database getEquippedModels error:", error);
    return [];
  }
};

export const saveChat = async (chat: Chat) => {
  const idb = await getDB();
  await idb.put('chats', chat);
};

export const getAllChats = async (): Promise<Chat[]> => {
  const idb = await getDB();
  return idb.getAll('chats');
};

export const deleteChat = async (id: string) => {
  const idb = await getDB();
  await idb.delete('chats', id);
};

export const saveFile = async (file: AppFile) => {
  const idb = await getDB();
  await idb.put('files', file);
};

export const getAllFiles = async (): Promise<AppFile[]> => {
  const idb = await getDB();
  return idb.getAll('files');
};

export const deleteFile = async (id: string) => {
  const idb = await getDB();
  await idb.delete('files', id);
};

export const saveSettings = async (settings: Settings) => {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      if (settings.geminiApiKey !== undefined) {
        if (settings.geminiApiKey) {
          window.localStorage.setItem('gemini_api_key', settings.geminiApiKey);
        } else {
          window.localStorage.removeItem('gemini_api_key');
        }
      }
      if (settings.openaiApiKey !== undefined) {
        if (settings.openaiApiKey) {
          window.localStorage.setItem('openai_api_key', settings.openaiApiKey);
        } else {
          window.localStorage.removeItem('openai_api_key');
        }
      }
      if (settings.openaiBaseUrl !== undefined) {
        if (settings.openaiBaseUrl) {
          window.localStorage.setItem('openai_base_url', settings.openaiBaseUrl);
        } else {
          window.localStorage.removeItem('openai_base_url');
        }
      }
      if (settings.openaiModelId !== undefined) {
        if (settings.openaiModelId) {
          window.localStorage.setItem('openai_model_id', settings.openaiModelId);
        } else {
          window.localStorage.removeItem('openai_model_id');
        }
      }
      if (settings.customOpenaiModels !== undefined) {
        if (settings.customOpenaiModels) {
          window.localStorage.setItem('custom_openai_models', JSON.stringify(settings.customOpenaiModels));
        } else {
          window.localStorage.removeItem('custom_openai_models');
        }
      }
    }
    const idb = await getDB();
    const tx = idb.transaction('settings', 'readwrite');
    // For safety, load existing settings to avoid overwriting unrelated fields if a partial object is passed
    const existing = await tx.store.get('main');
    await tx.store.put({ ...existing, ...settings, id: 'main' });
    await tx.done;
  } catch (error) {
    console.error("Database saveSettings error:", error);
  }
};

export const getSettings = async (): Promise<Settings | null> => {
  try {
    const idb = await getDB();
    const settings = await idb.get('settings', 'main');
    if (settings) {
      if (typeof window !== 'undefined' && window.localStorage) {
        const localApiKey = window.localStorage.getItem('gemini_api_key');
        if (localApiKey) {
          settings.geminiApiKey = localApiKey;
        } else if (settings.geminiApiKey) {
          window.localStorage.setItem('gemini_api_key', settings.geminiApiKey);
        }

        const localOpenaiKey = window.localStorage.getItem('openai_api_key');
        if (localOpenaiKey) {
          settings.openaiApiKey = localOpenaiKey;
        } else if (settings.openaiApiKey) {
          window.localStorage.setItem('openai_api_key', settings.openaiApiKey);
        }

        const localOpenaiBaseUrl = window.localStorage.getItem('openai_base_url');
        if (localOpenaiBaseUrl) {
          settings.openaiBaseUrl = localOpenaiBaseUrl;
        } else if (settings.openaiBaseUrl) {
          window.localStorage.setItem('openai_base_url', settings.openaiBaseUrl);
        }

        const localOpenaiModelId = window.localStorage.getItem('openai_model_id');
        if (localOpenaiModelId) {
          settings.openaiModelId = localOpenaiModelId;
        } else if (settings.openaiModelId) {
          window.localStorage.setItem('openai_model_id', settings.openaiModelId);
        }

        const localCustomOpenai = window.localStorage.getItem('custom_openai_models');
        if (localCustomOpenai) {
          try {
            settings.customOpenaiModels = JSON.parse(localCustomOpenai);
          } catch (e) {
            console.error("Failed to parse custom_openai_models", e);
          }
        } else if (settings.customOpenaiModels) {
          window.localStorage.setItem('custom_openai_models', JSON.stringify(settings.customOpenaiModels));
        }
      }
    } else {
      // If no settings exist in DB yet, see if we can bootstrap with localStorage api key
      if (typeof window !== 'undefined' && window.localStorage) {
        const localApiKey = window.localStorage.getItem('gemini_api_key');
        const localOpenaiKey = window.localStorage.getItem('openai_api_key');
        const localOpenaiBaseUrl = window.localStorage.getItem('openai_base_url');
        const localOpenaiModelId = window.localStorage.getItem('openai_model_id');
        const localCustomOpenai = window.localStorage.getItem('custom_openai_models');
        
        const partial: any = {};
        if (localApiKey) partial.geminiApiKey = localApiKey;
        if (localOpenaiKey) partial.openaiApiKey = localOpenaiKey;
        if (localOpenaiBaseUrl) partial.openaiBaseUrl = localOpenaiBaseUrl;
        if (localOpenaiModelId) partial.openaiModelId = localOpenaiModelId;
        if (localCustomOpenai) {
          try {
            partial.customOpenaiModels = JSON.parse(localCustomOpenai);
          } catch (_) {}
        }
        
        if (Object.keys(partial).length > 0) {
          return partial as any;
        }
      }
    }
    return settings;
  } catch (error) {
    console.error("Database getSettings error:", error);
    return null;
  }
};

export const saveAgent = async (agent: AgentConfig) => {
  const idb = await getDB();
  await idb.put('agents', agent);
};

export const saveMemory = async (memory: Memory) => {
  const idb = await getDB();
  await idb.put('memories', memory);
};

export const getAllMemories = async (): Promise<Memory[]> => {
  try {
    const idb = await getDB();
    return await idb.getAll('memories');
  } catch (error) {
    console.error("Database getAllMemories error:", error);
    return [];
  }
};

export const deleteMemory = async (id: string) => {
  try {
    const idb = await getDB();
    await idb.delete('memories', id);
  } catch (error) {
    console.error("Database deleteMemory error:", error);
  }
};

export const clearAllMemories = async () => {
  try {
    const idb = await getDB();
    const tx = idb.transaction('memories', 'readwrite');
    await tx.objectStore('memories').clear();
    await tx.done;
  } catch (error) {
    console.error("Database clearAllMemories error:", error);
  }
};

export const getAllAgents = async (): Promise<AgentConfig[]> => {
  const idb = await getDB();
  return idb.getAll('agents');
};

export const deleteAgent = async (id: string) => {
  const idb = await getDB();
  await idb.delete('agents', id);
};

export const clearAllData = async () => {
  const idb = await getDB();
  const tx = idb.transaction(['chats', 'files', 'agents', 'settings', 'equipped_models', 'memories'], 'readwrite');
  await Promise.all([
    tx.objectStore('chats').clear(),
    tx.objectStore('files').clear(),
    tx.objectStore('agents').clear(),
    tx.objectStore('settings').clear(),
    tx.objectStore('equipped_models').clear(),
    tx.objectStore('memories').clear(),
  ]);
  await tx.done;

  if (typeof window !== 'undefined' && window.localStorage) {
    window.localStorage.clear();
  }
};

export const exportDatabaseSnapshot = async (): Promise<any> => {
  try {
    const idb = await getDB();
    const chats = await idb.getAll('chats');
    const files = await idb.getAll('files');
    const agents = await idb.getAll('agents');
    const settings = await idb.getAll('settings');
    const equipped_models = await idb.getAll('equipped_models');
    const memories = await idb.getAll('memories');
    
    return {
      version: DB_VERSION,
      exportTimestamp: Date.now(),
      data: {
        chats,
        files,
        agents,
        settings,
        equipped_models,
        memories
      }
    };
  } catch (error) {
    console.error("Database exportDatabaseSnapshot error:", error);
    throw error;
  }
};
