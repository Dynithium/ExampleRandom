import { Zap } from "lucide-react";

interface WelcomeScreenProps {
  onNewChat: () => void;
}

export function WelcomeScreen({ onNewChat }: WelcomeScreenProps) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center space-y-4 max-w-md mx-auto">
      <div className="w-16 h-16 bg-primary/10 rounded-3xl flex items-center justify-center text-primary mb-2 relative group overflow-hidden">
        <div className="absolute inset-0 bg-[#3b82f6]/10 rounded-full blur-[2px] opacity-75" />
        <svg className="w-9 h-9 relative z-10 animate-[spin_24s_linear_infinite]" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="welcomeGearBody" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#0f172a" />
              <stop offset="80%" stopColor="#172554" />
              <stop offset="100%" stopColor="#020617" />
            </radialGradient>
          </defs>
          <circle cx="50" cy="50" r="48" fill="#3b82f6" opacity="0.15" />
          <g transform="rotate(-14.3 50 50)">
            <path d="M 85.00 50.00 L 84.64 55.01 L 77.98 56.39 L 76.78 60.33 L 81.53 65.19 L 79.04 69.54 L 72.44 67.89 L 69.65 70.92 L 71.82 77.36 L 67.68 80.21 L 62.45 75.86 L 58.62 77.37 L 57.79 84.12 L 52.82 84.89 L 50.00 78.70 L 45.89 78.40 L 42.21 84.12 L 37.41 82.66 L 37.55 75.86 L 33.97 73.81 L 28.18 77.36 L 24.49 73.96 L 27.56 67.89 L 25.23 64.50 L 18.47 65.19 L 16.62 60.52 L 22.02 56.39 L 21.39 52.32 L 15.00 50.00 L 15.36 44.99 L 22.02 43.61 L 23.22 39.67 L 18.47 34.81 L 20.96 30.46 L 27.56 32.11 L 30.35 29.08 L 28.18 22.64 L 32.32 19.79 L 37.55 24.14 L 41.38 22.63 L 42.21 15.88 L 47.18 15.11 L 50.00 21.30 L 54.11 21.60 L 57.79 15.88 L 62.59 17.34 L 62.45 24.14 L 66.03 26.19 L 71.82 22.64 L 75.51 26.04 L 72.44 32.11 L 74.77 35.50 L 81.53 34.81 L 83.38 39.48 L 77.98 43.61 L 78.61 47.68 Z" fill="url(#welcomeGearBody)" stroke="#3b82f6" strokeWidth="3.2" />
            <circle cx="50" cy="50" r="20" fill="none" stroke="#3b82f6" strokeWidth="1.2" strokeDasharray="2.5, 2.5" opacity="0.55" />
            <circle cx="50" cy="50" r="11" fill="#111827" stroke="#3b82f6" strokeWidth="3.2" />
            <circle cx="50" cy="50" r="5.5" fill="#030712" />
          </g>
        </svg>
      </div>
      <h2 className="text-2xl font-bold tracking-tight">Welcome to Accelerated Logic</h2>
      <div className="text-muted-foreground text-sm">
        A private, local-first AI platform. Start a new chat to begin interacting with models directly in your browser.
      </div>
      <button 
        onClick={onNewChat}
        className="bg-primary text-primary-foreground px-6 py-2.5 rounded-full font-semibold shadow-lg shadow-primary/20 hover:scale-105 transition-transform"
      >
        Start New Chat
      </button>
    </div>
  );
}
