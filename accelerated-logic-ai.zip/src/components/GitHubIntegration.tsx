import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Github, 
  HelpCircle, 
  ExternalLink, 
  CheckCircle2, 
  Code2, 
  Key, 
  Settings2, 
  RefreshCw, 
  AlertTriangle, 
  FileCode2, 
  ArrowLeft, 
  BookOpen, 
  Terminal, 
  Play, 
  Lock, 
  Eye, 
  EyeOff, 
  GitBranch, 
  GitCommit, 
  GitPullRequest, 
  FolderOpen,
  User,
  Shield,
  Layers,
  ChevronRight,
  Sparkles
} from 'lucide-react';

interface GitHubIntegrationProps {
  onBackToChat: () => void;
  theme: 'dark' | 'light';
}

interface GithubRepo {
  id: number;
  name: string;
  full_name: string;
  private: boolean;
  description: string;
  html_url: string;
  default_branch: string;
}

interface GithubFile {
  name: string;
  path: string;
  sha: string;
  content?: string;
  type: string;
}

export function GitHubIntegration({ onBackToChat, theme }: GitHubIntegrationProps) {
  // Personal Access Token state
  const [pat, setPat] = useState(() => localStorage.getItem('github_pat') || '');
  const [showPat, setShowPat] = useState(false);
  
  // Connection / User details
  const [isChecking, setIsChecking] = useState(false);
  const [userInfo, setUserInfo] = useState<{
    login: string;
    avatar_url: string;
    html_url: string;
    name: string;
    bio: string;
    scopes: string[];
    tokenType: 'classic' | 'fine-grained' | 'unknown';
  } | null>(null);

  const [testError, setTestError] = useState<string | null>(null);

  // Repository selection & navigation
  const [repos, setRepos] = useState<GithubRepo[]>([]);
  const [loadingRepos, setLoadingRepos] = useState(false);
  const [selectedRepo, setSelectedRepo] = useState<GithubRepo | null>(null);

  // File explorer & editing state
  const [repoFiles, setRepoFiles] = useState<GithubFile[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [selectedFile, setSelectedFile] = useState<GithubFile | null>(null);
  const [fileContent, setFileContent] = useState('');
  const [originalContent, setOriginalContent] = useState('');
  const [isFetchingContent, setIsFetchingContent] = useState(false);

  // Commit / Edit state
  const [commitMessage, setCommitMessage] = useState('update: modified file content via Accelerated Logic Workspace');
  const [targetBranch, setTargetBranch] = useState('');
  const [isCommitting, setIsCommitting] = useState(false);
  const [commitLogs, setCommitLogs] = useState<string[]>([]);

  // Initialize and check key if exists
  useEffect(() => {
    if (pat) {
      validateAndFetchUser(pat);
    } else {
      setCommitLogs([`[${new Date().toLocaleTimeString()}] DevTools: Listening. Please provide a Personal Access Token (PAT) below.`]);
    }
  }, []);

  // Save/Clear PAT
  const handleSavePat = (value: string) => {
    const trimmed = value.trim();
    setPat(trimmed);
    localStorage.setItem('github_pat', trimmed);
    if (trimmed) {
      validateAndFetchUser(trimmed);
    } else {
      setUserInfo(null);
      setRepos([]);
      setSelectedRepo(null);
      setRepoFiles([]);
      setSelectedFile(null);
    }
  };

  const handleClearPat = () => {
    if (confirm("Are you sure you want to discard your stored GitHub PAT?")) {
      setPat('');
      localStorage.removeItem('github_pat');
      setUserInfo(null);
      setRepos([]);
      setSelectedRepo(null);
      setRepoFiles([]);
      setSelectedFile(null);
      setTestError(null);
      setCommitLogs([`[${new Date().toLocaleTimeString()}] Session cleared.`]);
    }
  };

  // Perform a live test of the PAT on GitHub API
  const validateAndFetchUser = async (tokenToCheck: string) => {
    if (!tokenToCheck) {
      setTestError("Token cannot be empty.");
      return;
    }

    setIsChecking(true);
    setTestError(null);
    setUserInfo(null);
    
    setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Validating pattern: ${tokenToCheck.substring(0, 11)}...`]);

    try {
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `Bearer ${tokenToCheck}`,
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        }
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("Bad credentials. Your Personal Access Token is invalid or has expired.");
        }
        throw new Error(`GitHub API returned status ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      
      // Extract scopes from X-OAuth-Scopes response Header (only available for classic tokens)
      const scopesHeader = response.headers.get('X-OAuth-Scopes');
      let scopes: string[] = [];
      let tokenType: 'classic' | 'fine-grained' | 'unknown' = 'unknown';

      if (scopesHeader !== null) {
        scopes = scopesHeader.split(',').map(s => s.trim()).filter(Boolean);
        tokenType = 'classic';
      } else if (tokenToCheck.startsWith('github_pat_')) {
        tokenType = 'fine-grained';
        // Fine-grained PATs do not return active scopes in the headers; they are checked per repo
        scopes = ['repo-scoped (fine-grained)'];
      }

      setUserInfo({
        login: data.login,
        avatar_url: data.avatar_url,
        html_url: data.html_url,
        name: data.name || data.login,
        bio: data.bio || "No biography provided.",
        scopes: scopes,
        tokenType: tokenType
      });

      setCommitLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] Successfully authenticated! Welcome, @${data.login}.`,
        `[${new Date().toLocaleTimeString()}] Token standard identified: ${tokenType.toUpperCase()}`
      ]);

      // Trigger repo list fetch immediately
      fetchUserRepos(tokenToCheck);

    } catch (err: any) {
      setTestError(err.message || "Unable to reach GitHub servers.");
      setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ERR: Authentication failed. ${err.message}`]);
    } finally {
      setIsChecking(false);
    }
  };

  // Fetch the list of repositories accessible by this token
  const fetchUserRepos = async (token: string) => {
    setLoadingRepos(true);
    setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Querying repositories list...`]);
    try {
      const response = await fetch('https://api.github.com/user/repos?sort=updated&per_page=50', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        }
      });

      if (!response.ok) {
        throw new Error("Could not retrieve repository listings.");
      }

      const data = await response.json();
      setRepos(data);
      setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Fetched ${data.length} active repository mappings.`]);
    } catch (err: any) {
      setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ERR: Failed to retrieve repos. ${err.message}`]);
    } finally {
      setLoadingRepos(false);
    }
  };

  // When a repository is selected, grab its main folder contents
  const handleSelectRepository = async (repo: GithubRepo) => {
    setSelectedRepo(repo);
    setSelectedFile(null);
    setFileContent('');
    setOriginalContent('');
    setTargetBranch(repo.default_branch);
    setLoadingFiles(true);

    setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Selected repository: ${repo.full_name}. Target default branch: "${repo.default_branch}"`]);

    try {
      const response = await fetch(`https://api.github.com/repos/${repo.full_name}/contents`, {
        headers: {
          'Authorization': `Bearer ${pat}`,
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to load repository files: ${response.statusText}`);
      }

      const filesData: GithubFile[] = await response.json();
      setRepoFiles(filesData);
      setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Root catalog containing ${filesData.length} items loaded.`]);
    } catch (err: any) {
      setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ERR: Failed to read file tree. Check token scopes for 'repo' read access. ${err.message}`]);
    } finally {
      setLoadingFiles(false);
    }
  };

  // Load file content for editing
  const handleSelectFile = async (file: GithubFile) => {
    if (file.type !== 'file') {
      alert("This is a directory. Please select a singular file to view and edit.");
      return;
    }

    setSelectedFile(file);
    setIsFetchingContent(true);
    setFileContent('');
    setOriginalContent('');

    setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Fetching source for file: "${file.path}"...`]);

    try {
      const response = await fetch(`https://api.github.com/repos/${selectedRepo?.full_name}/contents/${file.path}`, {
        headers: {
          'Authorization': `Bearer ${pat}`,
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        }
      });

      if (!response.ok) {
        throw new Error("Could not download file contents.");
      }

      const data = await response.json();
      
      // GitHub contents API returns base64 string
      const base64Content = data.content.replace(/\s/g, '');
      const decoded = decodeURIComponent(escape(atob(base64Content)));

      setFileContent(decoded);
      setOriginalContent(decoded);
      
      // Update selected file object with the latest sha
      setSelectedFile(prev => prev ? { ...prev, sha: data.sha } : null);

      setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Loaded file "${file.name}" with original sha: ${data.sha.substring(0, 10)}...`]);
    } catch (err: any) {
      setCommitLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ERR: Failed to fetch item. ${err.message}`]);
    } finally {
      setIsFetchingContent(false);
    }
  };

  // Push code edits/commits back to GitHub
  const handlePushCommit = async () => {
    if (!pat || !selectedRepo || !selectedFile) {
      alert("Please authenticate, choose a repository and load a file first.");
      return;
    }

    if (fileContent === originalContent) {
      alert("There are no modifications to commit.");
      return;
    }

    if (!commitMessage.trim()) {
      alert("Please specify a commit message.");
      return;
    }

    setIsCommitting(true);
    
    setCommitLogs(prev => [
      ...prev, 
      `[${new Date().toLocaleTimeString()}] Committing modifications back to branch "${targetBranch}"...`
    ]);

    try {
      // Encode updated code contents using base64
      const b64Bytes = new TextEncoder().encode(fileContent);
      let base64Encoded = '';
      const step = 1024;
      for (let i = 0; i < b64Bytes.length; i += step) {
        base64Encoded += String.fromCharCode.apply(null, Array.from(b64Bytes.subarray(i, i + step)));
      }
      const finalBase64 = btoa(base64Encoded);

      const response = await fetch(`https://api.github.com/repos/${selectedRepo.full_name}/contents/${selectedFile.path}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${pat}`,
          'Content-Type': 'application/json',
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        },
        body: JSON.stringify({
          message: commitMessage.trim(),
          content: finalBase64,
          sha: selectedFile.sha,
          branch: targetBranch
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || response.statusText);
      }

      const commitResult = await response.json();
      
      // Update original content and latest SHA
      setOriginalContent(fileContent);
      setSelectedFile(prev => prev ? { ...prev, sha: commitResult.content.sha } : null);

      setCommitLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] SUCCESS! Commit pushed successfully.`,
        `[${new Date().toLocaleTimeString()}] New Commit Hash: ${commitResult.commit.sha.substring(0, 12)}`,
        `[${new Date().toLocaleTimeString()}] Tree File Updated SHA: ${commitResult.content.sha.substring(0, 10)}`
      ]);

      alert(`Commit pushed successfully to ${selectedRepo.full_name}!`);

    } catch (err: any) {
      setCommitLogs(prev => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] ERR: Commit rejected. ${err.message}.`,
        `[${new Date().toLocaleTimeString()}] Note: For fine-grained PATs, ensure "Metadata (Read)" and "Contents (Read & Write)" are enabled.`
      ]);
      alert(`Failed to commit: ${err.message}`);
    } finally {
      setIsCommitting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground overflow-y-auto">
      {/* Top action bar */}
      <div className="border-b border-border bg-card sticky top-0 z-40 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBackToChat}
            className="p-2 hover:bg-accent rounded-xl text-muted-foreground hover:text-foreground transition-all flex items-center gap-1.5 text-xs font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Workspace
          </button>
          <div className="h-4 w-[1px] bg-border"></div>
          <div className="flex items-center gap-2">
            <Github className="w-5 h-5 text-indigo-400" />
            <span className="font-extrabold text-sm tracking-tight bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent uppercase">GitHub PAT Companion</span>
            <span className="text-[9px] bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 px-1.5 py-0.5 rounded font-mono font-bold uppercase">PAT Sandbox</span>
          </div>
        </div>
        <div className="text-xs text-muted-foreground flex items-center gap-1">
          <Layers className="w-3.5 h-3.5" />
          <span>Workspace Endpoint: <strong className="font-mono text-[10px] bg-accent/40 px-1 py-0.5 rounded text-foreground">/github</strong></span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 w-full grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column (5 cols): Token Configuration & Guide */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* PAT Credentials Guard */}
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2 border-b border-border pb-3">
              <Key className="w-4 h-4 text-indigo-400" />
              <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Personal Access Token</h2>
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed">
              Authenticate using your personal key. This client communicates directly with the GitHub REST API via secure, CORS-compliant requests. No servers store your secret.
            </p>

            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[10px] font-mono uppercase text-muted-foreground font-bold tracking-wider block">GitHub PAT Secret</label>
                  <button 
                    onClick={() => setShowPat(!showPat)}
                    className="text-[10px] text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
                  >
                    {showPat ? (
                      <>
                        <EyeOff className="w-3.5 h-3.5" /> Hide Key
                      </>
                    ) : (
                      <>
                        <Eye className="w-3.5 h-3.5" /> Show Key
                      </>
                    )}
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPat ? "text" : "password"}
                    placeholder="github_pat_... or ghp_..."
                    value={pat}
                    onChange={(e) => handleSavePat(e.target.value)}
                    className="w-full text-xs font-mono bg-muted/40 border border-border rounded-lg pl-3 pr-10 py-2.5 text-foreground focus:outline-none focus:ring-1 focus:ring-indigo-500/40"
                  />
                  <div className="absolute right-3 top-2.5 flex items-center justify-center">
                    {userInfo ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : pat ? (
                      <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                    ) : null}
                  </div>
                </div>
              </div>

              {testError && (
                <div className="p-3 bg-red-500/5 border border-red-500/20 text-red-200 rounded-xl text-xs flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
                  <span>{testError}</span>
                </div>
              )}
              
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => validateAndFetchUser(pat)}
                  disabled={isChecking || !pat}
                  className="flex-1 py-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1"
                >
                  {isChecking ? (
                    <>
                      <RefreshCw className="w-3 h-3 animate-spin" /> Checking...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-3 h-3" /> Recheck Connection
                    </>
                  )}
                </button>
                <button
                  onClick={handleClearPat}
                  disabled={!pat}
                  className="py-1.5 px-3 border border-border hover:bg-destructive/10 hover:text-destructive rounded-lg text-xs font-semibold transition-all disabled:opacity-30"
                >
                  Discard Key
                </button>
              </div>
            </div>
          </div>

          {/* User Scope / Permission Inspector */}
          {userInfo && (
            <div className="bg-card border border-border rounded-2xl p-6 shadow-sm space-y-4">
              <div className="flex items-center gap-2.5 border-b border-border pb-3">
                <img src={userInfo.avatar_url} alt="" className="w-8 h-8 rounded-full border border-indigo-500/20" />
                <div>
                  <h3 className="text-sm font-bold tracking-tight text-foreground">{userInfo.name}</h3>
                  <a href={userInfo.html_url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-indigo-400 hover:underline flex items-center gap-1 font-mono">
                    @{userInfo.login} <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              <div className="space-y-3.5 text-xs text-muted-foreground">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] uppercase font-bold tracking-wider">Classification</span>
                  <span className="text-foreground tracking-tight font-semibold bg-accent px-2 py-0.5 rounded text-[10px] uppercase font-mono">
                    {userInfo.tokenType} Token
                  </span>
                </div>

                <div className="space-y-1">
                  <span className="font-mono text-[10px] uppercase font-bold tracking-wider block">Token Capabilities (Scopes)</span>
                  {userInfo.scopes.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {userInfo.scopes.map((scope) => (
                        <span key={scope} className="bg-indigo-500/10 border border-indigo-500/15 text-indigo-300 font-mono text-[9px] px-2 py-0.5 rounded-md">
                          {scope}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <div className="p-3 bg-muted/40 rounded-xl space-y-1.5 border border-border">
                      <div className="flex items-center gap-1.5 text-amber-300 font-semibold text-[11px]">
                        <Shield className="w-3.5 h-3.5 text-amber-400" /> No generic scopes listed
                      </div>
                      <p className="text-[10px] leading-relaxed text-muted-foreground">
                        This indicates you are using a <strong>Fine-Grained PAT</strong>. Fine-grained tokens restrict permission evaluation specifically to authorized target repositories rather than exposing wide open keys.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Setup Walkthrough Documentation */}
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-400" />
              <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Step-by-Step Setup Walkthrough</h2>
            </div>

            <div className="space-y-3.5 text-xs leading-relaxed text-muted-foreground">
              <p>
                To create a fresh Personal Access Token on GitHub with the correct permissions:
              </p>
              
              <ol className="list-decimal pl-4 space-y-2.5">
                <li>
                  Go directly to <a href="https://github.com/settings/tokens?type=beta" target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:underline font-semibold inline-flex items-center gap-0.5">GitHub Token Settings <ExternalLink className="w-3 h-3" /></a>.
                </li>
                <li>
                  Click <strong>Generate new token</strong> (Fine-grained is highly recommended).
                </li>
                <li>
                  Under <strong>Repository Access</strong>, select either <strong>All repositories</strong> or <strong>Only select repositories</strong> to restrict access.
                </li>
                <li>
                  Under <strong>Permissions</strong> click <strong>Repository permissions</strong> and choose:
                  <ul className="list-disc pl-4 mt-1 space-y-1 text-[11px] text-foreground font-medium">
                    <li><strong className="text-indigo-300">Contents:</strong> Read & Write (mandatory for editing file contents)</li>
                    <li><strong className="text-indigo-300">Metadata:</strong> Reader (mandatory)</li>
                  </ul>
                </li>
                <li>
                  Click <strong>Generate token</strong> at the bottom. Copy the resultant token (which begins with <code className="bg-accent px-1 py-0.5 rounded text-[10px] font-mono">github_pat_</code>) and paste it into the field above.
                </li>
              </ol>
            </div>
          </div>

        </div>

        {/* Right Column (7 cols): Active operations arena */}
        <div className="lg:col-span-7 space-y-6">
          
          {pat ? (
            <div className="space-y-6">
              {/* Repository Selector */}
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm space-y-4">
                <div className="flex items-center gap-2 border-b border-border pb-3">
                  <FolderOpen className="w-4 h-4 text-indigo-400" />
                  <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Select Repository & Files</h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Select Dropdown */}
                  <div>
                    <label className="text-[10px] font-mono uppercase text-muted-foreground font-bold tracking-wider block mb-1">Target Repository</label>
                    {loadingRepos ? (
                      <div className="h-9 flex items-center justify-center border border-border rounded-lg bg-muted/40 text-xs">
                        <RefreshCw className="w-3 h-3 animate-spin text-indigo-400 mr-1.5" /> Loading...
                      </div>
                    ) : (
                      <select
                        value={selectedRepo?.id || ''}
                        onChange={(e) => {
                          const matched = repos.find(r => r.id === Number(e.target.value));
                          if (matched) handleSelectRepository(matched);
                        }}
                        className="w-full text-xs bg-muted/40 border border-border rounded-lg px-3 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-indigo-500/40"
                      >
                        <option value="">-- Click to Choose --</option>
                        {repos.map((repo) => (
                          <option key={repo.id} value={repo.id}>
                            {repo.full_name} {repo.private ? '(Private)' : ''}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>

                  {/* Branch selector info */}
                  <div>
                    <label className="text-[10px] font-mono uppercase text-muted-foreground font-bold tracking-wider block mb-1">Pushes Destination Branch</label>
                    <input
                      type="text"
                      placeholder="e.g. main"
                      value={targetBranch}
                      onChange={(e) => setTargetBranch(e.target.value)}
                      disabled={!selectedRepo}
                      className="w-full text-xs bg-muted/40 border border-border rounded-lg px-3 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-indigo-500/40 disabled:opacity-40"
                    />
                  </div>
                </div>

                {/* File Navigator */}
                {selectedRepo && (
                  <div className="space-y-2 pt-3">
                    <label className="text-[10px] font-mono uppercase text-muted-foreground font-bold tracking-wider block">Repository Root Explorer (Choose a file to edit)</label>
                    {loadingFiles ? (
                      <div className="h-24 flex items-center justify-center border border-dashed border-border rounded-xl">
                        <RefreshCw className="w-4 h-4 animate-spin text-indigo-400 mr-2" />
                        <span className="text-xs text-muted-foreground">Navigating repository hierarchy...</span>
                      </div>
                    ) : (
                      <div className="border border-border rounded-xl overflow-hidden max-h-[160px] overflow-y-auto bg-muted/10">
                        {repoFiles.length === 0 ? (
                          <div className="p-4 text-center text-xs text-muted-foreground italic">No root-level files found, or folder is empty.</div>
                        ) : (
                          <div className="divide-y divide-border">
                            {repoFiles.map((file) => (
                              <button
                                key={file.path}
                                onClick={() => handleSelectFile(file)}
                                className={`w-full flex items-center justify-between text-left p-2.5 text-xs transition-colors hover:bg-accent/40 ${
                                  selectedFile?.path === file.path ? "bg-indigo-500/5 text-indigo-300 font-semibold" : ""
                                }`}
                              >
                                <div className="flex items-center gap-2 truncate">
                                  <FileCode2 className={`w-4 h-4 ${file.type === 'dir' ? 'text-amber-400' : 'text-indigo-400'}`} />
                                  <span className="truncate">{file.name}</span>
                                </div>
                                <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                                  {file.type === 'dir' ? (
                                    <span className="bg-accent px-1.5 py-0.5 rounded">Folder</span>
                                  ) : (
                                    <span className="font-mono text-[9px]">{file.sha.substring(0, 7)}</span>
                                  )}
                                  <ChevronRight className="w-3 h-3" />
                                </div>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Live Workspace Code Editor */}
              {selectedFile && (
                <div className="bg-card border border-border rounded-2xl p-6 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-border pb-3">
                    <div className="flex items-center gap-2">
                      <Code2 className="w-4 h-4 text-indigo-400" />
                      <div>
                        <span className="text-[10px] text-muted-foreground uppercase font-mono font-bold tracking-wider block">Active Source File</span>
                        <span className="text-xs font-bold text-foreground">{selectedFile.name} (at root)</span>
                      </div>
                    </div>
                    {fileContent !== originalContent && (
                      <span className="text-[9px] bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono font-bold px-1.5 py-0.5 rounded animate-pulse">Uncommitted Changes</span>
                    )}
                  </div>

                  {isFetchingContent ? (
                    <div className="h-60 flex flex-col items-center justify-center border border-dashed border-border rounded-xl">
                      <RefreshCw className="w-5 h-5 animate-spin text-indigo-400 mb-2" />
                      <span className="text-xs text-muted-foreground">Downloading file tree source payload...</span>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Text editor box */}
                      <div>
                        <textarea
                          placeholder="// Fetching source..."
                          value={fileContent}
                          onChange={(e) => setFileContent(e.target.value)}
                          rows={12}
                          className="w-full text-xs font-mono bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-zinc-100 focus:outline-none focus:ring-1 focus:ring-indigo-500/40 selection:bg-indigo-500/20"
                        />
                      </div>

                      {/* Commit configurations & action */}
                      <div className="space-y-3 pt-2 border-t border-border">
                        <div>
                          <label className="text-[10px] font-mono uppercase text-muted-foreground font-bold tracking-wider block mb-1">Commit Message</label>
                          <input
                            type="text"
                            placeholder="Specify commit purpose..."
                            value={commitMessage}
                            onChange={(e) => setCommitMessage(e.target.value)}
                            className="w-full text-xs bg-muted/40 border border-border rounded-lg px-3 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-indigo-500/40"
                          />
                        </div>

                        <button
                          onClick={handlePushCommit}
                          disabled={isCommitting || fileContent === originalContent}
                          className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-indigo-600/10"
                        >
                          {isCommitting ? (
                            <>
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              Pushing Commit to GitHub...
                            </>
                          ) : (
                            <>
                              <GitCommit className="w-3.5 h-3.5" />
                              Commit & Push File Fix
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Action Log / Diagnostic Panel */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 shadow-inner">
                <div className="flex items-center justify-between mb-3 border-b border-zinc-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5 text-indigo-400" />
                    <span className="font-mono text-xs text-zinc-300 font-bold">Integration Action Log</span>
                  </div>
                  <span className="text-[9px] font-mono bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded">Active Listening</span>
                </div>
                
                <div className="h-[120px] overflow-y-auto custom-scrollbar space-y-1.5 font-mono text-[11px] text-zinc-400 leading-relaxed">
                  {commitLogs.map((log, i) => (
                    <div key={i} className="whitespace-pre-wrap border-l-2 border-indigo-500/20 pl-2">
                      {log}
                    </div>
                  ))}
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-card border border-border rounded-2xl p-8 shadow-sm text-center flex flex-col items-center justify-center min-h-[350px] space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/5 flex items-center justify-center border border-indigo-500/10">
                <Github className="w-6 h-6 text-indigo-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-foreground">Authenticate to Begin</h3>
                <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto leading-relaxed">
                  Provide your GitHub Personal Access Token (PAT) inside the credential panel to inspect permissions, browse repositories, and interact with files.
                </p>
              </div>
              <div className="p-3.5 bg-muted/40 rounded-2xl border border-border text-left w-full max-w-lg">
                <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs mb-1.5">
                  <Shield className="w-4 h-4 shrink-0" />
                  <span>CORS & Secret Protection Agreement</span>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  Your token operates exclusively context-isolated within your local browser sandbox via secure standard headers without transmitting sensitive keys to any proxy database or third party services.
                </p>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
