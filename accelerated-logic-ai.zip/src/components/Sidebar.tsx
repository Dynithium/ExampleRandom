import { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Search, 
  MessageSquare, 
  FileText, 
  Image as ImageIcon, 
  Play, 
  Zap, 
  X, 
  Download,
  Info,
  ChevronLeft,
  Terminal,
  Globe,
  Sparkles,
  Brain,
  Bookmark,
  Github
} from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../utils';
import { Chat, AppFile } from '../db';
import { Tooltip } from './Tooltip';

export const Sidebar = ({ 
  chats, 
  files, 
  currentChatId, 
  onSelectChat, 
  onNewChat, 
  onDeleteChat,
  onClearAll,
  isOpen,
  setIsOpen,
  onExportChat,
  onExportAllChats,
  onImportAllChats,
  theme,
  setTheme,
  onOpenModelTesting,
  onOpenPythonPlayground,
  onOpenWebSandbox,
  onOpenGitHub,
  onOpenAllChats,
  onSelectFile,
  onDeleteFile,
  onOpenMemories,
  onOpenSkills,
  onTogglePinFile,
  onStartTutorial
}: {
  chats: Chat[];
  files: AppFile[];
  currentChatId: string | null;
  onSelectChat: (id: string) => void;
  onNewChat: (id?: string) => void;
  onDeleteChat: (id: string) => void;
  onClearAll: (skipConfirm?: boolean) => void;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  onExportChat: (id: string) => void;
  onExportAllChats: () => void;
  onImportAllChats: (chats: Chat[]) => void;
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  onOpenModelTesting: () => void;
  onOpenPythonPlayground: () => void;
  onOpenWebSandbox: () => void;
  onOpenGitHub: () => void;
  onOpenAllChats: () => void;
  onSelectFile?: (file: AppFile) => void;
  onDeleteFile?: (id: string) => void;
  onOpenMemories?: () => void;
  onOpenSkills?: () => void;
  onTogglePinFile?: (fileId: string) => void;
  onStartTutorial?: () => void;
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmingWipe, setConfirmingWipe] = useState(false);

  const currentChat = chats.find(c => c.id === currentChatId);

  const filteredChats = chats.filter(chat => {
    const query = searchQuery.toLowerCase();
    return (chat.title || '').toLowerCase().includes(query) ||
           chat.messages.some(m => m.content.toLowerCase().includes(query));
  });

  return (
    <motion.div 
      initial={false}
      animate={{ width: isOpen ? 260 : 0 }}
      className="bg-secondary/50 border-r border-border h-full overflow-hidden flex flex-col relative shrink-0"
    >
      <div className="p-4 flex items-center justify-between border-b border-border min-w-[260px]">
        <h1 className="font-bold text-xl tracking-tighter flex items-center gap-2">
          <div className="w-6 h-6 flex items-center justify-center rounded-full relative group transition-all duration-300 pointer-events-none select-none shrink-0">
            <div className="absolute inset-0 bg-[#3b82f6]/10 rounded-full blur-[2px] opacity-75" />
            <svg className="w-5.5 h-5.5 relative z-10 animate-[spin_24s_linear_infinite]" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="sidebarSwooshGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.05" />
                  <stop offset="60%" stopColor="#3b82f6" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#93c5fd" stopOpacity="1" />
                </linearGradient>
                <radialGradient id="sidebarGearBody" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#0f172a" />
                  <stop offset="80%" stopColor="#172554" />
                  <stop offset="100%" stopColor="#020617" />
                </radialGradient>
              </defs>
              <circle cx="50" cy="50" r="48" fill="#3b82f6" opacity="0.15" />
              <path d="M 4 50 A 46 46 0 1 1 50 96" fill="none" stroke="url(#sidebarSwooshGrad)" strokeWidth="3.5" strokeLinecap="round" />
              <circle cx="50" cy="96" r="2.6" fill="#3b82f6" />
              <g transform="rotate(-14.3 50 50)">
                <path d="M 85.00 50.00 L 84.64 55.01 L 77.98 56.39 L 76.78 60.33 L 81.53 65.19 L 79.04 69.54 L 72.44 67.89 L 69.65 70.92 L 71.82 77.36 L 67.68 80.21 L 62.45 75.86 L 58.62 77.37 L 57.79 84.12 L 52.82 84.89 L 50.00 78.70 L 45.89 78.40 L 42.21 84.12 L 37.41 82.66 L 37.55 75.86 L 33.97 73.81 L 28.18 77.36 L 24.49 73.96 L 27.56 67.89 L 25.23 64.50 L 18.47 65.19 L 16.62 60.52 L 22.02 56.39 L 21.39 52.32 L 15.00 50.00 L 15.36 44.99 L 22.02 43.61 L 23.22 39.67 L 18.47 34.81 L 20.96 30.46 L 27.56 32.11 L 30.35 29.08 L 28.18 22.64 L 32.32 19.79 L 37.55 24.14 L 41.38 22.63 L 42.21 15.88 L 47.18 15.11 L 50.00 21.30 L 54.11 21.60 L 57.79 15.88 L 62.59 17.34 L 62.45 24.14 L 66.03 26.19 L 71.82 22.64 L 75.51 26.04 L 72.44 32.11 L 74.77 35.50 L 81.53 34.81 L 83.38 39.48 L 77.98 43.61 L 78.61 47.68 Z" fill="url(#sidebarGearBody)" stroke="#3b82f6" strokeWidth="3.2" />
                <circle cx="50" cy="50" r="20" fill="none" stroke="#3b82f6" strokeWidth="1.2" strokeDasharray="2.5, 2.5" opacity="0.55" />
                <circle cx="50" cy="50" r="11" fill="#111827" stroke="#3b82f6" strokeWidth="3.2" />
                <circle cx="50" cy="50" r="5.5" fill="#030712" />
              </g>
            </svg>
          </div>
          Accelerated Logic
        </h1>
        <Tooltip content="Collapse Sidebar" position="right">
          <button 
            onClick={() => setIsOpen(false)} 
            className="p-1.5 hover:bg-accent rounded-lg text-muted-foreground hover:text-foreground transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </Tooltip>
      </div>

      <div className="p-3 border-b border-border min-w-[260px]">
        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground group-focus-within:text-primary transition-colors" />
          <input 
            type="text" 
            placeholder="Search history..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-muted/50 border border-border rounded-xl pl-9 pr-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/50 transition-all"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto min-w-[260px] p-2 space-y-6 custom-scrollbar">
        {/* AI Parameters */}
        <div className="space-y-1">
          <div className="flex items-center gap-1 px-2 mb-1.5">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">AI Platform</span>
            <Tooltip content="Manage context memory and activation skills for your assistant.">
              <Info className="w-2.5 h-2.5 text-muted-foreground/40" />
            </Tooltip>
          </div>
          
          <button 
            id="tour-memory"
            onClick={onOpenMemories}
            className="w-full flex items-center justify-between p-2 rounded-xl text-sm hover:bg-primary/10 text-muted-foreground hover:text-primary transition-all text-left group border border-transparent hover:border-primary/20 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:scale-105 transition-transform">
                <Brain className="w-4 h-4" />
              </div>
              <span className="truncate font-semibold text-foreground/90 group-hover:text-primary transition-colors">Memory</span>
            </div>
            <span className="text-[9px] font-mono bg-muted-foreground/10 px-1.5 py-0.5 rounded text-muted-foreground/80 group-hover:bg-primary/20 group-hover:text-primary">
              Local
            </span>
          </button>

          <button 
            id="tour-skills"
            onClick={onOpenSkills}
            className="w-full flex items-center justify-between p-2 rounded-xl text-sm hover:bg-indigo-500/10 text-muted-foreground hover:text-indigo-400 transition-all text-left group border border-transparent hover:border-indigo-500/20 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400 group-hover:scale-105 transition-transform">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="truncate font-semibold text-foreground/90 group-hover:text-indigo-400 transition-colors">Skills</span>
            </div>
            <span className="text-[9px] font-mono bg-muted-foreground/10 px-1.5 py-0.5 rounded text-muted-foreground/80 group-hover:bg-indigo-500/20 group-hover:text-indigo-400">
              Active
            </span>
          </button>
        </div>

        <div id="tour-chats">
          <div className="flex items-center justify-between px-2 mb-2">
            <button 
              onClick={onOpenAllChats}
              className="text-xs font-semibold text-muted-foreground uppercase tracking-wider hover:text-primary transition-colors flex items-center gap-1"
            >
              Chats
              <Search className="w-2.5 h-2.5 opacity-50" />
            </button>
            <Tooltip content="Start a fresh conversation" position="right">
              <button onClick={() => onNewChat()} className="p-1 hover:bg-accent rounded-md">
                <Plus className="w-3" />
              </button>
            </Tooltip>
          </div>
          <div className="space-y-1">
            {filteredChats.slice(0, 10).map(chat => (
              <div 
                key={chat.id}
                onClick={() => onSelectChat(chat.id)}
                className={cn(
                  "group flex items-center justify-between p-2 rounded-lg cursor-pointer text-sm transition-colors",
                  currentChatId === chat.id ? "bg-primary/10 text-primary font-medium" : "hover:bg-accent"
                )}
              >
                <div className="flex items-center gap-2 truncate">
                  <MessageSquare className="w-4 h-4 shrink-0 opacity-70" />
                  <span className="truncate">{chat.title || 'New Chat'}</span>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Tooltip content="Export JSON">
                    <button 
                      onClick={(e) => { e.stopPropagation(); onExportChat(chat.id); }}
                      className="p-1 hover:text-primary transition-colors"
                    >
                      <Download className="w-3 h-3" />
                    </button>
                  </Tooltip>
                  <Tooltip content="Delete permanently">
                    <button 
                      onClick={(e) => { e.stopPropagation(); onDeleteChat(chat.id); }}
                      className="p-1 hover:text-destructive transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </Tooltip>
                </div>
              </div>
            ))}
            {filteredChats.length > 10 && (
              <button 
                onClick={onOpenAllChats}
                className="w-full p-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-primary hover:bg-primary/5 rounded-lg transition-all text-center border border-dashed border-border/50 mt-2"
              >
                View all {filteredChats.length} chats
              </button>
            )}
          </div>
        </div>

        <div>
          <div className="flex items-center gap-1 px-2 mb-2">
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Files</h2>
            <Tooltip content="Upload documents or images to use as context for the agents.">
              <Info className="w-2.5 h-2.5 text-muted-foreground/40" />
            </Tooltip>
          </div>
          <div className="space-y-1">
            {files.map(file => {
              const isPinned = currentChat?.pinnedFileIds?.includes(file.id) || false;
              return (
                <div 
                  key={file.id} 
                  draggable
                  onDragStart={(e) => {
                    e.dataTransfer.setData('application/x-accelerated-logic-file', JSON.stringify(file));
                    e.dataTransfer.effectAllowed = 'copy';
                    const ghost = document.createElement('div');
                    ghost.textContent = file.name;
                    ghost.style.position = 'absolute';
                    ghost.style.top = '-1000px';
                    document.body.appendChild(ghost);
                    e.dataTransfer.setDragImage(ghost, 0, 0);
                    setTimeout(() => document.body.removeChild(ghost), 0);
                  }}
                  className="flex items-center gap-2 p-2 rounded-lg text-sm hover:bg-accent cursor-grab active:cursor-grabbing group/file transition-colors"
                  onClick={() => onSelectFile?.(file)}
                >
                  <div className="w-8 h-8 rounded-lg bg-background border border-border flex items-center justify-center shrink-0 group-hover/file:border-primary/50 transition-colors">
                    {file.type.startsWith('image/') ? <ImageIcon className="w-4 h-4 text-primary" /> : <FileText className="w-4 h-4 text-muted-foreground" />}
                  </div>
                  <div className="flex flex-col min-w-0 flex-1">
                    <span className="truncate font-medium">{file.name}</span>
                    <span className="text-[9px] uppercase font-bold text-muted-foreground opacity-60 tracking-widest">{file.type.split('/')[1] || 'File'}</span>
                  </div>
                  
                  {currentChatId && onTogglePinFile && (
                    <Tooltip content={isPinned ? "Unpin persistent context document" : "Pin persistent context document"}>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          onTogglePinFile(file.id);
                        }}
                        className={cn(
                          "p-1.5 rounded-md transition-all cursor-pointer",
                          isPinned 
                            ? "text-primary bg-primary/10 opacity-100" 
                            : "text-muted-foreground hover:text-foreground hover:bg-accent opacity-0 group-hover/file:opacity-100"
                        )}
                      >
                        <Bookmark className={cn("w-3.5 h-3.5", isPinned && "fill-primary")} />
                      </button>
                    </Tooltip>
                  )}

                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteFile?.(file.id);
                    }}
                    className="p-1.5 hover:bg-destructive/10 text-muted-foreground hover:text-destructive rounded-md opacity-0 group-hover/file:opacity-100 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
            {files.length === 0 && <span className="px-2 text-[10px] text-muted-foreground/60 italic">No files uploaded</span>}
          </div>
        </div>

        <div>
           <div className="flex items-center gap-1 px-2 mb-2">
            <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Experimental</h2>
            <Tooltip content="Tools for developers and model testing.">
              <Info className="w-2.5 h-2.5 text-muted-foreground/40" />
            </Tooltip>
          </div>
          <div className="space-y-1">
            <button 
              id="tour-model-playground"
              onClick={onOpenModelTesting}
              className="w-full flex items-center gap-2 p-2 rounded-lg text-sm hover:bg-accent transition-colors text-left"
            >
              <Play className="w-4 h-4 opacity-70" />
              <span className="truncate">Model Playground</span>
            </button>
            <button 
              id="tour-python-sandbox"
              onClick={onOpenPythonPlayground}
              className="w-full flex items-center gap-2 p-2 rounded-lg text-sm hover:bg-accent transition-colors text-left"
            >
              <Terminal className="w-4 h-4 opacity-70" />
              <span className="truncate">Python Sandbox</span>
            </button>
            <button 
              id="tour-web-sandbox"
              onClick={onOpenWebSandbox}
              className="w-full flex items-center gap-2 p-2 rounded-lg text-sm hover:bg-accent transition-colors text-left"
            >
              <Globe className="w-4 h-4 opacity-70" />
              <span className="truncate">Web Sandbox</span>
            </button>
            <button 
              id="tour-github"
              onClick={onOpenGitHub}
              className="w-full flex items-center gap-2 p-2 rounded-lg text-sm hover:bg-accent transition-colors text-left text-indigo-400 hover:text-indigo-300"
            >
              <Github className="w-4 h-4 opacity-70 text-indigo-400" />
              <span className="truncate font-semibold">GitHub Integration</span>
            </button>
          </div>
        </div>
      </div>

      <div className="p-4 border-t border-border min-w-[260px] space-y-3">
        {onStartTutorial && (
          <button 
            id="tour-start-tour"
            onClick={onStartTutorial}
            className="w-full flex items-center justify-center gap-2 py-2.5 bg-primary/10 hover:bg-primary/25 border border-primary/20 text-primary hover:text-primary rounded-xl text-xs font-bold transition-all shadow-sm group-hover:scale-[1.02] active:scale-[0.98]"
          >
            <Sparkles className="w-3.5 h-3.5 animate-pulse text-primary" />
            Interactive Guide
          </button>
        )}

        <Tooltip content={confirmingWipe ? "Click again to confirm wipe" : "Wipe all local storage data"} position="top" className="w-full">
          <button 
            onClick={() => {
              if (confirmingWipe) {
                onClearAll(true);
                setConfirmingWipe(false);
              } else {
                setConfirmingWipe(true);
                setTimeout(() => setConfirmingWipe(false), 3000);
              }
            }}
            className={cn(
              "w-full flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-bold transition-all border",
              confirmingWipe 
                ? "bg-destructive text-destructive-foreground border-destructive animate-pulse" 
                : "text-muted-foreground hover:text-destructive hover:bg-destructive/10 border-border/50"
            )}
          >
            <Trash2 className="w-3.5 h-3.5" />
            {confirmingWipe ? "Are you sure?" : "Clear Local Data"}
          </button>
        </Tooltip>
        
        <div className="flex items-center justify-between bg-muted/50 p-1 rounded-xl">
          {(['light', 'dark'] as const).map(t => (
            <Tooltip key={t} content={`Switch to ${t} theme`}>
              <button
                onClick={() => setTheme(t)}
                className={cn(
                  "px-6 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all",
                  theme === t ? "bg-background text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {t}
              </button>
            </Tooltip>
          ))}
        </div>
      </div>
    </motion.div>
  );
};
