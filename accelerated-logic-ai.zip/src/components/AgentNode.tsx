import React from 'react';
import { Layers, Pencil, Trash2, Info, Zap } from 'lucide-react';
import { Reorder } from 'motion/react';
import { cn } from '../utils';
import { AgentConfig } from '../db';
import { Tooltip } from './Tooltip';
import { getModelInfo } from '../models';

export const AgentNode = ({ 
  agent, 
  onToggle, 
  onEdit, 
  onDelete, 
  onCountChange 
}: { 
  agent: AgentConfig; 
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onCountChange: (count: number) => void;
}) => {
  const modelInfo = agent.modelId ? getModelInfo(agent.modelId) : null;

  return (
    <Reorder.Item
      value={agent}
      id={agent.id}
      className={cn(
        "p-3 rounded-xl border transition-all flex flex-col gap-2 cursor-grab active:cursor-grabbing",
        agent.enabled ? "border-primary bg-primary/5 shadow-sm" : "border-border bg-muted/30 opacity-60"
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1 -ml-1 text-muted-foreground/40">
            <Layers className="w-3.5 h-3.5" />
          </div>
          <Tooltip content={agent.enabled ? "Disable Agent" : "Enable Agent"}>
            <div 
              onClick={onToggle}
              className={cn(
                "w-8 h-4 rounded-full relative cursor-pointer transition-colors",
                agent.enabled ? "bg-primary" : "bg-muted"
              )}
            >
              <div className={cn(
                "absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all",
                agent.enabled ? "left-4.5" : "left-0.5"
              )} />
            </div>
          </Tooltip>
          <span className="text-sm font-medium">{agent.name}</span>
        </div>
        <div className="flex items-center gap-1">
          {!agent.isFixed && (
            <>
              <Tooltip content="Edit Agent Prompt & Role">
                <button onClick={onEdit} className="p-1.5 hover:bg-accent rounded-md text-muted-foreground hover:text-foreground">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
              </Tooltip>
              <Tooltip content="Remove Agent">
                <button onClick={onDelete} className="p-1.5 hover:bg-accent rounded-md text-muted-foreground hover:text-destructive">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </Tooltip>
            </>
          )}
          {agent.isFixed && (
            <div className="flex items-center gap-1">
              <Tooltip content="Edit Agent Prompt & Role">
                <button onClick={onEdit} className="p-1.5 hover:bg-accent rounded-md text-muted-foreground hover:text-foreground">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
              </Tooltip>
              <Tooltip content="System core agent (required)">
                <Info className="w-3 h-3 text-muted-foreground/40" />
              </Tooltip>
            </div>
          )}
        </div>
      </div>

      {agent.modelId && modelInfo && (
        <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-primary/10 border border-primary/20 self-start">
          <Zap className="w-2.5 h-2.5 text-primary" />
          <span className="text-[9px] font-bold text-primary truncate max-w-[150px]">
            {modelInfo.catalogModel?.name || modelInfo.modelId}
          </span>
        </div>
      )}
      
      {!agent.isFixed && (
        <div className="flex items-center justify-between mt-1">
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Instances</span>
            <Tooltip content="Run multiple copies of this agent in parallel to explore different reasoning paths.">
              <Info className="w-2.5 h-2.5 text-muted-foreground/40" />
            </Tooltip>
          </div>
          <div className="flex items-center gap-2 bg-background border rounded-lg p-1">
            <button 
              onClick={() => onCountChange(Math.max(1, agent.count - 1))}
              className="w-5 h-5 flex items-center justify-center hover:bg-accent rounded"
            >-</button>
            <span className="text-xs w-4 text-center font-mono">{agent.count}</span>
            <button 
              onClick={() => onCountChange(agent.count + 1)}
              className="w-5 h-5 flex items-center justify-center hover:bg-accent rounded"
            >+</button>
          </div>
        </div>
      )}
    </Reorder.Item>
  );
};
