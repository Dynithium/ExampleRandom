import React, { Component, ErrorInfo, ReactNode } from 'react';
import { X } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="h-screen w-full flex flex-col items-center justify-center bg-background text-foreground p-8 text-center space-y-4">
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center text-destructive mb-2">
            <X className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Something went wrong</h1>
          <div className="text-muted-foreground max-w-md">
            The application encountered a runtime error. This might be due to a missing dependency or an unsupported browser feature.
          </div>
          <div className="bg-muted p-4 rounded-xl text-left text-xs font-mono max-w-2xl overflow-auto border border-border">
            {this.state.error?.toString()}
          </div>
          <button 
            onClick={() => window.location.reload()}
            className="bg-primary text-primary-foreground px-6 py-2.5 rounded-full font-semibold shadow-lg shadow-primary/20"
          >
            Reload Application
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

