/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, useMemo, useCallback, memo } from 'react';
import * as webllm from '@mlc-ai/web-llm';
import { 
  Plus, 
  Triangle, 
  Settings as Gear, 
  Send, 
  Trash2, 
  Database,
  Pencil, 
  ChevronRight,
  ChevronDown, 
  ChevronUp, 
  Layers, 
  Zap, 
  Infinity as InfinityIcon,
  X,
  Star,
  Download,
  Upload,
  FileText,
  Image as ImageIcon,
  Video,
  Layout,
  Play,
  Pause,
  RefreshCw,
  Search,
  MessageSquare,
  MoreVertical,
  User,
  Bot,
  Brain,
  BrainCircuit,
  Mic,
  Volume2,
  VolumeX,
  Sparkles,
  ArrowRight,
  Code,
  Share2,
  Copy,
  Cloud,
  Info,
  ExternalLink,
  AlertCircle,
  Wand2,
  Check,
  Square,
  Loader2,
  Terminal,
  RotateCcw,
  ShieldCheck,
  Activity,
  Cpu,
  Key,
  Monitor,
  PanelLeftOpen,
  PanelLeftClose,
  GitBranch,
  Clock,
  Bookmark,
  ListPlus,
  Edit3
} from 'lucide-react';
import { motion, AnimatePresence, Reorder } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { cn, reduceTokens } from './utils';
import { 
  getDB, 
  saveChat, 
  getAllChats, 
  deleteChat, 
  saveFile, 
  getAllFiles, 
  saveSettings, 
  getSettings, 
  saveEquippedModels,
  getEquippedModels,
  saveAgent, 
  getAllAgents, 
  deleteAgent,
  clearAllData,
  exportDatabaseSnapshot,
  getAllMemories,
  saveMemory,
  deleteMemory,
  Chat,
  Message,
  AppFile,
  AgentConfig,
  Settings,
  Memory,
  MASArchitecture,
  SkillConfig
} from './db';

import { VoiceInterface } from './components/VoiceInterface';
import { CodePreview } from './components/CodePreview';
import { ModeSelector, Mode } from './components/ModeSelector';
import { AgentNode } from './components/AgentNode';
import { AgentPipelineFlow } from './components/AgentPipelineFlow';
import { Sidebar } from './components/Sidebar';
import { CodeBlock } from './components/CodeBlock';
import { MemoryManager } from './components/MemoryManager';
import { ModelOrganizer } from './components/ModelOrganizer';
import { SkillsManager } from './components/SkillsManager';
import { PythonPlayground } from './components/PythonPlayground';
import { WebSandbox } from './components/WebSandbox';
import { ThinkingTraceDrawer } from './components/ThinkingTraceDrawer';
import { GitHubIntegration } from './components/GitHubIntegration';

import { Tooltip } from './components/Tooltip';
import { FilePreview } from './components/FilePreview';

import { Tutorial } from './components/Tutorial';
import { ErrorBoundary } from './components/ErrorBoundary';
import { EulaModal } from './components/EulaModal';
import { SyncConflictModal } from './components/SyncConflictModal';
import { HelpCompanion } from './components/HelpCompanion';
import { getModelInfo, DEFAULT_SETTINGS, CHAT_MODELS, IMAGE_MODELS, AGENT_PRESETS, OLLAMA_MODELS_CACHE } from './models';
import { cleanMessage, MIME_MAP, isImageFile, isPdfFile, isKnownBinaryFile, ensureClosedThinkingTags, extractModelThinking, extractTextFromPdfBase64 } from './utils';
import { executePythonCode } from './services/pythonSandbox';
import { getCompletion as llmGetCompletion, countTokens, formatMessageWithAttachments, estimateGeneralTokens } from './services/llm';
import { GoogleGenAI } from '@google/genai';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Header } from './components/Header';
import { BootScreen } from './components/BootScreen';
import { GlobalOverlay } from './components/GlobalOverlay';
import { DragOverlay } from './components/DragOverlay';
import { LandingPage } from './components/LandingPage';
import { initGoogleDriveAuth, connectGoogleDrive, connectGoogleDriveSilently, saveChatsToGoogleDrive, getDriveToken, fetchChatsFromGoogleDrive, saveFileToGoogleDrive, fetchFileFromGoogleDrive, registerTokenExpiredCallback } from './services/googleDrive';
// Auto selector embeddings removed

const SKILL_PRESETS = [
  // Prompt type skills (standard skills, can parallel activate)
  {
    name: 'Frontend Architect',
    description: 'Expertise in UI components, Tailwind CSS, and polish.',
    systemPrompt: 'You are a Senior Frontend Architect. When this skill is active, you MUST prioritize using modern Tailwind CSS classes, logical component structures, and ensure high visual polish. Follow "Atomic Design" principles. Every component you suggest should be production-ready and aesthetically distinctive. Use lucid-react for icons and motion for animations.',
    type: 'prompt' as const,
  },
  {
    name: 'Logic Debugger',
    description: 'Expertise in finding edge cases and complex debugging.',
    systemPrompt: 'You are a Debugging Specialist. When active, perform a "Step-by-Step" analysis of every logic flow. Actively look for race conditions, null pointers, and off-by-one errors. For every fix you propose, explain why the original code failed and how the new version prevents future regressions.',
    type: 'prompt' as const,
  },
  {
    name: 'System Designer',
    description: 'Focuses on scalable architecture and database design.',
    systemPrompt: 'You are a Systems Architect. Focus on data flow, modularity, and scalability. When designing features, consider database consistency, indexing, and API lifecycle. Propose solutions that minimize technical debt and maximize future flexibility.',
    type: 'prompt' as const,
  },
  {
    name: 'Security Shield',
    description: 'Focuses on auditing code for vulnerabilities.',
    systemPrompt: 'You are a Security Researcher. Audit every suggestion for common vulnerabilities: SQL Injection, XSS, CSRF, and broken access control. If you find a risk, highlight it clearly and provide a secure alternative. Always adhere to "Zero Trust" security principles.',
    type: 'prompt' as const,
  },
  {
    name: 'Creative Director',
    description: 'Focuses on tone, branding, and storytelling.',
    systemPrompt: 'You are a World-Class Creative Director. Ensure all copy is engaging, consistent in tone, and aligns with high-end branding standards. Use descriptive, evocative language. Avoid clichés and prioritize unique storytelling hooks.',
    type: 'prompt' as const,
  },

  // Persona type skills (strictly one active at a time)
  {
    name: 'Pirate Captain',
    description: 'Adopt a rowdy high-seas pirate dialect filled with nautical charm.',
    systemPrompt: 'Ahoy, matey! Adopt the persona of a salty, enthusiastic Pirate Captain. Speak in a broad pirate dialect ("Ahoy!", "Shiver me timbers!", "Aye!"), sprinkle in sailing metaphors, tall tales, and rowdy sea shanties, but always solve the requested tasks in full with a pirate spin.',
    type: 'persona' as const,
  },
  {
    name: 'Silicon Valley VC',
    description: 'Adopt the persona of a hyped-up tech investor focused on hyper-growth.',
    systemPrompt: 'You are an ultra-hyped Silicon Valley Venture Capitalist. Adopt a tone obsessed with disruption, seed/series-A rounds, scaling to the moon, synergy, AI-first pivots, and product-market fit. Use hyped buzzwords, tell the user their idea is "absolutely legendary," and advise them on how to secure a $100M valuation.',
    type: 'persona' as const,
  },
  {
    name: 'Socratic Philosopher',
    description: 'Adopt the persona of a Socratic thinker probing code with deep inquiry.',
    systemPrompt: 'You are a modern Socratic philosopher who treats software engineering as a search for ultimate truth. Respond with intellectual depth, calm composure, and profound inquiry. When writing code, explain the existential meaning of the functions and variables, prompting the user with thoughtful follow-up questions.',
    type: 'persona' as const,
  },
  {
    name: 'Brutalist Minimalist',
    description: 'Speaks with radical clarity, ultra-brief explanations, and direct answers.',
    systemPrompt: 'You are an elite, minimal software purist. Never write greetings, introductory fluff, or polite summaries. Deliver pure code and raw, hyper-dense technical critiques of extreme clarity. Keep text to an absolute minimum.',
    type: 'persona' as const,
  }
];

function getSlashCommandInfo(text: string, selectionStart: number) {
  const textBeforeCursor = text.substring(0, selectionStart);
  const lastSlashIdx = textBeforeCursor.lastIndexOf('/');
  
  if (lastSlashIdx === -1) return { isActive: false, query: '', startIndex: -1 };
  
  const between = textBeforeCursor.substring(lastSlashIdx + 1);
  if (between.includes(' ') || between.includes('\n')) {
    return { isActive: false, query: '', startIndex: -1 };
  }
  
  if (lastSlashIdx > 0 && textBeforeCursor[lastSlashIdx - 1] !== ' ' && textBeforeCursor[lastSlashIdx - 1] !== '\n') {
    return { isActive: false, query: '', startIndex: -1 };
  }
  
  return {
    isActive: true,
    query: between,
    startIndex: lastSlashIdx
  };
}

// --- Types ---

export default function App() {
  return (
    <ErrorBoundary>
      <AppContent />
    </ErrorBoundary>
  );
}

function AppContent() {
  // --- State ---
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [ollamaCacheTick, setOllamaCacheTick] = useState(0);
  const [chats, setChats] = useState<Chat[]>([]);
  const [files, setFiles] = useState<AppFile[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 1024);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [showTutorial, setShowTutorial] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState<number | null>(null);
  const [editingContent, setEditingContent] = useState('');

  // --- Google Drive AppData Sync State & Effects ---
  const [isDriveConnected, setIsDriveConnected] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('gdrive_connected') === 'true';
    }
    return false;
  });
  const [isDriveSessionExpired, setIsDriveSessionExpired] = useState(() => {
    if (typeof window !== 'undefined') {
      const wasConnected = localStorage.getItem('gdrive_connected') === 'true';
      const token = localStorage.getItem('gdrive_access_token');
      const expiresAtStr = localStorage.getItem('gdrive_token_expires_at');
      if (wasConnected) {
        if (token && expiresAtStr) {
          const expiresAt = parseInt(expiresAtStr, 10);
          return Date.now() >= expiresAt;
        }
        return true;
      }
    }
    return false;
  });
  const [isSyncingDrive, setIsSyncingDrive] = useState(false);
  const [syncIndicatorStatus, setSyncIndicatorStatus] = useState<'idle' | 'syncing' | 'saved' | 'error'>('idle');
  const [pendingSync, setPendingSync] = useState<{
    local: Chat[];
    remote: Chat[];
    token: string;
  } | null>(null);
  const [memorySyncTrigger, setMemorySyncTrigger] = useState(0);

  // Use a ref to chats & settings to avoid stale closures in callbacks
  const chatsRef = useRef<Chat[]>([]);
  useEffect(() => {
    chatsRef.current = chats;
  }, [chats]);

  const settingsRef = useRef<Settings>(settings);
  useEffect(() => {
    settingsRef.current = settings;
  }, [settings]);

  const hasSyncConflict = (local: Chat[], remote: Chat[]): boolean => {
    if (local.length !== remote.length) return true;
    for (const lc of local) {
      const rc = remote.find(r => r.id === lc.id);
      if (!rc) return true;
      if (rc.messages.length !== lc.messages.length) return true;
      if (rc.title !== lc.title) return true;
      for (let i = 0; i < lc.messages.length; i++) {
        if (!rc.messages[i] || lc.messages[i].content !== rc.messages[i].content || lc.messages[i].role !== rc.messages[i].role) {
          return true;
        }
      }
    }
    return false;
  };

  const syncDriveData = useCallback(async (token: string) => {
    setIsSyncingDrive(true);
    setSyncIndicatorStatus('syncing');
    try {
      const activeSelectors = settingsRef.current?.gdriveBackupSelector || {
        chats: true,
        files: true,
        projects: true,
        skills: true,
        memories: true
      };

      // 1. Sync Chats
      if (activeSelectors.chats !== false) {
        const remoteChats = await fetchChatsFromGoogleDrive(token);
        const currentLocalChats = chatsRef.current;
        if (remoteChats && remoteChats.length > 0) {
          if (currentLocalChats.length === 0) {
            console.log("Restoring chats from Google Drive backup...", remoteChats);
            for (const rawChat of remoteChats) {
              const chatObj: Chat = {
                id: rawChat.id,
                title: rawChat.title || 'Untitled Chat',
                createdAt: rawChat.createdAt || Date.now(),
                messages: rawChat.messages || [],
                pinnedFileIds: rawChat.pinnedFileIds || [],
              };
              await saveChat(chatObj);
            }
            setChats(remoteChats.sort((a, b) => b.createdAt - a.createdAt));
          } else {
            // Check for sync conflict
            if (hasSyncConflict(currentLocalChats, remoteChats)) {
              const getInformationScore = (chatsList: Chat[]) => {
                let totalChats = chatsList.length;
                let totalMessages = 0;
                let totalChars = 0;
                for (const c of chatsList) {
                  totalMessages += c.messages?.length || 0;
                  for (const m of c.messages || []) {
                    totalChars += m.content?.length || 0;
                  }
                }
                return { totalChats, totalMessages, totalChars };
              };

              const localWeight = getInformationScore(currentLocalChats);
              const remoteWeight = getInformationScore(remoteChats);

              let remoteHasMore = false;
              if (remoteWeight.totalChats !== localWeight.totalChats) {
                remoteHasMore = remoteWeight.totalChats > localWeight.totalChats;
              } else if (remoteWeight.totalMessages !== localWeight.totalMessages) {
                remoteHasMore = remoteWeight.totalMessages > localWeight.totalMessages;
              } else if (remoteWeight.totalChars !== localWeight.totalChars) {
                remoteHasMore = remoteWeight.totalChars > localWeight.totalChars;
              }

              if (remoteHasMore) {
                console.log("[Google Drive Sync] Remote drive has more information. Overwriting local chats with remote chats.", remoteWeight, localWeight);
                // Delete all current local chats
                for (const localChat of currentLocalChats) {
                  await deleteChat(localChat.id);
                }
                // Save all remote chats locally
                for (const rawChat of remoteChats) {
                  const chatObj: Chat = {
                    id: rawChat.id,
                    title: rawChat.title || 'Untitled Chat',
                    createdAt: rawChat.createdAt || Date.now(),
                    messages: rawChat.messages || [],
                    pinnedFileIds: rawChat.pinnedFileIds || [],
                  };
                  await saveChat(chatObj);
                }
                setChats(remoteChats.sort((a, b) => b.createdAt - a.createdAt));
                const sorted = [...remoteChats].sort((a, b) => b.createdAt - a.createdAt);
                if (sorted.length > 0 && !sorted.some(c => c.id === currentChatId)) {
                  setCurrentChatId(sorted[0].id);
                }
              } else {
                console.log("[Google Drive Sync] Local database has same or more information. Overwriting Google Drive chats with local chats.", localWeight, remoteWeight);
                await saveChatsToGoogleDrive(currentLocalChats, token);
              }
            }
          }
        } else if (currentLocalChats.length > 0) {
          // Create initial backup
          await saveChatsToGoogleDrive(currentLocalChats, token);
        }
      }

      // 2. Sync Memories
      if (activeSelectors.memories !== false) {
        console.log("[Google Drive] Synchronizing memories...");
        const remoteMemories = await fetchFileFromGoogleDrive('my_ai_memories.json', token);
        const localMemories = await getAllMemories();
        if (remoteMemories && Array.isArray(remoteMemories)) {
          let memoriesAdded = false;
          const mergedMemories = [...localMemories];
          for (const rm of remoteMemories) {
            if (!mergedMemories.some(lm => lm.id === rm.id)) {
              mergedMemories.push(rm);
              await saveMemory(rm);
              memoriesAdded = true;
            }
          }
          if (memoriesAdded || localMemories.length > remoteMemories.length) {
            await saveFileToGoogleDrive('my_ai_memories.json', mergedMemories, token);
          }
          setMemorySyncTrigger(p => p + 1);
        } else if (localMemories.length > 0) {
          // Save initial memory backup
          await saveFileToGoogleDrive('my_ai_memories.json', localMemories, token);
        }
      }

      // 3. Sync Web/Python Projects
      if (activeSelectors.projects !== false) {
        console.log("[Google Drive] Synchronizing web/python projects...");
        const remoteProjects = await fetchFileFromGoogleDrive('my_ai_projects.json', token);
        const localPythonStr = localStorage.getItem("gemini_python_projects") || "{}";
        const localWebStr = localStorage.getItem("gemini_workspace_projects") || "{}";
        
        let localPython = {};
        let localWeb = {};
        try { localPython = JSON.parse(localPythonStr); } catch (_) {}
        try { localWeb = JSON.parse(localWebStr); } catch (_) {}

        if (remoteProjects && typeof remoteProjects === 'object') {
          const remotePython = remoteProjects.python || {};
          const remoteWeb = remoteProjects.web || {};
          
          const mergedPython = { ...remotePython, ...localPython };
          const mergedWeb = { ...remoteWeb, ...localWeb };
          
          localStorage.setItem("gemini_python_projects", JSON.stringify(mergedPython));
          localStorage.setItem("gemini_workspace_projects", JSON.stringify(mergedWeb));
          
          await saveFileToGoogleDrive('my_ai_projects.json', { python: mergedPython, web: mergedWeb }, token);
        } else if (Object.keys(localPython).length > 0 || Object.keys(localWeb).length > 0) {
          await saveFileToGoogleDrive('my_ai_projects.json', { python: localPython, web: localWeb }, token);
        }
      }

      // 4. Sync Files
      if (activeSelectors.files !== false) {
        console.log("[Google Drive] Synchronizing uploaded files...");
        const remoteFiles = await fetchFileFromGoogleDrive('my_ai_files.json', token);
        const localFiles = await getAllFiles();
        
        if (remoteFiles && Array.isArray(remoteFiles)) {
          let filesAdded = false;
          const mergedFiles = [...localFiles];
          for (const rf of remoteFiles) {
            if (!mergedFiles.some(lf => lf.id === rf.id)) {
              mergedFiles.push(rf);
              await saveFile(rf);
              filesAdded = true;
            }
          }
          if (filesAdded || localFiles.length > remoteFiles.length) {
            await saveFileToGoogleDrive('my_ai_files.json', mergedFiles, token);
          }
          if (filesAdded) {
            setFiles(mergedFiles);
          }
        } else if (localFiles.length > 0) {
          await saveFileToGoogleDrive('my_ai_files.json', localFiles, token);
        }
      }

      // 5. Sync Settings & Custom Skills
      console.log("[Google Drive] Synchronizing settings & skills...");
      const remoteSettings = await fetchFileFromGoogleDrive('my_ai_settings.json', token);
      if (remoteSettings) {
        const localSkills = settingsRef.current?.skills || [];
        const remoteSkills = remoteSettings.skills || [];
        
        // Merge or skip skills based on selector
        const shouldSyncSkills = activeSelectors.skills !== false;
        const mergedSkills = shouldSyncSkills 
          ? (() => {
              const merged = [...localSkills];
              for (const rs of remoteSkills) {
                if (!merged.some(ls => ls.id === rs.id)) {
                  merged.push(rs);
                }
              }
              return merged;
            })()
          : localSkills;

        const mergedSettings = {
          ...settingsRef.current,
          ...remoteSettings,
          skills: mergedSkills,
          gdriveBackupSelector: activeSelectors // preserve active toggles
        };

        if (settingsRef.current?.geminiApiKey && !mergedSettings.geminiApiKey) {
          mergedSettings.geminiApiKey = settingsRef.current.geminiApiKey;
        }
        if (settingsRef.current?.openaiApiKey && !mergedSettings.openaiApiKey) {
          mergedSettings.openaiApiKey = settingsRef.current.openaiApiKey;
        }

        await saveSettings(mergedSettings);
        setSettings(mergedSettings);

        // Upload back with right fields
        const settingsToSave = { ...mergedSettings };
        if (!shouldSyncSkills) {
          settingsToSave.skills = [];
        }
        await saveFileToGoogleDrive('my_ai_settings.json', settingsToSave, token);
      } else {
        const settingsToSave = { ...settingsRef.current };
        if (activeSelectors.skills === false) {
          settingsToSave.skills = [];
        }
        await saveFileToGoogleDrive('my_ai_settings.json', settingsToSave, token);
      }

      setSyncIndicatorStatus('saved');
      setTimeout(() => setSyncIndicatorStatus('idle'), 3000);
    } catch (err) {
      console.error("Failed to sync with Google Drive:", err);
      setSyncIndicatorStatus('error');
    } finally {
      setIsSyncingDrive(false);
    }
  }, []);

  const handleResolveSyncConflict = async (action: 'keep_local' | 'overwrite_cloud' | 'merge') => {
    if (!pendingSync) return;
    const { local, remote, token } = pendingSync;
    setIsSyncingDrive(true);
    setSyncIndicatorStatus('syncing');
    
    try {
      if (action === 'keep_local') {
        const success = await saveChatsToGoogleDrive(local, token);
        setSyncIndicatorStatus(success ? 'saved' : 'error');
      } else if (action === 'overwrite_cloud') {
        for (const rc of remote) {
          const chatObj: Chat = {
            id: rc.id,
            title: rc.title || 'Untitled Chat',
            createdAt: rc.createdAt || Date.now(),
            messages: rc.messages || [],
            pinnedFileIds: rc.pinnedFileIds || [],
          };
          await saveChat(chatObj);
        }
        setChats(remote.sort((a, b) => b.createdAt - a.createdAt));
        if (remote.length > 0 && !remote.some(c => c.id === currentChatId)) {
          setCurrentChatId(remote[0].id);
        }
        setSyncIndicatorStatus('saved');
      } else if (action === 'merge') {
        let merged = [...local];
        let updated = false;

        for (const rc of remote) {
          const localWithSameId = local.find(lc => lc.id === rc.id);
          if (!localWithSameId) {
            merged.push({
              id: rc.id,
              title: rc.title || 'Untitled Chat',
              createdAt: rc.createdAt || Date.now(),
              messages: rc.messages || [],
              pinnedFileIds: rc.pinnedFileIds || [],
            });
            updated = true;
          } else {
            const areMsgsDifferent = localWithSameId.messages.length !== rc.messages.length ||
              localWithSameId.messages.some((lm, idx) => {
                const rm = rc.messages[idx];
                return !rm || lm.content !== rm.content || lm.role !== rm.role;
              });

            if (areMsgsDifferent) {
              const cloudCopyId = `${rc.id}-merged-cloud-${Date.now()}`;
              merged.push({
                id: cloudCopyId,
                title: `${rc.title || 'Untitled'} (Cloud Sync Copy)`,
                createdAt: rc.createdAt + 1,
                messages: rc.messages || [],
                pinnedFileIds: rc.pinnedFileIds || [],
              });
              updated = true;
            }
          }
        }

        for (const chat of merged) {
          await saveChat(chat);
        }
        const sorted = merged.sort((a, b) => b.createdAt - a.createdAt);
        setChats(sorted);
        const success = await saveChatsToGoogleDrive(sorted, token);
        setSyncIndicatorStatus(success ? 'saved' : 'error');
      }
      setTimeout(() => setSyncIndicatorStatus('idle'), 3000);
    } catch (err) {
      console.error("Failed to resolve sync conflict:", err);
      setSyncIndicatorStatus('error');
    } finally {
      setPendingSync(null);
      setIsSyncingDrive(false);
    }
  };

  useEffect(() => {
    registerTokenExpiredCallback(() => {
      setIsDriveSessionExpired(true);
      const wasConnected = localStorage.getItem('gdrive_connected') === 'true';
      if (wasConnected) {
        connectGoogleDriveSilently();
      }
    });

    initGoogleDriveAuth(
      (token) => {
        setIsDriveConnected(true);
        setIsDriveSessionExpired(false);
        syncDriveData(token);
      },
      (err) => {
        console.warn("Google silent auth callback error:", err);
        setIsDriveSessionExpired(true);
      }
    );

    const wasConnected = localStorage.getItem('gdrive_connected') === 'true';
    const activeToken = getDriveToken();
    if (wasConnected && !activeToken) {
      setTimeout(() => {
        connectGoogleDriveSilently();
      }, 1500);
    }
  }, [syncDriveData]);

  // Silently save updates to Google Drive on content changes
  useEffect(() => {
    const token = getDriveToken();
    const allowChats = settings.gdriveBackupSelector?.chats !== false;
    if (isDriveConnected && token && chats.length > 0 && !isSyncingDrive && allowChats) {
      setSyncIndicatorStatus('syncing');
      const timer = setTimeout(() => {
        saveChatsToGoogleDrive(chats, token)
          .then(success => {
            setSyncIndicatorStatus(success ? 'saved' : 'error');
            if (success) {
              setTimeout(() => setSyncIndicatorStatus('idle'), 3000);
            }
          })
          .catch(() => {
            setSyncIndicatorStatus('error');
          });
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [chats, isDriveConnected, settings.gdriveBackupSelector?.chats]);

  // Silently save long-term memories updates to Google Drive
  useEffect(() => {
    const token = getDriveToken();
    const allowMemories = settings.gdriveBackupSelector?.memories !== false;
    if (isDriveConnected && token && allowMemories) {
      setSyncIndicatorStatus('syncing');
      const timer = setTimeout(async () => {
        try {
          const list = await getAllMemories();
          const success = await saveFileToGoogleDrive('my_ai_memories.json', list, token);
          setSyncIndicatorStatus(success ? 'saved' : 'error');
          if (success) {
            setTimeout(() => setSyncIndicatorStatus('idle'), 3000);
          }
        } catch (err) {
          console.error("Failed to automatically back up memories:", err);
          setSyncIndicatorStatus('error');
        }
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [memorySyncTrigger, isDriveConnected, settings.gdriveBackupSelector?.memories]);

  // Silently save settings (which contains custom skills) to Google Drive
  useEffect(() => {
    const token = getDriveToken();
    if (isDriveConnected && token && !isSyncingDrive) {
      setSyncIndicatorStatus('syncing');
      const timer = setTimeout(async () => {
        try {
          const activeSelectors = settings.gdriveBackupSelector || {
            chats: true,
            files: true,
            projects: true,
            skills: true,
            memories: true
          };

          const settingsToSave = { ...settings };
          if (activeSelectors.skills === false) {
            settingsToSave.skills = []; // omit custom skills list from backup file if skills sync is turned off
          }

          const success = await saveFileToGoogleDrive('my_ai_settings.json', settingsToSave, token);
          setSyncIndicatorStatus(success ? 'saved' : 'error');
          if (success) {
            setTimeout(() => setSyncIndicatorStatus('idle'), 3000);
          }
        } catch (err) {
          console.error("Failed to automatically back up settings/skills:", err);
          setSyncIndicatorStatus('error');
        }
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [settings, isDriveConnected]);

  // Silently save uploaded files to Google Drive
  useEffect(() => {
    const token = getDriveToken();
    const allowFiles = settings.gdriveBackupSelector?.files !== false;
    if (isDriveConnected && token && files.length > 0 && !isSyncingDrive && allowFiles) {
      setSyncIndicatorStatus('syncing');
      const timer = setTimeout(async () => {
        try {
          const success = await saveFileToGoogleDrive('my_ai_files.json', files, token);
          setSyncIndicatorStatus(success ? 'saved' : 'error');
          if (success) {
            setTimeout(() => setSyncIndicatorStatus('idle'), 3000);
          }
        } catch (err) {
          console.error("Failed to automatically back up files:", err);
          setSyncIndicatorStatus('error');
        }
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [files, isDriveConnected, settings.gdriveBackupSelector?.files]);

  const handleConnectDrive = () => {
    connectGoogleDrive();
  };

  const handleDeleteMessage = (timestamp: number) => {
    if (!currentChatId) return;
    setChats(prev => prev.map(c => {
      if (c.id === currentChatId) {
        const msgIndex = c.messages.findIndex(m => m.timestamp === timestamp);
        if (msgIndex === -1) return c;

        const targetMsg = c.messages[msgIndex];
        let updatedMessages = [...c.messages];

        if (targetMsg.role === 'user') {
          // If we delete a user prompt, also delete the subsequent response if it exists and is an assistant response
          const nextMsg = c.messages[msgIndex + 1];
          if (nextMsg && nextMsg.role === 'assistant') {
            updatedMessages = c.messages.filter((_, idx) => idx !== msgIndex && idx !== (msgIndex + 1));
          } else {
            updatedMessages = c.messages.filter((_, idx) => idx !== msgIndex);
          }
        } else {
          // If we delete an assistant response, delete the prompt that came before it if it is a user message
          const prevMsg = c.messages[msgIndex - 1];
          if (prevMsg && prevMsg.role === 'user') {
            updatedMessages = c.messages.filter((_, idx) => idx !== msgIndex && idx !== (msgIndex - 1));
          } else {
            updatedMessages = c.messages.filter((_, idx) => idx !== msgIndex);
          }
        }

        const updated = { ...c, messages: updatedMessages };
        saveChat(updated);
        return updated;
      }
      return c;
    }));
  };



  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) {
        setIsSidebarOpen(false);
      } else if (window.innerWidth > 1024) {
        setIsSidebarOpen(true);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const [input, setInput] = useState('');
  const [isAgentBoxOpen, setIsAgentBoxOpen] = useState(false);
  const [mode, setMode] = useState<Mode>('single');
  const [agents, setAgents] = useState<AgentConfig[]>([
    { id: 'orch', name: 'Orchestrator', systemPrompt: 'You are an orchestrator. Split the user request into logical tasks.', count: 1, enabled: true, isFixed: true },
    { id: 'coder', name: 'Coder', systemPrompt: 'You are an expert programmer. When generating code, use standard markdown blocks (e.g. ```python). Provide clear, efficient, and well-documented solutions.', count: 1, enabled: true },
    { id: 'writer', name: 'Writer', systemPrompt: 'You are a creative writer.', count: 1, enabled: false },
    { id: 'auditor', name: 'Auditor', systemPrompt: 'You are an auditor. Check if the output meets the requirements.', count: 1, enabled: true, isFixed: true },
    { id: 'checker', name: 'Prompt Checker', systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.', count: 1, enabled: true, isFixed: true },
    { id: 'finalizer', name: 'Finalizer', systemPrompt: 'You are a finalizer. Combine all agent outputs into a unified response. IMPORTANT: Only output user-relevant content. To generate an image (ONLY if specifically and explicitly requested by the user), use <image_gen prompt="..." />.', count: 1, enabled: true, isFixed: true },
  ]);

  const [customPresets, setCustomPresets] = useState<Record<string, AgentConfig[]>>(() => {
    try {
      const saved = localStorage.getItem('accelerated_logic_custom_presets');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      console.error("Failed to load custom presets:", e);
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('accelerated_logic_custom_presets', JSON.stringify(customPresets));
    } catch (e) {
      console.error("Failed to save custom presets:", e);
    }
  }, [customPresets]);

  const [newPresetName, setNewPresetName] = useState('');
  const [isSavingPreset, setIsSavingPreset] = useState(false);

  const handleSavePreset = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    setCustomPresets(prev => ({
      ...prev,
      [trimmed]: agents.map(a => ({ ...a }))
    }));
    setNewPresetName('');
    setIsSavingPreset(false);
  };

  const handleDeletePreset = (name: string) => {
    setCustomPresets(prev => {
      const copy = { ...prev };
      delete copy[name];
      return copy;
    });
  };

  const applyCustomPreset = (name: string) => {
    const presetAgents = customPresets[name];
    if (presetAgents) {
      setAgents(presetAgents);
      setMode('multi');
      setThinkingProcess(prev => [...prev, { agent: 'System', text: `Applied custom preset: ${name}` }]);
    }
  };

  const [isInfinityOpen, setIsInfinityOpen] = useState(false);
  const [isThinkingOpen, setIsThinkingOpen] = useState(false);
  const [isModelOrganizerOpen, setIsModelOrganizerOpen] = useState(false);
  const isTryingToUseOllama = useMemo(() => {
    if (getModelInfo(settings.puterModel || '').provider === 'ollama') {
      return true;
    }
    if (mode === 'multi') {
      return agents.some(a => {
        if (!a.enabled) return false;
        const mId = a.modelId || settings.puterModel || '';
        return getModelInfo(mId).provider === 'ollama';
      });
    }
    return false;
  }, [settings.puterModel, mode, agents]);

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [speechErrorNotice, setSpeechErrorNotice] = useState<string | null>(null);
  const [activeSettingsTab, setActiveSettingsTab] = useState<'ai' | 'gemini' | 'display' | 'llm' | 'image' | 'skills' | 'memory' | 'gdrive' | 'local_save'>('ai');
  const [settingsSearchQuery, setSettingsSearchQuery] = useState('');

  useEffect(() => {
    if (!isSettingsOpen) {
      setSettingsSearchQuery('');
    }
  }, [isSettingsOpen]);

  useEffect(() => {
    if (settingsSearchQuery) {
      const query = settingsSearchQuery.toLowerCase();
      const firstMatch = [
        { id: 'ai', label: 'AI Configuration', keywords: ['ai', 'configuration', 'model', 'webllm', 'ollama', 'openai', 'server', 'catalog', 'organizer', 'default model', 'agent'] },
        { id: 'gemini', label: 'Gemini API Key', keywords: ['gemini', 'api key', 'google', 'key', 'developer key', 'api_key', 'token', 'gemini-2.5', 'gemini-1.5', 'gemini-3.5', 'flash', 'pro', 'secret'] },
        { id: 'display', label: 'Display & Fonts', keywords: ['display', 'fonts', 'typography', 'theme', 'background animation', 'editor font size', 'serif', 'sans', 'mono', 'space grotesk', 'inter', 'size', 'style', 'dark mode', 'light mode'] },
        { id: 'llm', label: 'LLM Parameter Engine', keywords: ['temperature', 'top_p', 'top-p', 'tokens', 'system prompt', 'llm', 'parameter', 'engine', 'max tokens', 'response limit'] },
        { id: 'image', label: 'Image Generation', keywords: ['image', 'generation', 'diffusion', 'aspect ratio', 'imagen', 'stability', 'width', 'height', 'picture', 'art', 'draw'] },
        { id: 'skills', label: 'Custom Agent Skills', keywords: ['skills', 'tools', 'plugins', 'custom skill', 'prompt injection', 'expert skill', 'actions', 'code execution', 'python'] },
        { id: 'memory', label: 'Fact Memory', keywords: ['fact', 'memory', 'memories', 'long-term', 'indexeddb', 'continuity', 'facts', 'saved', 'persistence'] },
        { id: 'gdrive', label: 'Google Drive Sync', keywords: ['gdrive', 'google drive', 'sync', 'cloud', 'backup', 'oauth', 'google account', 'synchronization', 'drive'] },
        { id: 'local_save', label: 'Local Backup & Sync', keywords: ['local', 'backup', 'export', 'import', 'sync', 'indexeddb', 'reset', 'clear storage', 'purge', 'database', 'delete'] }
      ].find(tab => 
        tab.label.toLowerCase().includes(query) || 
        tab.keywords.some(k => k.includes(query))
      );
      if (firstMatch && firstMatch.id !== activeSettingsTab) {
        setActiveSettingsTab(firstMatch.id as any);
      }
    }
  }, [settingsSearchQuery]);

  const [isSkillsManagerOpen, setIsSkillsManagerOpen] = useState(false);
  const [isMemoryManagerOpen, setIsMemoryManagerOpen] = useState(false);
  const [dbExportStatus, setDbExportStatus] = useState<'idle' | 'exporting' | 'success' | 'error'>('idle');
  const [backupStatus, setBackupStatus] = useState<string | null>(null);
  const [backupError, setBackupError] = useState<string | null>(null);
  
  const fetchActiveMemoriesPrompt = async () => {
    try {
      const allMemories = await getAllMemories();
      const active = allMemories.filter(m => m.isActive);
      if (active.length === 0) return '';
      
      const listStr = active.map(m => `- [${m.category?.toUpperCase() || 'GENERAL'}] ${m.content}`).join('\n');
      return `\n\n### LONG-TERM MEMORIES & USER PREF-FACTS (Persistent facts extracted from past conversations):\n${listStr}\n\nMaintain absolute continuity with these details. Do not act surprised, ask for information mentioned here, or contradict these rules. Adapt your responses to fit these preferences seamlessly.\n\nIMPORTANT INTEGRITY RULE: These are persistent user preferences and factual details stored in long-term memories. They are completely separate from temporary conversation file uploads. Do not confuse long-term memories with file attachments uploaded by the user to the chat window.`;
    } catch (e) {
      console.error("Failed to load active memories for LLM prompt context:", e);
      return '';
    }
  };

  const [isAllChatsOpen, setIsAllChatsOpen] = useState(false);
  const [activeCodePreview, setActiveCodePreview] = useState<{ code: string, language: string } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [thinkingProcess, setThinkingProcess] = useState<{ agent: string, text: string }[]>([]);
  const [isTestingOpen, setIsTestingOpen] = useState(false);
  const [isPythonPlaygroundOpen, setIsPythonPlaygroundOpen] = useState(false);
  const [isWebSandboxOpen, setIsWebSandboxOpen] = useState(false);
  const [activeWebSandboxProjectId, setActiveWebSandboxProjectId] = useState<string | null>(null);
  const [activePythonPlaygroundProjectId, setActivePythonPlaygroundProjectId] = useState<string | null>(null);
  const [modelSearchQuery, setModelSearchQuery] = useState('');
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<number | null>(null);
  const [isEnhancingPrompt, setIsEnhancingPrompt] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [messageModelMenuId, setMessageModelMenuId] = useState<string | null>(null);
  const [activeModelMenu, setActiveModelMenu] = useState<string | null>(null);
  const [isAddingNewModels, setIsAddingNewModels] = useState(false);
  const [activePreviewFile, setActivePreviewFile] = useState<AppFile | null>(null);
  const [attachedFiles, setAttachedFiles] = useState<AppFile[]>([]);
  
  const [queuedPrompts, setQueuedPrompts] = useState<{ id: string; text: string; attachedFiles: AppFile[] }[]>([]);
  const [editingQueueId, setEditingQueueId] = useState<string | null>(null);
  const [editingQueueText, setEditingQueueText] = useState<string>('');
  const [backoffCountdown, setBackoffCountdown] = useState<number | null>(null);
  const [isQueuePaused, setIsQueuePaused] = useState(false);
  const [lastFailedQueueItem, setLastFailedQueueItem] = useState<{ id: string; text: string; attachedFiles: AppFile[] } | null>(null);
  const [currentRunningQueueItem, setCurrentRunningQueueItem] = useState<{ id: string; text: string; attachedFiles: AppFile[] } | null>(null);

  const handleQueuePrompt = () => {
    if (!input.trim()) return;
    const newQueueItem = {
      id: Math.random().toString(36).substring(2, 9),
      text: input.trim(),
      attachedFiles: [...attachedFiles]
    };
    setQueuedPrompts(prev => [...prev, newQueueItem]);
    setInput('');
    setAttachedFiles([]);
  };

  // Monitor sandbox project changes and backup to Google Drive
  useEffect(() => {
    const token = getDriveToken();
    const allowProjects = settings.gdriveBackupSelector?.projects !== false;
    if (isDriveConnected && token && !isPythonPlaygroundOpen && !isWebSandboxOpen && allowProjects) {
       const timer = setTimeout(async () => {
         try {
           const localPythonStr = localStorage.getItem("gemini_python_projects") || "{}";
           const localWebStr = localStorage.getItem("gemini_workspace_projects") || "{}";
           let localPython = {};
           let localWeb = {};
           try { localPython = JSON.parse(localPythonStr); } catch (_) {}
           try { localWeb = JSON.parse(localWebStr); } catch (_) {}
           
           await saveFileToGoogleDrive('my_ai_projects.json', { python: localPython, web: localWeb }, token);
         } catch (e) {
           console.error("Failed to automatically back up projects:", e);
         }
       }, 3000);
       return () => clearTimeout(timer);
    }
  }, [isPythonPlaygroundOpen, isWebSandboxOpen, isDriveConnected, settings.gdriveBackupSelector?.projects]);
  
  const [memoriesLength, setMemoriesLength] = useState<number>(0);
  useEffect(() => {
    const loadMemoriesLen = async () => {
      try {
        const list = await getAllMemories();
        const active = list.filter(m => m.isActive);
        const listStr = active.map(m => `- [${m.category?.toUpperCase() || 'GENERAL'}] ${m.content}`).join('\n');
        setMemoriesLength(listStr.length);
      } catch (e) {
        console.error("Error loading memories for context counter:", e);
      }
    };
    loadMemoriesLen();
  }, [isMemoryManagerOpen, isSettingsOpen, currentChatId, memorySyncTrigger]);

  const [downloadingModelId, setDownloadingModelId] = useState<string | null>(null);
  const [webLlmProgress, setWebLlmProgress] = useState('');
  const [workspaceCode, setWorkspaceCode] = useState<string>('');

  // --- Slash Command States and Helpers ---
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [cursorPos, setCursorPos] = useState<number>(0);
  const [slashSelectedIndex, setSlashSelectedIndex] = useState<number>(0);

  const { isActive: isSlashActive, query: slashQuery, startIndex: slashStartIndex } = useMemo(() => {
    return getSlashCommandInfo(input, cursorPos);
  }, [input, cursorPos]);

  const allAvailableSkills = useMemo(() => {
    const saved = settings.skills || [];
    const unsavedPresets = SKILL_PRESETS.filter(p => !saved.some(s => s.name.toLowerCase() === p.name.toLowerCase()))
      .map(p => ({
        id: `preset-${p.name.replace(/\s+/g, '-').toLowerCase()}`,
        name: p.name,
        description: p.description,
        systemPrompt: p.systemPrompt,
        enabled: false,
        isPreset: true,
        type: p.type
      }));
    return [...saved, ...unsavedPresets];
  }, [settings.skills]);

  const filteredSlashSkills = useMemo(() => {
    if (!isSlashActive) return [];
    const q = slashQuery.toLowerCase().trim();
    if (!q) return allAvailableSkills;
    return allAvailableSkills.filter(s => 
      s.name.toLowerCase().includes(q) || 
      s.description.toLowerCase().includes(q)
    );
  }, [allAvailableSkills, isSlashActive, slashQuery]);

  // Reset selected index when query/filtered skills list changes
  useEffect(() => {
    setSlashSelectedIndex(0);
  }, [slashQuery, filteredSlashSkills.length]);

  // Auto scroll active item into view inside popover drawer
  useEffect(() => {
    if (isSlashActive && filteredSlashSkills.length > 0) {
      const activeEl = document.getElementById(`slash-skill-item-${slashSelectedIndex}`);
      if (activeEl) {
        activeEl.scrollIntoView({ block: 'nearest' });
      }
    }
  }, [slashSelectedIndex, isSlashActive, filteredSlashSkills.length]);

  const handleSelectSlashSkill = (skill: any) => {
    let updatedSkills = [...(settings.skills || [])];
    const targetType = skill.type || 'prompt';
    
    if (skill.isPreset) {
      if (targetType === 'persona') {
        // Enforce mutual exclusivity: disable all other active personas
        updatedSkills = updatedSkills.map(s => 
          s.type === 'persona' ? { ...s, enabled: false } : s
        );
      }
      const newSkill = {
        id: crypto.randomUUID(),
        name: skill.name,
        description: skill.description,
        systemPrompt: skill.systemPrompt,
        enabled: true,
        type: targetType
      };
      updatedSkills.push(newSkill);
    } else {
      const willBeEnabled = !skill.enabled;
      if (willBeEnabled && targetType === 'persona') {
        // Enforce mutual exclusivity of personas
        updatedSkills = updatedSkills.map(s => 
          s.id === skill.id 
            ? { ...s, enabled: true } 
            : s.type === 'persona' 
            ? { ...s, enabled: false } 
            : s
        );
      } else {
        updatedSkills = updatedSkills.map(s => 
          s.id === skill.id ? { ...s, enabled: willBeEnabled } : s
        );
      }
    }
    
    const updated = { ...settings, skills: updatedSkills };
    setSettings(updated);
    saveSettings(updated);
    
    // Clean up slash query from input
    const beforeSlash = input.substring(0, slashStartIndex);
    const afterSlash = input.substring(cursorPos);
    const newInput = beforeSlash + afterSlash;
    setInput(newInput);
    
    // Refocus with updated selection range
    setTimeout(() => {
      setCursorPos(beforeSlash.length);
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(beforeSlash.length, beforeSlash.length);
      }
    }, 50);
  };

  const applyWorkspacePatch = useCallback((currentCode: string, patch: string) => {
    // Support both formats:
    // <<<< SEARCH
    // or
    // <<<<
    const regex = /<<<<(?:\s*SEARCH)?\n([\s\S]*?)\n====\n([\s\S]*?)\n>>>>(?:\s*REPLACE)?/g;
    let newCode = currentCode;
    let match;
    let found = false;

    while ((match = regex.exec(patch)) !== null) {
      const search = match[1];
      const replacement = match[2];
      if (newCode.includes(search)) {
        newCode = newCode.replace(search, replacement);
        found = true;
      }
    }

    // Fallback: if no diff tags found but there is content, it's a full replacement
    if (!found && patch.trim().length > 0 && !patch.includes('<<<<')) {
      return patch.trim();
    }

    return newCode;
  }, []);
  
  const [engineLoadedModelId, setEngineLoadedModelId] = useState<string | null>(() => (window as any)._webLlmModelId || null);
  const [ollamaConnectionStatus, setOllamaConnectionStatus] = useState<'idle' | 'checking' | 'connected' | 'error'>('idle');

  const handleLoadWebLLM = async (modelId: string, modelEquippedId: string) => {
    setDownloadingModelId(modelId);
    setWebLlmProgress("Starting download...");
    try {
      const webllm = await import('@mlc-ai/web-llm');
      let engine = (window as any)._webLlmEngine;
      if (!engine || (window as any)._webLlmModelId !== modelId) {
        engine = await webllm.CreateWebWorkerMLCEngine(
          new Worker(new URL('./worker.ts', import.meta.url), { type: 'module' }),
          modelId,
          {
            initProgressCallback: (progress) => {
              setWebLlmProgress(progress.text);
            }
          }
        );
        (window as any)._webLlmEngine = engine;
        (window as any)._webLlmModelId = modelId;
      }
      
      setEngineLoadedModelId(modelId);
      
      // Save loaded state to local storage
      const loadedModels = JSON.parse(localStorage.getItem('loadedWebLlmModels') || '{}');
      loadedModels[modelId] = true;
      localStorage.setItem('loadedWebLlmModels', JSON.stringify(loadedModels));
      
      if (!settings.puterModel?.startsWith('webllm:')) {
        setSettings({ ...settings, puterModel: modelEquippedId });
        saveSettings({ ...settings, puterModel: modelEquippedId });
      }
    } catch (err: any) {
      setWebLlmProgress(`Error: ${err.message || err}`);
    } finally {
      setDownloadingModelId(null);
    }
  };

  useEffect(() => {
    if (activeModelMenu === null) {
      setIsAddingNewModels(false);
    }
  }, [activeModelMenu]);
  const [scratchpad, setScratchpad] = useState<string>('');
  const [isGenerationPaused, setIsGenerationPausedState] = useState(false);
  const isGenerationPausedRef = useRef(false);
  const setIsGenerationPaused = (val: boolean) => {
    isGenerationPausedRef.current = val;
    setIsGenerationPausedState(val);
  };

  const waitForResume = async () => {
    while (isGenerationPausedRef.current) {
      if (abortControllerRef.current?.signal.aborted) break;
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  };

  const activeChatModel = useMemo(() => {
    const { modelId } = getModelInfo(settings.puterModel || '');
    return CHAT_MODELS.find(m => m.id === modelId) || CHAT_MODELS[0];
  }, [settings.puterModel]);

  const activeImageModel = IMAGE_MODELS.find(m => m.id === settings.imageModelId);

  const getActiveModelMaxContext = (customModelId?: string) => {
    const targetModel = customModelId || settings.puterModel || '';
    if (targetModel === 'auto') {
      const enabled = settings.enabledChatModels || [];
      if (enabled.length > 0) {
        const contexts = enabled.map(e => {
          const { catalogModel } = getModelInfo(e);
          if (catalogModel && 'maxContext' in catalogModel) return (catalogModel as any).maxContext;
          return 128000;
        });
        return Math.max(...contexts);
      }
      return 1000000;
    }
    const { catalogModel } = getModelInfo(targetModel);
    if (catalogModel && 'maxContext' in catalogModel) return (catalogModel as any).maxContext;

    // Default fallback for known models if metadata is missing
    const modelId = (getModelInfo(targetModel).modelId || 'gemini-3.5-flash').toLowerCase();
    if (modelId.includes('claude')) return 200000;
    if (modelId.includes('gpt-4o') || modelId.includes('gpt-4')) return 128000;
    if (modelId.includes('gemini-3')) return 1000000;
    if (modelId.includes('gemini-2') || modelId.includes('gemini-1.5')) return 2000000;
    if (modelId.includes('gemini')) return 1000000;
    
    return 128000;
  };

  const getActiveModelMaxOutput = (customModelId?: string) => {
    const targetModel = customModelId || settings.puterModel || '';
    if (targetModel === 'auto') {
      const enabled = settings.enabledChatModels || [];
      if (enabled.length > 0) {
        const outputs = enabled.map(e => {
          const { catalogModel } = getModelInfo(e);
          if (catalogModel && 'maxTokens' in catalogModel) return (catalogModel as any).maxTokens;
          return 16384;
        });
        return Math.max(...outputs);
      }
      return 65536;
    }
    const { catalogModel } = getModelInfo(targetModel);
    if (catalogModel && 'maxTokens' in catalogModel) return (catalogModel as any).maxTokens;

    // Default fallback for known models if metadata is missing
    const modelId = (getModelInfo(targetModel).modelId || 'gemini-3.5-flash').toLowerCase();
    if (modelId.includes('gemini')) return 65536;
    if (modelId.includes('claude-3-7')) return 128000;
    if (modelId.includes('claude-3-5')) return 8192;
    if (modelId.includes('gpt-4o')) return 16384;
    
    return 16384; 
  };

  useEffect(() => {
    const maxOutput = getActiveModelMaxOutput();
    const modelInfo = getModelInfo(settings.puterModel || '');
    let updated = false;
    let newSettings = { ...settings };
    
    if (settings.maxTokens !== maxOutput) {
      newSettings.maxTokens = maxOutput;
      updated = true;
    }
    
    // Gracefully handle model default system prompt.
    const modelSystemPrompt = (modelInfo.catalogModel as any)?.systemPrompt;
    if (modelSystemPrompt && (!settings.systemPrompt || settings.systemPrompt === 'You are a helpful AI assistant.')) {
      newSettings.systemPrompt = modelSystemPrompt;
      updated = true;
    }
    
    if (updated) {
      setSettings(newSettings);
      saveSettings(newSettings);
    }
  }, [settings.puterModel, ollamaCacheTick]);

  const activeMaxContext = getActiveModelMaxContext();
  const activeMaxOutput = getActiveModelMaxOutput();

  // Return all messages since context/truncation is managed on the api or local ai side
  const getTruncatedMessages = (messages: any[]) => {
    // Separate system prompt from conversational turns
    const systemMsg = messages.find(m => m.role === 'system');
    
    // Normal chat turns
    const normalMsgs = messages.filter(m => m.role !== 'system');
    
    // Coalesce/normalize successive identical roles (e.g., if messages are deleted)
    const normalizedMsgs: any[] = [];
    for (const msg of normalMsgs) {
      if (normalizedMsgs.length > 0 && normalizedMsgs[normalizedMsgs.length - 1].role === msg.role) {
        const last = normalizedMsgs[normalizedMsgs.length - 1];
        last.content = last.content + "\n\n" + msg.content;
        if (msg.attachedImages && msg.attachedImages.length > 0) {
          last.attachedImages = [...(last.attachedImages || []), ...msg.attachedImages];
        }
        if (msg.attachedFiles && msg.attachedFiles.length > 0) {
          last.attachedFiles = [...(last.attachedFiles || []), ...msg.attachedFiles];
        }
      } else {
        // Shallow copy to prevent mutating system/chat state items
        normalizedMsgs.push({ ...msg });
      }
    }
    
    return systemMsg ? [systemMsg, ...normalizedMsgs] : normalizedMsgs;
  };

  const calculateAccurateContextTokens = (messages: any[]): number => {
    if (!messages || messages.length === 0) return 0;
    
    // Format the messages via LLM service to represent the actual full text content (with file content, metadata, query matching limits)
    const formattedMessages = messages.map(m => formatMessageWithAttachments(m));
    
    // Stitch characters together to find the comprehensive character context
    let fullText = '';
    formattedMessages.forEach(msg => {
      const roleCapitalized = msg.role ? (msg.role.charAt(0).toUpperCase() + msg.role.slice(1)) : 'User';
      fullText += `${roleCapitalized}: ${msg.content || ''}\n`;
    });
    
    // Estimate tokens utilizing our core heuristics (automatically scale for code delimiters and multimodal files)
    return estimateGeneralTokens(fullText, formattedMessages);
  };

  useEffect(() => {
    // Automatically set to max when model changes or is loaded
    if (activeMaxOutput > 0) {
      setSettings(prev => ({ 
        ...prev, 
        maxTokens: activeMaxOutput 
      }));
    }
  }, [activeMaxOutput]);

  // Initialize selectedTestModels when testing modal opens
  useEffect(() => {
    if (isTestingOpen) {
      setSelectedTestModels(settings.enabledChatModels || []);
      setTestResults([]);
    }
  }, [isTestingOpen]);

  const applyPreset = (presetName: keyof typeof AGENT_PRESETS) => {
    setAgents(AGENT_PRESETS[presetName]);
    setMode('multi');
    setThinkingProcess(prev => [...prev, { agent: 'System', text: `Applied ${presetName} multi-agent preset.` }]);
  };



  const speak = (text: string, msgId?: number) => {
    try {
      if ('speechSynthesis' in window) {
        // Clear anything currently speaking
        window.speechSynthesis.cancel();

        // Create the utterance
        const utterance = new SpeechSynthesisUtterance(text);

        // Fetch voices (Chrome loads them asynchronously)
        let voices = window.speechSynthesis.getVoices();
        
        const attachVoice = () => {
          if (voices && voices.length > 0) {
            // Find English speaker accent
            const preferredVoice = voices.find(v => v.lang.startsWith('en-US')) 
              || voices.find(v => v.lang.startsWith('en')) 
              || voices[0];
            if (preferredVoice) {
              utterance.voice = preferredVoice;
            }
          }
        };

        attachVoice();

        // If voices aren't loaded yet, register standard onvoiceschanged
        if (!voices || voices.length === 0) {
          window.speechSynthesis.onvoiceschanged = () => {
            voices = window.speechSynthesis.getVoices();
            attachVoice();
          };
        }

        utterance.onstart = () => {
          setIsSpeaking(true);
          if (msgId !== undefined) {
            setSpeakingMessageId(msgId);
          }
          setIsPaused(false);
        };

        utterance.onend = () => {
          setIsSpeaking(false);
          setSpeakingMessageId(null);
          setIsPaused(false);
        };

        utterance.onerror = (event) => {
          console.error("SpeechSynthesis error event:", event);
          setIsSpeaking(false);
          setSpeakingMessageId(null);
          setIsPaused(false);
          
          if (event.error === 'not-allowed') {
            setSpeechErrorNotice(
              "Read Aloud is blocked by sandboxed iframe browser security rules. Please open this workspace in a new tab using the 'Open in New Tab' icon at the top right of your preview to start text-to-speech audio!"
            );
          } else if (event.error === 'interrupted') {
            // Ignored, user clicked stop or started another read
          } else {
            setSpeechErrorNotice(`Text-to-speech notification: Speech playback failed due to iframe constraints. Accessing this app outside the iframe restores full audio!`);
          }
        };

        window.speechSynthesis.speak(utterance);
      } else {
        setSpeechErrorNotice("Your web browser does not support the Web Speech API (Speech Synthesis).");
      }
    } catch (err: any) {
      console.error("Error referencing SpeechSynthesis:", err);
      setIsSpeaking(false);
      setSpeakingMessageId(null);
      setIsPaused(false);
      setSpeechErrorNotice(
        "Your browser blocks Speech Synthesis inside sandboxed iframes. Please click the 'Open in New Tab' icon at the top-right of your preview frame to enjoy the Read Aloud narrator!"
      );
    }
  };

  const stopSpeaking = () => {
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } catch (e) {
      console.error(e);
    }
    setIsSpeaking(false);
    setSpeakingMessageId(null);
    setIsPaused(false);
  };

  const togglePauseSpeaking = () => {
    try {
      if ('speechSynthesis' in window) {
        if (isPaused) {
          window.speechSynthesis.resume();
          setIsPaused(false);
        } else {
          window.speechSynthesis.pause();
          setIsPaused(true);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
  }, [theme]);

  const [currentPath, setCurrentPath] = useState(() => {
    return window.location.pathname;
  });

  const [isLaunched, setIsLaunched] = useState(() => {
    return window.location.pathname === '/chat' || window.location.pathname === '/github';
  });

  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      setCurrentPath(path);
      setIsLaunched(path === '/chat' || path === '/github');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const [isBooting, setIsBooting] = useState(true);
  const [editingAgent, setEditingAgent] = useState<AgentConfig | null>(null);
  const [isAgentEditOpen, setIsAgentEditOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [showMultiAgentBanner, setShowMultiAgentBanner] = useState(true);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    const handleScroll = () => {
      const isBottom = el.scrollHeight - el.scrollTop <= el.clientHeight + 100;
      setShowScrollBottom(!isBottom);
    };

    el.addEventListener('scroll', handleScroll);
    return () => el.removeEventListener('scroll', handleScroll);
  }, []);

  // Smoothly auto-scroll to bottom as streaming content accumulates (only active when user is already scrolled to bottom and tab is visible)
  useEffect(() => {
    if (document.hidden) return;
    const el = scrollRef.current;
    if (!el) return;
    const isAtBottom = el.scrollHeight - el.scrollTop <= el.clientHeight + 150;
    if (isAtBottom) {
      el.scrollTo({ top: el.scrollHeight, behavior: 'auto' });
    }
  }, [chats, currentChatId]);

  // Handle syncing chats smoothly from IndexedDB when user returns to the tab or focuses it
  useEffect(() => {
    if (isGenerating) return;

    const syncChatsFromDB = async () => {
      try {
        const dbChats = await getAllChats();
        setChats(prevChats => {
          // If identical, keep reference to avoid triggering unneeded renders / resetting inputs
          const sorted = [...dbChats].sort((a, b) => b.createdAt - a.createdAt);
          if (JSON.stringify(prevChats) === JSON.stringify(sorted)) {
            return prevChats;
          }
          return sorted;
        });
      } catch (e) {
        console.error('Failed to sync chats on visibility change:', e);
      }
    };
    
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        syncChatsFromDB();
      }
    };

    const handleFocus = () => {
      syncChatsFromDB();
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
    };
  }, [isGenerating]);

  // Check and poll Ollama connection status when Ollama provider is active
  useEffect(() => {
    const isUsingOrPendingOllama = isTryingToUseOllama || (isModelOrganizerOpen && settings.provider === 'ollama');

    if (!isUsingOrPendingOllama) {
      setOllamaConnectionStatus('idle');
      return;
    }

    let isMounted = true;
    const checkOllama = async () => {
      setOllamaConnectionStatus('checking');
      const ollamaUrl = settings.ollamaUrl || 'http://127.0.0.1:11434';
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      
      try {
        const res = await fetch(`${ollamaUrl}/api/tags`, {
          method: 'GET',
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (isMounted) {
          if (res.ok) {
            setOllamaConnectionStatus('connected');
            
            // Asynchronously fetch details for all models to populate OLLAMA_MODELS_CACHE
            try {
              const data = await res.json();
              const models = data.models || [];
              Promise.all(
                models.map(async (m: any) => {
                  try {
                    const detailController = new AbortController();
                    const detailTimeout = setTimeout(() => detailController.abort(), 1500);
                    
                    const showRes = await fetch(`${ollamaUrl}/api/show`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ name: m.name }),
                      signal: detailController.signal
                    });
                    clearTimeout(detailTimeout);
                    
                    if (showRes.ok) {
                      const showData = await showRes.json();
                      if (showData) {
                        let contextLength = 2048;
                        if (showData.model_info) {
                          for (const key of Object.keys(showData.model_info)) {
                            if (key.includes('context_length')) {
                              const val = parseInt(showData.model_info[key]);
                              if (!isNaN(val) && val > 0) {
                                contextLength = val;
                                break;
                              }
                            }
                          }
                        }
                        
                        let hasVision = false;
                        if (showData.details) {
                          const families = showData.details.families || [];
                          const vFamilies = ['clip', 'mllama', 'vision', 'vlm'];
                          if (families.some((f: string) => vFamilies.includes(f.toLowerCase()))) {
                            hasVision = true;
                          }
                          if (showData.details.family && vFamilies.includes(String(showData.details.family).toLowerCase())) {
                            hasVision = true;
                          }
                        }
                        if (!hasVision) {
                          const lowerName = m.name.toLowerCase();
                          const visionKeywords = ['vision', 'vlm', 'llava', 'bakllava', 'moondream', 'minicpm', 'mllama'];
                          hasVision = visionKeywords.some(kw => lowerName.includes(kw));
                        }
                        
                        OLLAMA_MODELS_CACHE[m.name] = {
                          id: m.name,
                          name: `Ollama: ${m.name}`,
                          provider: 'ollama',
                          maxContext: contextLength,
                          maxTokens: 4096,
                          hasVision: hasVision,
                          inputPrice: 'Free (Local)',
                          outputPrice: 'Free (Local)',
                          systemPrompt: showData.system || ""
                        };
                      }
                    }
                  } catch (showErr) {
                    // Ignore transient network errors
                  }
                })
              ).then(() => {
                try {
                  localStorage.setItem('ollama_models_cache', JSON.stringify(OLLAMA_MODELS_CACHE));
                  setOllamaCacheTick(prev => prev + 1);
                } catch (e) {
                  // Ignore localStorage issues
                }
              });
            } catch (err2) {
              // Ignore json parsing issues
            }
          } else {
            setOllamaConnectionStatus('error');
          }
        }
      } catch (err) {
        clearTimeout(timeoutId);
        if (isMounted) {
          setOllamaConnectionStatus('error');
        }
      }
    };

    checkOllama();
    const interval = setInterval(checkOllama, 10000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [settings.provider, settings.ollamaUrl, isTryingToUseOllama, isModelOrganizerOpen]);

  const scrollToBottom = () => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  };

  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (isLaunched) {
      setIsBooting(true);
      const timer = setTimeout(() => setIsBooting(false), 2500);
      return () => clearTimeout(timer);
    }
  }, [isLaunched]);

  // Pre-warming embedding pipeline removed

  const handleEditAgent = (agent: AgentConfig) => {
    setEditingAgent(agent);
    setIsAgentEditOpen(true);
  };

  const handleSaveAgent = async () => {
    if (editingAgent) {
      await saveAgent(editingAgent);
      setAgents(prev => prev.map(a => a.id === editingAgent.id ? editingAgent : a));
      setIsAgentEditOpen(false);
      setEditingAgent(null);
    }
  };

  const [infinitySettings, setInfinitySettings] = useState({
    enabled: false,
    maxAttempts: 3,
    strictness: 7, // 1-10
  });

  const [testPrompt, setTestPrompt] = useState('');
  const [testResults, setTestResults] = useState<{ model: string, result: string, pending?: boolean, latencyMs?: number, tps?: number }[]>([]);
  const [selectedTestModels, setSelectedTestModels] = useState<string[]>([]);
  const [isAutoRouting, setIsAutoRouting] = useState(false);
  const [autoRouteEnabled, setAutoRouteEnabled] = useState(false);

  const [isDragging, setIsDragging] = useState(false);
  const [isDraggingOverInput, setIsDraggingOverInput] = useState(false);

  useEffect(() => {
    const handleWindowDragOver = (e: DragEvent) => {
      // If it's a move or internal drag, don't show the global upload overlay
      if (e.dataTransfer?.types.includes('Files')) {
        e.preventDefault();
        if (!isDragging) setIsDragging(true);
      }
    };

    const handleWindowDragEnter = (e: DragEvent) => {
      if (e.dataTransfer?.types.includes('Files')) {
        e.preventDefault();
        setIsDragging(true);
      }
    };

    const handleWindowDragLeave = (e: DragEvent) => {
      // Only set to false if we're actually leaving the window
      // Check if we're moving towards a child or leaving entirely
      if (!e.relatedTarget || (e.relatedTarget as HTMLElement).nodeName === 'HTML') {
        setIsDragging(false);
      }
    };

    const handleWindowDrop = async (e: DragEvent) => {
      if (e.dataTransfer?.types.includes('Files')) {
        e.preventDefault();
        setIsDragging(false);
        const files = Array.from(e.dataTransfer.files);
        for (const file of files) {
          await processAndSaveFile(file);
        }
      }
    };

    window.addEventListener('dragover', handleWindowDragOver);
    window.addEventListener('dragenter', handleWindowDragEnter);
    window.addEventListener('dragleave', handleWindowDragLeave);
    window.addEventListener('drop', handleWindowDrop);
    
    return () => {
      window.removeEventListener('dragover', handleWindowDragOver);
      window.removeEventListener('dragenter', handleWindowDragEnter);
      window.removeEventListener('dragleave', handleWindowDragLeave);
      window.removeEventListener('drop', handleWindowDrop);
    };
  }, []);

  const handleDeleteFile = async (id: string) => {
    if (window.confirm("Are you sure you want to delete this file? This will remove it from all context.")) {
      const { deleteFile } = await import('./db');
      await deleteFile(id);
      setFiles(prev => prev.filter(f => f.id !== id));
      setAttachedFiles(prev => prev.filter(f => f.id !== id));
      if (activePreviewFile?.id === id) setActivePreviewFile(null);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    if (e.dataTransfer.types.includes('Files')) {
      e.preventDefault();
      setIsDragging(true);
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    if (droppedFiles.length > 0) {
      for (const file of droppedFiles) {
        await processAndSaveFile(file);
      }
    }
  };

  // Helper to deduplicate file processing logic
  const processAndSaveFile = async (file: File) => {
    const isDuplicate = files.some(f => f.name === file.name);
    if (isDuplicate) {
      const proceed = window.confirm(`A file named "${file.name}" is already uploaded. Are you sure you want to upload it again?`);
      if (!proceed) return;
    }

    const reader = new FileReader();
    return new Promise<void>((resolve) => {
      reader.onload = async (event) => {
        const content = event.target?.result as string;
        
        // Normalize file type for common images if needed
        let fileType = file.type;
        const extension = file.name.split('.').pop()?.toLowerCase() || '';
        
        if (!fileType && extension) {
          fileType = MIME_MAP[extension] || '';
        }

        const isImage = isImageFile(fileType, extension);
        const isPDF = isPdfFile(fileType, extension);
        
        let extractedText: string | undefined = undefined;
        if (isPDF) {
          extractedText = await extractTextFromPdfBase64(content);
        }
        
        const newFile: AppFile = {
          id: Math.random().toString(36).substring(2, 15),
          name: file.name,
          type: fileType || (isImage ? 'image/jpeg' : isPDF ? 'application/pdf' : 'text/plain'),
          content: content,
          createdAt: Date.now(),
          extractedText
        };
        
        await saveFile(newFile);
        setFiles(prev => [newFile, ...prev]);
        setAttachedFiles(prev => [newFile, ...prev]);
        
        resolve();
      };

      const extension = file.name.split('.').pop()?.toLowerCase() || '';
      const isImage = isImageFile(file.type, extension);
      const isPDF = isPdfFile(file.type, extension);
      const isVideo = file.type.startsWith('video/') || ['mp4', 'mov', 'webm', 'ogg', 'avi'].includes(extension);

      // Use a more comprehensive check for binary files
      const isKnownBinary = isKnownBinaryFile(extension);

      if (isImage || isPDF || isKnownBinary || isVideo) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    });
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processAndSaveFile(file);
    e.target.value = '';
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = Array.from(e.clipboardData.items);
    const mediaItems = items.filter(item => item.type.startsWith('image/') || item.type.startsWith('video/'));
    
    if (mediaItems.length > 0) {
      e.preventDefault();
      for (const item of mediaItems) {
        const file = item.getAsFile();
        if (file) {
          await processAndSaveFile(file);
        }
      }
      return;
    }

    const textData = e.clipboardData.getData('text/plain')?.trim();
    if (textData) {
      const isBase64Img = textData.startsWith('data:image/');
      const isBase64Vid = textData.startsWith('data:video/');
      const isUrl = /^https?:\/\/\S+$/i.test(textData);
      
      let isImgUrl = false;
      let isVidUrl = false;
      
      if (isUrl) {
        const cleanUrl = textData.split('?')[0];
        const ext = cleanUrl.split('.').pop()?.toLowerCase() || '';
        isImgUrl = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext);
        isVidUrl = ['mp4', 'mov', 'webm', 'ogg', 'avi'].includes(ext);
      }
      
      if (isBase64Img || isBase64Vid || isImgUrl || isVidUrl) {
        e.preventDefault();
        const fileId = Math.random().toString(36).substring(2, 15);
        const name = isUrl 
          ? textData.substring(textData.lastIndexOf('/') + 1).split('?')[0] || 'pasted_media' 
          : `pasted_${isBase64Img || isImgUrl ? 'image' : 'video'}_${fileId.substring(0, 5)}`;
        
        let type = 'image/jpeg';
        if (isBase64Img) {
          type = textData.substring(5, textData.indexOf(';'));
        } else if (isBase64Vid) {
          type = textData.substring(5, textData.indexOf(';'));
        } else if (isImgUrl) {
          type = `image/${textData.split('?')[0].split('.').pop()?.toLowerCase()}`;
        } else if (isVidUrl) {
          type = `video/${textData.split('?')[0].split('.').pop()?.toLowerCase()}`;
        }

        const newFile: AppFile = {
          id: fileId,
          name: name,
          type: type,
          content: textData,
          createdAt: Date.now()
        };
        
        await saveFile(newFile);
        setFiles(prev => [newFile, ...prev]);
        setAttachedFiles(prev => [newFile, ...prev]);
      }
    }
  };

  const executeTool = useCallback(async (toolName: string, args: any, addThinkingStep?: (agent: string, text: string) => void) => {
    const log = (agent: string, text: string) => {
      if (addThinkingStep) addThinkingStep(agent, text);
      else setThinkingProcess(prev => [...prev, { agent, text }]);
    };

    if (toolName === 'calculator') {
      try {
        // Simple math evaluation
        const result = eval(args.expression.replace(/[^-()\d/*+.]/g, ''));
        return `Result: ${result}`;
      } catch (e) {
        return `Error in calculation: ${e}`;
      }
    }
    if (toolName === 'python') {
      const patch = args.code;
      const fullCode = applyWorkspacePatch(workspaceCode, patch);
      setWorkspaceCode(fullCode);
      
      return await executePythonCode(fullCode, log);
    }
    return "Tool not found.";
  }, [workspaceCode, applyWorkspacePatch]);
  const handleRegenerate = async (msg: Message, modelOverride?: string) => {
    if (!currentChatId) return;
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;

    // Find the last user message before this assistant message
    const msgIndex = chat.messages.findIndex(m => m.timestamp === msg.timestamp);
    if (msgIndex === -1) return;

    let lastUserPrompt = '';
    for (let i = msgIndex - 1; i >= 0; i--) {
      if (chat.messages[i].role === 'user') {
        lastUserPrompt = chat.messages[i].content;
        break;
      }
    }

    if (!lastUserPrompt) return;

    // Remove all messages after the last user message
    const userMsgIndex = chat.messages.findIndex(m => m.role === 'user' && m.content === lastUserPrompt);
    const updatedMessages = chat.messages.slice(0, userMsgIndex + 1);
    
    const updatedChat = { ...chat, messages: updatedMessages };
    setChats(prev => prev.map(c => c.id === chat.id ? updatedChat : c));
    
    // Trigger send
    setIsGenerating(true);
    setThinkingProcess([]);
    const controller = new AbortController();
    abortControllerRef.current = controller;
    
    try {
      if (mode === 'auto') {
        const routeConfig = await resolveAutoModeExecutionInternal(updatedChat as Chat, lastUserPrompt);
        setThinkingProcess([
          { 
            agent: 'Auto Orchestrator', 
            text: `${routeConfig.reason}\n\nRouting targets:\n- Mode: ${routeConfig.mode === 'single' ? 'Single Agent' : `Multi-Agent (${routeConfig.architecture})`}\n- Model quality: ${routeConfig.modelLevel === 'pro' ? 'Pro-tier reasoning' : 'Flash-tier speed'}` 
          }
        ]);
        if (routeConfig.mode === 'single') {
          await runSingleAgent(updatedChat as Chat, lastUserPrompt, modelOverride || routeConfig.modelOverride);
        } else {
          await runMultiAgent(updatedChat as Chat, lastUserPrompt, modelOverride || routeConfig.modelOverride, routeConfig.architecture);
        }
      } else if (mode === 'single') {
        await runSingleAgent(updatedChat as Chat, lastUserPrompt, modelOverride);
      } else {
        await runMultiAgent(updatedChat as Chat, lastUserPrompt, modelOverride);
      }
    } catch (err: any) {
      const isAbort = err.message === 'Aborted' || err.name === 'AbortError';
      if (isAbort) {
        console.log("Regeneration aborted by user");
      } else {
        console.error("Regeneration error:", err);
      }

      setChats(prev => {
        const chatToUpdate = prev.find(c => c.id === currentChatId);
        if (!chatToUpdate) return prev;

        const messages = [...chatToUpdate.messages];
        const lastMsg = messages[messages.length - 1];

        if (lastMsg && lastMsg.role === 'assistant') {
          const statusText = isAbort ? "\n\n*(Response stopped)*" : `\n\n**Error:** ${err instanceof Error ? err.message : String(err)}`;
          messages[messages.length - 1] = { 
            ...lastMsg, 
            content: lastMsg.content ? lastMsg.content + statusText : (isAbort ? "Response stopped." : `Error: ${err instanceof Error ? err.message : String(err)}`)
          };
        }
        
        const finalChat = { ...chatToUpdate, messages };
        saveChat(finalChat as Chat);
        return prev.map(c => c.id === currentChatId ? finalChat : c);
      });
    } finally {
      if (abortControllerRef.current === controller) {
        setIsGenerating(false);
        abortControllerRef.current = null;
      }
    }
  };

  const handleUpdateMessage = async (timestamp: number, newContent: string) => {
    if (!currentChatId || !newContent.trim()) return;
    const chat = chats.find(c => c.id === currentChatId);
    if (!chat) return;

    // Find the message index
    const msgIndex = chat.messages.findIndex(m => m.timestamp === timestamp);
    if (msgIndex === -1) return;

    const msg = chat.messages[msgIndex];
    if (msg.role !== 'user') return;

    // Update the message content
    const updatedMsg = { ...msg, content: newContent };
    
    // Remove all messages after this user prompt (any subsequent assistant messages)
    const updatedMessages = [...chat.messages.slice(0, msgIndex), updatedMsg];
    const updatedChat = { ...chat, messages: updatedMessages };

    // Update state and persistent DB
    setChats(prev => prev.map(c => c.id === chat.id ? updatedChat : c));
    await saveChat(updatedChat);

    setEditingMessageId(null);
    setEditingContent('');

    // Trigger regeneration of response
    setIsGenerating(true);
    setThinkingProcess([]);
    setScratchpad('');
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      if (mode === 'auto') {
        const routeConfig = await resolveAutoModeExecutionInternal(updatedChat as Chat, newContent);
        setThinkingProcess([
          { 
            agent: 'Auto Orchestrator', 
            text: `${routeConfig.reason}\n\nRouting targets:\n- Mode: ${routeConfig.mode === 'single' ? 'Single Agent' : `Multi-Agent (${routeConfig.architecture})`}\n- Model quality: ${routeConfig.modelLevel === 'pro' ? 'Pro-tier reasoning' : 'Flash-tier speed'}` 
          }
        ]);
        if (routeConfig.mode === 'single') {
          await runSingleAgent(updatedChat as Chat, newContent, routeConfig.modelOverride);
        } else {
          await runMultiAgent(updatedChat as Chat, newContent, routeConfig.modelOverride, routeConfig.architecture);
        }
      } else if (mode === 'single') {
        await runSingleAgent(updatedChat as Chat, newContent);
      } else {
        if (autoRouteEnabled) {
          await handleAutoRoute(newContent);
        }
        await runMultiAgent(updatedChat as Chat, newContent);
      }
    } catch (err: any) {
      const isAbort = err.message === 'Aborted' || err.name === 'AbortError' || err === 'Aborted' || String(err).includes('Abort');
      
      setChats(prev => {
        const chatToUpdate = prev.find(c => c.id === currentChatId);
        if (!chatToUpdate) return prev;

        const messages = [...chatToUpdate.messages];
        const lastMsg = messages[messages.length - 1];

        if (lastMsg && lastMsg.role === 'assistant') {
          const statusText = isAbort ? "\n\n*(Response stopped)*" : `\n\n**Error:** ${err instanceof Error ? err.message : String(err)}`;
          messages[messages.length - 1] = { 
            ...lastMsg, 
            content: lastMsg.content ? lastMsg.content + statusText : (isAbort ? "Response stopped." : `Error: ${err instanceof Error ? err.message : String(err)}`)
          };
        }
        
        const finalChat = { ...chatToUpdate, messages };
        saveChat(finalChat as Chat);
        return prev.map(c => c.id === currentChatId ? finalChat : c);
      });
    } finally {
      if (abortControllerRef.current === controller) {
        setIsGenerating(false);
        abortControllerRef.current = null;
      }
    }
  };

  const handleAddAgent = () => {
    const newAgent: AgentConfig = {
      id: Math.random().toString(36).substring(2, 9),
      name: 'Specialist',
      systemPrompt: 'You are a specialized agent. Focus on providing accurate and helpful information in your area of expertise.',
      count: 1,
      enabled: true
    };
    setAgents(prev => [...prev, newAgent]);
    handleEditAgent(newAgent);
  };

  const handleAutoRoute = async (promptInput?: string) => {
    const targetInput = promptInput || input;
    if (!targetInput.trim()) return;
    setIsAutoRouting(true);
    setThinkingProcess(prev => [...prev, { agent: 'Auto Router', text: 'Analyzing request to determine optimal agent configuration...' }]);
    
    try {
      // Use the model to decide which agents to enable
      const agentList = agents.map(a => `${a.id}: ${a.name} (${a.systemPrompt})`).join('\n');
      const prompt = `Given the user request: "${targetInput}"\n\nAnd the following available agents:\n${agentList}\n\nDecide which agents should be enabled for this task. Return a JSON array of agent IDs that should be enabled. Example: ["orch", "coder", "auditor"]`;
      
      const response = await getCompletion([
        { role: 'system', content: 'You are an AI router. Only return a JSON array of strings.' },
        { role: 'user', content: prompt }
      ], { temperature: 0 }) as any;

      const content = response?.choices[0].message.content || '[]';
      const enabledIds = JSON.parse(content.match(/\[.*\]/)?.[0] || '[]');
      
      if (enabledIds.length > 0) {
        setAgents(prev => prev.map(a => ({
          ...a,
          enabled: enabledIds.includes(a.id)
        })));
        setThinkingProcess(prev => [...prev, { agent: 'Auto Router', text: `Enabled agents: ${enabledIds.join(', ')}` }]);
      }
    } catch (error) {
      console.error("Auto routing error:", error);
    } finally {
      setIsAutoRouting(false);
    }
  };

  const handleSearch = async (query: string) => {
    setThinkingProcess(prev => [...prev, { agent: 'Search Tool', text: `Searching for: ${query}...` }]);
    try {
      // Mock search for now, as real search requires a CORS proxy or API
      const response = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json`);
      const data = await response.json();
      return data.AbstractText || "No direct results found, but search was performed.";
    } catch (error) {
      console.error("Search error:", error);
      return "Search failed due to network or CORS issues.";
    }
  };
  const runModelTest = async () => {
    if (!testPrompt.trim()) return;
    
    const modelsToRun = selectedTestModels.length > 0 
      ? selectedTestModels 
      : (settings.enabledChatModels?.length ? settings.enabledChatModels : [settings.puterModel || '']);

    setTestResults(modelsToRun.map(m => ({ model: m, result: 'Testing...', pending: true })));
    
    // Group models by effective physical provider (Gemini, OpenAI, Anthropic, Ollama, etc.)
    const groups: { [provider: string]: string[] } = {};
    for (const modelId of modelsToRun) {
      const info = getModelInfo(modelId);
      let provider = (info.catalogModel?.provider || info.provider || 'unknown').toLowerCase();
      
      // Fallback heuristic: search model name/ID for common physical provider keywords
      // to resolve any overlapping 'puter' proxy wrappers or dynamic custom configurations
      const lowerId = modelId.toLowerCase();
      if (provider === 'unknown' || provider === 'puter') {
        if (lowerId.includes('gemini') || lowerId.includes('google') || lowerId.includes('gemma')) {
          provider = 'google';
        } else if (lowerId.includes('gpt') || lowerId.includes('openai') || lowerId.includes('o1') || lowerId.includes('o3')) {
          provider = 'openai';
        } else if (lowerId.includes('claude') || lowerId.includes('anthropic')) {
          provider = 'anthropic';
        } else if (lowerId.includes('grok') || lowerId.includes('xai')) {
          provider = 'xai';
        } else if (lowerId.includes('deepseek')) {
          provider = 'deepseek';
        } else if (lowerId.includes('qwen')) {
          provider = 'qwen';
        } else if (lowerId.includes('ollama')) {
          provider = 'ollama';
        } else if (lowerId.includes('webllm')) {
          provider = 'webllm';
        } else if (lowerId.includes('poolside') || lowerId.includes('laguna')) {
          provider = 'poolside';
        } else if (lowerId.includes('nvidia') || lowerId.includes('nemotron')) {
          provider = 'nvidia';
        }
      }
      
      if (!groups[provider]) {
        groups[provider] = [];
      }
      groups[provider].push(modelId);
    }

    // Run providers concurrently, but run sequentially within each provider group
    await Promise.allSettled(
      Object.keys(groups).map(async (provider) => {
        const modelsInGroup = groups[provider];
        for (const modelId of modelsInGroup) {
          try {
            const startTime = performance.now();
            let fullContent = '';
            let firstTokenTime: number | null = null;
            let lastTokenTime: number | null = null;
            let totalTokens = 0;

            const responseStream = await getCompletion([
              { role: 'user', content: testPrompt }
            ], { temperature: 0.7, modelOverride: modelId, stream: true }) as any;

            if (responseStream && typeof responseStream[Symbol.asyncIterator] === 'function') {
              for await (const chunk of responseStream) {
                const content = chunk?.choices?.[0]?.delta?.content || '';
                if (content) {
                  if (firstTokenTime === null) {
                    firstTokenTime = performance.now();
                  }
                  lastTokenTime = performance.now();
                  fullContent += content;
                  totalTokens = Math.ceil(fullContent.length / 4);

                  setTestResults(prev => prev.map(r => r.model === modelId ? { ...r, result: fullContent } : r));
                }
              }
            } else {
              fullContent = responseStream?.choices?.[0]?.message?.content || 'Error';
            }

            const endTime = performance.now();
            const latencyMs = endTime - startTime;

            let tps = 0;
            if (firstTokenTime !== null && lastTokenTime !== null && lastTokenTime > firstTokenTime) {
              const activeTimeSec = (lastTokenTime - firstTokenTime) / 1000;
              const outTokens = totalTokens || Math.ceil(fullContent.length / 4);
              if (outTokens > 0) {
                tps = outTokens / activeTimeSec;
              }
            } else {
              const outTokens = Math.ceil(fullContent.length / 4);
              const latencySec = latencyMs / 1000;
              if (latencySec > 0 && outTokens > 0) {
                tps = outTokens / latencySec;
              }
            }

            setTestResults(prev => prev.map(r => r.model === modelId ? { ...r, result: fullContent, pending: false, latencyMs, tps } : r));
          } catch (e: any) {
            setTestResults(prev => prev.map(r => r.model === modelId ? { ...r, result: `Error: ${e.message || e}`, pending: false } : r));
          }
        }
      })
    );
  };

  const [isLoaded, setIsLoaded] = useState(false);
  const loadData = useCallback(async () => {
    try {
      const dbChats = await getAllChats();
      setChats(dbChats.sort((a, b) => b.createdAt - a.createdAt));
      
      const dbFiles = await getAllFiles();
      setFiles(dbFiles);
      
      const dbSettings = await getSettings();
      const dbEquippedModels = await getEquippedModels();
      const hasNoData = dbChats.length === 0 && dbFiles.length === 0;

      let mergedSettings = { ...DEFAULT_SETTINGS };
      if (dbSettings) {
        const enabledModels = dbEquippedModels.length > 0 ? dbEquippedModels : (dbSettings.enabledChatModels || DEFAULT_SETTINGS.enabledChatModels);
        
        mergedSettings = {
          ...DEFAULT_SETTINGS,
          ...dbSettings,
          enabledChatModels: enabledModels,
          toolsEnabled: {
            ...DEFAULT_SETTINGS.toolsEnabled,
            ...(dbSettings.toolsEnabled || {})
          },
          gdriveBackupSelector: {
            ...DEFAULT_SETTINGS.gdriveBackupSelector,
            ...(dbSettings.gdriveBackupSelector || {})
          },
          puterModel: (enabledModels.length > 0) ? (dbSettings.puterModel || enabledModels[0]) : ''
        };
      }

      // Load gemini_api_key from localStorage if available
      if (typeof window !== 'undefined' && window.localStorage) {
        const localPrefixKey = window.localStorage.getItem('gemini_api_key');
        if (localPrefixKey) {
          mergedSettings.geminiApiKey = localPrefixKey;
        }
      }

      setSettings(mergedSettings);
      
      // Show tutorial only if no data AND has not seen tutorial
      if (mergedSettings.hasSeenTutorial === false && hasNoData) {
        setShowTutorial(true);
      }

      const dbAgents = await getAllAgents();
      if (dbAgents.length > 0) {
        const hasChecker = dbAgents.some(a => a.id === 'checker');
        if (!hasChecker) {
          const defaultChecker: AgentConfig = {
            id: 'checker',
            name: 'Prompt Checker',
            systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.',
            count: 1,
            enabled: true,
            isFixed: true
          };
          dbAgents.push(defaultChecker);
          await saveAgent(defaultChecker);
        }
        setAgents(dbAgents);
      }
      
      setIsLoaded(true);
    } catch (error) {
      console.error("Failed to load data:", error);
      setIsLoaded(true); // Still mark as loaded to allow user interaction
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    if (currentChatId) {
      const chat = chats.find(c => c.id === currentChatId);
      if (chat) {
        // Update local state if needed
      }
    }
  }, [currentChatId, chats]);

  // --- Handlers ---
  const handleNewChat = () => {
    handleStopGeneration();
    const newChat: Chat = {
      id: Math.random().toString(36).substring(2, 15),
      title: 'New Chat',
      messages: [],
      createdAt: Date.now()
    };
    setChats([newChat, ...chats]);
    setCurrentChatId(newChat.id);
    saveChat(newChat);
  };

  const handleSelectChat = (id: string) => {
    handleStopGeneration();
    setCurrentChatId(id);
  };

  const handleDeleteChat = async (id: string) => {
    await deleteChat(id);
    setChats(chats.filter(c => c.id !== id));
    if (currentChatId === id) setCurrentChatId(null);
  };

  const handleClearAll = async (skipConfirm = false) => {
    try {
      if (!skipConfirm && typeof window !== 'undefined' && window.confirm && !window.confirm("Are you sure you want to clear all data? This cannot be undone.")) {
        return;
      }
      
      await clearAllData();
      setChats([]);
      setFiles([]);
      setCurrentChatId(null);
      setSettings(DEFAULT_SETTINGS);
      
      // Force reload to ensure everything is fresh
      window.location.reload();
    } catch (error) {
      console.error("Failed to clear data:", error);
      // Fallback if reload/clear fails
    }
  };

  const handleExportDatabaseSnapshot = async () => {
    setDbExportStatus('exporting');
    try {
      const snapshot = await exportDatabaseSnapshot();
      const jsonString = JSON.stringify(snapshot, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const dateStr = new Date().toISOString().slice(0, 10);
      link.href = url;
      link.download = `my_ai_db_snapshot_${dateStr}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setDbExportStatus('success');
      setTimeout(() => setDbExportStatus('idle'), 3000);
    } catch (error) {
      console.error("Export database snapshot failed:", error);
      setDbExportStatus('error');
      setTimeout(() => setDbExportStatus('idle'), 4000);
    }
  };

  useEffect(() => {
    if (!isLoaded) return;
    
    saveSettings(settings);
    if (settings.enabledChatModels) {
      saveEquippedModels(settings.enabledChatModels);
    }
  }, [settings, isLoaded]);


  useEffect(() => {
    document.documentElement.classList.remove('dark', 'light', 'neon');
    document.documentElement.classList.add(theme);
  }, [theme]);

  const handleExportChat = (id: string) => {
    const chat = chats.find(c => c.id === id);
    if (!chat) return;
    
    const content = chat.messages.map(m => `### ${m.role.toUpperCase()}\n${m.content}\n\n---\n\n`).join('');
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `accelerated-logic-chat-${chat.title || id}.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleExportAllChats = () => {
    if (chats.length === 0) return;
    const backupData = {
      version: 1,
      exportedAt: Date.now(),
      chats: chats,
    };
    const content = JSON.stringify(backupData, null, 2);
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `accelerated-logic-all-chats-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportAllChats = async (importedChats: Chat[]) => {
    if (!Array.isArray(importedChats)) return;
    
    let merged = [...chats];
    let updated = false;
    for (const rawChat of importedChats) {
      if (!rawChat || !rawChat.id) continue;
      const existingIdx = merged.findIndex(c => c.id === rawChat.id);
      const cleanedChat: Chat = {
        id: rawChat.id,
        title: rawChat.title || 'Imported Chat',
        createdAt: rawChat.createdAt || Date.now(),
        messages: rawChat.messages || [],
        pinnedFileIds: rawChat.pinnedFileIds || [],
      };
      
      if (existingIdx !== -1) {
        merged[existingIdx] = cleanedChat;
        updated = true;
      } else {
        merged.push(cleanedChat);
        updated = true;
      }
      await saveChat(cleanedChat);
    }
    
    if (updated) {
      const sorted = merged.sort((a, b) => b.createdAt - a.createdAt);
      setChats(sorted);
      if (sorted.length > 0 && !currentChatId) {
        setCurrentChatId(sorted[0].id);
      }
      const token = getDriveToken();
      if (isDriveConnected && token && !isSyncingDrive) {
        saveChatsToGoogleDrive(sorted, token);
      }
    }
  };

  const handleImportFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        let imported: Chat[] = [];
        if (Array.isArray(parsed)) {
          imported = parsed;
        } else if (parsed && Array.isArray(parsed.chats)) {
          imported = parsed.chats;
        } else {
          setBackupError("Invalid backup format.");
          setTimeout(() => setBackupError(null), 4000);
          return;
        }
        
        if (imported.length === 0) {
          setBackupError("No chats found in backup.");
          setTimeout(() => setBackupError(null), 4000);
          return;
        }
        
        handleImportAllChats(imported);
        setBackupStatus(`Imported ${imported.length} chats!`);
        setTimeout(() => setBackupStatus(null), 4000);
      } catch (err) {
        setBackupError("Invalid JSON backup file.");
        setTimeout(() => setBackupError(null), 4000);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleStopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsGenerating(false);
      setThinkingProcess(prev => [...prev, { agent: 'System', text: 'Generation stopped by user.' }]);
    } else {
      setIsGenerating(false);
    }
  };

  const handleImageMeasure = (chatId: string, timestamp: number, width: number, height: number) => {
    setChats(prev => prev.map(c => {
      if (c.id === chatId) {
        const messages = c.messages.map(m => {
          if (m.timestamp === timestamp && (m.imageWidth !== width || m.imageHeight !== height)) {
            return { ...m, imageWidth: width, imageHeight: height };
          }
          return m;
        });
        const updated = { ...c, messages };
        saveChat(updated);
        return updated;
      }
      return c;
    }));
  };

  const downloadImage = useCallback(async (url: string, filename?: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename || `accelerated-logic-image-${Date.now()}.png`;
      link.click();
      URL.revokeObjectURL(blobUrl);
    } catch (error) {
      window.open(url, '_blank');
    }
  }, []);

  const generateChatTitle = async (chatId: string, messages: Message[]) => {
    try {
      // Only use the first few messages to get the core topic
      const history = messages.slice(0, 4).map(m => `${m.role.toUpperCase()}: ${m.content.slice(0, 500)}`).join('\n\n');
      const completion = await getCompletion([
        { role: 'system', content: 'Generate a short, punchy chat title (max 5 words) that describes the conversation. Respond with ONLY the title. Do not use quotes.' },
        { role: 'user', content: `Conversation history:\n${history}\n\nTitle:` }
      ], { temperature: 0.7, max_tokens: 20, stream: false }) as any;

      const title = completion.choices?.[0]?.message?.content?.replace(/^"|"$/g, '').trim();
      if (title && title.length > 2) {
        setChats(prev => prev.map(c => {
          if (c.id === chatId) {
            const updated = { ...c, title };
            saveChat(updated);
            return updated;
          }
          return c;
        }));
      }
    } catch (e) {
      console.error("Chat title generation failed:", e);
    }
  };

  const handleSaveToFile = async (name: string, content: string, type: string) => {
    const isHtml = type === 'text/html' || name.toLowerCase().endsWith('.html') || name.toLowerCase().endsWith('.htm');
    const isPython = type === 'text/x-python' || name.toLowerCase().endsWith('.py');
    
    // Always save to SQLite/Dexie workspace files for general listing access
    const newFile: AppFile = {
      id: Math.random().toString(36).substring(2, 15),
      name,
      type,
      content,
      createdAt: Date.now()
    };
    await saveFile(newFile);
    setFiles(prev => [newFile, ...prev]);

    if (isHtml) {
      // Save as Sandbox App project to localStorage (Vibe Coding Tool)
      let cleanName = name.replace(/\.html?$/i, '');
      cleanName = cleanName.split(/[-_]/).map(word => {
        if (!word) return '';
        return word.charAt(0).toUpperCase() + word.slice(1);
      }).filter(Boolean).join(' ');
      
      if (!cleanName.trim()) {
        cleanName = 'Imported App';
      }
      
      const projId = 'proj_' + Date.now();
      const newProj = {
        id: projId,
        name: cleanName,
        description: `Saved from chat on ${new Date().toLocaleDateString()}`,
        lastModified: Date.now(),
        fs: {
          'index.html': content,
          'style.css': '/* Custom styles */',
          'app.js': '// Custom scripts'
        }
      };

      try {
        const projectsStr = localStorage.getItem("gemini_workspace_projects");
        let projects = {};
        if (projectsStr) {
          try {
            projects = JSON.parse(projectsStr);
          } catch (e) {
            projects = {};
          }
        }
        const updatedProjects = { ...projects, [projId]: newProj };
        localStorage.setItem("gemini_workspace_projects", JSON.stringify(updatedProjects));
      } catch (err) {
        console.error("Failed to save HTML file as Sandbox App:", err);
      }

      // Open the vibe coding sandbox tool so the user sees it immediately
      setActiveWebSandboxProjectId(projId);
      setIsWebSandboxOpen(true);
    } else if (isPython) {
      // Save as Python Sandbox project to localStorage
      let cleanName = name.replace(/\.py$/i, '');
      cleanName = cleanName.split(/[-_]/).map(word => {
        if (!word) return '';
        return word.charAt(0).toUpperCase() + word.slice(1);
      }).filter(Boolean).join(' ');
      
      if (!cleanName.trim()) {
        cleanName = 'Imported Python Script';
      }
      
      const projId = 'proj_' + Date.now();
      const newProj = {
        id: projId,
        name: cleanName,
        description: `Saved from chat on ${new Date().toLocaleDateString()}`,
        lastModified: Date.now(),
        fs: {
          'main.py': content,
          'helper.py': '# Supplementary Python library\n\ndef check_prime(n):\n    if n < 2: return False\n    for i in range(2, int(n**0.5) + 1):\n        if n % i == 0:\n            return False\n    return True'
        }
      };

      try {
        const projectsStr = localStorage.getItem("gemini_python_projects");
        let projects = {};
        if (projectsStr) {
          try {
            projects = JSON.parse(projectsStr);
          } catch (e) {
            projects = {};
          }
        }
        const updatedProjects = { ...projects, [projId]: newProj };
        localStorage.setItem("gemini_python_projects", JSON.stringify(updatedProjects));
      } catch (err) {
        console.error("Failed to save Python script as Sandbox Script:", err);
      }

      // Open the python playground sandbox so the user sees it immediately
      setActivePythonPlaygroundProjectId(projId);
      setIsPythonPlaygroundOpen(true);
    }
  };

  const handleBranchChat = async (msgTimestamp: number) => {
    if (!currentChat) return;
    const cutoffIndex = currentChat.messages.findIndex(m => m.timestamp === msgTimestamp);
    if (cutoffIndex === -1) return;
    
    const branchMessages = currentChat.messages.slice(0, cutoffIndex + 1);
    const newChatId = Math.random().toString(36).substring(2, 15);
    
    const branchedChat: Chat = {
      id: newChatId,
      title: `${currentChat.title || 'Chat'} (Branch)`,
      messages: branchMessages.map(m => ({ ...m })),
      createdAt: Date.now()
    };
    
    await saveChat(branchedChat);
    setChats(prev => [branchedChat, ...prev]);
    setCurrentChatId(newChatId);
  };

  const handleTogglePinFile = async (fileId: string) => {
    if (!currentChatId) return;
    const currentChat = chats.find(c => c.id === currentChatId);
    if (!currentChat) return;

    const pinnedFileIds = currentChat.pinnedFileIds || [];
    const isPinned = pinnedFileIds.includes(fileId);
    const updatedPinnedIds = isPinned 
      ? pinnedFileIds.filter(id => id !== fileId) 
      : [...pinnedFileIds, fileId];

    const updatedChat: Chat = {
      ...currentChat,
      pinnedFileIds: updatedPinnedIds
    };

    await saveChat(updatedChat);
    setChats(prev => prev.map(c => c.id === currentChatId ? updatedChat : c));
  };

  const handleEnhancePrompt = async () => {
    if (!input.trim() || isEnhancingPrompt) return;
    setIsEnhancingPrompt(true);
    try {
      const promptText = `Your task is to act as an expert Prompt Engineer. Take the draft prompt written by the user and optimize it. Make it professional, clear, and feature-rich. Expand on the details, add explicit structuring and context, and specify precise instruction blocks. Save 100% of the original objective and details.
CRITICAL: Output ONLY the improved/enhanced prompt as final plain text, with no introductory, greeting, or conversational remarks, and no markdown formatting wrappers (like three backticks).

DRAFT PROMPT TO ENHANCE:
"${input}"`;

      const res = await getCompletion([{ role: 'user', content: promptText }], {
        temperature: 0.5,
        modelOverride: settings.puterModel || 'puter:gemini-3.5-flash',
        stream: false
      }) as any;

      let refined = '';
      if (res && res.choices && res.choices[0] && res.choices[0].message) {
        refined = res.choices[0].message.content || '';
      } else if (res && typeof res === 'string') {
        refined = res;
      } else if (res && res.content) {
        refined = res.content;
      }

      if (refined) {
        refined = refined.trim();
        if (refined.startsWith('```')) {
          refined = refined.replace(/^```[a-zA-Z]*\n/, '').replace(/\n```$/, '');
        }
        setInput(refined.trim());
      }
    } catch (err) {
      console.error("Enhancing prompt failed:", err);
    } finally {
      setIsEnhancingPrompt(false);
    }
  };

  const handleSendMessage = async (overrideInput?: string, overrideAttachedFiles?: AppFile[]) => {
    const finalInput = overrideInput || input;
    if (!finalInput.trim() || isGenerating) return;

    let targetChatId = currentChatId;
    let currentChats = chats;

    if (!targetChatId) {
      const newChat: Chat = {
        id: Math.random().toString(36).substring(2, 15),
        title: finalInput.slice(0, 30) + (finalInput.length > 30 ? '...' : ''),
        messages: [],
        createdAt: Date.now()
      };
      await saveChat(newChat);
      currentChats = [newChat, ...chats];
      setChats(currentChats);
      setCurrentChatId(newChat.id);
      targetChatId = newChat.id;
    }

    const finalAttachedFiles = overrideAttachedFiles || attachedFiles;

    const userMsg: Message = {
      role: 'user',
      content: finalInput,
      attachedImages: finalAttachedFiles.filter(f => f.type.startsWith('image/')).map(f => f.content),
      attachedFiles: finalAttachedFiles, // Store all attached files of any type
      timestamp: Date.now()
    };
    if (!overrideAttachedFiles) {
      setAttachedFiles([]);
    }

    const updatedChats = currentChats.map(c => {
      if (c.id === targetChatId) {
        return { ...c, messages: [...c.messages, userMsg] };
      }
      return c;
    });
    setChats(updatedChats);
    const currentChat = updatedChats.find(c => c.id === targetChatId)!;
    await saveChat(currentChat);
    
    const processedInput = finalInput;
    
    if (!overrideInput) setInput('');
    setIsGenerating(true);
    setThinkingProcess([]);
    setScratchpad('');
    const controller = new AbortController();
    abortControllerRef.current = controller;

    const isNewChat = !currentChatId;

    try {
      if (mode === 'auto') {
        const routeConfig = await resolveAutoModeExecutionInternal(currentChat, processedInput);
        setThinkingProcess([
          { 
            agent: 'Auto Orchestrator', 
            text: `${routeConfig.reason}\n\nRouting targets:\n- Mode: ${routeConfig.mode === 'single' ? 'Single Agent' : `Multi-Agent (${routeConfig.architecture})`}\n- Model quality: ${routeConfig.modelLevel === 'pro' ? 'Pro-tier reasoning' : 'Flash-tier speed'}` 
          }
        ]);
        if (routeConfig.mode === 'single') {
          await runSingleAgent(currentChat, processedInput, routeConfig.modelOverride);
        } else {
          await runMultiAgent(currentChat, processedInput, routeConfig.modelOverride, routeConfig.architecture);
        }
      } else if (mode === 'single') {
        await runSingleAgent(currentChat, processedInput);
      } else {
        if (autoRouteEnabled) {
          await handleAutoRoute(processedInput);
        }
        await runMultiAgent(currentChat, processedInput);
      }

      // Automatically rename if it's the first exchange
      if (isNewChat) {
        // Need to get the updated messages to generate a good title
        setChats(prev => {
          const finalChat = prev.find(c => c.id === targetChatId);
          if (finalChat) {
            generateChatTitle(targetChatId!, finalChat.messages);
          }
          return prev;
        });
      }
      setCurrentRunningQueueItem(null);
    } catch (err: any) {
      if (currentRunningQueueItem) {
        setLastFailedQueueItem(currentRunningQueueItem);
        setIsQueuePaused(true);
        setCurrentRunningQueueItem(null);
      }
      const isAbort = err.message === 'Aborted' || err.name === 'AbortError' || err === 'Aborted' || String(err).includes('Abort');
      
      if (isAbort) {
        console.log("Generation aborted by user");
      } else {
        console.error("Generation error:", err);
      }
      
      let errorDisplay = "Unknown error";
      if (isAbort) {
        errorDisplay = "Response stopped by user.";
      } else if (err instanceof Error) {
        errorDisplay = err.message;
      } else if (typeof err === 'object' && err !== null) {
        errorDisplay = err.message || err.error || (err.toString && err.toString() !== '[object Object]' ? err.toString() : JSON.stringify(err));
      } else {
        errorDisplay = String(err);
      }

      // Check for Ollama-specific connection errors to provide clear trouble resolution inline
      if (settings.provider === 'ollama' && (
        errorDisplay.toLowerCase().includes('connect') || 
        errorDisplay.toLowerCase().includes('fetch') || 
        errorDisplay.toLowerCase().includes('network') || 
        errorDisplay.toLowerCase().includes('unreachable') || 
        errorDisplay.toLowerCase().includes('failed to contact') ||
        errorDisplay.toLowerCase().includes('cors')
      )) {
        errorDisplay += `\n\n💡 **Ollama Troubleshooter & Fix Guide:**\n\nIt looks like the web app cannot establish a connection to your local Ollama instance at \`${settings.ollamaUrl || 'http://127.0.0.1:11434'}\`:\n\n1. **Is Ollama background application started?** If not, please launch Ollama on your computer.\n2. **Is CORS permitted?** Traditional browsers restrict random cross-origin (CORS) requests. You MUST launch Ollama through your local terminal to authorize access:\n   - **macOS / Linux terminal:** \`OLLAMA_ORIGINS="*" ollama serve\`\n   - **Windows PowerShell:** \`$env:OLLAMA_ORIGINS="*" ; ollama serve\`\n   - **Windows Command Prompt (cmd):** \`set OLLAMA_ORIGINS=* && ollama serve\`\n3. **Already active background instance?** If you receive a *"bind: address already in use"* terminal warning, look for the Ollama icon in your desktop system tray space, right-click and click **Quit Ollama**, and run the terminal command again. This allows direct browser access to your local models.`;
      }

      // Instead of adding a NEW message, we should try to update the last assistant message if it exists
      // because runSingleAgent/runMultiAgent already added one.
      setChats(prev => {
        const chatToUpdate = prev.find(c => c.id === targetChatId);
        if (!chatToUpdate) return prev;

        const messages = [...chatToUpdate.messages];
        const lastMsg = messages[messages.length - 1];

        if (lastMsg && lastMsg.role === 'assistant') {
          // If the message already has content, append the error/stopped status
          const statusText = isAbort ? "\n\n*(Response stopped)*" : `\n\n**Error:** ${errorDisplay}`;
          messages[messages.length - 1] = { 
            ...lastMsg, 
            content: lastMsg.content ? lastMsg.content + statusText : (isAbort ? "Response stopped." : `Error: ${errorDisplay}`)
          };
        } else {
          // Fallback: Add a new message if for some reason the last one wasn't assistant
          messages.push({
            role: 'assistant',
            content: isAbort ? "Response stopped." : `Error: ${errorDisplay}`,
            timestamp: Date.now()
          });
        }

        const finalChat = { ...chatToUpdate, messages };
        saveChat(finalChat as Chat);
        return prev.map(c => c.id === targetChatId ? finalChat : c);
      });
    } finally {
      if (abortControllerRef.current === controller) {
        setIsGenerating(false);
        abortControllerRef.current = null;
      }
    }
  };

  const getCompletion = async (messages: any[], config: { temperature?: number, max_tokens?: number, stream?: boolean, signal?: AbortSignal, modelOverride?: string }) => {
    const signal = config.signal || abortControllerRef.current?.signal;

    const abortPromise = new Promise((_, reject) => {
      if (signal?.aborted) reject(new Error("Aborted"));
      signal?.addEventListener('abort', () => reject(new Error("Aborted")));
    });

    let finalModelOverride = config.modelOverride;
    if (finalModelOverride === 'auto') {
      finalModelOverride = (settings.enabledChatModels && settings.enabledChatModels[0]) || 'puter:gemini-3.5-flash';
    } else if (!finalModelOverride && settings.puterModel === 'auto') {
      finalModelOverride = (settings.enabledChatModels && settings.enabledChatModels[0]) || 'puter:gemini-3.5-flash';
    }

    const executeRequest = () => llmGetCompletion({
      messages,
      config: { ...config, modelOverride: finalModelOverride, signal },
      settings,
      activeChatModel,
      setThinkingProcess
    });

    // For non-streaming, we can use Promise.race
    if (!config.stream) {
      return Promise.race([executeRequest(), abortPromise]);
    }

    // For streaming, we just return the generator
    return executeRequest();
  };

  const handleModelTriggeredImageGen = async (chatId: string, fullContent: string, currentChat: Chat, addThinkingStep: (agent: string, text: string) => void) => {
    const imageMatch = fullContent.match(/<image_gen\s+([^>]*?)\/?>/i);
    if (imageMatch) {
      const attrs = imageMatch[1];
      const pMatch = attrs.match(/prompt="([^"]*?)"/i);
      const arMatch = attrs.match(/aspect_ratio="([^"]*?)"/i);
      const rMatch = attrs.match(/resolution="([^"]*?)"/i);
      
      const imagePrompt = (pMatch ? pMatch[1] : '').trim();
      if (!imagePrompt) return;
      
      const modelPickedAspectRatio = arMatch ? arMatch[1].trim() : settings.aspectRatio || '1:1';
      const modelPickedResolution = rMatch ? rMatch[1].trim() : settings.resolution || '1024x1024';
      
      // Pre-calculate dimensions for skeleton
      let width = 1024;
      let height = 1024;
      const resValue = modelPickedResolution === '512x512' ? 512 : 1024;
      if (modelPickedAspectRatio === '16:9') {
        width = resValue;
        height = Math.round(resValue * 9 / 16);
      } else if (modelPickedAspectRatio === '9:16') {
        width = Math.round(resValue * 9 / 16);
        height = resValue;
      } else {
        width = resValue;
        height = resValue;
      }

      // Mark as loading in first place
      setChats(prev => prev.map(c => {
        if (c.id === chatId) {
          const messages = [...c.messages];
          for (let i = messages.length - 1; i >= 0; i--) {
            if (messages[i].role === 'assistant') {
              messages[i] = { ...messages[i], isImageLoading: true, imageWidth: width, imageHeight: height };
              break;
            }
          }
          return { ...c, messages };
        }
        return c;
      }));

      try {
        addThinkingStep('Image Gen', `Model requested image: "${imagePrompt}". Generating with ${activeImageModel?.name}...`);
        
        let finalPrompt = imagePrompt;
        if (settings.autoEnhance) {
          addThinkingStep('Enhancer', 'Enhancing prompt...');
          const enhancementResponse = await getCompletion([
            { role: 'user', content: `Expand the following image prompt into a highly detailed, descriptive, and artistic prompt for an AI image generator. Focus on lighting, composition, style, and specific details to make it visually stunning. Keep the core subject the same. Respond ONLY with the enhanced prompt text.\n\nOriginal Prompt: "${imagePrompt}"` }
          ], { temperature: 0.7, max_tokens: 200, stream: false }) as any;
          finalPrompt = enhancementResponse.choices?.[0]?.message?.content || imagePrompt;
          addThinkingStep('Enhancer', 'Prompt enhanced.');
        }

        let imageUrl = '';
        const puter = (window as any).puter;

        const isGoogleImageModel = 
          activeImageModel?.provider === 'google' || 
          activeImageModel?.id?.includes('gemini') || 
          settings.imageModelId?.includes('gemini') || 
          (!activeImageModel && settings.imageModelId === 'gemini-2.5-flash-image');

        if (isGoogleImageModel) {
          const geminiApiKey = settings.geminiApiKey;
          if (!geminiApiKey) {
            throw new Error("Gemini API key is not configured. Please add your Gemini API key in Settings.");
          }
          const rawTarget = activeImageModel?.id || settings.imageModelId || 'gemini-2.5-flash-image';
          const targetModel = rawTarget.includes('gemini') ? 'imagen-3.0-generate-002' : rawTarget;
          addThinkingStep('Image Gen', `Calling Gemini API (${targetModel})...`);
          
          const googleGenAi = new GoogleGenAI({ apiKey: geminiApiKey });
          const response = await googleGenAi.models.generateContent({
            model: targetModel,
            contents: {
              parts: [
                {
                  text: finalPrompt,
                },
              ],
            },
            config: {
              imageConfig: {
                aspectRatio: modelPickedAspectRatio,
              }
            },
          });

          if (response?.candidates?.[0]?.content?.parts) {
            for (const part of response.candidates[0].content.parts) {
              if (part.inlineData) {
                const base64EncodeString: string = part.inlineData.data;
                imageUrl = `data:image/png;base64,${base64EncodeString}`;
                break;
              }
            }
          }

          if (!imageUrl) {
            const hasText = response?.candidates?.[0]?.content?.parts?.find((p: any) => p.text)?.text;
            if (hasText) {
              throw new Error(`Gemini returned text instead of an image: ${hasText}`);
            }
            throw new Error("No image data returned from Gemini API.");
          }
        } else {
          if (!puter) throw new Error("Puter.js not loaded.");

          if (puter && typeof puter.auth?.isSignedIn === 'function') {
            const signedIn = await puter.auth.isSignedIn();
            if (!signedIn) {
              if (typeof puter.auth?.signIn === 'function') {
                try {
                  await puter.auth.signIn();
                  const signedInRetry = await puter.auth.isSignedIn();
                  if (!signedInRetry) {
                    throw new Error("You must be signed into Puter to generate images.");
                  }
                } catch (signInErr: any) {
                  let detail = '';
                  if (signInErr) {
                    if (typeof signInErr === 'string') detail = signInErr;
                    else if (typeof signInErr === 'object') detail = signInErr.message || signInErr.error || JSON.stringify(signInErr);
                    else detail = String(signInErr);
                  }
                  if (detail === '[object Object]' || !detail) {
                    detail = 'Authentication popup closed or credentials rejected.';
                  }
                  throw new Error(`Puter login is required to generate images. Please log in to your Puter account.\nDetail: ${detail}`);
                }
              } else {
                throw new Error("You are not signed into Puter. Please sign in to generate images.");
              }
            }
          }
          
          // Puter txt2img has a 1000 character limit for the prompt
          const truncatedPrompt = finalPrompt.length > 1000 ? finalPrompt.substring(0, 997) + "..." : finalPrompt;
          
          const ai = puter.ai;
          const image = await ai.txt2img.call(ai, truncatedPrompt, activeImageModel?.id, {
            aspect_ratio: modelPickedAspectRatio,
            resolution: modelPickedResolution
          });
          imageUrl = image.src;
        }
        
        setChats(prev => prev.map(c => {
          if (c.id === chatId) {
            const messages = [...c.messages];
            // Find the last assistant message to attach the image and update thinking
            for (let i = messages.length - 1; i >= 0; i--) {
              if (messages[i].role === 'assistant') {
                messages[i] = {
                  ...messages[i],
                  imageUrl: imageUrl,
                  imageWidth: width,
                  imageHeight: height,
                  isImageLoading: false
                };
                break;
              }
            }
            const updated = { ...c, messages };
            saveChat(updated);
            return updated;
          }
          return c;
        }));
        
        addThinkingStep('Image Gen', 'Image generated successfully.');
      } catch (err: any) {
        console.error("Model-triggered image gen failed:", err);
        
        // Clear loading state on error
        setChats(prev => prev.map(c => {
          if (c.id === chatId) {
            const messages = [...c.messages];
            for (let i = messages.length - 1; i >= 0; i--) {
              if (messages[i].role === 'assistant') {
                messages[i] = { ...messages[i], isImageLoading: false };
                break;
              }
            }
            return { ...c, messages };
          }
          return c;
        }));

        let rawError = 'Unknown error';
        if (err) {
          if (typeof err === 'string') rawError = err;
          else if (typeof err === 'object') rawError = err.message || err.error || JSON.stringify(err);
          else rawError = String(err);
        }

        let isTokenExhausted = false;
        const lowerErr = rawError.toLowerCase();
        if (
          lowerErr.includes('token') || 
          lowerErr.includes('quota') || 
          lowerErr.includes('credit') || 
          lowerErr.includes('limit') || 
          lowerErr.includes('insufficient') ||
          lowerErr.includes('payment') ||
          lowerErr.includes('subscribe') ||
          lowerErr.includes('free tier') ||
          lowerErr.includes('balance') ||
          lowerErr.includes('depleted')
        ) {
          isTokenExhausted = true;
        }

        const errorMessage = isTokenExhausted 
          ? `Failed to generate image: You have run out of Puter.js tokens / quota limit. Please log in with a Puter account containing available credits or wait for quota reset.`
          : `Failed to generate image: ${rawError}`;

        addThinkingStep('Image Gen', errorMessage);
        
        setChats(prev => prev.map(c => {
          if (c.id === chatId) {
            const messages = [...c.messages];
            for (let i = messages.length - 1; i >= 0; i--) {
              if (messages[i].role === 'assistant') {
                messages[i] = {
                  ...messages[i],
                  content: messages[i].content + `\n\n**Error:** ${errorMessage}`
                };
                break;
              }
            }
            const updated = { ...c, messages };
            saveChat(updated);
            return updated;
          }
          return c;
        }));
      }
    } else {
      // Nudge if the model seems to have forgotten the tag
      const lowerContent = fullContent.toLowerCase();
      const imageKeywords = ['generate an image', 'here is an image', 'created an image', 'made an image', 'image of a'];
      if (imageKeywords.some(kw => lowerContent.includes(kw)) && !fullContent.includes('<image_gen')) {
        addThinkingStep('System', 'Model mentioned an image but forgot the <image_gen prompt="..." /> tag.');
      }
    }
  };

  const resolveAutoModeExecutionInternal = async (chat: Chat, prompt: string): Promise<{
    mode: 'single' | 'multi';
    architecture: 'standard' | 'planning' | 'debate' | 'doc_analyzer';
    modelLevel: 'flash' | 'pro';
    reason: string;
    modelOverride?: string;
  }> => {
    // Collect all attached documents
    const docs: AppFile[] = [];
    const docIds = new Set<string>();
    chat.messages.forEach(m => {
      if (m.attachedFiles) {
        m.attachedFiles.forEach(f => {
          if (!f.type.startsWith('image/') && !docIds.has(f.id)) {
            docIds.add(f.id);
            docs.push(f);
          }
        });
      }
    });

    // Helper to find an enabled or favorite Pro level model
    const findProModel = (): string | undefined => {
      const proKeywords = ['pro', 'gpt-5.5', 'opus', 'claude', 'grok', 'deepseek-v4-pro', 'sonnet'];
      const enabled = settings.enabledChatModels || [];
      for (const mId of enabled) {
        const mLower = mId.toLowerCase();
        if (proKeywords.some(kw => mLower.includes(kw))) {
          return mId;
        }
      }
      return undefined;
    };

    // Heuristics Check: Document analyzer
    if (docs.length > 0) {
      return {
        mode: 'multi',
        architecture: 'doc_analyzer',
        modelLevel: 'flash',
        reason: 'Detected attached context documents. Selected Multi-Agent Document Analyzer and search-optimized semantic chunking to prune noise.'
      };
    }

    const lower = prompt.toLowerCase();

    // Heuristics Check: Self-Debate
    const debateKeywords = ['debate', 'argue', 'oppose', 'critique', 'pros and cons', 'vs', 'comparison', 'good or bad', 'philosophical', 'opinion'];
    if (debateKeywords.some(kw => lower.includes(kw))) {
      return {
        mode: 'multi',
        architecture: 'debate',
        modelLevel: 'pro',
        reason: 'Requested critical evaluation, debate, or opposing view comparisons. Selected Self-Debate MAS architecture to provide an exhaustive, multi-faceted analysis.',
        modelOverride: findProModel()
      };
    }

    // Heuristics Check: Planning/Code
    const codeTerms = ['code', 'function', 'class', 'python', 'javascript', 'typescript', 'script', 'fix error', 'compile', 'bug', 'regex', 'html', 'css', 'develop', 'implement', 'database', 'sql', 'json'];
    if (codeTerms.some(term => lower.includes(term))) {
      return {
        mode: 'multi',
        architecture: 'planning',
        modelLevel: 'flash',
        reason: 'Detected coding, script development, or structural query. Selected Planner-Critic (Planning) MAS architecture to write, audit, and systematically optimize code outputs.'
      };
    }

    // Heuristics Check: Micro/Conversational Queries (e.g. very short)
    if (prompt.trim().length < 80) {
      return {
        mode: 'single',
        architecture: 'standard',
        modelLevel: 'flash',
        reason: 'Short query or casual conversation. Routed directly to a Single Agent for minimal response duration and zero orchestration overhead.'
      };
    }

    // Advanced dynamic check using LLM
    try {
      const routingPrompt = `You are the AI Router/Orchestrator. Analyze this user request:
"${prompt}"

Decide:
1. "mode": "single" (for conversational, straightforward Q&A, formatting) or "multi" (for code, detailed research, planning, or complex instructions)
2. "architecture": "standard" (sequential flow), "planning" (collaborator-critic loop), "debate" (opposing views analysis), or "doc_analyzer" (files context)
3. "modelLevel": "flash" (high speed, standard tasks) or "pro" (detailed reasoning, maths, deep code)

Reply ONLY with a raw JSON block like:
{"mode": "single", "architecture": "standard", "modelLevel": "flash", "reason": "A brief explanation of why this routing is optimal."}
Do not use markdown backticks or extra text.`;

      // Perform a fast LLM completion
      const response = await getCompletion([
        { role: 'system', content: 'You are an AI Routing Assistant. Answer only with a single raw JSON block.' },
        { role: 'user', content: routingPrompt }
      ], { temperature: 0, max_tokens: 200 }) as any;

      const content = response?.choices[0]?.message?.content || '{}';
      const match = content.match(/\{[\s\S]*\}/);
      if (match) {
        const parsed = JSON.parse(match[0]);
        if (parsed.mode && parsed.architecture && parsed.modelLevel) {
          const proOverride = parsed.modelLevel === 'pro' ? findProModel() : undefined;
          return {
            mode: parsed.mode,
            architecture: parsed.architecture,
            modelLevel: parsed.modelLevel,
            reason: parsed.reason || 'Optimal routing match based on request context.',
            modelOverride: proOverride
          };
        }
      }
    } catch (e) {
      console.error('Advanced dynamic routing error:', e);
    }

    // Default Fallback
    return {
      mode: 'multi',
      architecture: 'standard',
      modelLevel: 'flash',
      reason: 'General request. Selected Multi-Agent standard sequential flow for a robust, detailed general response.'
    };
  };

  const aiDirectivesSystemPrompt = `
[AI DOCK INTEGRATED CAPABILITIES - EXPLICIT CHAT ACTIONS]:
You have direct programmatical control over the user's custom skills library and long-term memory engine. When the user explicitly requests you to remember something, write a skill, add a rule, delete standard memories, or activate a tool, you MUST use the following precise XML-like tags inside your text block response (write them directly in your response text, do not omit them):

1. **Create or Update an Expert Agent Skill**:
   If the user asks you to write, create, or modify a custom expert skill or persona, generate a <create_skill> tag. Do not put backticks around the tag itself, just emit it organically in your text:
   <create_skill name="Skill Name" description="One-sentence description of the expert skill" type="prompt" enabled="true">
   Detailed behavior guidelines, coding principles, tone directives, and rules to execute when the skill is enabled.
   </create_skill>

2. **Activate / Select an Inactive Skill**:
   If the user asks to enable/select a skill, or if a custom background skill listed in the [AUTO-ADAPTIVE SKILL LIBRARY] matches the user's request but isn't enabled, you can activate it by outputting:
   <select_skill name="Exact Skill Name" />

3. **Log a Long-term Memory**:
   If the user tells you personal details (their name, pets, preferences, workflow constraints) and says "remember this", "save this", or "store memory", record it using:
   <create_memory category="preferences">The factual sentence for continuity.</create_memory>
   Valid categories: "preferences", "personal", "project", "general".

4. **Wipe or Forget a Long-Term Memory**:
   If the user asks you to "forget that my cat is name Luna" or "clear memory about Luna", output:
   <delete_memory content_sub="Luna" />
`;

  const processAIToolsDirectives = async (content: string) => {
    if (!content) return;
    let hasChanges = false;
    let updatedSkillList = [...(settings.skills || [])];

    // 1. Check for <create_skill> tags
    const skillRegex = /<create_skill\s+name="([^"]+)"\s+description="([^"]*)"(?:\s+type="([^"]*)")?(?:\s+enabled="([^"]*)")?>\s*([\s\S]*?)\s*<\/create_skill>/gi;
    let match;
    while ((match = skillRegex.exec(content)) !== null) {
      const [_, name, description, type, enabledStr, systemPrompt] = match;
      const isEnabled = enabledStr === 'false' ? false : true;
      const skillType = type === 'persona' ? 'persona' : 'prompt';
      
      const existingIdx = updatedSkillList.findIndex(s => s.name.toLowerCase() === name.toLowerCase());
      const skillId = existingIdx !== -1 ? updatedSkillList[existingIdx].id : crypto.randomUUID();

      const newSkill: SkillConfig = {
        id: skillId,
        name: name.trim(),
        description: description.trim(),
        systemPrompt: systemPrompt.trim(),
        type: skillType as any,
        enabled: isEnabled,
        isPreset: false,
        attachedFiles: existingIdx !== -1 ? updatedSkillList[existingIdx].attachedFiles : []
      };

      if (existingIdx !== -1) {
        updatedSkillList[existingIdx] = newSkill;
      } else {
        updatedSkillList.push(newSkill);
      }
      hasChanges = true;
    }

    // 2. Check for <select_skill> / <activate_skill> tags
    const selectRegex = /<(?:select_skill|activate_skill)\s+name="([^"]+)"\s*\/>/gi;
    while ((match = selectRegex.exec(content)) !== null) {
      const name = match[1].trim().toLowerCase();
      updatedSkillList = updatedSkillList.map(s => {
        if (s.name.toLowerCase() === name) {
          if (!s.enabled) {
            hasChanges = true;
            return { ...s, enabled: true };
          }
        }
        return s;
      });
    }

    if (hasChanges) {
      const updatedSettings = { ...settings, skills: updatedSkillList };
      setSettings(updatedSettings);
      await saveSettings(updatedSettings);
    }

    // 3. Check for <create_memory> tags
    let memoryAddedOrUpdated = false;
    const memoryRegex = /<create_memory(?:\s+category="([^"]*)")?>\s*([\s\S]*?)\s*<\/create_memory>/gi;
    while ((match = memoryRegex.exec(content)) !== null) {
      const [_, categoryParam, memoryContent] = match;
      const trimmedContent = memoryContent.trim();
      if (trimmedContent) {
        const cat = ['preferences', 'personal', 'project', 'general'].includes(categoryParam || '') ? categoryParam : 'general';
        
        const currentMemories = await getAllMemories();
        const duplicate = currentMemories.find(m => m.content.toLowerCase().trim() === trimmedContent.toLowerCase());
        
        if (!duplicate) {
          const memory: Memory = {
            id: crypto.randomUUID(),
            content: trimmedContent,
            category: cat as any,
            createdAt: Date.now(),
            isActive: true,
            updatedAt: Date.now()
          };
          await saveMemory(memory);
          memoryAddedOrUpdated = true;
        }
      }
    }

    // 4. Check for <delete_memory> tags
    const deleteRegex = /<delete_memory(?:\s+id="([^"]+)"|\s+content_sub="([^"]+)").*?\/>/gi;
    while ((match = deleteRegex.exec(content)) !== null) {
      const [_, id, contentSub] = match;
      if (id) {
        await deleteMemory(id);
        memoryAddedOrUpdated = true;
      } else if (contentSub) {
        const sub = contentSub.trim().toLowerCase();
        const currentMemories = await getAllMemories();
        for (const m of currentMemories) {
          if (m.content.toLowerCase().includes(sub)) {
            await deleteMemory(m.id);
            memoryAddedOrUpdated = true;
          }
        }
      }
    }

    if (memoryAddedOrUpdated) {
      setMemorySyncTrigger(p => p + 1);
    }
  };

  const triggerBackgroundMemoryReflection = async (chatId: string, latestPrompt: string, latestResponse: string) => {
    if (settings.autoMemoryEnabled === false) return;
    
    try {
      console.log("[Memory Reflect] Triggering background extraction...");
      const currentMemories = await getAllMemories();
      const currentMemoriesText = currentMemories.map(m => `- [${m.category?.toUpperCase() || 'GENERAL'}] ${m.content}`).join('\n');
      
      const reflectionSystemPrompt = `You are a background Memory Extractor.
Analyze the user's latest prompt and the assistant's latest response. Identify any brand new key details, user preferences, personal details (like names, location, pets), project constraints, libraries, technologies, or custom naming guidelines that should be preserved across future chat threads.

Existing memories:
${currentMemoriesText || 'None'}

Rules for extraction:
1. ONLY extract truly useful, specific facts (e.g., "User prefers tailwind-css over custom CSS", "User is building a React application using Vite", "User name is Sarah").
2. Only output a JSON array of objects representing NEW extracted memories. Do not repeat or contradict existing memories.
3. Keep the content of each memory short, explicit, and complete (1 sentence maximum).
4. Assign a category to each new memory from the following set: "preferences", "personal", "project", "general".
5. If no new important cross-chat memories are found, return an empty array [].

Response Format constraint: You MUST respond with ONLY a raw JSON block containing a list of memories:
[
  { "content": "Visual description or preference", "category": "preferences" | "personal" | "project" | "general" }
]`;

      const activeModel = settings.puterModel || 'puter:gemini-3.5-flash';
      const response = await getCompletion([
        { role: 'system', content: reflectionSystemPrompt },
        { role: 'user', content: `Latest User Message: "${latestPrompt}"\n\nLatest Assistant Response: "${latestResponse}"` }
      ], { temperature: 0.2, modelOverride: activeModel }) as any;
      
      const content = response?.choices?.[0]?.message?.content || '';
      const matched = content.match(/\[\s*\{[\s\S]*\}\s*\]/);
      if (matched) {
        const extracted = JSON.parse(matched[0]);
        if (Array.isArray(extracted) && extracted.length > 0) {
          console.log("[Memory Reflect] Found new memories:", extracted);
          let added = false;
          for (const item of extracted) {
            const trimmedContent = (item.content || '').trim();
            if (trimmedContent) {
              const cat = ['preferences', 'personal', 'project', 'general'].includes(item.category) ? item.category : 'general';
              const memory: Memory = {
                id: crypto.randomUUID(),
                content: trimmedContent,
                category: cat as any,
                createdAt: Date.now(),
                isActive: true,
                updatedAt: Date.now()
              };
              await saveMemory(memory);
              added = true;
            }
          }
          if (added) {
            setMemorySyncTrigger(p => p + 1);
          }
        }
      }
    } catch (e) {
      console.error("[Memory Reflect] Background memory extraction failed:", e);
    }
  };

  const isTransitioningRef = useRef(false);

  useEffect(() => {
    if (isGenerating || isQueuePaused) {
      isTransitioningRef.current = false;
      setBackoffCountdown(null);
      return;
    }

    if (queuedPrompts.length === 0 || isTransitioningRef.current) return;

    const backoffSeconds = settings.promptQueueBackoff || 0;

    if (backoffSeconds > 0) {
      isTransitioningRef.current = true;
      setBackoffCountdown(backoffSeconds);

      let timeLeft = backoffSeconds;
      const interval = setInterval(() => {
        timeLeft -= 1;
        if (timeLeft <= 0) {
          clearInterval(interval);
          setBackoffCountdown(null);
          
          const nextItem = queuedPrompts[0];
          setCurrentRunningQueueItem(nextItem);
          setQueuedPrompts(prev => prev.slice(1));
          handleSendMessage(nextItem.text, nextItem.attachedFiles);
        } else {
          setBackoffCountdown(timeLeft);
        }
      }, 1000);

      return () => {
        clearInterval(interval);
        setBackoffCountdown(null);
        isTransitioningRef.current = false;
      };
    } else {
      isTransitioningRef.current = true;
      const nextItem = queuedPrompts[0];
      setCurrentRunningQueueItem(nextItem);
      setQueuedPrompts(prev => prev.slice(1));
      handleSendMessage(nextItem.text, nextItem.attachedFiles);
    }
  }, [isGenerating, queuedPrompts, settings.promptQueueBackoff, isQueuePaused]);

  const runSingleAgent = async (chat: Chat, prompt: string, modelOverride?: string) => {
    let localThinkingSteps: { agent: string, text: string }[] = [];
    const addThinkingStep = (agent: string, text: string) => {
      localThinkingSteps.push({ agent, text });
      setThinkingProcess([...localThinkingSteps]);
    };

    let currentSkills = [...(settings.skills || [])];
    const userPromptLower = prompt.toLowerCase();
    
    // Auto-select skills based on semantic keyword presence in user prompt
    const newlyEnabledSkills: any[] = [];
    currentSkills = currentSkills.map(s => {
      if (s.type !== 'persona' && !s.enabled) {
        // Split name and description into keywords
        const skillNameWords = s.name.toLowerCase().split(/\W+/).filter(w => w.length > 3);
        const skillDescWords = s.description.toLowerCase().split(/\W+/).filter(w => w.length > 3);
        const allKeywords = [...new Set([...skillNameWords, ...skillDescWords])];
        
        const isMatched = allKeywords.some(keyword => userPromptLower.includes(keyword));
        if (isMatched) {
          newlyEnabledSkills.push(s);
          return { ...s, enabled: true };
        }
      }
      return s;
    });

    if (newlyEnabledSkills.length > 0) {
      const updatedSettings = { ...settings, skills: currentSkills };
      setSettings(updatedSettings);
      await saveSettings(updatedSettings);
      addThinkingStep('Auto Skills Selection', `Automatically detected and activated expert agent skill: ${newlyEnabledSkills.map(ns => ns.name).join(', ')} (based on prompt matching context)`);
    }

    let activeModel = modelOverride || settings.puterModel || 'puter:gemini-3.5-flash';
    if (activeModel === 'auto') {
      activeModel = (settings.enabledChatModels && settings.enabledChatModels[0]) || 'puter:gemini-3.5-flash';
    }

    const assistantMsg: Message = {
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      modelId: activeModel
    };

    setChats(prev => prev.map(c => {
      if (c.id === chat.id) return { ...c, messages: [...c.messages, assistantMsg] };
      return c;
    }));

    const formatSkillWithKnowledge = (s: any): string => {
      let pr = `[SKILL: ${s.name}] (Type: ${s.type || 'prompt'})\nDescription: ${s.description}\nCore Behavior Guidelines:\n${s.systemPrompt}`;
      if (s.attachedFiles && s.attachedFiles.length > 0) {
        pr += `\n\n[KNOWLEDGE ATTACHMENTS FOR SKILL "${s.name}"]:`;
        s.attachedFiles.forEach((f: any) => {
          pr += `\n--- START OF REFERENCE FILE: ${f.name} (Type: ${f.type}) ---`;
          pr += `\n${f.content}`;
          pr += `\n--- END OF REFERENCE FILE: ${f.name} ---\n`;
        });
      }
      return pr;
    };

    const activePersona = currentSkills.find(s => s.type === 'persona' && s.enabled);
    const activeSkills = currentSkills.filter(s => s.type !== 'persona' && s.enabled);
    const inactiveSkills = currentSkills.filter(s => s.type !== 'persona' && !s.enabled);

    const personaPrompt = activePersona 
      ? `[ACTIVE PERSONA: ${activePersona.name}] ${activePersona.systemPrompt}\n\nYou MUST reply in the tone, persona, voice, and style specified by this active persona. Remain fully immersed in this persona at all times.` 
      : '';
    const activeSkillPrompt = activeSkills.map(s => formatSkillWithKnowledge(s)).join('\n\n');

    let backgroundSkillsPrompt = '';
    if (inactiveSkills.length > 0) {
      backgroundSkillsPrompt = `\n\n[AUTO-ADAPTIVE SKILL LIBRARY (INACTIVE BY DEFAULT, DYNAMICALLY USE IF RELEVANT)]:
You have access to the following background custom skills. You should automatically and dynamically adopt their tone, rules, and attached knowledge files if the user's intent or query aligns with them, even when the user hasn't explicitly triggered or called them.
${inactiveSkills.map(s => formatSkillWithKnowledge(s)).join('\n\n')}`;
    }

    const combinedSkillsPrompt = `${personaPrompt ? `${personaPrompt}\n\n` : ''}${activeSkillPrompt}${backgroundSkillsPrompt}`;
    const memoriesPrompt = await fetchActiveMemoriesPrompt();
    const imageGenDirective = settings.imageGenerationEnabled ? `\n\nIMAGE GENERATION: You MUST only generate an image if the user specifically and explicitly asks for one. To generate an image, use the tag <image_gen prompt="..." />. Example: <image_gen prompt="a futuristic city" />. Do NOT generate images spontaneously unless the user's intent is clearly to have an image created.` : `\n\nIMAGE GENERATION: DISABLED.`;
    
    let persistentKnowledgePrompt = '';
    if (chat.pinnedFileIds && chat.pinnedFileIds.length > 0) {
      const pinnedFiles = files.filter(f => chat.pinnedFileIds?.includes(f.id));
      if (pinnedFiles.length > 0) {
        persistentKnowledgePrompt = `\n\n[PERSISTENT PROJECT REFERENCE DOCUMENTS INJECTED BY USER FOR THIS THREAD]:\n` + 
          pinnedFiles.map(f => {
            return `--- START OF FILE: ${f.name} (Type: ${f.type}) ---\n${f.content}\n--- END OF FILE: ${f.name} ---`;
          }).join('\n\n');
      }
    }

    const messages = [
      { role: 'system', content: `${settings.systemPrompt}\n\n${combinedSkillsPrompt}${imageGenDirective}${memoriesPrompt}${persistentKnowledgePrompt}\n\n${aiDirectivesSystemPrompt}` },
      ...chat.messages.map(m => ({ 
        role: m.role as any, 
        content: m.content,
        attachedImages: m.attachedImages,
        attachedFiles: m.attachedFiles
      }))
    ];

    const truncatedMessages = getTruncatedMessages(messages);
    const contextTokens = calculateAccurateContextTokens(truncatedMessages);
    const contextLimit = getActiveModelMaxContext(activeModel);

    let retryCount = 0;
    const maxRetries = 3;
    let fullContent = '';
    let currentMessages = truncatedMessages;
    let finalChat = chat;
    let tps = 0;

    const startTime = Date.now();
    const chunks = await getCompletion(currentMessages, {
      temperature: settings.temperature,
      max_tokens: settings.maxTokens,
      stream: true,
      modelOverride: activeModel
    }) as any;

    fullContent = '';
    let fullThinking = '';
    let chunkCount = 0;
    let lastUpdateTime = Date.now();
    for await (const chunk of chunks) {
      const delta = chunk.choices[0]?.delta?.content || '';
      const thoughtDelta = chunk.choices[0]?.delta?.thought || '';
      fullContent += delta;
      fullThinking += thoughtDelta;
      chunkCount++;
      
      const now = Date.now();
      const throttleLimit = document.hidden ? 1500 : 50;
      // Throttle state updates dynamically based on tab visibility to prevent background tab CPU freezing
      if (now - lastUpdateTime > throttleLimit || chunkCount === 1) {
        lastUpdateTime = now;

        // Dynamically extract <think> block if native thoughts are not present
        let currentThinkingText = fullThinking;
        if (!currentThinkingText) {
          const modelThinkingText = extractModelThinking(fullContent);
          if (modelThinkingText !== null) {
            currentThinkingText = modelThinkingText.trim();
          }
        } else {
          currentThinkingText = currentThinkingText.trim();
        }

        if (currentThinkingText) {
          const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
          if (existingStepIdx !== -1) {
            localThinkingSteps[existingStepIdx].text = currentThinkingText;
          } else {
            localThinkingSteps.push({ agent: 'Model Thinking', text: currentThinkingText });
          }
          setThinkingProcess([...localThinkingSteps]);
        }

        setChats(prev => prev.map(c => {
          if (c.id === chat.id) {
            const lastMsg = c.messages[c.messages.length - 1];
            return {
              ...c,
              messages: [...c.messages.slice(0, -1), { 
                ...lastMsg, 
                content: fullContent,
                thinking: currentThinkingText || undefined,
                thinkingSteps: [...localThinkingSteps]
              }]
            };
          }
          return c;
        }));
      }

      // Save intermediate progress occasionally (heavy IndexedDB operation restricted to visible tab/larger intervals in background)
      if (chunkCount % (document.hidden ? 100 : 20) === 0) {
        let currentThinkingText = fullThinking;
        if (!currentThinkingText) {
          const modelThinkingText = extractModelThinking(fullContent);
          if (modelThinkingText !== null) {
            currentThinkingText = modelThinkingText.trim();
          }
        } else {
          currentThinkingText = currentThinkingText.trim();
        }

        const partialChat = {
          ...chat,
          messages: [...chat.messages, { 
            ...assistantMsg, 
            content: fullContent, 
            thinking: currentThinkingText || undefined,
            thinkingSteps: [...localThinkingSteps] 
          }]
        };
        saveChat(partialChat as Chat);
      }
    }

    const endTime = Date.now();
    const durationSec = (endTime - startTime) / 1000;
    
    // Auto-close any unclosed thinking tags if execution cut off or finished
    fullContent = ensureClosedThinkingTags(fullContent);
    tps = durationSec > 0 ? (fullContent.length / 4) / durationSec : 0;

    // Final thinking extraction check
    let finalThinkingText = fullThinking;
    if (!finalThinkingText) {
      const finalModelThinkingText = extractModelThinking(fullContent);
      if (finalModelThinkingText !== null) {
        finalThinkingText = finalModelThinkingText.trim();
      }
    } else {
      finalThinkingText = finalThinkingText.trim();
    }

    if (finalThinkingText) {
      const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
      if (existingStepIdx !== -1) {
        localThinkingSteps[existingStepIdx].text = finalThinkingText;
      } else {
        localThinkingSteps.push({ agent: 'Model Thinking', text: finalThinkingText });
      }
      setThinkingProcess([...localThinkingSteps]);
    }

    const updatedChat = {
      ...chat,
      messages: [...chat.messages, { 
        ...assistantMsg, 
        content: fullContent, 
        tps, 
        contextTokens,
        contextLimit,
        modelId: activeModel,
        thinking: finalThinkingText || undefined,
        thinkingSteps: [...localThinkingSteps]
      }]
    };
    
    // Unified Tool Integration for single agent
    finalChat = updatedChat;
    
    setChats(prev => prev.map(c => c.id === chat.id ? finalChat as Chat : c));
    await saveChat(finalChat as Chat);
    
    // Parse any programmatically generated skill/memory directives
    await processAIToolsDirectives(fullContent);

    // Background memory reflection
    triggerBackgroundMemoryReflection(chat.id, prompt, fullContent);
    
    await handleModelTriggeredImageGen(chat.id, fullContent, finalChat as Chat, addThinkingStep);
  };

  const runMultiAgent = async (chat: Chat, prompt: string, incomingModelOverride?: string, architectureOverride?: MASArchitecture) => {
    let activeArchitecture = architectureOverride || settings.masArchitecture;
    let modelOverride = incomingModelOverride;

    let activeModel = modelOverride || settings.puterModel || 'puter:gemini-3.5-flash';
    if (activeModel === 'auto') {
      activeModel = (settings.enabledChatModels && settings.enabledChatModels[0]) || 'puter:gemini-3.5-flash';
    }

    if (!modelOverride) {
      modelOverride = activeModel;
    }

    const activeAgents = agents.filter(a => a.enabled);
    let agentOutputs: { name: string, content: string }[] = [];
    let attempts = 0;
    let isApproved = false;
    let currentPrompt = prompt;
    let currentScratchpad = '';
    let localThinkingSteps: { agent: string, text: string }[] = [];

    const assistantMsg: Message = {
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      thinkingSteps: [],
      modelId: activeModel
    };

    setChats(prev => prev.map(c => {
      if (c.id === chat.id) return { ...c, messages: [...c.messages, assistantMsg] };
      return c;
    }));

    const updateAssistantMessage = (content: string, steps: any[], scratchpad: string) => {
      const extractedThinking = extractModelThinking(content);
      setChats(prev => prev.map(c => {
        if (c.id === chat.id) {
          const messages = [...c.messages];
          const lastMsg = messages[messages.length - 1];
          if (lastMsg && lastMsg.role === 'assistant') {
            messages[messages.length - 1] = { 
              ...lastMsg, 
              content, 
              thinkingSteps: steps,
              scratchpad,
              thinking: extractedThinking ? extractedThinking.trim() : undefined
            };
          }
          return { ...c, messages };
        }
        return c;
      }));
    };

    const addThinkingStep = (agent: string, text: string) => {
      localThinkingSteps.push({ agent, text });
      setThinkingProcess([...localThinkingSteps]);
      updateAssistantMessage("Agents are collaborating on a plan...", localThinkingSteps, currentScratchpad);
    };

    const updateScratchpad = (agent: string, text: string) => {
      currentScratchpad += `\n[${agent}]: ${text}\n`;
      setScratchpad(currentScratchpad);
      updateAssistantMessage("Agents are refining the scratchpad...", localThinkingSteps, currentScratchpad);
    };

    let currentSkills = [...(settings.skills || [])];
    const userPromptLower = prompt.toLowerCase();
    
    // Auto-select skills based on semantic keyword overlap in user prompt
    const newlyEnabledSkills: any[] = [];
    currentSkills = currentSkills.map(s => {
      if (s.type !== 'persona' && !s.enabled) {
        const skillNameWords = s.name.toLowerCase().split(/\W+/).filter(w => w.length > 3);
        const skillDescWords = s.description.toLowerCase().split(/\W+/).filter(w => w.length > 3);
        const allKeywords = [...new Set([...skillNameWords, ...skillDescWords])];
        
        const isMatched = allKeywords.some(keyword => userPromptLower.includes(keyword));
        if (isMatched) {
          newlyEnabledSkills.push(s);
          return { ...s, enabled: true };
        }
      }
      return s;
    });

    if (newlyEnabledSkills.length > 0) {
      const updatedSettings = { ...settings, skills: currentSkills };
      setSettings(updatedSettings);
      await saveSettings(updatedSettings);
      addThinkingStep('Auto Skills Selection', `Automatically detected and activated expert agent skill: ${newlyEnabledSkills.map(ns => ns.name).join(', ')} (based on prompt matching context)`);
    }

    let finalTps = 0;
    const history = getTruncatedMessages(chat.messages.map(m => ({ 
      role: m.role as any, 
      content: m.content,
      attachedImages: m.attachedImages,
      attachedFiles: m.attachedFiles
    })));
    let contextTokens = 0;
    
    // activeModel and modelOverride have already been calculated and set at the top of runMultiAgent

    let contextLimit = getActiveModelMaxContext(modelOverride);
    const formatSkillWithKnowledge = (s: any): string => {
      let pr = `[SKILL: ${s.name}] (Type: ${s.type || 'prompt'})\nDescription: ${s.description}\nCore Behavior Guidelines:\n${s.systemPrompt}`;
      if (s.attachedFiles && s.attachedFiles.length > 0) {
        pr += `\n\n[KNOWLEDGE ATTACHMENTS FOR SKILL "${s.name}"]:`;
        s.attachedFiles.forEach((f: any) => {
          pr += `\n--- START OF REFERENCE FILE: ${f.name} (Type: ${f.type}) ---`;
          pr += `\n${f.content}`;
          pr += `\n--- END OF REFERENCE FILE: ${f.name} ---\n`;
        });
      }
      return pr;
    };

    const activePersona = currentSkills.find(s => s.type === 'persona' && s.enabled);
    const activeSkills = currentSkills.filter(s => s.type !== 'persona' && s.enabled);
    const inactiveSkills = currentSkills.filter(s => s.type !== 'persona' && !s.enabled);

    const personaPrompt = activePersona 
      ? `[ACTIVE PERSONA: ${activePersona.name}] ${activePersona.systemPrompt}\n\nYou MUST reply in the tone, persona, voice, and style specified by this active persona. Remain fully immersed in this persona at all times.` 
      : '';
    const activeSkillPrompt = activeSkills.map(s => formatSkillWithKnowledge(s)).join('\n\n');

    let backgroundSkillsPrompt = '';
    if (inactiveSkills.length > 0) {
      backgroundSkillsPrompt = `\n\n[AUTO-ADAPTIVE SKILL LIBRARY (INACTIVE BY DEFAULT, DYNAMICALLY USE IF RELEVANT)]:
You have access to the following background custom skills. You should automatically and dynamically adopt their tone, rules, and attached knowledge files if the user's intent or query aligns with them, even when the user hasn't explicitly triggered or called them.
${inactiveSkills.map(s => formatSkillWithKnowledge(s)).join('\n\n')}`;
    }

    const memoriesPrompt = await fetchActiveMemoriesPrompt();
    let persistentKnowledgePrompt = '';
    if (chat.pinnedFileIds && chat.pinnedFileIds.length > 0) {
      const pinnedFiles = files.filter(f => chat.pinnedFileIds?.includes(f.id));
      if (pinnedFiles.length > 0) {
        persistentKnowledgePrompt = `\n\n[PERSISTENT PROJECT REFERENCE DOCUMENTS INJECTED BY USER FOR THIS THREAD]:\n` + 
          pinnedFiles.map(f => {
            return `--- START OF FILE: ${f.name} (Type: ${f.type}) ---\n${f.content}\n--- END OF FILE: ${f.name} ---`;
          }).join('\n\n');
      }
    }
    const skillPrompt = `${personaPrompt ? `${personaPrompt}\n\n` : ''}${activeSkillPrompt}${backgroundSkillsPrompt}${memoriesPrompt}${persistentKnowledgePrompt}\n\n${aiDirectivesSystemPrompt}`;
    const imageGenDirective = settings.imageGenerationEnabled ? `\n\nIMAGE GENERATION: You MUST only generate an image if the user specifically and explicitly asks for one. To generate an image, use the tag <image_gen prompt="..." />. Example: <image_gen prompt="a futuristic city" />. Do NOT generate images spontaneously unless the user's intent is clearly to have an image created.` : ``;

    const contextMessages = [
      { role: 'system', content: `${settings.systemPrompt}\n\n${skillPrompt}${imageGenDirective}` },
      ...history,
      { role: 'user', content: currentPrompt }
    ];
    contextTokens = calculateAccurateContextTokens(contextMessages);

    if (activeArchitecture === 'auto') {
      addThinkingStep('Auto Architecture Router', 'Analyzing user request to auto-select optimal MAS Architecture...');
      const routeResult = await resolveAutoModeExecutionInternal(chat, prompt);
      activeArchitecture = routeResult.architecture;
      addThinkingStep('Auto Architecture Router', `Selected MAS Architecture: ${activeArchitecture === 'standard' ? 'Standard (Sequential)' : activeArchitecture === 'planning' ? 'Planning (Planner-Critic)' : activeArchitecture === 'debate' ? 'Self-Debate (Opposing Views)' : 'Document Analyzer'}. Reason: ${routeResult.reason}`);
      if (!incomingModelOverride && routeResult.modelOverride) {
        modelOverride = routeResult.modelOverride;
        activeModel = modelOverride;
        contextLimit = getActiveModelMaxContext(modelOverride);
      }
    }

    if (activeArchitecture === 'planning') {
      let plan: any = null;
      while (attempts < (settings.criticStrictness > 5 ? 3 : 1) && !isApproved) {
        if (abortControllerRef.current?.signal.aborted) throw new Error('Aborted');
        attempts++;
        addThinkingStep('Planner', `Breaking down request into steps... ${attempts > 1 ? `(Attempt ${attempts})` : ''}`);
        
        const plannerResponse = await getCompletion([
          { role: 'system', content: `You are a Planner. Break down the user prompt into multiple steps. Assign each step to a specific agent role (Coder, Writer, Analyst, etc.). Return a JSON object with "context" and "steps" (array of {step: string, agent: string}).\n\nOriginal User Request: ${prompt}\n\nAvailable Skills:\n${skillPrompt}` },
          ...history,
          { role: 'user', content: currentPrompt }
        ], { temperature: 0.3, response_format: { type: 'json_object' }, modelOverride } as any) as any;
        
        try {
          const content = plannerResponse.choices[0].message.content;
          plan = JSON.parse(content.match(/\{[\s\S]*\}/)?.[0] || '{}');
          updateScratchpad('Planner', `Plan created with ${plan.steps?.length} steps.`);
        } catch (e) {
          console.error("Planner JSON error:", e);
          plan = { context: prompt, steps: [{ step: prompt, agent: 'Generalist' }] };
        }

        let intermediateOutput = "";
        for (const step of plan.steps || []) {
          if (abortControllerRef.current?.signal.aborted) throw new Error('Aborted');
          await waitForResume();
          addThinkingStep(step.agent, `Executing: ${step.step}`);
          
          const stepAgentRef = agents.find(a => a.name.toLowerCase() === step.agent.toLowerCase());
          const stepModelOverride = stepAgentRef?.modelId || modelOverride;

          const response = await getCompletion([
            { role: 'system', content: `You are a ${step.agent}. Context: ${plan.context || prompt}. Original User Request: ${prompt}. You are in a chain of agents. Previous output: ${intermediateOutput}\n\nAvailable Skills:\n${skillPrompt}` },
            ...history,
            { role: 'user', content: `Task: ${step.step}\n\nOriginal User Request: ${prompt}` }
          ], { temperature: settings.temperature, modelOverride: stepModelOverride }) as any;
          let content = response.choices[0].message.content || '';
          
          updateScratchpad(step.agent, content);
          agentOutputs.push({ name: step.agent, content });
        }

      const maxFinalizerRetries = 3;
      let finalizerRetryCount = 0;
      const lastMessage = history[history.length - 1];
      let finalizerMessages = [
        { role: 'system', content: `You are a Finalizer. Combine all agent outputs into a single, cohesive response that directly addresses the user's request. If it is code, make it a complete program.${imageGenDirective}\n\nOriginal User Request: ${prompt}\n\nAvailable Skills:\n${skillPrompt}` },
        { 
          role: 'user', 
          content: `Original User Request: ${prompt}\n\nOutputs:\n${agentOutputs.map(o => `${o.name}: ${o.content}`).join('\n\n')}`,
          attachedImages: lastMessage?.attachedImages || [],
          attachedFiles: lastMessage?.attachedFiles || []
        }
      ];

      while (finalizerRetryCount <= maxFinalizerRetries) {
        if (abortControllerRef.current?.signal.aborted) throw new Error('Aborted');
        addThinkingStep('Finalizer', 'Combining all outputs...');
        const startTime = Date.now();
        const chunks = await getCompletion(finalizerMessages, { temperature: 0.5, stream: true, modelOverride }) as any;

        let finalizedContent = '';
        let chunkCount = 0;
        let lastUpdateTime = Date.now();
        for await (const chunk of chunks) {
          const delta = chunk.choices[0]?.delta?.content || '';
          finalizedContent += delta;
          chunkCount++;
          
          const now = Date.now();
          const throttleLimit = document.hidden ? 1500 : 50;
          if (now - lastUpdateTime > throttleLimit || chunkCount === 1) {
            lastUpdateTime = now;

            const modelThinkingText = extractModelThinking(finalizedContent);
            if (modelThinkingText !== null) {
              const thinkingTextClean = modelThinkingText.trim();
              const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
              if (existingStepIdx !== -1) {
                localThinkingSteps[existingStepIdx].text = thinkingTextClean;
              } else {
                localThinkingSteps.push({ agent: 'Model Thinking', text: thinkingTextClean });
              }
              setThinkingProcess([...localThinkingSteps]);
            }

            updateAssistantMessage(finalizedContent, localThinkingSteps, currentScratchpad);
          }
        }
        
        finalizedContent = ensureClosedThinkingTags(finalizedContent);

        const finalModelThinkingText = extractModelThinking(finalizedContent);
        if (finalModelThinkingText !== null) {
          const thinkingTextClean = finalModelThinkingText.trim();
          const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
          if (existingStepIdx !== -1) {
            localThinkingSteps[existingStepIdx].text = thinkingTextClean;
          } else {
            localThinkingSteps.push({ agent: 'Model Thinking', text: thinkingTextClean });
          }
          setThinkingProcess([...localThinkingSteps]);
        }

        const endTime = Date.now();
        const durationSec = (endTime - startTime) / 1000;
        finalTps = durationSec > 0 ? (finalizedContent.length / 4) / durationSec : 0;
        
        updateScratchpad('Finalizer', finalizedContent);
        updateAssistantMessage(finalizedContent, localThinkingSteps, currentScratchpad);
        
        // Critic
        addThinkingStep('Critic', 'Reviewing finalized output...');
        const criticResponse = await getCompletion([
          { role: 'system', content: `You are a Critic. Strictness: ${settings.criticStrictness}/10. Review the finalized output against the original user prompt and plan to ensure everything is perfectly resolved. If it's good, respond with "APPROVED". If not, respond with "REJECT: [reasons and improvements]".` },
          { role: 'user', content: `Original User Request: ${prompt}\n\nPlan: ${JSON.stringify(plan)}\n\nFinalized Output: ${finalizedContent}` }
        ], { temperature: 0.2, modelOverride }) as any;
        const criticContent = criticResponse.choices[0].message.content || '';
        updateScratchpad('Critic', criticContent);

        if (criticContent.toUpperCase().includes('APPROVED')) {
          isApproved = true;
          currentPrompt = finalizedContent; // This will be the final response
          break;
        } else {
          currentPrompt = `Feedback from Critic: ${criticContent}\n\nOriginal Request: ${prompt}`;
          agentOutputs = []; // Reset for next attempt
          // If we are rejected by critic, we might want to restart the whole planning loop or just return.
          // For now, let's just break the finalizer retry loop and let the outer while loop (attempts) handle it.
          break;
        }
      }
      }
    } else if (activeArchitecture === 'debate') {
      addThinkingStep('Analyzer', 'Identifying opposing viewpoints...');
      const analyzerResponse = await getCompletion([
        { role: 'system', content: `You are an Analyzer. Identify two opposing viewpoints for the user request. Return a JSON object with "sideA" (system prompt for side A) and "sideB" (system prompt for side B).\n\nOriginal User Request: ${prompt}\n\nAvailable Skills:\n${skillPrompt}` },
        ...history,
        ...history,
        { role: 'user', content: prompt }
      ], { temperature: 0.3, response_format: { type: 'json_object' }, modelOverride } as any) as any;
      
      const viewpoints = JSON.parse(analyzerResponse.choices[0].message.content.match(/\{[\s\S]*\}/)?.[0] || '{}');
      updateScratchpad('Analyzer', `Debate started between ${viewpoints.sideA?.slice(0, 50)}... and ${viewpoints.sideB?.slice(0, 50)}...`);

      let debateHistory = `User Question: ${prompt}\n\n`;
      for (let i = 0; i < 3; i++) {
        await waitForResume();
        addThinkingStep('Debater A', `Round ${i+1} argument...`);
        const responseA = await getCompletion([
          { role: 'system', content: viewpoints.sideA + ` You are in a debate on the user request. Be persuasive but open to good arguments. Original User Request: ${prompt}.${memoriesPrompt}` },
          { role: 'user', content: `Original User Request: ${prompt}\n\nDebate History so far:\n` + debateHistory + "\nWhat is your argument/counter-argument?" }
        ], { temperature: 0.8, modelOverride }) as any;
        const contentA = responseA.choices[0].message.content || '';
        debateHistory += `Side A: ${contentA}\n\n`;
        updateScratchpad('Debater A', contentA);

        addThinkingStep('Debater B', `Round ${i+1} counter-argument...`);
        const responseB = await getCompletion([
          { role: 'system', content: viewpoints.sideB + ` You are in a debate on the user request. Be persuasive but open to good arguments. Original User Request: ${prompt}.${memoriesPrompt}` },
          { role: 'user', content: `Original User Request: ${prompt}\n\nDebate History so far:\n` + debateHistory + "\nWhat is your argument/counter-argument?" }
        ], { temperature: 0.8, modelOverride }) as any;
        const contentB = responseB.choices[0].message.content || '';
        debateHistory += `Side B: ${contentB}\n\n`;
        updateScratchpad('Debater B', contentB);
      }

      addThinkingStep('Moderator', 'Synthesizing agreement...');
      let moderatorRetryCount = 0;
      const maxModeratorRetries = 3;
      const lastMessage = history[history.length - 1];
      let moderatorMessages = [
        { role: 'system', content: `You are a Moderator. Summarize the debate and provide a final balanced conclusion that directly addresses the user's original request.${imageGenDirective}\n\nOriginal User Request: ${prompt}\n\nAvailable Skills:\n${skillPrompt}` },
        { 
          role: 'user', 
          content: `Original User Request: ${prompt}\n\nDebate History:\n${debateHistory}`,
          attachedImages: lastMessage?.attachedImages || [],
          attachedFiles: lastMessage?.attachedFiles || []
        }
      ];

      while (moderatorRetryCount <= maxModeratorRetries) {
        addThinkingStep('Moderator', 'Synthesizing agreement...');
        const startTime = Date.now();
        const chunks = await getCompletion(moderatorMessages, { temperature: 0.5, stream: true, modelOverride }) as any;

        let finalizedContent = '';
        let chunkCount = 0;
        let lastUpdateTime = Date.now();
        for await (const chunk of chunks) {
          const delta = chunk.choices[0]?.delta?.content || '';
          finalizedContent += delta;
          chunkCount++;
          
          const now = Date.now();
          const throttleLimit = document.hidden ? 1500 : 50;
          if (now - lastUpdateTime > throttleLimit || chunkCount === 1) {
            lastUpdateTime = now;

            const modelThinkingText = extractModelThinking(finalizedContent);
            if (modelThinkingText !== null) {
              const thinkingTextClean = modelThinkingText.trim();
              const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
              if (existingStepIdx !== -1) {
                localThinkingSteps[existingStepIdx].text = thinkingTextClean;
              } else {
                localThinkingSteps.push({ agent: 'Model Thinking', text: thinkingTextClean });
              }
              setThinkingProcess([...localThinkingSteps]);
            }

            updateAssistantMessage(finalizedContent, localThinkingSteps, currentScratchpad);
          }
        }

        finalizedContent = ensureClosedThinkingTags(finalizedContent);

        const finalModelThinkingText = extractModelThinking(finalizedContent);
        if (finalModelThinkingText !== null) {
          const thinkingTextClean = finalModelThinkingText.trim();
          const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
          if (existingStepIdx !== -1) {
            localThinkingSteps[existingStepIdx].text = thinkingTextClean;
          } else {
            localThinkingSteps.push({ agent: 'Model Thinking', text: thinkingTextClean });
          }
          setThinkingProcess([...localThinkingSteps]);
        }

        const endTime = Date.now();
        const durationSec = (endTime - startTime) / 1000;
        finalTps = durationSec > 0 ? (finalizedContent.length / 4) / durationSec : 0;

        currentPrompt = finalizedContent;
        updateScratchpad('Moderator', currentPrompt);
        updateAssistantMessage(currentPrompt, localThinkingSteps, currentScratchpad);
        break;
      }
    } else if (activeArchitecture === 'doc_analyzer') {
      addThinkingStep('Fuzzy Query Analyzer', 'Tokenizing user request and filtering stop words to extract search terms...');
      
      const stopWords = new Set([
        'the', 'a', 'an', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'to', 'for', 'in', 'on', 'with', 'by', 'at', 
        'this', 'that', 'of', 'from', 'it', 'its', 'as', 'if', 'then', 'else', 'your', 'my', 'how', 'what', 'why', 
        'who', 'where', 'when', 'which', 'them', 'they', 'you', 'he', 'she', 'we', 'us', 'i', 'me', 'please', 'can', 
        'should', 'would', 'could', 'does', 'do', 'did', 'done', 'has', 'have', 'had', 'any', 'some', 'all', 'more', 
        'most', 'many', 'few', 'about', 'above'
      ]);

      const queryWords = (prompt || '').toLowerCase()
        .replace(/[^\w\s]/g, ' ')
        .split(/\s+/)
        .filter(w => w.length > 2 && !stopWords.has(w));

      addThinkingStep('Fuzzy Indexer', `Search query terms extracted: [${queryWords.join(', ') || 'entire query'}]`);

      // Collect all attached documents
      const docs: AppFile[] = [];
      const docIds = new Set<string>();
      chat.messages.forEach(m => {
        if (m.attachedFiles) {
          m.attachedFiles.forEach(f => {
            if (!f.type.startsWith('image/') && !docIds.has(f.id)) {
              docIds.add(f.id);
              docs.push(f);
            }
          });
        }
      });

      let mergedExcerpts = '';
      let percentMatched = 0;
      let totalSkippedChars = 0;
      let totalScannedDocs = docs.length;

      const decodeB64 = (b64: string): string => {
        try {
          return decodeURIComponent(atob(b64).split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''));
        } catch (e) {
          try { return atob(b64); } catch { return b64; }
        }
      };

      if (docs.length > 0) {
        addThinkingStep('Fuzzy Ranker', `Scanning ${docs.length} attached document(s) & segmenting them into overlapping chunks...`);
        
        interface SearchedChunk {
          fileName: string;
          text: string;
          startLine: number;
          endLine: number;
          score: number;
          index: number;
        }

        const allChunks: SearchedChunk[] = [];
        let globalChunkIndex = 0;

        docs.forEach(doc => {
          let fileBody = doc.content;
          if (typeof fileBody === 'string' && fileBody.startsWith('data:')) {
            const parts = fileBody.split(',');
            if (parts[1]) {
              const isText = doc.type.startsWith('text/') || 
                             ['json', 'py', 'js', 'ts', 'tsx', 'jsx', 'html', 'css', 'md', 'txt', 'csv', 'yaml', 'yml', 'rs', 'go', 'c', 'cpp', 'h', 'java', 'gradle'].some(ext => doc.name.toLowerCase().endsWith('.' + ext));
              if (isText) {
                fileBody = decodeB64(parts[1]);
              } else {
                fileBody = `[Binary Data Description: File ${doc.name} of type ${doc.type}]`;
              }
            }
          }

          const lines = fileBody.split(/\r?\n/);
          const chunkSize = 20;
          const overlap = 5;

          for (let i = 0; i < lines.length; i += (chunkSize - overlap)) {
            const chunkLines = lines.slice(i, i + chunkSize);
            if (chunkLines.length === 0) break;
            const chunkText = chunkLines.join('\n');
            const lowercaseText = chunkText.toLowerCase();

            let score = 0;
            let matchedKeys = 0;
            if (queryWords.length > 0) {
              queryWords.forEach(word => {
                let pos = lowercaseText.indexOf(word);
                let count = 0;
                while (pos !== -1) {
                  count++;
                  pos = lowercaseText.indexOf(word, pos + word.length);
                }
                if (count > 0) {
                  // Reward query word occurrence and length
                  score += count * (word.length / 3);
                  matchedKeys++;
                }
              });

              if (matchedKeys > 1) {
                // Boost for consecutive key matches to favor cohesive context
                score *= (1 + 0.6 * matchedKeys);
              }
            } else {
              // fall back score
              score = 1;
            }

            allChunks.push({
              fileName: doc.name,
              text: chunkText,
              startLine: i + 1,
              endLine: Math.min(i + chunkLines.length, lines.length),
              score,
              index: globalChunkIndex++
            });

            if (i + chunkSize >= lines.length) break;
          }
        });

        // Rank chunks by highest relevance score
        const ranked = [...allChunks].sort((a, b) => b.score - a.score);
        const bestScore = ranked[0]?.score || 0;

        const maxTotalExcerptChars = 8000;
        const selected: SearchedChunk[] = [];
        let accumulatedLength = 0;

        if (bestScore > 0) {
          for (const chunk of ranked) {
            if (chunk.score === 0 && selected.length > 0) break;
            if (accumulatedLength + chunk.text.length > maxTotalExcerptChars) {
              if (selected.length === 0) selected.push(chunk);
              break;
            }
            selected.push(chunk);
            accumulatedLength += chunk.text.length;
          }
        }

        // If no matches found, fallback to selecting top/initial chunks of files to keep overview
        if (selected.length === 0) {
          for (const chunk of allChunks) {
            if (accumulatedLength + chunk.text.length > maxTotalExcerptChars) {
              if (selected.length === 0) selected.push(chunk);
              break;
            }
            selected.push(chunk);
            accumulatedLength += chunk.text.length;
          }
        }

        // Re-sort selected chunks by their file index for logical reading order
        selected.sort((a, b) => {
          if (a.fileName === b.fileName) {
            return a.index - b.index;
          }
          return a.fileName.localeCompare(b.fileName);
        });

        // Merge contiguous chunk selections to minimize visual segmentation
        const formattedMerged: string[] = [];
        let currentMerge: { fileName: string; text: string; startLine: number; endLine: number; index: number } | null = null;

        selected.forEach(chunk => {
          if (!currentMerge) {
            currentMerge = { ...chunk };
          } else if (currentMerge.fileName === chunk.fileName && chunk.startLine <= currentMerge.endLine + 1) {
            const chunkLines = chunk.text.split('\n');
            const overlapCount = currentMerge.endLine - chunk.startLine + 1;
            const nonOverlapLines = overlapCount > 0 ? chunkLines.slice(overlapCount) : chunkLines;
            currentMerge.text = [...currentMerge.text.split('\n'), ...nonOverlapLines].join('\n');
            currentMerge.endLine = chunk.endLine;
          } else {
            formattedMerged.push(`--- File: ${currentMerge.fileName} (Lines ${currentMerge.startLine}-${currentMerge.endLine}) ---\n${currentMerge.text}`);
            currentMerge = { ...chunk };
          }
        });

        if (currentMerge) {
          formattedMerged.push(`--- File: ${(currentMerge as any).fileName} (Lines ${(currentMerge as any).startLine}-${(currentMerge as any).endLine}) ---\n${(currentMerge as any).text}`);
        }

        mergedExcerpts = formattedMerged.join('\n\n... [Truncated sections hidden to conserve context] ...\n\n');

        // Calculate approximate keyword coverage percentage across entire corpus
        let matchedKeysGlobal = 0;
        if (queryWords.length > 0) {
          queryWords.forEach(word => {
            const matched = docs.some(d => d.content.toLowerCase().includes(word));
            if (matched) matchedKeysGlobal++;
          });
          percentMatched = Math.round((matchedKeysGlobal / queryWords.length) * 100);
        } else {
          percentMatched = 100;
        }

        const totalDocLength = docs.reduce((acc, d) => acc + d.content.length, 0);
        totalSkippedChars = Math.max(0, totalDocLength - accumulatedLength);

        updateScratchpad('Local Fuzzy Matcher', `Indexed ${allChunks.length} chunks across ${docs.length} files. Extracted top relevant subsections with ${percentMatched}% of fuzzy keyword overlap. Saved ~${Math.round(totalSkippedChars / 4)} tokens of potential context bloat.`);
        addThinkingStep('Context Reducer', `Reduced context payload by ${Math.round((totalSkippedChars / (totalDocLength || 1)) * 100)}%! Prioritized only the most relevant passages for fast, accurate generation.`);
      } else {
        addThinkingStep('Fuzzy Matcher', 'No attached files to extract chunks from. Passing standard message history to the query model.');
        updateScratchpad('Local Fuzzy Matcher', 'No external documents found. Prompt evaluated cleanly against standard session context.');
      }

      addThinkingStep('Big Model', 'Generating response focusing on the optimized factual matching sections...');
      
      let optimizedPrompt = prompt;
      if (docs.length > 0) {
        optimizedPrompt = `[DOCUMENT ANALYZER - DETECTED MATCHES (${percentMatched}% Relevance)]
The user has attached some files. Our high-performance fuzzy indexing has extracted the most relevant paragraphs/lines for your query as follows:

=== RELEVANT CONTEXT EXCERPTS ===
${mergedExcerpts}
=================================

Please use this precise local reference context to give a thorough, reliable, and perfectly factual answer to the client's request. Mention filenames/line ranges if appropriate.

User Original Request: ${prompt}`;
      }

      let analyzerRetryCount = 0;
      const maxAnalyzerRetries = 3;
      const lastMessage = history[history.length - 1];
      let analyzerMessages = [
        ...history.slice(0, -1), // Include context prior to the last user message
        { 
          role: 'user', 
          content: optimizedPrompt,
          attachedImages: lastMessage?.attachedImages || [],
          attachedFiles: lastMessage?.attachedFiles || []
        }
      ];

      while (analyzerRetryCount <= maxAnalyzerRetries) {
        const startTime = Date.now();
        const chunks = await getCompletion(analyzerMessages, { temperature: 0.7, stream: true, modelOverride }) as any;

        let finalizedContent = '';
        let chunkCount = 0;
        let lastUpdateTime = Date.now();
        for await (const chunk of chunks) {
          const delta = chunk.choices[0]?.delta?.content || '';
          finalizedContent += delta;
          chunkCount++;
          
          const now = Date.now();
          const throttleLimit = document.hidden ? 1500 : 50;
          if (now - lastUpdateTime > throttleLimit || chunkCount === 1) {
            lastUpdateTime = now;

            const modelThinkingText = extractModelThinking(finalizedContent);
            if (modelThinkingText !== null) {
              const thinkingTextClean = modelThinkingText.trim();
              const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
              if (existingStepIdx !== -1) {
                localThinkingSteps[existingStepIdx].text = thinkingTextClean;
              } else {
                localThinkingSteps.push({ agent: 'Model Thinking', text: thinkingTextClean });
              }
              setThinkingProcess([...localThinkingSteps]);
            }

            updateAssistantMessage(finalizedContent, localThinkingSteps, currentScratchpad);
          }
        }

        finalizedContent = ensureClosedThinkingTags(finalizedContent);

        const finalModelThinkingText = extractModelThinking(finalizedContent);
        if (finalModelThinkingText !== null) {
          const thinkingTextClean = finalModelThinkingText.trim();
          const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
          if (existingStepIdx !== -1) {
            localThinkingSteps[existingStepIdx].text = thinkingTextClean;
          } else {
            localThinkingSteps.push({ agent: 'Model Thinking', text: thinkingTextClean });
          }
          setThinkingProcess([...localThinkingSteps]);
        }

        const endTime = Date.now();
        const durationSec = (endTime - startTime) / 1000;
        finalTps = durationSec > 0 ? (finalizedContent.length / 4) / durationSec : 0;

        currentPrompt = finalizedContent;
        updateScratchpad('Big Model', currentPrompt);
        updateAssistantMessage(currentPrompt, localThinkingSteps, currentScratchpad);
        break;
      }
    } else {
      // Standard flow
      while (attempts < (infinitySettings.enabled ? infinitySettings.maxAttempts : 1) && !isApproved) {
        await waitForResume();
        attempts++;
        agentOutputs = [];
        
        const orch = agents.find(a => a.id === 'orch')!;
        addThinkingStep(orch.name, `Analyzing request and planning tasks... ${attempts > 1 ? `(Attempt ${attempts})` : ''}`);
        const orchResponse = await getCompletion([
          { role: 'system', content: `${orch.systemPrompt}\n\nOriginal User Request: ${prompt}\n\nAvailable Skills:\n${skillPrompt}` },
          ...history,
          { role: 'user', content: currentPrompt }
        ], { temperature: 0.3, modelOverride: orch.modelId || modelOverride }) as any;
        const plan = orchResponse.choices[0].message.content || '';
        agentOutputs.push({ name: orch.name, content: plan });
        updateScratchpad(orch.name, plan);

        let intermediateContext = `Original Request: ${prompt}\n\nPlan: ${plan}`;
        const workers = activeAgents.filter(a => !['orch', 'auditor', 'finalizer'].includes(a.id));
        
        for (const agent of workers) {
          await waitForResume();
          addThinkingStep(agent.name, `Executing task...`);
          const response = await getCompletion([
            { role: 'system', content: `${agent.systemPrompt}\n\nOriginal User Request: ${prompt}\n\nAvailable Skills:\n${skillPrompt}` },
            ...history,
            { role: 'user', content: intermediateContext }
          ], { temperature: settings.temperature, modelOverride: agent.modelId || modelOverride }) as any;
          let content = response.choices[0].message.content || '';

          agentOutputs.push({ name: agent.name, content });
          updateScratchpad(agent.name, content);
          intermediateContext = `Original Request: ${prompt}\n\nPlan: ${plan}\n\nPrevious Agent (${agent.name}) Output: ${content}`;
        }

        const auditor = agents.find(a => a.id === 'auditor');
        if (auditor && auditor.enabled) {
          addThinkingStep(auditor.name, `Reviewing outputs (Strictness: ${settings.criticStrictness}/10)...`);
          const auditResponse = await getCompletion([
            { role: 'system', content: `${auditor.systemPrompt}\n\nOriginal User Request: ${prompt}\n\nStrictness: ${settings.criticStrictness}/10. Respond with "APPROVED" if good, otherwise provide feedback starting with "REJECT:".` },
            { role: 'user', content: `Original User Request: ${prompt}\n\nReview these outputs against the original request:\n${agentOutputs.map(o => `${o.name}: ${o.content}`).join('\n\n')}` }
          ], { temperature: 0.2, modelOverride: auditor.modelId || modelOverride }) as any;
          const auditContent = auditResponse.choices[0].message.content || '';
          agentOutputs.push({ name: auditor.name, content: auditContent });
          updateScratchpad(auditor.name, auditContent);
          
          if (auditContent.toUpperCase().includes('APPROVED') || !infinitySettings.enabled) {
            isApproved = true;
          } else {
            currentPrompt = `Feedback from Auditor: ${auditContent}\n\nOriginal Request: ${prompt}`;
          }
        } else {
          isApproved = true;
        }
      }

      const finalizer = agents.find(a => a.id === 'finalizer')!;
      let finalizerRetryCount = 0;
      const maxFinalizerRetries = 3;

      let finalizerMessages: any[] = [
        { role: 'system', content: `${finalizer.systemPrompt}\n\nOriginal User Request: ${prompt}\n\n${imageGenDirective}\n\nAvailable Skills:\n${skillPrompt}` },
        { role: 'user', content: `Original User Request: ${prompt}\n\nCombine these agent outputs into a final response for the user:\n${agentOutputs.map(o => `${o.name}: ${o.content}`).join('\n\n')}` }
      ];

      while (finalizerRetryCount <= maxFinalizerRetries) {
        addThinkingStep(finalizer.name, `Synthesizing final response...`);
        const startTime = Date.now();
        const chunks = await getCompletion(finalizerMessages, { temperature: settings.temperature, stream: true, modelOverride: finalizer.modelId || modelOverride }) as any;
        
        let finalizedContent = '';
        let chunkCount = 0;
        let lastUpdateTime = Date.now();
        for await (const chunk of chunks) {
          const delta = chunk.choices[0]?.delta?.content || '';
          finalizedContent += delta;
          chunkCount++;
          
          const now = Date.now();
          const throttleLimit = document.hidden ? 1500 : 50;
          if (now - lastUpdateTime > throttleLimit || chunkCount === 1) {
            lastUpdateTime = now;

            const modelThinkingText = extractModelThinking(finalizedContent);
            if (modelThinkingText !== null) {
              const thinkingTextClean = modelThinkingText.trim();
              const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
              if (existingStepIdx !== -1) {
                localThinkingSteps[existingStepIdx].text = thinkingTextClean;
              } else {
                localThinkingSteps.push({ agent: 'Model Thinking', text: thinkingTextClean });
              }
              setThinkingProcess([...localThinkingSteps]);
            }

            updateAssistantMessage(finalizedContent, localThinkingSteps, currentScratchpad);
          }
        }

        finalizedContent = ensureClosedThinkingTags(finalizedContent);

        const finalModelThinkingText = extractModelThinking(finalizedContent);
        if (finalModelThinkingText !== null) {
          const thinkingTextClean = finalModelThinkingText.trim();
          const existingStepIdx = localThinkingSteps.findIndex(s => s.agent === 'Model Thinking');
          if (existingStepIdx !== -1) {
            localThinkingSteps[existingStepIdx].text = thinkingTextClean;
          } else {
            localThinkingSteps.push({ agent: 'Model Thinking', text: thinkingTextClean });
          }
          setThinkingProcess([...localThinkingSteps]);
        }

        const endTime = Date.now();
        currentPrompt = finalizedContent;
        const durationSec = (endTime - startTime) / 1000;
        finalTps = durationSec > 0 ? (currentPrompt.length / 4) / durationSec : 0;
        updateScratchpad(finalizer.name, currentPrompt);
        updateAssistantMessage(currentPrompt, localThinkingSteps, currentScratchpad);
        break;
      }
    }

    // Checker agent verification pass
    let checkedPrompt = currentPrompt;
    const checker = agents.find(a => a.id === 'checker');
    if (checker && checker.enabled) {
      addThinkingStep(checker.name, `Verifying if the synthesized output directly, fully, and accurately resolves the original user prompt...`);
      const checkerModelOverride = checker.modelId || modelOverride;
      try {
        const checkerResponse = await getCompletion([
          { role: 'system', content: `${checker.systemPrompt}\n\nOriginal User Request: ${prompt}` },
          { role: 'user', content: `Original User Request: ${prompt}\n\nFinal Synthesized Output:\n${currentPrompt}\n\nTask: Carefully review if the Final Synthesized Output directly, fully, and accurately resolves the Original User Request. If it is high-quality and directly answers the prompt, output the exact finalized response content verbatim (do not add any meta-commentary, introduction, or headers; keep it completely identical so we maintain the formatted output fully). If there is a missing detail, wrong interpretation, or if it doesn't answer the prompt, rewrite or append/polish the response so it is fully and directly answering the prompt.` }
        ], { temperature: 0.2, modelOverride: checkerModelOverride }) as any;
        const checkerOutput = checkerResponse.choices[0].message.content || '';
        
        if (checkerOutput.trim()) {
          checkedPrompt = checkerOutput;
          updateScratchpad(checker.name, checkedPrompt);
          addThinkingStep(checker.name, `Response verified and polished successfully.`);
        }
      } catch (err) {
        console.error("Checker agent failed:", err);
        addThinkingStep('Prompt Checker', `Skipping checker verification due to an error.`);
      }
    }

    // Final result is what the user wants
    const finalContent = checkedPrompt;

    const finalMsg: Message = {
      role: 'assistant',
      content: finalContent.trim(),
      timestamp: Date.now(),
      tps: finalTps,
      contextTokens,
      contextLimit,
      modelId: modelOverride,
      thinkingSteps: localThinkingSteps,
      scratchpad: currentScratchpad
    };

    updateAssistantMessage(finalMsg.content, localThinkingSteps, currentScratchpad);
    
    // Save to DB
    const finalChatData = {
      ...chat,
      messages: [...chat.messages, finalMsg]
    };

    setChats(prev => prev.map(c => {
      if (c.id === chat.id) {
        return {
          ...c,
          messages: [...c.messages.slice(0, -1), finalMsg]
        };
      }
      return c;
    }));
    
    const savedChat = {
      ...chat,
      messages: [...chat.messages, finalMsg]
    };
    await saveChat(savedChat as Chat);
    
    // Parse any programmatically generated skill/memory directives
    await processAIToolsDirectives(finalMsg.content);

    // Background memory extraction
    triggerBackgroundMemoryReflection(chat.id, prompt, finalMsg.content);
    
    if (settings.imageGenerationEnabled) {
      await handleModelTriggeredImageGen(chat.id, currentPrompt, savedChat as Chat, addThinkingStep);
    }
  };

  const currentChat = chats.find(c => c.id === currentChatId);

  const newestUserPromptTimestamp = useMemo(() => {
    const userMessages = currentChat?.messages?.filter(m => m.role === 'user') || [];
    return userMessages.length > 0 ? userMessages[userMessages.length - 1].timestamp : null;
  }, [currentChat?.messages]);

  const newestAssistantTimestamp = useMemo(() => {
    const assistantMessages = currentChat?.messages?.filter(m => m.role === 'assistant') || [];
    return assistantMessages.length > 0 ? assistantMessages[assistantMessages.length - 1].timestamp : null;
  }, [currentChat?.messages]);

  const markdownComponents = useMemo(() => ({
    table({children}: any) {
      return (
        <div className="w-full my-4 overflow-x-auto rounded-xl border border-border bg-card">
          <table className="w-full text-xs text-left border-collapse">
            {children}
          </table>
        </div>
      );
    },
    thead({children}: any) {
      return <thead className="bg-muted/50 border-b border-border">{children}</thead>;
    },
    tbody({children}: any) {
      return <tbody className="divide-y divide-border/50">{children}</tbody>;
    },
    tr({children}: any) {
      return <tr className="hover:bg-muted/20 transition-colors">{children}</tr>;
    },
    th({children}: any) {
      return <th className="px-4 py-3 font-bold text-muted-foreground uppercase tracking-wider text-[10px]">{children}</th>;
    },
    td({children}: any) {
      return <td className="px-4 py-3 text-foreground leading-relaxed font-normal">{children}</td>;
    },
    pre({children}: any) {
      return <div className="not-prose my-4">{children}</div>;
    },
    p({children}: any) {
      return <div className="mb-4 last:mb-0 leading-relaxed">{children}</div>;
    },
    li({children}: any) {
      return <li className="mb-1">{children}</li>;
    },
    ul({children}: any) {
      return <ul className="list-disc pl-6 mb-4 space-y-1">{children}</ul>;
    },
    ol({children}: any) {
      return <ol className="list-decimal pl-6 mb-4 space-y-1">{children}</ol>;
    },
    blockquote({children}: any) {
      return <blockquote className="border-l-4 border-primary/20 pl-4 italic my-4 text-muted-foreground">{children}</blockquote>;
    },
    h1({children}: any) { return <h1 className="text-2xl font-black tracking-tighter mb-4 mt-6">{children}</h1>; },
    h2({children}: any) { return <h2 className="text-xl font-bold tracking-tight mb-3 mt-5">{children}</h2>; },
    h3({children}: any) { return <h3 className="text-lg font-bold mb-2 mt-4">{children}</h3>; },
    img({node, ...props}: any) {
      const [dims, setDims] = useState<string | null>(null);
      if (!props.src || props.src === 'undefined' || props.src === 'null') return null;
      
      const isPlot = props.alt === 'Plot';
      
      if (isPlot) {
        return (
          <div className="my-6 rounded-2xl overflow-hidden border border-border bg-zinc-900 shadow-xl overflow-hidden">
             <div className="px-4 py-2 bg-zinc-800/50 border-b border-border flex items-center gap-2">
               <Monitor className="w-3.5 h-3.5 text-zinc-500" />
               <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Python Visualization</span>
             </div>
             <div className="p-6 bg-white flex items-center justify-center min-h-[300px]">
               <img 
                 {...props} 
                 className="max-w-full h-auto rounded-lg shadow-lg" 
                 referrerPolicy="no-referrer"
               />
             </div>
          </div>
        );
      }

      return (
        <div className="my-6 flex flex-col items-center w-full">
          <div className="rounded-xl overflow-hidden border border-border bg-muted/5 shadow-md group relative transition-all max-h-[50vh] flex items-center justify-center">
            <img 
              {...props} 
              className="max-w-full max-h-[50vh] h-auto object-contain block transition-transform group-hover:scale-[1.02]" 
              referrerPolicy="no-referrer"
              onLoad={(e) => setDims(`${e.currentTarget.naturalWidth} × ${e.currentTarget.naturalHeight}`)}
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center pointer-events-none">
               <span className="text-[10px] font-mono font-bold text-white uppercase tracking-widest bg-black/60 px-3 py-1.5 rounded-full border border-white/10 backdrop-blur-md mb-2">
                 {dims || 'Media Preview'}
               </span>
               <button 
                 onClick={(e) => {
                   e.stopPropagation();
                   downloadImage(props.src || '');
                 }}
                 className="p-2 bg-white/20 hover:bg-white/40 rounded-full text-white backdrop-blur-md transition-all hover:scale-110 pointer-events-auto shadow-lg"
                 title="Download Image"
               >
                 <Download className="w-5 h-5" />
               </button>
            </div>
          </div>
        </div>
      );
    },
    code({node, className, children, ...props}: any) {
      const match = /language-(\w+)/.exec(className || '')
      const isInline = !className;
      const code = String(children).replace(/\n$/, '');
      
      const isPatch = code.includes('<<<<') && code.includes('====') && code.includes('>>>>');
      
      if (!isInline && match && match[1] === 'python_tool') {
        return (
          <CodeBlock 
            code={code} 
            language="python" 
            props={props} 
            setActiveCodePreview={() => setActiveCodePreview({ 
              code: isPatch ? workspaceCode : code, 
              language: 'python' 
            })} 
            isGenerating={isGenerating}
            onSaveToFile={handleSaveToFile}
            onFixError={(error: string, code: string) => {
              const fixPrompt = `I encountered an error while running this Python code:\n\n\`\`\`\n${error}\n\`\`\`\n\nOriginal Code:\n\`\`\`python\n${code}\n\`\`\`\n\nPlease debug and fix the error. Return the corrected code.`;
              handleSendMessage(fixPrompt);
            }}
          />
        );
      }

      return !isInline && match ? (
              <CodeBlock 
                code={code} 
                language={match[1]} 
                props={props} 
                setActiveCodePreview={(params: any) => {
                  if (params && params.isPatch) {
                    const fullCode = applyWorkspacePatch(workspaceCode, code);
                    setWorkspaceCode(fullCode);
                    setActiveCodePreview({ code: fullCode, language: match[1] });
                  } else {
                    setActiveCodePreview(params || { code, language: match[1] });
                  }
                }} 
                isGenerating={isGenerating}
                onSaveToFile={handleSaveToFile}
                onFixError={(error: string, code: string) => {
                  const fixPrompt = `I encountered an error while running this code:\n\n\`\`\`\n${error}\n\`\`\`\n\nOriginal Code:\n\`\`\`${match[1]}\n${code}\n\`\`\`\n\nPlease debug and fix the error. Return the corrected code.`;
                  handleSendMessage(fixPrompt);
                }}
        />
      ) : (
        <code className={className} {...props}>
          {children}
        </code>
      )
    }
  }), [executeTool, downloadImage, handleSendMessage, isGenerating, workspaceCode]);

  const handleTutorialComplete = async () => {
    setShowTutorial(false);
    const updatedSettings = { ...settings, hasSeenTutorial: true };
    setSettings(updatedSettings);
    await saveSettings(updatedSettings);
  };

  const activeCatalogModel = getModelInfo(settings.puterModel || '');
  const isWebLlmModel = activeCatalogModel.provider === 'webllm';
  const webLlmModelId = activeCatalogModel.catalogModel?.id;
  const isWebLlmLoaded = isWebLlmModel && engineLoadedModelId === webLlmModelId && !!(window as any)._webLlmEngine;

  if (currentPath === '/github') {
    return (
      <GitHubIntegration 
        onBackToChat={() => {
          window.history.pushState(null, '', '/chat');
          setCurrentPath('/chat');
        }}
        theme={theme}
      />
    );
  }

  if (!isLaunched) {
    return (
      <>
        <EulaModal onAccept={() => {}} />
        <LandingPage 
          onLaunch={() => {
            window.history.pushState(null, '', '/chat');
            setIsLaunched(true);
          }} 
        />
      </>
    );
  }

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans relative">
      <EulaModal onAccept={() => {}} />
      <SyncConflictModal 
        isOpen={pendingSync !== null}
        onResolve={handleResolveSyncConflict}
        localCount={pendingSync?.local.length || 0}
        remoteCount={pendingSync?.remote.length || 0}
      />
      <HelpCompanion />
      <AnimatePresence>
        {showTutorial && (
          <Tutorial 
            onComplete={handleTutorialComplete} 
            isSidebarOpen={isSidebarOpen}
            setIsSidebarOpen={setIsSidebarOpen}
            isSettingsOpen={isSettingsOpen}
            setIsSettingsOpen={setIsSettingsOpen}
            isModelOrganizerOpen={isModelOrganizerOpen}
            setIsModelOrganizerOpen={setIsModelOrganizerOpen}
          />
        )}
      </AnimatePresence>
      <GlobalOverlay isVisible={isSidebarOpen && isMobile} onClick={() => setIsSidebarOpen(false)} />

      <AnimatePresence>
        {speechErrorNotice && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 50 }}
            className="fixed bottom-6 right-6 z-[200] max-w-sm p-4 bg-slate-900 border border-amber-500/40 rounded-2xl shadow-2xl backdrop-blur-md"
          >
            <div className="flex gap-3">
              <div className="p-2 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-xl h-fit">
                <AlertCircle className="w-5 h-5 animate-pulse" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-100">
                    Read Aloud Notice
                  </h4>
                  <button 
                    onClick={() => setSpeechErrorNotice(null)}
                    className="text-slate-400 hover:text-white p-0.5 rounded cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mt-1.5">
                  {speechErrorNotice}
                </p>
                <div className="mt-3 flex gap-2">
                  <a 
                    href={window.location.href}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex-1 py-1.5 px-3 bg-primary text-primary-foreground text-center text-xs font-bold rounded-lg hover:opacity-90 transition-opacity"
                  >
                    Open in New Tab
                  </a>
                  <button 
                    onClick={() => setSpeechErrorNotice(null)}
                    className="py-1.5 px-3 bg-slate-800 text-slate-300 text-xs font-bold rounded-lg hover:bg-slate-700 border border-slate-700 transition-all cursor-pointer"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <BootScreen isBooting={isBooting} />

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-[50] lg:relative lg:z-0 transition-transform duration-300 ease-in-out",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0 lg:w-0"
      )}>
        <DragOverlay 
          isDragging={isDragging}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        />

      <Sidebar 
          chats={chats}
          files={files}
          currentChatId={currentChatId}
          onSelectChat={(id) => {
            handleSelectChat(id);
            if (isMobile) setIsSidebarOpen(false);
          }}
          onNewChat={() => {
            handleNewChat();
            if (isMobile) setIsSidebarOpen(false);
          }}
          onDeleteChat={handleDeleteChat}
          onClearAll={handleClearAll}
          isOpen={isSidebarOpen}
          setIsOpen={setIsSidebarOpen}
          onExportChat={handleExportChat}
          onExportAllChats={handleExportAllChats}
          onImportAllChats={handleImportAllChats}
          theme={theme}
          setTheme={setTheme}
          onOpenModelTesting={() => setIsTestingOpen(true)}
          onOpenPythonPlayground={() => setIsPythonPlaygroundOpen(true)}
          onOpenWebSandbox={() => setIsWebSandboxOpen(true)}
          onOpenGitHub={() => {
            window.history.pushState(null, '', '/github');
            setCurrentPath('/github');
            setIsLaunched(true);
          }}
          onOpenAllChats={() => setIsAllChatsOpen(true)}
          onSelectFile={(file) => setActivePreviewFile(file)}
          onDeleteFile={handleDeleteFile}
          onOpenMemories={() => setIsMemoryManagerOpen(true)}
          onOpenSkills={() => setIsSkillsManagerOpen(true)}
          onTogglePinFile={handleTogglePinFile}
          onStartTutorial={() => setShowTutorial(true)}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-row relative h-full overflow-hidden">
        <div className={cn(
          "flex flex-col h-full transition-all duration-500 relative min-w-0",
          activeCodePreview ? "w-full lg:w-1/2" : "w-full"
        )}>
          {/* Header */}
          <Header 
            isSidebarOpen={isSidebarOpen}
            setIsSidebarOpen={setIsSidebarOpen}
            currentChat={currentChat}
            currentChatId={currentChatId}
            isMobile={isMobile}
            settings={settings}
            setIsModelOrganizerOpen={setIsModelOrganizerOpen}
            setIsSettingsOpen={setIsSettingsOpen}
            setIsMemoryManagerOpen={setIsMemoryManagerOpen}
            handleDeleteChat={handleDeleteChat}
            isDriveConnected={isDriveConnected}
            isDriveSessionExpired={isDriveSessionExpired}
            onConnectDrive={handleConnectDrive}
            isSyncingDrive={isSyncingDrive}
            syncIndicatorStatus={syncIndicatorStatus}
          />

          {/* Chat Area */}
          <main 
            ref={scrollRef}
            className="flex-1 overflow-y-auto p-4 space-y-6 scroll-smooth relative custom-scrollbar"
          >
            {!currentChatId ? (
              <WelcomeScreen onNewChat={handleNewChat} />
            ) : (
            <>
              {currentChat?.messages.map((msg, i) => {
                const fontSizeClass = 
                  settings.chatFontSize === 'sm' ? 'text-xs md:text-[13px]' : 
                  settings.chatFontSize === 'lg' ? 'text-base md:text-[17px]' : 
                  'text-sm md:text-[15px]';
                const fontFamilyClass = 
                  settings.chatFontFamily === 'mono' ? 'font-mono' : 
                  settings.chatFontFamily === 'serif' ? 'font-serif' : 
                  'font-sans';
                const densityClass = 
                  settings.chatDensity === 'spacious' ? 'p-5 sm:p-6' : 
                  'p-3 sm:p-4';

                return (
                  <div key={`${msg.timestamp}-${i}`} className={cn(
                    "flex gap-4 max-w-3xl mx-auto",
                    msg.role === 'user' ? "flex-row-reverse" : "flex-row"
                  )}>
                    <div className={cn(
                      "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 shadow-sm",
                      msg.role === 'user' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                    )}>
                      {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
                    </div>
                    <div className={cn(
                      "flex flex-col gap-1 max-w-[85%] min-w-0 relative group/msg-outer",
                      msg.role === 'user' ? "items-end" : "items-start"
                    )}>
                      <div className={cn(
                        "rounded-2xl leading-relaxed shadow-sm relative break-words min-w-[60px] max-w-full",
                        fontSizeClass,
                        fontFamilyClass,
                        densityClass,
                        msg.role === 'user' ? "bg-primary text-primary-foreground rounded-tr-none" : "bg-card border border-border rounded-tl-none"
                      )}>
                        {(Boolean(msg.imageUrl?.trim()) || msg.isImageLoading) && (
                          <div className="mb-4 flex flex-col items-center w-full">
                          <div 
                            className={cn(
                              "rounded-xl overflow-hidden border border-border bg-muted/5 shadow-sm relative group/img transition-all",
                              msg.isImageLoading && "animate-pulse"
                            )}
                            style={msg.imageWidth ? { 
                              aspectRatio: `${msg.imageWidth} / ${msg.imageHeight}`,
                              width: '100%',
                              maxWidth: `min(100%, ${(msg.imageWidth / msg.imageHeight) * 50}vh, ${msg.imageWidth}px)`,
                              maxHeight: '50vh'
                            } : { width: '100px', height: '100px' }}
                          >
                            {msg.isImageLoading ? (
                              <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/30 backdrop-blur-[4px] overflow-hidden">
                                {/* Grid Background */}
                                <div className="absolute inset-0 bg-[linear-gradient(rgba(var(--primary),0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(var(--primary),0.05)_1px,transparent_1px)] bg-[size:32px_32px] opacity-20" />
                                
                                {/* Scanning Effect */}
                                <motion.div 
                                  animate={{ top: ["-10%", "110%", "-10%"] }}
                                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                                  className="absolute inset-x-0 h-24 bg-gradient-to-b from-transparent via-primary/20 to-transparent z-10 pointer-events-none"
                                />
                                <motion.div 
                                  animate={{ top: ["0%", "100%", "0%"] }}
                                  transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                                  className="absolute inset-x-0 h-[1px] bg-primary/50 shadow-[0_0_10px_rgba(110,231,183,0.5)] z-10"
                                />

                                {/* Center Content (Simplified for 100x100) */}
                                <div className="relative z-20 flex flex-col items-center">
                                  <div className="relative">
                                    <motion.div 
                                      animate={{ rotate: 360 }}
                                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                                      className="w-10 h-10 rounded-full border-2 border-primary/20 border-t-primary shadow-[0_0_15px_rgba(var(--primary),0.3)]"
                                    />
                                    <Sparkles className="w-4 h-4 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                                  </div>
                                </div>

                                {/* Corners UI elements (Simplified) */}
                                <div className="absolute top-2 left-2 w-2 h-2 border-t border-l border-primary/30" />
                                <div className="absolute top-2 right-2 w-2 h-2 border-t border-r border-primary/30" />
                                <div className="absolute bottom-2 left-2 w-2 h-2 border-b border-l border-primary/30" />
                                <div className="absolute bottom-2 right-2 w-2 h-2 border-b border-r border-primary/30" />
                              </div>
                            ) : (
                              <>
                                <img 
                                  src={msg.imageUrl || null} 
                                  alt="Generated" 
                                  className="w-full h-full object-contain block transition-transform group-hover/img:scale-[1.02]"
                                  referrerPolicy="no-referrer"
                                  onLoad={(e) => {
                                    if (currentChatId) {
                                      handleImageMeasure(currentChatId, msg.timestamp, e.currentTarget.naturalWidth, e.currentTarget.naturalHeight);
                                    }
                                  }}
                                />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex flex-col items-center justify-center">
                                  <span className="text-[10px] font-mono font-bold text-white uppercase tracking-widest bg-black/60 px-3 py-1.5 rounded-full border border-white/10 backdrop-blur-md mb-2 pointer-events-none">
                                    {msg.imageWidth} × {msg.imageHeight}
                                  </span>
                                  <button 
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      downloadImage(msg.imageUrl || '', `accelerated-logic-${msg.timestamp}.png`);
                                    }}
                                    className="p-2 bg-white/20 hover:bg-white/40 rounded-full text-white backdrop-blur-md transition-all hover:scale-110 shadow-lg"
                                    title="Download Image"
                                  >
                                    <Download className="w-5 h-5" />
                                  </button>
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      )}
                      {msg.role === 'assistant' && (msg.thinkingSteps?.length || msg.scratchpad) && mode !== 'single' && (
                        <div className="mb-4 border border-border rounded-xl overflow-hidden bg-muted/20">
                          <button 
                            onClick={(e) => {
                              const details = e.currentTarget.nextElementSibling as HTMLElement;
                              details.classList.toggle('hidden');
                            }}
                            className="w-full flex items-center justify-between p-3 bg-muted/40 font-semibold text-xs hover:bg-muted/60 transition-colors"
                          >
                            <div className="flex items-center gap-2">
                              <BrainCircuit className="w-4 h-4 text-primary" />
                              Detailed Thinking Process
                            </div>
                            <ChevronDown className="w-3 h-3" />
                          </button>
                          <div className="hidden p-4 space-y-4 border-t border-border bg-card/50">
                            {msg.thinkingSteps && msg.thinkingSteps.length > 0 && (
                              <div className="space-y-3">
                                <h4 className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Execution Steps</h4>
                                <div className="space-y-2">
                                  {msg.thinkingSteps.map((step, idx) => (
                                    <div key={idx} className="flex gap-3 text-xs">
                                      <div className="shrink-0 w-1.5 h-1.5 rounded-full bg-primary/40 mt-1.5" />
                                      <div className="space-y-1">
                                        <span className="font-bold text-primary">{step.agent}:</span>
                              <div className="text-muted-foreground leading-relaxed">{step.text}</div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            {msg.scratchpad && (
                              <div className="space-y-2 pt-2 border-t border-border/50">
                                <h4 className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Internal Scratchpad (What AI Sees)</h4>
                                <pre className="text-[10px] font-mono bg-muted p-3 rounded-lg overflow-x-auto custom-scrollbar whitespace-pre-wrap text-muted-foreground border border-border/50">
                                  {msg.scratchpad}
                                </pre>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {msg.role === 'assistant' && msg.thinking && (
                        <div className="mb-3 border border-primary/10 rounded-2xl overflow-hidden bg-muted/5 select-text">
                          <button 
                            onClick={(e) => {
                              const details = e.currentTarget.nextElementSibling as HTMLElement;
                              details.classList.toggle('hidden');
                              const icon = e.currentTarget.querySelector('.chevron-icon');
                              if (icon) {
                                icon.classList.toggle('rotate-180');
                              }
                            }}
                            className="w-full flex items-center justify-between p-3 bg-muted/10 hover:bg-muted/15 transition-colors text-xs font-bold text-muted-foreground border-b border-border/10"
                          >
                            <div className="flex items-center gap-2">
                              <Brain className="w-4 h-4 text-primary animate-pulse" />
                              <span className="uppercase tracking-wider text-[10px] sm:text-xs">Model Thinking Trace</span>
                            </div>
                            <ChevronUp className="chevron-icon w-4 h-4 text-muted-foreground/60 transition-transform duration-200" />
                          </button>
                          <div className="p-4 bg-muted/5 text-xs text-muted-foreground font-sans leading-relaxed italic whitespace-pre-wrap border-t border-border/5 text-left select-text">
                            {msg.thinking}
                          </div>
                        </div>
                      )}

                      {(cleanMessage(msg.content) || /<(?:thinking|think|thought)/i.test(msg.content) || (msg.role === 'assistant' && isGenerating && i === (currentChat?.messages?.length || 0) - 1)) && (
                        <div className="flex flex-col w-full">
                          {editingMessageId === msg.timestamp ? (
                            <div className="space-y-2 w-full">
                              <textarea
                                value={editingContent}
                                onChange={(e) => setEditingContent(e.target.value)}
                                className={cn(
                                  "w-full bg-muted/50 border border-primary/20 rounded-xl p-3 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[100px] resize-none",
                                  msg.role === 'user' ? "text-primary-foreground placeholder:text-primary-foreground/50" : "text-foreground"
                                )}
                                autoFocus
                              />
                              <div className="flex justify-end gap-2">
                                <button 
                                  onClick={() => setEditingMessageId(null)}
                                  className={cn(
                                    "px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all",
                                    msg.role === 'user' ? "text-primary-foreground/70 hover:bg-white/10" : "text-muted-foreground hover:bg-muted"
                                  )}
                                >
                                  Cancel
                                </button>
                                <button 
                                  onClick={() => handleUpdateMessage(msg.timestamp, editingContent)}
                                  className={cn(
                                    "px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all shadow-sm",
                                    msg.role === 'user' ? "bg-white text-primary hover:bg-white/90" : "bg-primary text-primary-foreground hover:bg-primary/90"
                                  )}
                                >
                                  Save Changes
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="markdown-body">
                              {/* If content is completely empty and generating, show fancy inline typing feedback */}
                              {msg.role === 'assistant' && !msg.content && isGenerating && i === (currentChat?.messages?.length || 0) - 1 ? (
                                <div className="flex flex-col gap-2 py-1 select-none">
                                  <div className="flex items-center gap-1.5 text-xs text-primary font-bold tracking-tight animate-pulse">
                                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                    <span>Accelerated Logic is typing...</span>
                                  </div>
                                  <div className="flex items-center gap-1.5 mt-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '0ms' }} />
                                    <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '150ms' }} />
                                    <span className="w-1.5 h-1.5 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '300ms' }} />
                                  </div>
                                </div>
                              ) : (
                                <ReactMarkdown 
                                  remarkPlugins={[remarkMath, remarkGfm]} 
                                  rehypePlugins={[[rehypeKatex, { output: 'html', throwOnError: false }]]}
                                  components={markdownComponents}
                                >
                                  {cleanMessage(msg.content)}
                                </ReactMarkdown>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Display attached files/images specifically submitted with this prompt */}
                      {msg.attachedFiles && msg.attachedFiles.length > 0 && (
                        <div className={cn(
                          "flex flex-wrap gap-2 mt-3 pt-3 border-t w-full",
                          msg.role === 'user' ? "border-primary-foreground/15" : "border-border/60"
                        )}>
                          {msg.attachedFiles.map((file) => (
                            <div 
                              key={file.id}
                              onClick={() => setActivePreviewFile(file)}
                              className={cn(
                                "flex items-center gap-2 rounded-xl p-2 text-xs shrink-0 cursor-pointer transition-all border shadow-[0_1px_2px_rgba(0,0,0,0.05)]",
                                msg.role === 'user' 
                                  ? "bg-white/10 hover:bg-white/20 border-white/5 text-white" 
                                  : "bg-muted/30 hover:bg-muted/60 border-border text-foreground hover:border-primary/50"
                              )}
                            >
                              <div className={cn(
                                "w-6 h-6 rounded-lg flex items-center justify-center shrink-0 overflow-hidden",
                                msg.role === 'user' ? "bg-white/15 text-white" : "bg-card text-primary"
                              )}>
                                {file.type.startsWith('image/') ? (
                                  file.content.startsWith('data:') || file.content.startsWith('http') ? (
                                    <img src={file.content} className="w-full h-full object-cover rounded-lg" referrerPolicy="no-referrer" alt="" />
                                  ) : (
                                    <ImageIcon className="w-3.5 h-3.5" />
                                  )
                                ) : file.type.startsWith('video/') ? (
                                  file.content.startsWith('data:') || file.content.startsWith('http') ? (
                                    <video src={file.content} className="w-full h-full object-cover rounded-lg" muted playsInline />
                                  ) : (
                                    <Video className="w-3.5 h-3.5" />
                                  )
                                ) : (
                                  <FileText className="w-3.5 h-3.5" />
                                )}
                              </div>
                              <div className="flex flex-col min-w-0 pr-1 select-none">
                                <span className="text-[10px] font-bold truncate max-w-[120px] leading-tight text-left">{file.name}</span>
                                <span className={cn(
                                  "text-[8px] font-mono text-left",
                                  msg.role === 'user' ? "text-white/60" : "text-muted-foreground/80"
                                )}>
                                  {file.type.startsWith('image/') ? 'Image/Vision' : file.type.startsWith('video/') ? 'Video/Clip' : 'Context Document'}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                    </div>
                      {/* Unified Message Controls under the Prompt or Response */}
                      {msg.role === 'user' && (
                        <div className="flex items-center gap-3.5 mt-2 px-1 opacity-0 group-hover/msg-outer:opacity-100 transition-opacity flex-wrap justify-end">
                          {msg.timestamp === newestUserPromptTimestamp && (
                            <Tooltip content="Fork Conversation from here" position="top">
                              <button 
                                onClick={() => handleBranchChat(msg.timestamp)}
                                className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-indigo-400 transition-colors"
                              >
                                <GitBranch className="w-3 h-3" />
                                Fork
                              </button>
                            </Tooltip>
                          )}

                          <Tooltip content="Copy Message" position="top">
                            <button 
                              onClick={() => navigator.clipboard.writeText(msg.content)}
                              className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-primary transition-colors"
                            >
                              <Copy className="w-3 h-3" />
                              Copy
                            </button>
                          </Tooltip>

                          {msg.timestamp === newestUserPromptTimestamp && (
                            <Tooltip content="Edit Message" position="top">
                              <button 
                                onClick={() => {
                                  setEditingMessageId(msg.timestamp);
                                  setEditingContent(msg.content);
                                }}
                                className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-primary transition-colors"
                              >
                                <Pencil className="w-3 h-3" />
                                Edit
                              </button>
                            </Tooltip>
                          )}

                          <Tooltip content="Delete Message" position="top">
                            <button 
                              onClick={() => handleDeleteMessage(msg.timestamp)}
                              className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-destructive transition-colors"
                            >
                              <Trash2 className="w-3 h-3" />
                              Delete
                            </button>
                          </Tooltip>
                        </div>
                      )}

                      {msg.role === 'assistant' && (
                        <div className="flex items-center gap-3.5 mt-2 px-1 opacity-0 group-hover/msg-outer:opacity-100 transition-opacity flex-wrap justify-start">
                          <Tooltip content="Request a new response" position="top">
                            <button 
                              onClick={() => handleRegenerate(msg)}
                              className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-primary transition-colors"
                            >
                              <RotateCcw className="w-3 h-3" />
                              Regenerate
                            </button>
                          </Tooltip>

                          <div className="relative">
                            <Tooltip content="Change the AI model used for this response" position="top">
                              <button 
                                onClick={() => {
                                  setMessageModelMenuId(messageModelMenuId === msg.timestamp.toString() ? null : msg.timestamp.toString());
                                }}
                                className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-primary transition-colors"
                              >
                                <Cpu className="w-3 h-3" />
                                Model: {(() => {
                                  const modelInfo = getModelInfo(msg.modelId || '');
                                  return modelInfo.catalogModel?.name || modelInfo.modelId || 'Gemini 3.5 Flash';
                                })()}
                              </button>
                            </Tooltip>
                            
                            <AnimatePresence>
                              {messageModelMenuId === msg.timestamp.toString() && (
                                <motion.div 
                                  initial={{ opacity: 0, y: 5 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, y: 5 }}
                                  className="absolute bottom-full left-0 mb-2 w-48 sm:w-64 bg-card border border-border rounded-xl shadow-2xl z-50 overflow-hidden"
                                >
                                  <div className="px-3 py-2 text-[9px] font-black uppercase tracking-wider border-b border-border/40 bg-muted/30 flex items-center justify-between text-muted-foreground select-none">
                                    <span>Active Model</span>
                                    <span className="text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-bold">
                                      {(() => {
                                        const { catalogModel, modelId } = getModelInfo(msg.modelId || '');
                                        return catalogModel?.name || modelId || 'Gemini 3.5 Flash';
                                      })()}
                                    </span>
                                  </div>
                                  <div className="p-1">
                                    <div className="px-3 py-1.5 text-[8px] font-bold uppercase tracking-widest text-muted-foreground opacity-50 border-b border-border/50 mb-1">Equipped Models</div>
                                    
                                    <div className="max-h-60 overflow-y-auto p-1 space-y-1 custom-scrollbar">
                                      {(settings.enabledChatModels || []).length > 0 ? (
                                        <>
                                          {(settings.enabledChatModels || []).map(equippedId => {
                                            const { provider, modelId, catalogModel: model } = getModelInfo(equippedId);
                                            
                                            if (!model) return null;

                                            return (
                                              <button
                                                key={equippedId}
                                                onClick={() => {
                                                  const updated = {...settings, puterModel: equippedId};
                                                  setSettings(updated);
                                                  saveSettings(updated);
                                                  setMessageModelMenuId(null);
                                                  handleRegenerate(msg, equippedId);
                                                }}
                                                className={cn(
                                                  "w-full text-left p-2 rounded-xl text-[10px] sm:text-xs transition-all flex items-center gap-3",
                                                  settings.puterModel === equippedId 
                                                    ? "bg-primary/10 text-primary border border-primary/20 shadow-sm" 
                                                    : "hover:bg-accent text-muted-foreground hover:text-foreground border border-transparent"
                                                )}
                                              >
                                                <div className={cn(
                                                  "w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-transform group-hover:scale-105",
                                                  settings.puterModel === equippedId
                                                    ? "bg-primary text-primary-foreground shadow-sm shadow-primary/20" 
                                                    : "bg-muted text-muted-foreground"
                                                )}>
                                                  <Cpu className="w-3.5 h-3.5" />
                                                </div>
                                                <div className="flex flex-col min-w-0 text-left">
                                                  <div className="flex items-center gap-1.5 min-w-0">
                                                    <span className="font-bold truncate">{model.name}</span>
                                                    {settings.puterModel === equippedId && <Check className="w-3 h-3 shrink-0" />}
                                                  </div>
                                                  {(() => {
                                                    const prov = provider;
                                                    const displayProv = prov === 'google' ? 'Gemini API' : prov === 'webllm' ? 'WebLLM' : prov === 'ollama' ? 'Ollama' : prov === 'openai' ? 'OpenAI Compatible' : 'Puter.js';
                                                    return (
                                                    <span className={cn(
                                                      "text-[7.5px] font-bold uppercase tracking-tighter px-1.5 py-0.5 rounded border inline-block w-fit mt-0.5",
                                                      prov === 'webllm'
                                                        ? "bg-purple-500/10 text-purple-500 border-purple-500/20"
                                                        : prov === 'google'
                                                        ? "bg-orange-500/10 text-orange-500 border-orange-500/10"
                                                        : prov === 'openai'
                                                        ? "bg-violet-500/10 text-violet-500 border-violet-500/20"
                                                        : "bg-blue-500/10 text-blue-500 border-blue-500/10"
                                                    )}>
                                                      {displayProv}
                                                    </span>
                                                    );
                                                  })()}
                                                </div>
                                              </button>
                                            );
                                          })}
                                        </>
                                      ) : (
                                        <div className="p-4 text-center">
                                          <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-2">No Models Equipped</div>
                                          <button 
                                            onClick={() => {
                                              setMessageModelMenuId(null);
                                              setIsModelOrganizerOpen(true);
                                            }}
                                            className="px-3 py-1.5 bg-primary/10 text-primary hover:bg-primary/20 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-colors w-full"
                                          >
                                            Configure AI
                                          </button>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>

                          <Tooltip content={(isSpeaking && speakingMessageId === msg.timestamp) ? "Stop Speaking" : "Read Aloud"} position="top">
                            <button 
                              onClick={() => (isSpeaking && speakingMessageId === msg.timestamp) ? stopSpeaking() : speak(msg.content.replace(/<(?:thinking|think)>[\s\S]*?<\/(?:thinking|think)>/, ''), msg.timestamp)}
                              className={cn(
                                "flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter transition-colors",
                                (isSpeaking && speakingMessageId === msg.timestamp) ? "text-primary hover:text-primary" : "text-muted-foreground hover:text-primary"
                              )}
                            >
                              {(isSpeaking && speakingMessageId === msg.timestamp) ? (
                                <>
                                  <VolumeX className="w-3 h-3 animate-pulse" />
                                  <span>Stop Aloud</span>
                                  <div className="flex items-center gap-[1px] h-3 ml-1">
                                    <span className="w-[1.5px] h-2.5 bg-primary rounded-full soundwave-bar" style={{ animationDelay: '0.1s' }} />
                                    <span className="w-[1.5px] h-3 bg-primary rounded-full soundwave-bar" style={{ animationDelay: '0.3s' }} />
                                    <span className="w-[1.5px] h-2 bg-primary rounded-full soundwave-bar" style={{ animationDelay: '0.5s' }} />
                                    <span className="w-[1.5px] h-3.5 bg-primary rounded-full soundwave-bar" style={{ animationDelay: '0.2s' }} />
                                    <span className="w-[1.5px] h-1.5 bg-primary rounded-full soundwave-bar" style={{ animationDelay: '0.4s' }} />
                                  </div>
                                </>
                              ) : (
                                <>
                                  <Volume2 className="w-3 h-3" />
                                  <span>Read Aloud</span>
                                </>
                              )}
                            </button>
                          </Tooltip>

                          <Tooltip content="Copy Message" position="top">
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText(msg.content);
                              }}
                              className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-primary transition-colors"
                            >
                              <Copy className="w-3 h-3" />
                              Copy
                            </button>
                          </Tooltip>

                          <Tooltip content="Delete Message" position="top">
                            <button 
                              onClick={() => handleDeleteMessage(msg.timestamp)}
                              className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-destructive transition-colors"
                            >
                              <Trash2 className="w-3 h-3" />
                              Delete
                            </button>
                          </Tooltip>

                          {msg.timestamp === newestAssistantTimestamp && (
                            <Tooltip content="Fork Conversation from here" position="top">
                              <button 
                                onClick={() => handleBranchChat(msg.timestamp)}
                                className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground hover:text-indigo-400 transition-colors"
                              >
                                <GitBranch className="w-3 h-3" />
                                Fork
                              </button>
                            </Tooltip>
                          )}

                          {msg.tps && (
                            <Tooltip content="Tokens Per Second (Estimated generation speed)" position="top">
                              <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground cursor-help">
                                <Activity className="w-3 h-3" />
                                {msg.tps.toFixed(1)} TPS
                              </div>
                            </Tooltip>
                          )}

                          {msg.contextTokens && msg.contextLimit && (
                            <Tooltip content={`Context Used: ${msg.contextTokens.toLocaleString()} / ${msg.contextLimit.toLocaleString()} tokens`} position="top">
                              <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-tighter text-muted-foreground cursor-help">
                                <Layers className="w-3 h-3" />
                                {((msg.contextTokens / msg.contextLimit) * 100).toFixed(2)}% Context
                              </div>
                            </Tooltip>
                          )}
                        </div>
                      )}
                    <span className="text-[10px] text-muted-foreground px-1 mt-1">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              );
            })}
              
              {isGenerating && (
                <div className="flex gap-4 max-w-3xl mx-auto">
                  <div className="flex flex-col gap-2 w-full pl-12">
                    {/* Thinking Process removed as requested */}
                  </div>
                </div>
              )}
              <div className="h-20" /> {/* Spacer */}
              <AnimatePresence>
                {showScrollBottom && (
                  <motion.button
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    onClick={scrollToBottom}
                    className={cn(
                      "fixed bottom-32 p-3 bg-primary text-primary-foreground rounded-full shadow-xl z-30 hover:scale-110 transition-transform",
                      "right-8"
                    )}
                  >
                    <ChevronDown className="w-5 h-5" />
                  </motion.button>
                )}
              </AnimatePresence>
            </>
          )}
        </main>

        <div 
          className="p-4 bg-gradient-to-t from-background via-background to-transparent relative z-20"
        >
          <div className="max-w-3xl mx-auto relative">
            {/* Ollama Connection Error Banner */}
            {settings.provider === 'ollama' && isTryingToUseOllama && ollamaConnectionStatus === 'error' && (
              <div id="ollama-disconnection-warning" className="mb-4 p-4 text-xs bg-amber-500/10 border border-amber-500/20 rounded-2xl text-amber-700 dark:text-amber-400 font-sans space-y-3 shadow-sm transition-all animate-in fade-in slide-in-from-bottom-2">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-sm block text-amber-800 dark:text-amber-200">Local Ollama is Disconnected</span>
                      <span className="text-[11px] leading-relaxed block text-muted-foreground/80 dark:text-muted-foreground mt-0.5">
                        Unable to reach your local Ollama server at <code className="font-mono bg-muted/60 px-1 py-0.5 rounded text-foreground">{settings.ollamaUrl || 'http://127.0.0.1:11434'}</code>. Ensure Ollama is running on your computer.
                      </span>
                    </div>
                  </div>
                  <button 
                    onClick={async () => {
                      setOllamaConnectionStatus('checking');
                      const ollamaUrl = settings.ollamaUrl || 'http://127.0.0.1:11434';
                      try {
                        const res = await fetch(`${ollamaUrl}/api/tags`, { method: 'GET' });
                        if (res.ok) {
                          setOllamaConnectionStatus('connected');
                        } else {
                          setOllamaConnectionStatus('error');
                        }
                      } catch (e) {
                        setOllamaConnectionStatus('error');
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 active:scale-95 transition-all rounded-xl text-[10px] font-bold tracking-wider text-amber-700 dark:text-amber-300 uppercase shrink-0"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Retry Check
                  </button>
                </div>
                
                <div className="bg-background/40 hover:bg-background/60 p-3 rounded-xl border border-border/40 text-[11px] space-y-2 transition-all">
                  <div className="font-semibold text-foreground flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-primary" />
                    How to Enable Local Connection & Fix CORS:
                  </div>
                  <p className="text-muted-foreground leading-relaxed">
                    Modern browsers restrict cross-origin (CORS) requests by default. To allow this web-app preview to communicate with your desktop, you MUST start Ollama with CORS allowed:
                  </p>
                  <div className="space-y-1.5 pt-1.5">
                    <div>
                      <span className="font-semibold text-foreground/80 block mb-0.5">Mac / Linux Terminal:</span>
                      <code className="bg-background px-2 py-1 rounded block font-mono text-[10px] select-all border border-border text-foreground overflow-x-auto whitespace-nowrap">
                        OLLAMA_ORIGINS="*" ollama serve
                      </code>
                    </div>
                    <div>
                      <span className="font-semibold text-foreground/80 block mb-0.5">Windows PowerShell:</span>
                      <code className="bg-background px-2 py-1 rounded block font-mono text-[10px] select-all border border-border text-foreground overflow-x-auto whitespace-nowrap">
                        $env:OLLAMA_ORIGINS="*" ; ollama serve
                      </code>
                    </div>
                    <div>
                      <span className="font-semibold text-foreground/80 block mb-0.5">Windows Command Prompt (cmd):</span>
                      <code className="bg-background px-2 py-1 rounded block font-mono text-[10px] select-all border border-border text-foreground overflow-x-auto whitespace-nowrap">
                        set OLLAMA_ORIGINS=* && ollama serve
                      </code>
                    </div>
                  </div>
                  <p className="text-[10px] text-muted-foreground italic leading-normal pt-1 flex items-start gap-1">
                    <span>⚠</span> 
                    <span>
                      If you get a "bind: address already in use" error, it means Ollama is already running in the background. Right-click the Ollama tray icon, click <strong>Quit Ollama</strong>, then rerun the command above.
                    </span>
                  </p>
                </div>
              </div>
            )}

            {/* Attached Files Pop-up Area relocated inline into the Composer area */}

            {/* Agent Box */}
            <AnimatePresence>
              {isAgentBoxOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 20, scale: 0.95 }}
                  className="absolute bottom-full mb-4 w-full bg-card border border-border rounded-3xl shadow-2xl p-6 z-20 max-h-[calc(100vh-250px)] overflow-y-auto custom-scrollbar"
                >
                  <div className="flex items-center justify-between mb-4">
                    <ModeSelector 
                      mode={mode}
                      setMode={setMode}
                      infinityEnabled={infinitySettings.enabled}
                      setInfinityEnabled={(enabled) => setInfinitySettings(prev => ({ ...prev, enabled }))}
                      enabledModelsCount={settings.enabledChatModels?.length || 1}
                      onOpenSettings={() => {
                        if (infinitySettings.enabled) {
                          setIsInfinityOpen(!isInfinityOpen);
                        } else if (mode === 'multi') {
                          setIsAgentBoxOpen(!isAgentBoxOpen);
                        } else {
                          setIsSettingsOpen(!isSettingsOpen);
                        }
                      }}
                    />
                    <button onClick={() => setIsAgentBoxOpen(false)} className="p-1 hover:bg-muted rounded-md">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                    <div className="space-y-4">
                      {/* Presets and custom presets controls */}
                      <div className="space-y-3 pb-3 border-b border-border/80">
                        <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-muted-foreground mr-1">
                          <span className="flex items-center gap-1"><Layers className="w-3.5 h-3.5 text-primary" /> Preset Architectures</span>
                          <div className="flex items-center gap-3">
                            <button 
                              onClick={() => {
                                setNewPresetName('');
                                setIsSavingPreset(!isSavingPreset);
                              }}
                              className="flex items-center gap-1 text-primary hover:text-primary-foreground bg-primary/10 hover:bg-primary px-2 py-0.5 rounded transition-all"
                            >
                              <Bookmark className="w-3 h-3" />
                              {isSavingPreset ? 'Cancel' : 'Save Preset'}
                            </button>
                            <button 
                              onClick={handleAddAgent}
                              className="hover:text-primary transition-colors flex items-center gap-1 text-muted-foreground"
                            >
                              <Plus className="w-3 h-3" />
                              Add Agent
                            </button>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-1.5 items-center">
                          {(Object.keys(AGENT_PRESETS) as Array<keyof typeof AGENT_PRESETS>).map(preset => (
                            <button 
                              key={preset}
                              onClick={() => applyPreset(preset)}
                              className="px-2.5 py-1 bg-muted hover:bg-accent hover:text-accent-foreground border border-border/40 rounded-lg text-[10px] font-bold uppercase tracking-tight whitespace-nowrap transition-all"
                            >
                              {preset}
                            </button>
                          ))}
                        </div>

                        {/* Save custom preset form */}
                        <AnimatePresence>
                          {isSavingPreset && (
                            <motion.div 
                              initial={{ opacity: 0, height: 0, y: -5 }}
                              animate={{ opacity: 1, height: 'auto', y: 0 }}
                              exit={{ opacity: 0, height: 0, y: -5 }}
                              className="bg-muted/10 border border-dashed border-primary/20 rounded-xl p-2 flex items-center gap-1.5 overflow-hidden"
                            >
                              <input 
                                type="text"
                                placeholder="Enter custom preset name..."
                                value={newPresetName}
                                onChange={(e) => setNewPresetName(e.target.value)}
                                className="flex-1 bg-background border border-border rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-primary font-medium"
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' && newPresetName.trim()) {
                                    handleSavePreset(newPresetName);
                                  }
                                }}
                              />
                              <button 
                                onClick={() => handleSavePreset(newPresetName)}
                                disabled={!newPresetName.trim()}
                                className="px-3 py-1 bg-primary text-primary-foreground font-semibold rounded-lg text-xs hover:bg-primary/95 disabled:opacity-50 transition-all flex items-center gap-1 shrink-0"
                              >
                                <Check className="w-3.5 h-3.5" />
                                Save
                              </button>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        {/* Custom presets list */}
                        {Object.keys(customPresets).length > 0 && (
                          <div className="space-y-1.5 pt-1 border-t border-dashed border-border/60">
                            <span className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground block">My Custom Presets</span>
                            <div className="flex flex-wrap gap-1.5 items-center">
                              {Object.entries(customPresets).map(([name, presetAgents]) => (
                                <div 
                                  key={name} 
                                  className="group flex items-center gap-1 pl-2.5 pr-1.5 py-1 bg-primary/10 hover:bg-primary/15 border border-primary/20 text-primary rounded-md text-[10px] font-bold uppercase tracking-tighter transition-colors max-w-full"
                                >
                                  <button 
                                    onClick={() => applyCustomPreset(name)}
                                    className="truncate text-primary"
                                    title={`Load preset "${name}"`}
                                  >
                                    {name}
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleDeletePreset(name);
                                    }}
                                    className="p-0.5 rounded hover:bg-red-500/10 hover:text-red-500 transition-colors"
                                    title={`Delete preset "${name}"`}
                                  >
                                    <X className="w-2.5 h-2.5" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between bg-muted/30 p-3 rounded-xl border border-border">
                        <div className="flex flex-col gap-0.5">
                          <div className="flex items-center gap-2">
                            <Zap className="w-3.5 h-3.5 text-primary" />
                            <span className="text-xs font-bold uppercase tracking-tight">Auto Smart Router</span>
                          </div>
                          <span className="text-[10px] text-muted-foreground">Selects specialized agents automatically based on your prompt</span>
                        </div>
                        <button 
                          onClick={() => setAutoRouteEnabled(!autoRouteEnabled)}
                          className={cn(
                            "w-12 h-6 rounded-full transition-all relative",
                            autoRouteEnabled ? "bg-primary" : "bg-muted"
                          )}
                        >
                          <motion.div 
                            animate={{ x: autoRouteEnabled ? 24 : 2 }}
                            transition={{ type: "spring", stiffness: 500, damping: 30 }}
                            className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-sm"
                          />
                        </button>
                      </div>

                      {mode === 'multi' ? (
                        <>
                        <div className="mb-4">
                          <AgentPipelineFlow 
                            agents={agents} 
                            onSelectAgent={handleEditAgent} 
                          />
                        </div>
                        <Reorder.Group 
                          axis="y" 
                          values={agents} 
                          onReorder={setAgents}
                          className="flex flex-col gap-3 pr-2"
                        >
                          {agents.map(agent => (
                            <AgentNode 
                              key={agent.id} 
                              agent={agent} 
                              onToggle={() => {
                                if (agent.isFixed) return;
                                setAgents(agents.map(a => a.id === agent.id ? { ...a, enabled: !a.enabled } : a));
                              }}
                              onEdit={() => handleEditAgent(agent)}
                              onDelete={() => {
                                if (agent.isFixed) return;
                                setAgents(agents.filter(a => a.id !== agent.id));
                              }}
                              onCountChange={(count) => {
                                if (agent.isFixed) return;
                                setAgents(agents.map(a => a.id === agent.id ? { ...a, count } : a));
                              }}
                            />
                          ))}
                        </Reorder.Group>
                        </>
                      ) : (
                        <div className="p-8 text-center space-y-2 bg-muted/30 rounded-2xl border border-dashed border-border">
                          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary mx-auto mb-2">
                            <User className="w-6 h-6" />
                          </div>
                          <h3 className="font-bold">Standard Mode</h3>
                          <p className="text-xs text-muted-foreground">The model will respond directly to your prompt. Switch to Multi-Agent for complex workflows.</p>
                        </div>
                      )}
                    </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Prompt Queue Manager */}
            {(queuedPrompts.length > 0 || lastFailedQueueItem !== null) && (
              <div id="prompt-queue-manager" className="mb-3 bg-card border border-border rounded-2xl p-4 shadow-md space-y-3 font-sans animate-in slide-in-from-bottom-2 duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold font-mono">
                      {queuedPrompts.length}
                    </div>
                    <span className="text-xs font-extrabold uppercase tracking-widest text-foreground">
                      Prompt Queue Manager
                    </span>
                    
                    {/* Status badges */}
                    {lastFailedQueueItem !== null ? (
                      <span className="text-[9px] font-black uppercase tracking-widest bg-destructive/10 text-destructive border border-destructive/20 px-2 py-0.5 rounded">
                        Halted
                      </span>
                    ) : isQueuePaused ? (
                      <span className="text-[9px] font-black uppercase tracking-widest bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded">
                        Paused
                      </span>
                    ) : (
                      <span className="text-[9px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-2 py-0.5 rounded animate-pulse">
                        Active
                      </span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-3">
                    {/* Pause / Play controls */}
                    {lastFailedQueueItem === null && (
                      <button
                        onClick={() => setIsQueuePaused(p => !p)}
                        className="p-1 hover:bg-muted rounded text-muted-foreground hover:text-foreground transition-all flex items-center gap-1 text-[10px] uppercase font-bold"
                        title={isQueuePaused ? "Resume Queue" : "Pause Queue"}
                      >
                        {isQueuePaused ? (
                          <>
                            <Play className="w-3 h-3 text-emerald-500 animate-pulse" />
                            <span className="text-emerald-500">Resume</span>
                          </>
                        ) : (
                          <>
                            <Pause className="w-3 h-3 text-amber-500" />
                            <span className="text-amber-500">Pause</span>
                          </>
                        )}
                      </button>
                    )}
                    
                    <button 
                      onClick={() => {
                        setQueuedPrompts([]);
                        setLastFailedQueueItem(null);
                        setIsQueuePaused(false);
                      }}
                      className="text-[10px] font-bold text-destructive hover:underline tracking-wider uppercase"
                    >
                      Clear All
                    </button>
                  </div>
                </div>
                
                {/* Last Failed Item Warning & Control Panel */}
                {lastFailedQueueItem !== null && (
                  <div className="bg-destructive/5 border border-destructive/20 p-3.5 rounded-xl space-y-3">
                    <div className="flex items-start gap-2 text-xs">
                      <AlertCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <p className="font-extrabold text-destructive uppercase tracking-wide text-[10px]">Queue Process Blocked</p>
                        <p className="text-muted-foreground text-[11px] leading-relaxed">
                          The following prompt execution threw an error. Choose to retry this item or skip:
                        </p>
                        <blockquote className="bg-background/60 p-2.5 rounded-lg text-xs italic font-mono border-l-2 border-destructive/40 text-foreground break-all whitespace-pre-wrap">
                          "{lastFailedQueueItem.text}"
                        </blockquote>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap items-center justify-end gap-2 pt-1 border-t border-destructive/15">
                      <button
                        onClick={() => {
                          setLastFailedQueueItem(null);
                          setIsQueuePaused(false);
                        }}
                        className="px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground hover:bg-muted border border-border rounded-lg transition-all"
                      >
                        Discard Prompt
                      </button>
                      <button
                        onClick={() => {
                          const failed = lastFailedQueueItem;
                          setLastFailedQueueItem(null);
                          setIsQueuePaused(false);
                          // Re-insert at the start of original queue
                          setQueuedPrompts(prev => [failed, ...prev]);
                        }}
                        className="px-3 py-1.5 text-[10px] font-black uppercase text-white bg-destructive hover:bg-destructive/90 rounded-lg transition-all flex items-center gap-1 shadow-sm"
                      >
                        <RefreshCw className="w-3 h-3" />
                        Retry Prompt
                      </button>
                    </div>
                  </div>
                )}
                
                {/* Backoff Countdown Status */}
                {backoffCountdown !== null && lastFailedQueueItem === null && (
                  <div className="flex items-center gap-2 bg-primary/5 text-primary border border-primary/20 px-3 py-2 rounded-xl text-xs font-medium animate-pulse">
                    <div className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                    </div>
                    <span>
                      Prompt queue backoff active: sending next query in <strong className="font-mono">{backoffCountdown}s</strong>...
                    </span>
                  </div>
                )}
                
                {queuedPrompts.length > 0 && (
                  <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                    {queuedPrompts.map((item, idx) => {
                      const isEditing = editingQueueId === item.id;
                      return (
                        <div 
                          key={item.id} 
                          className={cn(
                            "group/queue flex items-start gap-2.5 p-2.5 rounded-xl border transition-all text-xs",
                            isEditing 
                              ? "bg-primary/5 border-primary/40 shadow-sm" 
                              : "bg-muted/10 border-border/40 hover:bg-muted/30 hover:border-border"
                          )}
                        >
                          <div className="w-5 h-5 rounded-md bg-muted text-muted-foreground flex items-center justify-center text-[10px] font-semibold shrink-0 mt-0.5 select-none font-mono">
                            #{idx + 1}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            {isEditing ? (
                              <div className="space-y-2">
                                <textarea
                                  value={editingQueueText}
                                  onChange={(e) => setEditingQueueText(e.target.value)}
                                  className="w-full bg-background border border-border rounded-lg p-2 text-xs font-sans focus:outline-none focus:ring-1 focus:ring-primary/40 min-h-[60px] resize-none"
                                />
                                <div className="flex justify-end gap-1.5">
                                  <button
                                    onClick={() => setEditingQueueId(null)}
                                    className="px-2 py-1 text-[10px] font-bold text-muted-foreground hover:bg-muted rounded"
                                  >
                                    Cancel
                                  </button>
                                  <button
                                    onClick={() => {
                                      setQueuedPrompts(prev => prev.map(p => p.id === item.id ? { ...p, text: editingQueueText } : p));
                                      setEditingQueueId(null);
                                    }}
                                    className="px-2.5 py-1 text-[10px] font-bold bg-primary text-primary-foreground rounded shadow-sm hover:scale-[1.02] active:scale-[0.98] transition-transform"
                                  >
                                    Save
                                  </button>
                                </div>
                              </div>
                            ) : (
                              <div className="space-y-1 text-left">
                                <p className="text-foreground leading-normal break-words whitespace-pre-wrap">
                                  {item.text}
                                </p>
                                {item.attachedFiles && item.attachedFiles.length > 0 && (
                                  <div className="flex flex-wrap gap-1 mt-1.5">
                                    {item.attachedFiles.map(file => (
                                      <div key={file.id} className="flex items-center gap-1 bg-background border border-border/80 px-1.5 py-0.5 rounded text-[9px] text-muted-foreground">
                                        {file.type.startsWith('image/') ? <ImageIcon className="w-2.5 h-2.5" /> : <FileText className="w-2.5 h-2.5" />}
                                        <span className="truncate max-w-[80px]">{file.name}</span>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>

                          {!isEditing && (
                            <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover/queue:opacity-100 transition-opacity">
                              {/* Reordering Controls */}
                              <div className="flex flex-col mr-1">
                                <button
                                  disabled={idx === 0}
                                  onClick={() => {
                                    if (idx === 0) return;
                                    setQueuedPrompts(prev => {
                                      const next = [...prev];
                                      const temp = next[idx];
                                      next[idx] = next[idx - 1];
                                      next[idx - 1] = temp;
                                      return next;
                                    });
                                  }}
                                  className="p-0.5 hover:bg-muted text-muted-foreground rounded transition-all disabled:opacity-35"
                                  title="Move Up"
                                >
                                  <ChevronUp className="w-3 h-3" />
                                </button>
                                <button
                                  disabled={idx === queuedPrompts.length - 1}
                                  onClick={() => {
                                    if (idx === queuedPrompts.length - 1) return;
                                    setQueuedPrompts(prev => {
                                      const next = [...prev];
                                      const temp = next[idx];
                                      next[idx] = next[idx + 1];
                                      next[idx + 1] = temp;
                                      return next;
                                    });
                                  }}
                                  className="p-0.5 hover:bg-muted text-muted-foreground rounded transition-all disabled:opacity-35"
                                  title="Move Down"
                                >
                                  <ChevronDown className="w-3 h-3" />
                                </button>
                              </div>
                              
                              <button
                                onClick={() => {
                                  setEditingQueueId(item.id);
                                  setEditingQueueText(item.text);
                                }}
                                className="p-1 hover:bg-muted text-muted-foreground hover:text-foreground rounded transition-all"
                                title="Edit Prompt"
                              >
                                <Pencil className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  setQueuedPrompts(prev => prev.filter(p => p.id !== item.id));
                                }}
                                className="p-1 hover:bg-destructive/10 text-muted-foreground hover:text-destructive rounded transition-all"
                                title="Delete Prompt"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* Prompt Input */}
            <div id="tour-composer" className="bg-card border border-border rounded-2xl shadow-xl focus-within:ring-2 focus-within:ring-primary/20 transition-all relative">
              <div className="flex items-center gap-0.5 sm:gap-1 p-1.5 sm:p-2 border-b border-border bg-muted/30 overflow-visible">
                <div id="tour-mode-selector">
                  <ModeSelector 
                    mode={mode}
                    setMode={setMode}
                    infinityEnabled={infinitySettings.enabled}
                    setInfinityEnabled={(enabled) => setInfinitySettings(prev => ({ ...prev, enabled }))}
                    enabledModelsCount={settings.enabledChatModels?.length || 1}
                    onOpenSettings={() => {
                      if (infinitySettings.enabled) {
                        setIsInfinityOpen(!isInfinityOpen);
                      } else if (mode === 'multi') {
                        setIsAgentBoxOpen(!isAgentBoxOpen);
                      } else {
                        setIsSettingsOpen(!isSettingsOpen);
                      }
                    }}
                  />
                </div>
                <div className="h-4 w-px bg-border mx-0.5 sm:mx-1 shrink-0" />
                
                {/* Chat Model Selector */}
                <div id="tour-model-dropdown" className="relative shrink-0 text-white">
                  <button 
                    onClick={() => setActiveModelMenu(activeModelMenu === 'chat' ? null : 'chat')}
                    className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-primary/5 hover:bg-primary/10 border border-primary/20 hover:border-primary/40 transition-all h-8 sm:h-9 group relative overflow-hidden shrink-0"
                  >
                    <div className="w-5 h-5 rounded-lg bg-primary flex items-center justify-center text-primary-foreground shadow-sm shadow-primary/20 shrink-0">
                      <Sparkles className="w-3 h-3" />
                    </div>
                    <div className="flex flex-col items-start leading-none min-w-0">
                      <span className="max-w-[80px] sm:max-w-[120px] truncate font-bold text-[9px] sm:text-[10px]">
                        {settings.puterModel === 'auto' ? 'Auto Select' : (getModelInfo(settings.puterModel || '').catalogModel?.name || settings.puterModel || 'Select AI')}
                      </span>
                      <span className="text-[7px] sm:text-[8px] uppercase tracking-widest font-black text-muted-foreground/60 group-hover:text-primary transition-colors">
                        {(() => {
                           if (settings.puterModel === 'auto') return 'Transformers.js';
                           const prov = getModelInfo(settings.puterModel || '').provider;
                           return prov === 'google' ? 'Gemini API' : prov === 'webllm' ? 'WebLLM' : prov === 'ollama' ? 'Ollama' : prov === 'openai' ? 'OpenAI' : 'Puter.js';
                        })()}
                      </span>
                    </div>
                    <ChevronDown className={cn("w-3 h-3 transition-transform text-muted-foreground/50 group-hover:text-foreground", activeModelMenu === 'chat' && "rotate-180")} />
                  </button>
                  
                  <AnimatePresence>
                    {activeModelMenu === 'chat' && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute bottom-full left-0 mb-2 w-48 sm:w-64 bg-card border border-border rounded-xl shadow-2xl z-50 overflow-hidden"
                      >
                        <div className="p-1">
                          <div className="px-3 py-2 flex items-center justify-between border-b border-border/50 mb-1">
                            <span className="text-[8px] font-bold uppercase tracking-widest text-muted-foreground opacity-50">AI Models</span>
                          </div>
                          
                          <div className="max-h-60 overflow-y-auto p-1 space-y-1 custom-scrollbar">
                            {(settings.enabledChatModels || []).filter(id => {
                              if (!modelSearchQuery) return true;
                              const { modelId, catalogModel } = getModelInfo(id);
                              const name = catalogModel?.name || modelId || '';
                              return name.toLowerCase().includes(modelSearchQuery.toLowerCase());
                            }).length > 0 ? (
                              <>
                                <div className="px-3 py-1 text-[7px] font-black uppercase tracking-tighter text-muted-foreground/40">Equipped Models</div>
                                {(settings.enabledChatModels || []).filter(id => {
                                  if (!modelSearchQuery) return true;
                                  const { modelId, catalogModel } = getModelInfo(id);
                                  const name = catalogModel?.name || modelId || '';
                                  return name.toLowerCase().includes(modelSearchQuery.toLowerCase());
                                }).map(equippedId => {
                                  const { provider, modelId, catalogModel: model } = getModelInfo(equippedId);
                                  const displayName = model?.name || modelId;
                                  const isWebLlm = provider === 'webllm';
                                  const isActuallyLoaded = engineLoadedModelId === modelId;

                                  return (
                                    <div key={equippedId} className="group/item relative">
                                      <button
                                        onClick={() => {
                                          const updated = {...settings, puterModel: equippedId};
                                          setSettings(updated);
                                          saveSettings(updated);
                                          setActiveModelMenu(null);
                                        }}
                                        className={cn(
                                          "w-full text-left p-2 rounded-xl text-[10px] sm:text-xs transition-all flex items-center gap-3",
                                          settings.puterModel === equippedId 
                                            ? "bg-primary/10 text-primary border border-primary/20 shadow-sm" 
                                            : "hover:bg-accent text-muted-foreground hover:text-foreground border border-transparent"
                                        )}
                                      >
                                        <div className={cn(
                                          "w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-transform",
                                          settings.puterModel === equippedId
                                            ? "bg-primary text-primary-foreground shadow-sm shadow-primary/20" 
                                            : "bg-muted text-muted-foreground"
                                        )}>
                                          <Cpu className="w-3.5 h-3.5" />
                                        </div>
                                        <div className="flex flex-col min-w-0 text-left flex-1">
                                          <div className="flex items-center gap-1.5 min-w-0">
                                            <span className="font-bold truncate">{displayName}</span>
                                            {settings.puterModel === equippedId && <Check className="w-3 h-3 shrink-0" />}
                                          </div>
                                          <div className="flex items-center gap-1.5 mt-0.5">
                                            {(() => {
                                              const prov = provider;
                                              const displayProv = prov === 'google' ? 'Gemini API' : prov === 'webllm' ? 'WebLLM' : prov === 'ollama' ? 'Ollama' : prov === 'openai' ? 'OpenAI Compatible' : 'Puter.js';
                                              return (
                                              <span className={cn(
                                                "text-[7.5px] font-bold uppercase tracking-tighter px-1.5 py-0.5 rounded border inline-block w-fit",
                                                prov === 'webllm'
                                                  ? "bg-purple-500/10 text-purple-500 border-purple-500/10"
                                                  : prov === 'google'
                                                  ? "bg-orange-500/10 text-orange-500 border-orange-500/10"
                                                  : prov === 'openai'
                                                  ? "bg-violet-500/10 text-violet-500 border-violet-500/10"
                                                  : "bg-blue-500/10 text-blue-500 border-blue-500/10"
                                              )}>
                                                {displayProv}
                                              </span>
                                              );
                                            })()}
                                            {isWebLlm && (
                                              <span className={cn(
                                                "text-[7.5px] font-bold uppercase tracking-tighter px-1.5 py-0.5 rounded border inline-block w-fit opacity-60",
                                                isActuallyLoaded ? "bg-green-500/10 text-green-500 border-green-500/10" : "bg-zinc-500/10 text-zinc-500 border-zinc-500/10"
                                              )}>
                                                {isActuallyLoaded ? 'Loaded' : 'Local'}
                                              </span>
                                            )}
                                          </div>
                                          {((model as any)?.inputPrice || (model as any)?.outputPrice) && (
                                            <div className="text-[8px] text-muted-foreground/80 mt-1 font-medium leading-none">
                                              In: {(model as any).inputPrice} • Out: {(model as any).outputPrice}
                                            </div>
                                          )}
                                        </div>
                                      </button>
                                      
                                      {isWebLlm && !isActuallyLoaded && (
                                        <button 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleLoadWebLLM(modelId, equippedId);
                                          }}
                                          disabled={!!downloadingModelId}
                                          className="absolute right-2 top-1/2 -translate-y-1/2 px-2 py-1 bg-primary text-primary-foreground rounded-md text-[8px] font-bold uppercase tracking-widest hover:scale-105 active:scale-95 transition-all opacity-0 group-hover/item:opacity-100 disabled:opacity-50"
                                        >
                                          {downloadingModelId === modelId ? 'Loading...' : 'Load'}
                                        </button>
                                      )}
                                    </div>
                                  );
                                })}
                              </>
                            ) : (
                              <div className="p-4 text-center">
                                <p className="text-[10px] text-muted-foreground mb-1 italic">No models selected.</p>
                                <p className="text-[9px] text-muted-foreground/60 leading-tight">Equip your favorite AIs in settings.</p>
                              </div>
                            )}
                          </div>
                          
                          <div className="h-px bg-border my-1" />
                          
                          <button 
                            onClick={() => {
                              setActiveModelMenu(null);
                              setIsModelOrganizerOpen(true);
                            }}
                            className="w-full flex items-center justify-between p-3 rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-primary/10 hover:text-primary transition-all group"
                          >
                            <div className="flex items-center gap-2">
                              <Sparkles className="w-4 h-4 text-primary" />
                              Manage AI Config
                            </div>
                            <ChevronRight className="w-3.5 h-3.5 opacity-50 group-hover:opacity-100 transition-opacity" />
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="flex-1" />
              </div>
              
              <div 
                className={cn(
                  "flex flex-col relative transition-all duration-200",
                  "border-2 rounded-2xl bg-card border-border/80 shadow-md focus-within:border-primary/40 focus-within:shadow-[0_0_20px_rgba(var(--primary),0.05)]",
                  isDraggingOverInput ? "border-primary bg-primary/5 shadow-[0_0_20px_rgba(var(--primary),0.1)]" : "border-transparent hover:border-primary/20",
                  isWebLlmModel && !isWebLlmLoaded && "justify-center items-center h-[56px] p-0"
                )}
                onDragOver={(e) => {
                  if (e.dataTransfer.types.includes('application/x-accelerated-logic-file') || e.dataTransfer.types.includes('Files')) {
                    e.preventDefault();
                    e.dataTransfer.dropEffect = 'copy';
                    setIsDraggingOverInput(true);
                  }
                }}
                onDragLeave={() => setIsDraggingOverInput(false)}
                onDrop={async (e) => {
                  e.preventDefault();
                  setIsDraggingOverInput(false);
                  
                  // Handle Internal File Drop
                  const internalData = e.dataTransfer.getData('application/x-accelerated-logic-file');
                  if (internalData) {
                    try {
                      const file = JSON.parse(internalData);
                      if (!attachedFiles.some(f => f.id === file.id)) {
                        setAttachedFiles(prev => [...prev, file]);
                      }
                      return;
                    } catch (err) {
                      console.error('Failed to drop internal file:', err);
                    }
                  }

                  // Handle External File Drop (if dropped specifically here)
                  const externalFiles = Array.from(e.dataTransfer.files);
                  if (externalFiles.length > 0) {
                    for (const file of externalFiles) {
                      await processAndSaveFile(file);
                    }
                  }
                }}
              >
                {isWebLlmModel && !isWebLlmLoaded ? (
                  <button
                    onClick={() => handleLoadWebLLM(webLlmModelId!, settings.puterModel!)}
                    disabled={!!downloadingModelId}
                    className="w-full h-full bg-primary/10 hover:bg-primary/20 text-primary font-bold flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed rounded-2xl"
                  >
                    {downloadingModelId === webLlmModelId ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>{webLlmProgress || "Loading Engine..."}</span>
                      </>
                    ) : (
                      <>
                        <BrainCircuit className="w-5 h-5" />
                        <span>Load Local WebLLM Model into RAM to Chat</span>
                      </>
                    )}
                  </button>
                ) : (
                  <>
                    {/* Active Skills Bar */}
                    {settings.skills?.some(s => s.enabled) && (
                      <div className="flex flex-wrap gap-1.5 px-3 py-2 border-b border-border/30 bg-muted/20 w-full animate-in slide-in-from-top-1 duration-150 rounded-t-[14px]">
                        {settings.skills.filter(s => s.enabled).map(skill => {
                          const isPersona = skill.type === 'persona';
                          return (
                            <div 
                              key={skill.id}
                              style={{ contentVisibility: 'auto' }}
                              className={cn(
                                "flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold max-w-full truncate border",
                                isPersona 
                                  ? "bg-indigo-500/10 border-indigo-500/25 text-indigo-400" 
                                  : "bg-primary/10 border-primary/20 text-primary"
                              )}
                            >
                              {isPersona ? (
                                <MessageSquare className="w-3 h-3 text-indigo-400 shrink-0" />
                              ) : (
                                <BrainCircuit className="w-3 h-3 text-primary shrink-0" />
                              )}
                              <span className="truncate">
                                {isPersona ? 'Persona: ' : 'Skill: '}{skill.name}
                              </span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const updated = {
                                    ...settings,
                                    skills: settings.skills.map(s => s.id === skill.id ? { ...s, enabled: false } : s)
                                  };
                                  setSettings(updated);
                                  saveSettings(updated);
                                }}
                                className={cn(
                                  "rounded-full p-0.5 transition-colors shrink-0 animate-in zoom-in-75 duration-75",
                                  isPersona 
                                    ? "hover:bg-indigo-500/20 text-indigo-400/80 hover:text-indigo-400" 
                                    : "hover:bg-primary/20 text-primary/80 hover:text-primary"
                                )}
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Active Persistent Thread Context Files (Pinned Files) */}
                    {currentChat && currentChat.pinnedFileIds && currentChat.pinnedFileIds.length > 0 && (
                      <div className={cn(
                        "flex items-center gap-1.5 flex-wrap px-3 py-2 border-b border-border/30 bg-indigo-500/5 w-full animate-in slide-in-from-top-1 duration-150",
                        !settings.skills?.some(s => s.enabled) && "rounded-t-[14px]"
                      )}>
                        <span className="text-[10px] font-black uppercase text-indigo-400 tracking-wider flex items-center gap-1 select-none">
                          <Bookmark className="w-3.5 h-3.5 fill-indigo-400 text-indigo-400" />
                          Project Context:
                        </span>
                        <div className="flex items-center gap-1.5 flex-wrap max-h-24 overflow-y-auto">
                          {files.filter(f => currentChat.pinnedFileIds?.includes(f.id)).map(file => (
                            <div 
                              key={file.id} 
                              className="flex items-center gap-1 bg-indigo-500/10 border border-indigo-500/25 rounded-lg px-2 py-0.5 text-[10px] text-indigo-400 font-bold hover:bg-indigo-500/20 cursor-pointer hover:border-indigo-400/50 transition-colors"
                              onClick={() => setActivePreviewFile(file)}
                              title="Click to view file"
                            >
                              <FileText className="w-3 h-3 text-indigo-400" />
                              <span className="truncate max-w-[120px]">{file.name}</span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleTogglePinFile(file.id);
                                }}
                                className="rounded-full p-0.5 text-indigo-400 hover:bg-indigo-500/20 ml-1 transition-colors flex items-center justify-center"
                                title="Unpin from context"
                              >
                                <X className="w-2.5 h-2.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Inline Attached Files Staging Area (In the Prompt Composer itself) */}
                    <AnimatePresence>
                      {attachedFiles.length > 0 && (
                        <motion.div 
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className={cn(
                            "flex flex-col gap-2 p-3 border-b border-border/30 bg-muted/10 w-full animate-in slide-in-from-top-1 duration-150",
                            (!settings.skills?.some(s => s.enabled) && !(currentChat && currentChat.pinnedFileIds && currentChat.pinnedFileIds.length > 0)) && "rounded-t-[14px]"
                          )}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-black uppercase text-primary tracking-wider flex items-center gap-1.5 select-none shrink-0">
                              <Sparkles className="w-3 h-3 text-primary animate-pulse" />
                              Staged Media Assets ({attachedFiles.length})
                            </span>
                            <button 
                              type="button"
                              onClick={() => setAttachedFiles([])}
                              className="flex items-center gap-1.5 px-2 py-0.5 bg-destructive/10 text-destructive hover:bg-destructive/20 rounded-md text-[9px] font-bold uppercase tracking-widest transition-all whitespace-nowrap shrink-0"
                            >
                              <Trash2 className="w-2.5 h-2.5" />
                              Clear All
                            </button>
                          </div>
                          <div className="flex items-center gap-3 overflow-x-auto pb-1.5 pt-0.5 max-w-full custom-scrollbar">
                            {attachedFiles.map(file => {
                              const isImg = file.type.startsWith('image/');
                              const isVid = file.type.startsWith('video/');
                              const isAud = file.type.startsWith('audio/');
                              return (
                                <motion.div 
                                  key={file.id}
                                  layout
                                  className="relative w-16 h-16 sm:w-[72px] sm:h-[72px] bg-card border border-border rounded-xl shadow-md shrink-0 group/preview hover:border-primary/50 cursor-pointer overflow-visible transition-all flex flex-col items-center justify-center text-center p-0.5"
                                  onClick={() => setActivePreviewFile(file)}
                                >
                                  {isImg ? (
                                    file.content.startsWith('data:') || file.content.startsWith('http') ? (
                                      <img src={file.content} className="w-full h-full object-cover rounded-[10px]" referrerPolicy="no-referrer" alt="" />
                                    ) : (
                                      <div className="flex flex-col items-center justify-center p-1 w-full h-full bg-accent/25 rounded-[10px]">
                                        <ImageIcon className="w-5 h-5 text-primary" />
                                        <span className="text-[8px] text-muted-foreground mt-1 truncate max-w-full">Image</span>
                                      </div>
                                    )
                                  ) : isVid ? (
                                    file.content.startsWith('data:') || file.content.startsWith('http') ? (
                                      <video src={file.content} className="w-full h-full object-cover rounded-[10px]" muted playsInline />
                                    ) : (
                                      <div className="flex flex-col items-center justify-center p-1 w-full h-full bg-accent/25 rounded-[10px]">
                                        <Video className="w-5 h-5 text-primary" />
                                        <span className="text-[8px] text-muted-foreground mt-1 truncate max-w-full">Video</span>
                                      </div>
                                    )
                                  ) : isAud ? (
                                    <div className="flex flex-col items-center justify-center p-1 w-full h-full bg-indigo-500/5 rounded-[10px]">
                                      <Mic className="w-5 h-5 text-indigo-400" />
                                      <span className="text-[8px] text-muted-foreground mt-1 truncate max-w-full">Audio</span>
                                    </div>
                                  ) : (
                                    <div className="flex flex-col items-center justify-center p-1 w-full h-full bg-muted/30 rounded-[10px]">
                                      <FileText className="w-5 h-5 text-muted-foreground" />
                                      <span className="text-[8px] text-foreground font-bold mt-1 truncate max-w-full px-1">{file.name.split('.').pop()?.toUpperCase() || 'FILE'}</span>
                                    </div>
                                  )}

                                  {/* Delete badge absolute on top-right */}
                                  <button 
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setAttachedFiles(prev => prev.filter(f => f.id !== file.id));
                                    }}
                                    className="absolute -top-1.5 -right-1.5 p-1 bg-destructive hover:bg-destructive-foreground text-white rounded-full shadow-md transition-all hover:scale-110 active:scale-95 opacity-80 sm:opacity-0 sm:group-hover/preview:opacity-100 z-30"
                                    title={`Remove ${file.name}`}
                                  >
                                    <X className="w-2.5 h-2.5" />
                                  </button>

                                  {/* Overlay Tooltip-like label showing file title on hover */}
                                  <div className="absolute inset-x-0 bottom-0 bg-black/60 text-white text-[8px] font-bold p-1 rounded-b-[10px] opacity-0 group-hover/preview:opacity-100 transition-opacity flex justify-center text-center select-none truncate max-w-full overflow-hidden leading-tight pointer-events-none">
                                    {(file.name || '').substring(0, 12)}
                                  </div>
                                </motion.div>
                              );
                            })}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <div className="flex items-end p-2 gap-2 w-full">
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileUpload} 
                        className="hidden" 
                        accept="text/*,image/*,video/*,.pdf,.doc,.docx,.mp4,.mov,.webm"
                      />
                      <Tooltip content="Upload context files" position="bottom" align="start">
                        <button 
                          onClick={() => fileInputRef.current?.click()}
                          className="p-2.5 hover:bg-accent rounded-xl transition-colors shrink-0 text-muted-foreground hover:text-foreground mb-0.5"
                        >
                          <Plus className="w-5 h-5" />
                        </button>
                      </Tooltip>
                      <textarea 
                        ref={textareaRef}
                        value={input}
                        onChange={(e) => {
                          setInput(e.target.value);
                          setCursorPos(e.target.selectionStart || 0);
                        }}
                        onSelect={(e: any) => {
                          setCursorPos(e.target.selectionStart || 0);
                        }}
                        onPaste={handlePaste}
                        onKeyDown={(e) => {
                          if (isSlashActive && filteredSlashSkills.length > 0) {
                            if (e.key === 'ArrowDown') {
                              e.preventDefault();
                              setSlashSelectedIndex((prev) => (prev + 1) % filteredSlashSkills.length);
                              return;
                            }
                            if (e.key === 'ArrowUp') {
                              e.preventDefault();
                              setSlashSelectedIndex((prev) => (prev - 1 + filteredSlashSkills.length) % filteredSlashSkills.length);
                              return;
                            }
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleSelectSlashSkill(filteredSlashSkills[slashSelectedIndex]);
                              return;
                            }
                            if (e.key === 'Escape') {
                              e.preventDefault();
                              const beforeSlash = input.substring(0, slashStartIndex);
                              const afterSlash = input.substring(cursorPos);
                              setInput(beforeSlash + afterSlash);
                              setTimeout(() => {
                                if (textareaRef.current) {
                                  textareaRef.current.focus();
                                  textareaRef.current.setSelectionRange(beforeSlash.length, beforeSlash.length);
                                }
                              }, 50);
                              return;
                            }
                          }

                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                        id="tour-composer-input"
                        placeholder="Ask anything... (type '/' for skills)"
                        className="flex-1 bg-transparent border-none focus:ring-0 resize-none py-2.5 text-sm max-h-40 min-h-[44px] overflow-y-auto custom-scrollbar focus:outline-none"
                        rows={1}
                      />

                      {input.trim() && !isGenerating && (
                        <Tooltip content="Improve/Expand Prompt with AI" position="bottom">
                          <button 
                            type="button"
                            disabled={isEnhancingPrompt}
                            onClick={handleEnhancePrompt}
                            className={cn(
                              "p-2.5 rounded-xl transition-all shrink-0 mb-0.5 mr-1 hover:bg-accent text-indigo-500 relative flex items-center justify-center",
                              isEnhancingPrompt && "animate-pulse"
                            )}
                          >
                            {isEnhancingPrompt ? (
                              <Loader2 className="w-5 h-5 animate-spin text-primary" />
                            ) : (
                              <Wand2 className="w-5 h-5 text-indigo-400 hover:text-indigo-500" />
                            )}
                          </button>
                        </Tooltip>
                      )}

                      {isGenerating ? (
                        <div className="flex gap-2 shrink-0 z-20 mb-0.5">
                          {input.trim() && (
                            <Tooltip content="Queue Prompt">
                              <motion.button 
                                type="button"
                                initial={{ scale: 0.8, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                onClick={handleQueuePrompt}
                                className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/20 transition-all hover:scale-105 active:scale-95 cursor-pointer text-xs font-bold"
                              >
                                <ListPlus className="w-5 h-5 shrink-0" />
                                <span className="hidden sm:inline">Queue Response</span>
                              </motion.button>
                            </Tooltip>
                          )}
                          <Tooltip content="Stop Generation">
                            <motion.button 
                              type="button"
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              onClick={handleStopGeneration}
                              className="p-2.5 rounded-xl bg-destructive text-destructive-foreground shadow-lg shadow-destructive/20 transition-all hover:scale-105 active:scale-95 cursor-pointer flex items-center justify-center"
                            >
                              <Square className="w-5 h-5 fill-current" />
                            </motion.button>
                          </Tooltip>
                        </div>
                      ) : (
                        <Tooltip content={input.trim() ? "Send Message" : "Voice Input"} position="bottom" align="end">
                          <button 
                            onClick={() => input.trim() ? handleSendMessage() : setIsVoiceOpen(true)}
                            className={cn(
                              "p-2.5 rounded-xl transition-all shrink-0 mb-0.5",
                              input.trim() 
                                ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                                : "bg-muted text-muted-foreground hover:bg-accent"
                            )}
                          >
                            {input.trim() ? <Send className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                          </button>
                        </Tooltip>
                      )}
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Slash Command Skills Popover Popup */}
            <AnimatePresence>
              {isSlashActive && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  transition={{ duration: 0.12 }}
                  className="absolute bottom-full left-0 mb-3 w-full sm:w-[420px] max-h-64 overflow-hidden bg-card/95 border border-border rounded-3xl shadow-2xl p-2 z-50 flex flex-col backdrop-blur-md"
                >
                  <div className="flex items-center justify-between px-3 py-2 border-b border-border/40 shrink-0">
                    <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                      <BrainCircuit className="w-3.5 h-3.5 text-primary" />
                      <span>Equip Skills</span>
                    </div>
                    <span className="text-[9px] font-mono text-muted-foreground/60 px-1.5 py-0.5 rounded bg-muted/60">
                      {filteredSlashSkills.length} options
                    </span>
                  </div>

                  <div className="flex-1 overflow-y-auto custom-scrollbar p-1 space-y-1 max-h-[190px]">
                    {filteredSlashSkills.length > 0 ? (
                      filteredSlashSkills.map((skill, index) => {
                        const isSelected = index === slashSelectedIndex;
                        const isCurrentlyEnabled = skill.enabled;
                        const isPersona = skill.type === 'persona';
                        return (
                          <button
                            key={skill.id}
                            id={`slash-skill-item-${index}`}
                            onClick={() => handleSelectSlashSkill(skill)}
                            onMouseEnter={() => setSlashSelectedIndex(index)}
                            className={cn(
                              "w-full text-left p-2.5 rounded-2xl transition-all flex items-start gap-3 relative overflow-hidden",
                              isSelected 
                                ? (isPersona ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/25" : "bg-primary/10 text-primary border border-primary/25")
                                : "hover:bg-accent/40 text-foreground border border-transparent"
                            )}
                          >
                            {isSelected && (
                              <div className={cn(
                                "absolute left-0 top-0 bottom-0 w-1 animate-pulse",
                                isPersona ? "bg-indigo-500" : "bg-primary"
                              )} />
                            )}
                            <div className={cn(
                              "w-7 h-7 rounded-xl flex items-center justify-center shrink-0 mt-0.5 transition-all text-xs border",
                              isCurrentlyEnabled 
                                ? "bg-green-500/10 text-green-500 border-green-500/20" 
                                : isPersona 
                                ? "bg-indigo-500/15 text-indigo-400 border border-indigo-500/20"
                                : skill.isPreset 
                                ? "bg-primary/15 text-primary border border-primary/20" 
                                : "bg-muted text-muted-foreground border-transparent"
                            )}>
                              {isCurrentlyEnabled ? (
                                <Check className="w-4 h-4" />
                              ) : isPersona ? (
                                <MessageSquare className="w-4 h-4" />
                              ) : (
                                <BrainCircuit className="w-4 h-4" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-xs truncate">{skill.name}</span>
                                <span className={cn(
                                  "text-[7.5px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded border leading-none shrink-0",
                                  isPersona 
                                    ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" 
                                    : "bg-primary/10 text-primary border-primary/20"
                                )}>
                                  {isPersona ? 'Persona' : 'Skill'}
                                </span>
                                {skill.isPreset && (
                                  <span className="text-[7.5px] font-black uppercase tracking-wider px-1 bg-muted text-muted-foreground border border-border/30 rounded">Preset</span>
                                )}
                                {isCurrentlyEnabled && (
                                  <span className="text-[7.5px] font-bold text-green-500 flex items-center gap-0.5 bg-green-500/5 px-1 rounded border border-green-500/10">Active</span>
                                )}
                              </div>
                              <p className="text-[10px] text-muted-foreground line-clamp-1 mt-0.5">{skill.description}</p>
                            </div>
                          </button>
                        );
                      })
                    ) : (
                      <div className="py-8 text-center text-muted-foreground flex flex-col items-center justify-center gap-1">
                        <Cpu className="w-6 h-6 text-muted-foreground/30" />
                        <span className="text-[10px] uppercase font-bold tracking-wider">No matching skills</span>
                        <p className="text-[9px] text-muted-foreground/60">Type letters to search or define skills in settings.</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            
            <div className="text-[10px] text-center text-muted-foreground mt-2 uppercase tracking-widest font-bold opacity-50">
              Studio Workspace • Powered by Puter.js
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {/* Agent Edit Modal */}
      <AnimatePresence>
        {isAgentEditOpen && editingAgent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-card border border-border rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden"
            >
              <div className="p-4 sm:p-6 border-b border-border flex items-center justify-between">
                <h2 className="text-lg sm:text-xl font-bold tracking-tight">Edit Agent: {editingAgent.name}</h2>
                <button onClick={() => setIsAgentEditOpen(false)} className="p-2 hover:bg-accent rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-4 sm:p-6 space-y-4 overflow-y-auto max-h-[60vh] custom-scrollbar">
                <div className="space-y-2">
                  <label className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-muted-foreground">System Prompt</label>
                  <textarea 
                    value={editingAgent.systemPrompt}
                    onChange={(e) => setEditingAgent({ ...editingAgent, systemPrompt: e.target.value })}
                    className="w-full bg-muted border-none rounded-xl px-4 py-3 text-sm min-h-[150px] sm:min-h-[200px] resize-none"
                    placeholder="Enter agent's instructions..."
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-muted-foreground">Model Override</label>
                  <select
                    value={editingAgent.modelId || settings.puterModel || ''}
                    onChange={(e) => setEditingAgent({ ...editingAgent, modelId: e.target.value })}
                    className="w-full bg-muted border-none rounded-xl px-4 py-3 text-sm appearance-none cursor-pointer hover:bg-muted/80 transition-colors"
                  >
                    <option value="">Default (Global Setting)</option>
                    {(settings.enabledChatModels || []).map(equippedId => {
                      const { modelId, provider, catalogModel } = getModelInfo(equippedId);
                      return (
                        <option key={equippedId} value={equippedId}>
                          {catalogModel?.name || modelId} ({provider})
                        </option>
                      );
                    })}
                  </select>
                  <p className="text-[10px] text-muted-foreground">Specify a dedicated model for this agent instance.</p>
                </div>
              </div>
              <div className="p-4 sm:p-6 border-t border-border bg-muted/30 flex gap-3">
                <button 
                  onClick={() => setIsAgentEditOpen(false)}
                  className="flex-1 bg-muted text-muted-foreground py-2.5 rounded-xl font-bold text-sm"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSaveAgent}
                  className="flex-1 bg-primary text-primary-foreground py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-primary/20"
                >
                  Save Changes
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ModelOrganizer 
        isOpen={isModelOrganizerOpen}
        setIsOpen={setIsModelOrganizerOpen}
        settings={settings}
        setSettings={(newSettings) => {
          setSettings(newSettings);
          saveSettings(newSettings);
        }}
        downloadingModelId={downloadingModelId}
        setDownloadingModelId={setDownloadingModelId}
        webLlmProgress={webLlmProgress}
        setWebLlmProgress={setWebLlmProgress}
        onLoadModel={handleLoadWebLLM}
        engineLoadedModelId={engineLoadedModelId}
      />

      {/* All Chats Modal */}
      <AnimatePresence>
        {isAllChatsOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card border border-border rounded-3xl shadow-2xl w-full max-w-2xl h-[70vh] flex flex-col overflow-hidden"
            >
              <div className="p-6 border-b border-border flex items-center justify-between bg-muted/20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold tracking-tight">Full Chat History</h2>
                    <div className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">Browse all your conversations</div>
                  </div>
                </div>
                <button onClick={() => setIsAllChatsOpen(false)} className="p-2 hover:bg-muted rounded-full">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
                {chats.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-12 space-y-4 opacity-50">
                    <MessageSquare className="w-12 h-12" />
                    <div>No chats found.</div>
                  </div>
                ) : (
                  chats.map(chat => (
                    <div 
                      key={chat.id}
                      onClick={() => {
                        handleSelectChat(chat.id);
                        setIsAllChatsOpen(false);
                      }}
                      className={cn(
                        "group flex items-center justify-between p-4 rounded-2xl cursor-pointer transition-all border",
                        currentChatId === chat.id 
                          ? "bg-primary/5 border-primary/50" 
                          : "bg-background border-border hover:bg-muted hover:border-border/80"
                      )}
                    >
                      <div className="flex items-center gap-4 min-w-0">
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-sm",
                          currentChatId === chat.id ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                        )}>
                          <MessageSquare className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold truncate text-sm">{chat.title || 'New Chat'}</div>
                          <div className="text-[10px] text-muted-foreground opacity-70">
                            {chat.messages.length} messages • {new Date(chat.createdAt).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={(e) => { e.stopPropagation(); handleDeleteChat(chat.id); }}
                          className="p-2 hover:bg-destructive/10 text-muted-foreground hover:text-destructive rounded-lg transition-colors border border-transparent hover:border-destructive/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <div className="p-4 border-t border-border bg-muted/20 text-center">
                <button 
                  onClick={() => setIsAllChatsOpen(false)}
                  className="px-8 py-2.5 bg-muted hover:bg-primary hover:text-primary-foreground rounded-xl font-bold text-xs uppercase tracking-widest transition-all"
                >
                  Close History
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <SkillsManager 
        isOpen={isSkillsManagerOpen}
        onClose={() => setIsSkillsManagerOpen(false)}
        skills={settings.skills || []}
        settings={settings}
        onUpdateSkills={(skills) => {
          const updated = { ...settings, skills };
          setSettings(updated);
          saveSettings(updated);
        }}
      />

      <MemoryManager 
        isOpen={isMemoryManagerOpen}
        onClose={() => setIsMemoryManagerOpen(false)}
        autoMemoryEnabled={settings.autoMemoryEnabled ?? true}
        onToggleAutoMemory={(enabled) => {
          const updated = { ...settings, autoMemoryEnabled: enabled };
          setSettings(updated);
          saveSettings(updated);
        }}
        onMemoriesChanged={() => setMemorySyncTrigger(p => p + 1)}
      />

      <AnimatePresence>
        {activePreviewFile && (
          <div className="fixed inset-0 z-[140] flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
            <FilePreview 
              file={activePreviewFile} 
              onClose={() => setActivePreviewFile(null)} 
            />
          </div>
        )}
      </AnimatePresence>

      {/* Settings Modal */}

      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 z-50 bg-[#141419] text-[#e4e4eb] flex flex-col md:flex-row overflow-hidden font-sans select-none">
            <motion.div 
              initial={{ opacity: 0, scale: 0.99 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.99 }}
              className="w-full h-full flex flex-col md:flex-row overflow-hidden"
            >
              {/* Sidebar Navigation (Left Panel) */}
              <div className="w-full md:w-80 border-r border-border/10 flex flex-col bg-[#1a1a22] md:h-full justify-between shrink-0">
                <div className="flex flex-col min-h-0 flex-1">
                  {/* Title & User Profile Info (Windows-style) */}
                  <div className="flex items-center gap-3 p-5 border-b border-border/5 shrink-0">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center font-black text-white shadow-lg shadow-indigo-500/10 text-sm">
                      AL
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-extrabold text-xs tracking-wide truncate text-foreground">Accelerated Logic</span>
                      <span className="text-[10px] text-muted-foreground/60 truncate">acceleratedlogicai@gmail.com</span>
                    </div>
                  </div>

                  {/* Sidebar Search Bar */}
                  <div className="px-4 py-3 border-b border-border/5 shrink-0 animate-fadeIn">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground/50" />
                      <input 
                        type="text" 
                        value={settingsSearchQuery}
                        onChange={(e) => setSettingsSearchQuery(e.target.value)}
                        placeholder="Find a setting..." 
                        className="w-full bg-[#121217] border border-border/15 rounded-xl pl-9 pr-8 py-1.5 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-primary/40 transition-all font-sans placeholder-muted-foreground/30 shadow-inner"
                      />
                      {settingsSearchQuery && (
                        <button 
                          onClick={() => setSettingsSearchQuery('')}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 hover:bg-muted/50 rounded text-muted-foreground/50 hover:text-foreground transition-colors cursor-pointer"
                          title="Clear search query"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Settings Category Navigation List */}
                  <div className="flex-1 overflow-y-auto px-2 py-3 space-y-1 custom-scrollbar">
                    {(() => {
                      const settingsTabsList = [
                        { id: 'ai' as const, label: 'AI Configuration', icon: Bot, color: 'text-purple-400', keywords: ['ai', 'configuration', 'model', 'webllm', 'ollama', 'openai', 'server', 'catalog', 'organizer', 'default model', 'agent'] },
                        { id: 'gemini' as const, label: 'Gemini API Key', icon: Key, color: 'text-emerald-400', keywords: ['gemini', 'api key', 'google', 'key', 'developer key', 'api_key', 'token', 'gemini-2.5', 'gemini-1.5', 'gemini-3.5', 'flash', 'pro', 'secret'] },
                        { id: 'display' as const, label: 'Display & Fonts', icon: Layout, color: 'text-sky-400', keywords: ['display', 'fonts', 'typography', 'theme', 'background animation', 'editor font size', 'serif', 'sans', 'mono', 'space grotesk', 'inter', 'size', 'style', 'dark mode', 'light mode'] },
                        { id: 'llm' as const, label: 'LLM Parameter Engine', icon: Cpu, color: 'text-pink-400', keywords: ['temperature', 'top_p', 'top-p', 'tokens', 'system prompt', 'llm', 'parameter', 'engine', 'max tokens', 'response limit'] },
                        { id: 'image' as const, label: 'Image Generation', icon: ImageIcon, color: 'text-amber-400', keywords: ['image', 'generation', 'diffusion', 'aspect ratio', 'imagen', 'stability', 'width', 'height', 'picture', 'art', 'draw'] },
                        { id: 'skills' as const, label: 'Custom Agent Skills', icon: BrainCircuit, color: 'text-indigo-400', keywords: ['skills', 'tools', 'plugins', 'custom skill', 'prompt injection', 'expert skill', 'actions', 'code execution', 'python'] },
                        { id: 'memory' as const, label: 'Fact Memory', icon: Brain, color: 'text-teal-400', keywords: ['fact', 'memory', 'memories', 'long-term', 'indexeddb', 'continuity', 'facts', 'saved', 'persistence'] },
                        { id: 'gdrive' as const, label: 'Google Drive Sync', icon: Cloud, color: 'text-blue-400', keywords: ['gdrive', 'google drive', 'sync', 'cloud', 'backup', 'oauth', 'google account', 'synchronization', 'drive'] },
                        { id: 'local_save' as const, label: 'Local Backup & Sync', icon: Database, color: 'text-orange-400', keywords: ['local', 'backup', 'export', 'import', 'sync', 'indexeddb', 'reset', 'clear storage', 'purge', 'database', 'delete'] }
                      ];

                      const filtered = settingsTabsList.filter(tab => {
                        if (!settingsSearchQuery) return true;
                        const query = settingsSearchQuery.toLowerCase();
                        return tab.label.toLowerCase().includes(query) || tab.keywords.some(k => k.includes(query));
                      });

                      if (filtered.length === 0) {
                        return (
                          <div className="py-8 px-4 text-center select-none animate-fadeIn">
                            <Bot className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2.5 animate-bounce" />
                            <p className="text-xs font-semibold text-muted-foreground/75 mb-1">No settings found</p>
                            <p className="text-[10px] text-muted-foreground/45 max-w-[180px] mx-auto leading-normal">
                              We couldn't find any category matching "{settingsSearchQuery}".
                            </p>
                          </div>
                        );
                      }

                      return filtered.map((tab) => {
                        const isActive = activeSettingsTab === tab.id;
                        const TabIcon = tab.icon;
                        return (
                          <button
                            key={tab.id}
                            onClick={() => {
                              setActiveSettingsTab(tab.id);
                            }}
                            className={cn(
                              "w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all duration-200 border-l-2 text-left relative",
                              isActive 
                                ? "bg-primary/10 text-primary border-primary font-bold shadow-sm shadow-primary/5" 
                                : "text-muted-foreground hover:bg-muted/30 hover:text-foreground border-transparent cursor-pointer"
                            )}
                          >
                            <TabIcon className={cn("w-4 h-4 shrink-0", tab.color)} />
                            <span>{tab.label}</span>
                            {isActive && (
                              <div className="absolute right-3 w-1.5 h-1.5 rounded-full bg-primary" />
                            )}
                          </button>
                        );
                      });
                    })()}
                  </div>
                </div>

                {/* Footer Section */}
                <div className="p-4 border-t border-border/5 bg-muted/5 shrink-0 text-center">
                  <div className="text-[10px] text-muted-foreground/45 font-mono">WORKSPACE CLIENT v2.5</div>
                </div>
              </div>

              {/* Main Content Area (Right Panel) */}
              <div className="flex-1 h-full overflow-hidden flex flex-col bg-[#111116] text-[#e0e0e6] select-text">
                {/* Top Header of Settings Panel */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-border/10 shrink-0 bg-[#16161c]">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground/60">System Configuration</span>
                    <span className="text-muted-foreground/40 text-xs">/</span>
                    <span className="text-xs font-extrabold text-primary capitalize select-none">
                      {activeSettingsTab === 'ai' ? 'AI Configuration' : 
                       activeSettingsTab === 'gemini' ? 'Gemini API Key' : 
                       activeSettingsTab === 'display' ? 'Display & Personalization' : 
                       activeSettingsTab === 'llm' ? 'LLM Settings' : 
                       activeSettingsTab === 'image' ? 'Image Engine' : 
                       activeSettingsTab === 'skills' ? 'Agent Skills' : 
                       activeSettingsTab === 'memory' ? 'Fact Memory' : 
                       activeSettingsTab === 'gdrive' ? 'Google Drive Cloud' : 'Local Storage Backups'}
                    </span>
                  </div>
                  
                  {/* Primary Save & Close button */}
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => {
                        saveSettings(settings);
                        setIsSettingsOpen(false);
                      }}
                      className="px-4 py-1.5 bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-bold rounded-xl transition-all shadow-md shadow-primary/10 active:scale-95 cursor-pointer animate-pulse"
                      title="Apply current changes and return to chat space"
                    >
                      Save & Close
                    </button>
                    <button 
                      onClick={() => {
                        saveSettings(settings);
                        setIsSettingsOpen(false);
                      }}
                      className="p-1.5 hover:bg-destructive hover:text-white rounded-lg transition-colors cursor-pointer text-muted-foreground"
                      title="Back to Workspace"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Tab Render panel */}
                <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
                  <div className="max-w-3xl mx-auto space-y-6">

                    {/* 1. AI Configuration */}
                    {activeSettingsTab === 'ai' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1">
                          <h2 className="text-xl font-black text-foreground tracking-tight">AI Server Configuration</h2>
                          <p className="text-xs text-muted-foreground">Manage active models, connect external API providers, or explore the integrated client catalog.</p>
                        </div>

                        {/* Model catalog redirect card */}
                        <div className="p-5 bg-purple-500/5 rounded-2xl border border-purple-500/20 hover:border-purple-500/35 transition-all space-y-4">
                          <div className="flex items-start justify-between gap-4 text-left">
                            <div className="space-y-1">
                              <span className="text-sm font-extrabold text-[#f3e8ff] flex items-center gap-1.5">
                                <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
                                Model Catalog & Organizers
                              </span>
                              <p className="text-[11px] text-muted-foreground/80 leading-relaxed max-w-xl">
                                Dynamically pull, download, and equip models from WebLLM, local Ollama interfaces, or OpenAI servers. All active agents adapt automatically to your equipped target model.
                              </p>
                            </div>
                            <button 
                              id="tour-explore-catalog"
                              onClick={() => {
                                setIsSettingsOpen(false);
                                setIsModelOrganizerOpen(true);
                              }}
                              className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-purple-600/10 cursor-pointer shrink-0"
                            >
                              Explore Catalog
                            </button>
                          </div>
                          
                          <div className="pt-2 border-t border-purple-500/10 flex items-center justify-between text-[10px] font-mono text-purple-300 font-bold select-text text-left">
                            <span>Currently Active Engine:</span>
                            <span className="font-bold underline">
                              {getModelInfo(settings.puterModel || '').catalogModel?.name || settings.puterModel || 'Configure AI Model'}
                            </span>
                          </div>
                        </div>



                        {/* Ollama options if selected */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-3 text-left">
                          <div className="space-y-1">
                            <label className="text-xs font-extrabold uppercase tracking-wider text-purple-300">Local Ollama API Setup</label>
                            <p className="text-[10px] text-muted-foreground">Adjust fallback API endpoints when utilizing high-speed local models.</p>
                          </div>
                          
                          <div className="relative">
                            <Cpu className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/60" />
                            <input 
                              type="text"
                              value={settings.ollamaUrl || 'http://127.0.0.1:11434'}
                              onChange={(e) => setSettings({ ...settings, ollamaUrl: e.target.value })}
                              placeholder="e.g. http://127.0.0.1:11434"
                              className="w-full bg-[#121217] border border-border/15 rounded-xl pl-10 pr-4 py-2.5 text-xs text-foreground focus:outline-none"
                            />
                          </div>
                          <p className="text-[9px] text-muted-foreground italic px-1">Tip: Please verify that Ollama is currently executing with active CORS permissions (`OLLAMA_ORIGINS="*" OLLAMA_HOST="0.0.0.0"`).</p>
                        </div>
                      </div>
                    )}


                    {/* 2. Gemini API Credentials */}
                    {activeSettingsTab === 'gemini' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1">
                          <h2 className="text-xl font-black text-foreground tracking-tight">Gemini Provider Authentication</h2>
                          <p className="text-xs text-muted-foreground">This token acts as your gateway to high-performance multimodal Gemini models and image pipelines.</p>
                        </div>

                        <div className="bg-[#181820] rounded-2xl border border-emerald-500/10 p-6 space-y-5 text-left">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                                <Key className="w-4 h-4 animate-pulse" />
                              </div>
                              <span className="text-sm font-extrabold text-foreground">Paste Your Gemini Secret Key</span>
                            </div>
                          </div>

                          <div className="relative group">
                            <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400/80" />
                            <input 
                              type="password"
                              value={settings.geminiApiKey || ''}
                              onChange={(e) => {
                                const newKey = e.target.value;
                                setSettings({ ...settings, geminiApiKey: newKey });
                                if (typeof window !== 'undefined' && window.localStorage) {
                                  if (newKey) {
                                    window.localStorage.setItem('gemini_api_key', newKey);
                                  } else {
                                    window.localStorage.removeItem('gemini_api_key');
                                  }
                                }
                              }}
                              placeholder="AIzaSy... or AQ.Ab..."
                              className="w-full bg-[#121217] border border-border/20 rounded-xl pl-11 pr-4 py-3 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-emerald-500/30 transition-all font-mono"
                            />
                          </div>

                          <div className="p-3 bg-emerald-500/5 rounded-xl border border-emerald-500/10 space-y-1.5 select-none text-left">
                            <div className="text-[10px] font-bold text-emerald-400 flex items-center gap-1 uppercase tracking-wider">
                              <ShieldCheck className="w-3.5 h-3.5" /> Client-Side Encryption Guarantee
                            </div>
                            <p className="text-[10px] text-muted-foreground leading-relaxed font-sans">
                              Keys are stored strictly in your browser's private IndexedDB (Web Sandbox). They are never sent to external servers, protecting your token quota and account security.
                            </p>
                          </div>

                          {settings.geminiApiKey && (
                            <button
                              onClick={() => {
                                setSettings({ ...settings, geminiApiKey: '' });
                                if (typeof window !== 'undefined' && window.localStorage) {
                                  window.localStorage.removeItem('gemini_api_key');
                                }
                              }}
                              className="w-full py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold rounded-xl border border-rose-500/20 transition-all cursor-pointer"
                            >
                              Revoke & Purge Gemini Token
                            </button>
                          )}
                        </div>
                      </div>
                    )}


                    {/* 3. Display & Personalization */}
                    {activeSettingsTab === 'display' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1">
                          <h2 className="text-xl font-black text-foreground tracking-tight">Display & Personalization</h2>
                          <p className="text-xs text-muted-foreground">Tailor your active prompt bubble spacing, font settings, and responsive text sizing.</p>
                        </div>

                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-6 space-y-6">
                          {/* Font Size group */}
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-border/10 pb-5 text-left">
                            <div className="space-y-0.5">
                              <span className="text-xs font-extrabold text-foreground">Interface Text Scaling</span>
                              <p className="text-[10px] text-muted-foreground">Configure the text output size rendered inside your message history.</p>
                            </div>
                            <div className="flex bg-[#121217] rounded-xl p-1 gap-1">
                              {['sm', 'base', 'lg'].map((sz) => (
                                <button
                                  key={sz}
                                  type="button"
                                  onClick={() => {
                                    const updated = { ...settings, chatFontSize: sz as any };
                                    setSettings(updated);
                                    saveSettings(updated);
                                  }}
                                  className={cn(
                                    "text-[10px] uppercase font-bold py-1.5 px-4 rounded-lg transition-all capitalize whitespace-nowrap min-w-16 text-center shrink-0 cursor-pointer",
                                    (settings.chatFontSize || 'sm') === sz 
                                      ? "bg-primary text-primary-foreground shadow-md" 
                                      : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
                                  )}
                                >
                                  {sz === 'base' ? 'Normal' : sz}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Font Family group */}
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-border/10 pb-5 text-left">
                            <div className="space-y-0.5">
                              <span className="text-xs font-extrabold text-foreground">Workspace Fonts Pairing</span>
                              <p className="text-[10px] text-muted-foreground">Select a distinctive typeface alignment optimized for your eyes.</p>
                            </div>
                            <div className="flex bg-[#121217] rounded-xl p-1 gap-1">
                              {['sans', 'mono', 'serif'].map((fam) => (
                                <button
                                  key={fam}
                                  type="button"
                                  onClick={() => {
                                    const updated = { ...settings, chatFontFamily: fam as any };
                                    setSettings(updated);
                                    saveSettings(updated);
                                  }}
                                  className={cn(
                                    "text-[10px] uppercase font-bold py-1.5 px-4 rounded-lg transition-all capitalize whitespace-nowrap min-w-16 text-center shrink-0 cursor-pointer",
                                    (settings.chatFontFamily || 'sans') === fam 
                                      ? "bg-primary text-primary-foreground shadow-md" 
                                      : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
                                  )}
                                >
                                  {fam}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Layout Density group */}
                          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-left">
                            <div className="space-y-0.5">
                              <span className="text-xs font-extrabold text-foreground">Chat Bubbles Density</span>
                              <p className="text-[10px] text-muted-foreground">Adjust bubble margins for tight density or expansive clarity.</p>
                            </div>
                            <div className="flex bg-[#121217] rounded-xl p-1 gap-1">
                              {['cozy', 'spacious'].map((den) => (
                                <button
                                  key={den}
                                  type="button"
                                  onClick={() => {
                                    const updated = { ...settings, chatDensity: den as any };
                                    setSettings(updated);
                                    saveSettings(updated);
                                  }}
                                  className={cn(
                                    "text-[10px] uppercase font-bold py-1.5 px-4 rounded-lg transition-all capitalize whitespace-nowrap min-w-20 text-center shrink-0 cursor-pointer",
                                    (settings.chatDensity || 'cozy') === den 
                                      ? "bg-primary text-primary-foreground shadow-md" 
                                      : "text-muted-foreground hover:text-foreground hover:bg-muted/30"
                                  )}
                                >
                                  {den}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}


                    {/* 4. LLM Settings */}
                    {activeSettingsTab === 'llm' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1 text-left">
                          <h2 className="text-xl font-black text-foreground tracking-tight">LLM Parameter Engine</h2>
                          <p className="text-xs text-muted-foreground">Optimize multi-agent system dynamics, edit prompts, adjust token logic, and manage core tools.</p>
                        </div>

                        {/* Text Prompt */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-3 text-left animate-fadeIn">
                          <span className="text-xs font-extrabold text-[#f3e8ff]">System Prompts Instructions</span>
                          <textarea 
                            value={settings.systemPrompt}
                            onChange={(e) => setSettings({ ...settings, systemPrompt: e.target.value })}
                            className="w-full bg-[#121217] border border-border/15 rounded-xl px-4 py-3 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-primary/20 min-h-[120px] resize-none font-sans leading-relaxed"
                            placeholder="You are an expert computational assistant..."
                          />
                        </div>

                        {/* MAS Architecture select */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 grid grid-cols-1 md:grid-cols-2 gap-6 items-center text-left">
                          <div className="space-y-1">
                            <span className="text-xs font-extrabold text-[#f3e8ff] flex items-center gap-1">
                              MAS Architecture
                            </span>
                            <p className="text-[10px] text-muted-foreground max-w-xs">Configures interaction flow when executing multi-persona workflows.</p>
                          </div>
                          <select 
                            value={settings.masArchitecture}
                            onChange={(e) => setSettings({ ...settings, masArchitecture: e.target.value as any })}
                            className="bg-[#121217] border border-border/20 rounded-xl px-4 py-2.5 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-primary/30 w-full cursor-pointer"
                          >
                            <option value="auto">Auto (Dynamic Select)</option>
                            <option value="standard">Standard (Sequential)</option>
                            <option value="planning">Planning (Planner-Critic)</option>
                            <option value="debate">Self-Debate (Opposing Views)</option>
                            <option value="doc_analyzer">Document Analyzer (Small-Big Model)</option>
                          </select>
                        </div>

                        {/* Critic strictness */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-3 text-left">
                          <div className="flex justify-between items-center text-xs font-extrabold">
                            <span className="text-[#f3e8ff]">MAS Critic strictness (Level: {settings.criticStrictness})</span>
                          </div>
                          <input 
                            type="range" min="1" max="10" step="1" 
                            value={settings.criticStrictness}
                            onChange={(e) => setSettings({ ...settings, criticStrictness: parseInt(e.target.value) })}
                            className="w-full accent-primary"
                          />
                          <div className="flex justify-between text-[9px] font-mono text-muted-foreground">
                            <span>Lax (1)</span>
                            <span>Strict (10)</span>
                          </div>
                        </div>

                        {/* Temperature and prompt backoff */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                          <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-3">
                            <span className="text-xs font-extrabold text-[#f3e8ff]">LLM Temperature: {settings.temperature}</span>
                            <input 
                              type="range" min="0" max="1" step="0.1" 
                              value={settings.temperature}
                              onChange={(e) => setSettings({ ...settings, temperature: parseFloat(e.target.value) })}
                              className="w-full accent-primary"
                            />
                            <div className="flex justify-between text-[9px] font-mono text-muted-foreground">
                              <span>Deterministic (0)</span>
                              <span>Creative (1)</span>
                            </div>
                          </div>

                          <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-3">
                            <span className="text-xs font-extrabold text-[#f3e8ff]">Queue Backoff Delay: {settings.promptQueueBackoff || 0}s</span>
                            <input 
                              type="range" min="0" max="30" step="1" 
                              value={settings.promptQueueBackoff !== undefined ? settings.promptQueueBackoff : 0}
                              onChange={(e) => setSettings({ ...settings, promptQueueBackoff: parseInt(e.target.value) })}
                              className="w-full accent-primary"
                            />
                            <div className="flex justify-between text-[9px] font-mono text-muted-foreground">
                              <span>Direct throughput</span>
                              <span>30 seconds</span>
                            </div>
                          </div>
                        </div>

                        {/* Max Context and Auto-Summarize */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-5 text-left">
                          <div className="space-y-3">
                            <div className="flex justify-between text-xs font-extrabold text-[#f3e8ff]">
                              <span>Max Context Window</span>
                              <span className="text-primary">{settings.maxContext.toLocaleString()} Tokens</span>
                            </div>
                            <input 
                              type="range" min="1024" max={activeMaxContext > 0 ? activeMaxContext : 128000} step="1024" 
                              value={settings.maxContext}
                              onChange={(e) => setSettings({ ...settings, maxContext: parseInt(e.target.value) })}
                              className="w-full accent-primary"
                            />
                            <div className="flex justify-between items-center text-[9px] font-mono text-muted-foreground">
                              <span>Buffer Size: {Math.round(settings.maxContext * 4 / 1024)} KB</span>
                              <span>Model Limit: {activeMaxContext.toLocaleString()}</span>
                            </div>
                          </div>

                          <div className="pt-4 border-t border-border/10 flex items-center justify-between">
                            <div className="space-y-0.5">
                              <span className="text-xs font-extrabold text-foreground">Auto-Summarize Long Contexts</span>
                              <p className="text-[10px] text-muted-foreground font-sans">Summarize older chat layers when approaching token caps.</p>
                            </div>
                            <button 
                              onClick={() => setSettings({ ...settings, summarizeEnabled: !settings.summarizeEnabled })}
                              className={cn(
                                "w-10 h-5 rounded-full relative transition-colors cursor-pointer shrink-0",
                                settings.summarizeEnabled ? "bg-primary" : "bg-muted"
                              )}
                            >
                              <div className={cn(
                                "absolute top-1 w-3 h-3 rounded-full bg-white transition-all",
                                settings.summarizeEnabled ? "left-6" : "left-1"
                              )} />
                            </button>
                          </div>
                        </div>

                        {/* Agent active tools */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-4 text-left">
                          <div className="space-y-1">
                            <span className="text-xs font-extrabold text-[#f3e8ff]">Interactive Agent Tools</span>
                            <p className="text-[10.5px] text-muted-foreground">Select which functional utility packages agents are authorized to use.</p>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-3">
                            {Object.entries(settings.toolsEnabled || {}).map(([tool, enabled]) => (
                              <button
                                key={tool}
                                onClick={() => setSettings({
                                  ...settings,
                                  toolsEnabled: { 
                                    ...DEFAULT_SETTINGS.toolsEnabled,
                                    ...(settings.toolsEnabled || {}), 
                                    [tool]: !enabled 
                                  } as Settings['toolsEnabled']
                                })}
                                className={cn(
                                  "flex items-center justify-between p-3 rounded-xl border transition-all text-xs font-extrabold capitalize cursor-pointer",
                                  enabled 
                                    ? "bg-primary/5 border-primary text-primary" 
                                    : "bg-[#121217] border-transparent text-muted-foreground hover:bg-[#121217]/80"
                                )}
                              >
                                <span>{tool}</span>
                                {enabled ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5 opacity-40" />}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}


                    {/* 5. Image Generation */}
                    {activeSettingsTab === 'image' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1 text-left">
                          <h2 className="text-xl font-black text-foreground tracking-tight">Image Generation Engine</h2>
                          <p className="text-xs text-muted-foreground">Enable visual media synthesis, configure rendering models or enable intelligent prompt expansion.</p>
                        </div>

                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-6 space-y-6 text-left">
                          {/* Enable Generation */}
                          <div className="flex items-center justify-between border-b border-border/10 pb-5">
                            <div className="space-y-0.5">
                              <span className="text-xs font-extrabold text-foreground">Enable Generation Execution</span>
                              <p className="text-[10px] text-muted-foreground">Allow models to output inline tags that trigger our asset synthesizers.</p>
                            </div>
                            <button 
                              onClick={() => setSettings({ ...settings, imageGenerationEnabled: !settings.imageGenerationEnabled })}
                              className={cn(
                                "w-10 h-5 rounded-full relative transition-colors cursor-pointer shrink-0",
                                settings.imageGenerationEnabled ? "bg-amber-500" : "bg-muted"
                              )}
                            >
                              <div className={cn(
                                "absolute top-1 w-3 h-3 rounded-full bg-white transition-all",
                                settings.imageGenerationEnabled ? "left-6" : "left-1"
                              )} />
                            </button>
                          </div>

                          {settings.imageGenerationEnabled && (
                            <>
                              {/* Selection model dropdown */}
                              <div className="space-y-1 pb-5 border-b border-border/10">
                                <span className="text-xs font-extrabold text-foreground">Synthesizer Pipeline Model</span>
                                <select 
                                  value={settings.imageModelId}
                                  onChange={(e) => setSettings({ ...settings, imageModelId: e.target.value })}
                                  className="w-full bg-[#121217] border border-border/20 rounded-xl px-4 py-2.5 text-xs text-foreground focus:outline-none"
                                >
                                  {IMAGE_MODELS.map(model => (
                                    <option key={model.id} value={model.id}>{model.name} ({model.provider})</option>
                                  ))}
                                </select>
                              </div>

                              {/* Prompts Auto enhanced */}
                              <div className="flex items-center justify-between">
                                <div className="space-y-0.5">
                                  <span className="text-xs font-extrabold text-foreground">Auto-Enhance Prompts</span>
                                  <p className="text-[10px] text-muted-foreground">Expand simple requests with rich style details for exquisite results.</p>
                                </div>
                                <button 
                                  onClick={() => setSettings({ ...settings, autoEnhance: !settings.autoEnhance })}
                                  className={cn(
                                    "w-10 h-5 rounded-full relative transition-colors cursor-pointer shrink-0",
                                    settings.autoEnhance ? "bg-amber-500" : "bg-muted"
                                  )}
                                >
                                  <div className={cn(
                                    "absolute top-1 w-3 h-3 rounded-full bg-white transition-all",
                                    settings.autoEnhance ? "left-6" : "left-1"
                                  )} />
                                </button>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    )}


                    {/* 6. Custom Agent Skills */}
                    {activeSettingsTab === 'skills' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1 text-left">
                          <h2 className="text-xl font-black text-foreground tracking-tight">Custom Expert Agent Skills</h2>
                          <p className="text-xs text-muted-foreground">Upload and equip customized system prompt instructions in IndexedDB, giving experts specialized abilities when matching commands.</p>
                        </div>

                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-6 space-y-6 text-left">
                          <div className="flex items-center justify-between bg-[#121217] p-4 rounded-xl border border-border/10">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                                <BrainCircuit className="w-5 h-5" />
                              </div>
                              <div className="flex flex-col">
                                <span className="text-xs font-bold text-[#f3e8ff]">Active Loaded Skills</span>
                                <span className="text-[10px] font-mono text-muted-foreground">Count: {settings.skills?.length || 0} expert overrides</span>
                              </div>
                            </div>
                            <button 
                              onClick={() => {
                                setIsSettingsOpen(false);
                                setIsSkillsManagerOpen(true);
                              }}
                              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-600/10 cursor-pointer"
                            >
                              Manage Skills Panels
                            </button>
                          </div>

                          <span className="text-xs font-bold text-foreground block">Active Expert Skills Preview</span>
                          <div className="space-y-2 max-h-64 overflow-y-auto custom-scrollbar pr-1">
                            {!settings.skills || settings.skills.length === 0 ? (
                              <div className="text-center p-8 border border-dashed border-border/20 rounded-xl text-xs text-muted-foreground">
                                No custom expert skills loaded. Click Manage Skills above to initialize custom triggers.
                              </div>
                            ) : (
                              settings.skills.map((s: any) => (
                                <div key={s.id} className="p-3 bg-[#121217] rounded-xl border border-border/10 flex items-center justify-between text-xs">
                                  <div className="space-y-0.5">
                                    <span className="font-extrabold text-foreground">{s.name || 'Untitled Skill'}</span>
                                    <p className="text-[10px] text-muted-foreground truncate max-w-sm">{s.prompt || 'No description provided'}</p>
                                  </div>
                                  <span className="px-2 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20 text-[9px] font-mono text-indigo-400 font-bold uppercase shrink-0">Expert Override</span>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </div>
                    )}


                    {/* 7. Fact Memory */}
                    {activeSettingsTab === 'memory' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1 text-left">
                          <h2 className="text-xl font-black text-foreground tracking-tight">Long-Term Continuity Memory</h2>
                          <p className="text-xs text-muted-foreground font-sans">Maintains contextual facts and user configuration across independent prompts for infinite continuity.</p>
                        </div>

                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-6 space-y-6 text-left">
                          <div className="flex items-center justify-between bg-[#121217] p-4 rounded-xl border border-border/10">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-xl bg-teal-500/10 flex items-center justify-center text-teal-400">
                                <Brain className="w-5 h-5 text-teal-400 animate-pulse" />
                              </div>
                              <div className="flex flex-col">
                                <span className="text-xs font-bold text-foreground font-sans">Stored Cross-Chat Memories</span>
                                <span className="text-[10px] font-mono text-muted-foreground">Total records in db: {memoriesLength} items</span>
                              </div>
                            </div>
                            <button 
                              onClick={() => {
                                setIsSettingsOpen(false);
                                setIsMemoryManagerOpen(true);
                              }}
                              className="px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-teal-600/10 cursor-pointer"
                            >
                              Explore Memory Board
                            </button>
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <span className="text-xs font-semibold text-foreground">Auto-Capture Fact Memories</span>
                              <p className="text-[10px] text-muted-foreground font-sans">Silently audit and extract preferences directly from conversation pipelines.</p>
                            </div>
                            <button 
                              onClick={() => {
                                const val = settings.autoMemoryEnabled ?? true;
                                const updated = { ...settings, autoMemoryEnabled: !val };
                                setSettings(updated);
                                saveSettings(updated);
                              }}
                              className={cn(
                                "w-10 h-5 rounded-full relative transition-colors cursor-pointer shrink-0",
                                (settings.autoMemoryEnabled ?? true) ? "bg-teal-500" : "bg-muted"
                              )}
                            >
                              <div className={cn(
                                "absolute top-1 w-3 h-3 rounded-full bg-white transition-all",
                                (settings.autoMemoryEnabled ?? true) ? "left-6" : "left-1"
                              )} />
                            </button>
                          </div>
                        </div>
                      </div>
                    )}


                    {/* 8. Google Drive Integration */}
                    {activeSettingsTab === 'gdrive' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1 text-left">
                          <h2 className="text-xl font-black text-foreground tracking-tight">Google Drive Cloud Synchronization</h2>
                          <p className="text-xs text-muted-foreground">Authorize, disconnect, or customize automatic database snapshots sent straight to your personal Google Drive account sandbox space.</p>
                        </div>

                        {/* Connection Card (OneDrive style clone) */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-6 space-y-6 text-left">
                          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 bg-[#121217] rounded-xl border border-border/10">
                            <div className="flex items-center gap-3">
                              <div className={cn(
                                "w-10 h-10 rounded-xl flex items-center justify-center shadow-lg",
                                isDriveConnected ? "bg-emerald-500/15 text-emerald-400" : "bg-[#2563eb]/15 text-[#2563eb]"
                              )}>
                                <Cloud className="w-5 h-5 animate-pulse" />
                              </div>
                              <div className="flex flex-col">
                                <span className="text-xs font-extrabold text-foreground">Sync State Indicator</span>
                                <span className={cn(
                                  "text-[10px] font-mono font-bold uppercase tracking-wider",
                                  isDriveConnected ? "text-emerald-400" : "text-blue-400"
                                )}>
                                  {isDriveConnected ? "ESTABLISHED (Connected)" : "NOT CONNECTED"}
                                </span>
                              </div>
                            </div>
                            
                            {isDriveConnected ? (
                              <button 
                                onClick={() => {
                                  localStorage.removeItem('gdrive_connected');
                                  localStorage.removeItem('gdrive_token');
                                  setIsDriveConnected(false);
                                }}
                                className="px-4 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-bold rounded-xl border border-rose-500/20 transition-all cursor-pointer"
                              >
                                Disconnect Account
                              </button>
                            ) : (
                              <button 
                                onClick={handleConnectDrive}
                                className="px-4 py-1.5 bg-[#2563eb] hover:bg-[#1d4ed8] text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-blue-600/10 cursor-pointer"
                              >
                                Authenticate Drive Setup
                              </button>
                            )}
                          </div>

                          {/* Cloud backup selector checkboxes */}
                          <div className="space-y-3">
                            <div className="space-y-0.5">
                              <span className="text-xs font-extrabold text-[#f3e8ff]">Cloud Synchronize Categories Selector</span>
                              <p className="text-[10px] text-muted-foreground font-sans">Select precisely which categories automatically back up & sync to your Google Drive sandbox.</p>
                            </div>
                            
                            <div className="space-y-2 bg-[#121217] rounded-xl border border-border/10 p-4">
                              {[
                                { key: 'chats', label: 'Conversations & Prompts', desc: 'Sync prompt histories and chains' },
                                { key: 'files', label: 'Uploaded Documents & Binaries', desc: 'Backup IndexedDB documents' },
                                { key: 'projects', label: 'Web & Python Projects', desc: 'Sync full sandbox files and code' },
                                { key: 'skills', label: 'Custom Agent Skills', desc: 'Backup custom expert instructions' },
                                { key: 'memories', label: 'Long-term Memories', desc: 'Sync facts recalled across sessions' }
                              ].map(({ key, label, desc }) => {
                                const enabled = settings.gdriveBackupSelector?.[key as keyof typeof settings.gdriveBackupSelector] !== false;
                                return (
                                  <div key={key} className="flex items-center justify-between border-b border-border/5 pb-2.5 last:pb-0 last:border-0 text-left">
                                    <div className="space-y-0.5 pr-4">
                                      <span className="text-xs font-bold text-[#e4e4eb]">{label}</span>
                                      <p className="text-[10px] text-muted-foreground font-sans">{desc}</p>
                                    </div>
                                    <button 
                                      type="button"
                                      onClick={() => {
                                        const updatedSelectors = {
                                          chats: true,
                                          files: true,
                                          projects: true,
                                          skills: true,
                                          memories: true,
                                          ...(settings.gdriveBackupSelector || {}),
                                          [key]: !enabled
                                        };
                                        const updatedSettings = {
                                          ...settings,
                                          gdriveBackupSelector: updatedSelectors
                                        };
                                        setSettings(updatedSettings);
                                        saveSettings(updatedSettings);
                                      }}
                                      className={cn(
                                        "w-10 h-5 rounded-full relative transition-colors cursor-pointer shrink-0",
                                        enabled ? "bg-primary" : "bg-muted"
                                      )}
                                    >
                                      <div className={cn(
                                        "absolute top-1 w-3 h-3 rounded-full bg-white transition-all",
                                        enabled ? "left-6" : "left-1"
                                      )} />
                                    </button>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}


                    {/* 9. Local Storage & Backups */}
                    {activeSettingsTab === 'local_save' && (
                      <div className="space-y-6 animate-fadeIn">
                        <div className="space-y-1 text-left">
                          <h2 className="text-xl font-black text-foreground tracking-tight">Local Storage backups</h2>
                          <p className="text-xs text-muted-foreground">Download instant database snapshots, restore specific chats or reset all workspace environments.</p>
                        </div>

                        {/* snapshot packaging */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-4 text-left">
                          <div className="space-y-1">
                            <span className="text-xs font-extrabold text-[#f3e8ff]">Download Complete Snapshot Schema</span>
                            <p className="text-[10px] text-muted-foreground">Locks and packages all files, chats, memories, skills, and layouts into an offline JSON snapshot file.</p>
                          </div>
                          
                          <button 
                            onClick={handleExportDatabaseSnapshot}
                            disabled={dbExportStatus === 'exporting'}
                            className="w-full flex items-center justify-between p-3.5 bg-[#121217] rounded-xl text-xs hover:bg-[#1a1a24] transition-colors border border-border/15 disabled:opacity-50 cursor-pointer text-foreground"
                          >
                            <div className="flex items-center gap-2">
                              <Database className="w-4 h-4 text-primary animate-pulse" />
                              <span className="font-extrabold">
                                {dbExportStatus === 'idle' && 'Export Full Database Schema Snapshot'}
                                {dbExportStatus === 'exporting' && 'Packaging Database Indexes...'}
                                {dbExportStatus === 'success' && 'Downloaded Snapshot successfully!'}
                                {dbExportStatus === 'error' && 'Snapshot Packaging Failed'}
                              </span>
                            </div>
                            {dbExportStatus === 'success' ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400 font-bold" />
                            ) : (
                              <Download className="w-3.5 h-3.5 text-primary" />
                            )}
                          </button>
                        </div>

                        {/* Local chats backups */}
                        <div className="bg-[#181820] rounded-2xl border border-border/30 p-5 space-y-4 text-left font-sans">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-extrabold text-[#f3e8ff]">Local Prompt History Snapshots</span>
                            <div className="flex gap-2">
                              {backupStatus && (
                                <span className="text-[10px] text-emerald-400 font-bold animate-pulse">{backupStatus}</span>
                              )}
                              {backupError && (
                                <span className="text-[10px] text-rose-400 font-bold animate-pulse">{backupError}</span>
                              )}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <button 
                              onClick={handleExportAllChats}
                              disabled={chats.length === 0}
                              className="flex items-center justify-center gap-2 p-3 bg-[#121217] rounded-xl text-xs font-bold hover:bg-[#1a1a24] hover:text-primary transition-all border border-border/15 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer text-foreground"
                            >
                              <Download className="w-4 h-4 text-primary" />
                              <span>Export Prompt JSON</span>
                            </button>
                            
                            <label className="flex items-center justify-center gap-2 p-3 bg-[#121217] rounded-xl text-xs font-bold hover:bg-[#1a1a24] hover:text-[#818cf8] transition-all border border-border/15 cursor-pointer text-center text-foreground">
                              <Upload className="w-4 h-4 text-[#818cf8]" />
                              <span>Import Prompt Snapshots</span>
                              <input 
                                type="file" 
                                accept=".json"
                                onChange={handleImportFileChange}
                                className="hidden" 
                              />
                            </label>
                          </div>
                        </div>

                        {/* Purgatory danger zone */}
                        <div className="bg-rose-500/5 rounded-2xl border border-rose-500/15 p-5 space-y-3 text-left">
                          <span className="text-xs font-extrabold text-rose-400 flex items-center gap-2 uppercase tracking-wider select-none animate-pulse">
                            <AlertCircle className="w-4 h-4 text-rose-400" /> Danger Environment Zone
                          </span>
                          <p className="text-[10px] text-muted-foreground/80 leading-relaxed font-sans">
                            Resets all IndexedDB databases, deletes custom expert skills, purges all uploaded file tokens, clears long-term continuity memories, and logs out Google syncing accounts. This action is absolutely permanent.
                          </p>
                          <button 
                            onClick={() => handleClearAll()}
                            className="w-full flex items-center justify-center gap-2 p-3.5 bg-rose-500/10 text-rose-400 hover:bg-rose-500 hover:text-white rounded-xl text-xs font-extrabold transition-all border border-rose-500/25 cursor-pointer font-sans"
                          >
                            <Trash2 className="w-4 h-4" />
                            Purge All Browser Workspace Data
                          </button>
                        </div>
                      </div>
                    )}

                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      
      <AnimatePresence>
        {isPythonPlaygroundOpen && (
          <PythonPlayground 
            isOpen={isPythonPlaygroundOpen}
            onClose={() => setIsPythonPlaygroundOpen(false)}
            onRun={(code) => executeTool('python', { code }) as Promise<{ stdout: string, plot: string | null }>}
            settings={settings}
            chatModels={CHAT_MODELS}
            getModelInfo={getModelInfo}
            initialProjectId={activePythonPlaygroundProjectId || undefined}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isWebSandboxOpen && (
          <WebSandbox 
            isOpen={isWebSandboxOpen}
            onClose={() => setIsWebSandboxOpen(false)}
            settings={settings}
            chatModels={CHAT_MODELS}
            getModelInfo={getModelInfo}
            initialProjectId={activeWebSandboxProjectId || undefined}
          />
        )}
      </AnimatePresence>

      {/* Infinity Mode Modal */}
      <AnimatePresence>
        {isInfinityOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-card border border-border rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-md overflow-hidden"
            >
              <div className="p-4 sm:p-6 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <InfinityIcon className="w-5 h-5 text-primary" />
                  <h2 className="text-lg sm:text-xl font-bold tracking-tight">Infinity Mode</h2>
                </div>
                <button onClick={() => setIsInfinityOpen(false)} className="p-2 hover:bg-accent rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-4 sm:p-6 space-y-6 overflow-y-auto max-h-[60vh] custom-scrollbar">
                <div className="space-y-2">
                  <label className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-muted-foreground">Max Attempts: {infinitySettings.maxAttempts}</label>
                  <input 
                    type="range" min="1" max="10" step="1" 
                    value={infinitySettings.maxAttempts}
                    onChange={(e) => setInfinitySettings({ ...infinitySettings, maxAttempts: parseInt(e.target.value) })}
                    className="w-full accent-primary"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-muted-foreground">Critic Strictness: {infinitySettings.strictness}</label>
                  <input 
                    type="range" min="1" max="10" step="1" 
                    value={infinitySettings.strictness}
                    onChange={(e) => setInfinitySettings({ ...infinitySettings, strictness: parseInt(e.target.value) })}
                    className="w-full accent-primary"
                  />
                </div>
              </div>
              <div className="p-4 sm:p-6 border-t border-border bg-muted/30">
                <button 
                  onClick={() => setIsInfinityOpen(false)}
                  className="w-full bg-primary text-primary-foreground py-2.5 rounded-xl font-bold shadow-lg shadow-primary/20 text-sm"
                >
                  Confirm Configuration
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isTestingOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-card border border-border rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-4 sm:p-6 border-b border-border flex items-center justify-between">
                <h2 className="text-lg sm:text-xl font-bold tracking-tight">Model Testing Arena</h2>
                <button onClick={() => setIsTestingOpen(false)} className="p-2 hover:bg-accent rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-4 sm:p-6 flex-1 overflow-hidden flex flex-col gap-4">
                <div className="flex flex-col gap-3">
                  <div className="flex flex-wrap gap-2">
                    <span className="text-xs font-semibold text-muted-foreground flex items-center pr-2">Models:</span>
                    {(settings.enabledChatModels || []).map(modelId => {
                      const isSelected = selectedTestModels.includes(modelId);
                      return (
                        <button 
                          key={modelId}
                          onClick={() => {
                            setSelectedTestModels(prev => {
                              if (prev.includes(modelId)) {
                                return prev.filter(m => m !== modelId);
                              } else {
                                return [...prev, modelId];
                              }
                            });
                          }}
                          className={cn(
                            "px-3 py-1.5 rounded-full text-xs font-medium transition-colors border",
                            isSelected
                              ? "bg-primary text-primary-foreground border-primary" 
                              : "bg-muted/50 border-border hover:bg-muted text-muted-foreground"
                          )}
                        >
                          {getModelInfo(modelId).catalogModel?.name || getModelInfo(modelId).modelId || modelId}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input 
                      value={testPrompt}
                      onChange={(e) => setTestPrompt(e.target.value)}
                      placeholder="Enter a prompt to test across selected models..."
                      className="flex-1 bg-muted border-none rounded-xl px-4 py-2.5 text-sm"
                    />
                    <button 
                      onClick={runModelTest}
                      disabled={testResults.some(r => r.pending)}
                      className="bg-primary text-primary-foreground px-6 py-2.5 rounded-xl font-bold text-sm disabled:opacity-50"
                    >
                      {testResults.some(r => r.pending) ? 'Running...' : 'Run Test'}
                    </button>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-4 custom-scrollbar">
                  {testResults.map((res, i) => (
                    <div key={i} className={cn("border rounded-2xl p-4 flex flex-col space-y-2 h-[400px]", res.pending ? "bg-muted/10 border-border/50 animate-pulse" : "bg-muted/20 border-border")}>
                      <div className="flex items-center justify-between shrink-0">
                        <span className="text-[10px] font-bold uppercase tracking-widest text-primary">
                          {getModelInfo(res.model).catalogModel?.name || getModelInfo(res.model).modelId || res.model}
                        </span>
                        {res.latencyMs && (
                          <div className="flex items-center gap-3 text-[10px] font-mono text-muted-foreground bg-background/50 px-2 py-1 rounded-md border border-border/50">
                            <span>{(res.latencyMs / 1000).toFixed(2)}s</span>
                            {res.tps && <span>{res.tps.toFixed(1)} tps</span>}
                          </div>
                        )}
                      </div>
                      <div className="text-xs sm:text-sm overflow-y-auto custom-scrollbar flex-1 bg-background/50 rounded-xl p-3 border border-border/50">
                        <div className="markdown-body">
                          <ReactMarkdown
                            remarkPlugins={[remarkMath, remarkGfm]}
                            rehypePlugins={[[rehypeKatex, { output: 'html', throwOnError: false }]]}
                            components={{
                              code({node, inline, className, children, ...props}: any) {
                                const match = /language-(\w+)/.exec(className || '');
                                return !inline && match ? (
                                  <CodeBlock
                                    language={match[1]}
                                    code={String(children).replace(/\n$/, '')}
                                  />
                                ) : (
                                  <code className={className} {...props}>
                                    {children}
                                  </code>
                                )
                              }
                            }}
                          >
                            {cleanMessage(res.result)}
                          </ReactMarkdown>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Voice Interface */}
      <AnimatePresence>
        {isVoiceOpen && (
          <VoiceInterface 
            onTranscript={(text) => {
              setInput(text);
              setIsVoiceOpen(false);
            }}
            onClose={() => setIsVoiceOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Thinking Trace Drawer */}
      <ThinkingTraceDrawer 
        isOpen={isThinkingOpen}
        onClose={() => setIsThinkingOpen(false)}
        thinkingProcess={thinkingProcess}
        isGenerating={isGenerating}
        mode={mode === 'multi' ? 'multi' : 'single'}
        infinityEnabled={infinitySettings.enabled}
        infinitySettings={infinitySettings}
      />

        {/* Side Preview Panel */}
        <AnimatePresence>
          {activeCodePreview && (
            <motion.div 
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: isMobile ? '100%' : '50%', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className={cn(
                "border-l border-border bg-card relative overflow-hidden flex flex-col z-40 min-w-0",
                isMobile && "fixed inset-0 z-[100]"
              )}
            >
              <CodePreview 
                code={activeCodePreview.code}
                language={activeCodePreview.language}
                onClose={() => setActiveCodePreview(null)}
                inline={!isMobile}
                onFixError={(error, code) => {
                  console.log("Fixing error:", { error, lang: activeCodePreview?.language });
                  const lang = activeCodePreview?.language || 'python';
                  setActiveCodePreview(null);
                  const fixPrompt = `I encountered an error in the code you generated:\n\n\`\`\`\n${error}\n\`\`\`\n\nOriginal Code:\n\`\`\`${lang}\n${code}\n\`\`\`\n\nPlease debug and fix this error. Return the complete corrected code and verify it works if possible.`;
                  handleSendMessage(fixPrompt);
                }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
  </div>
  );
}
