import { GoogleGenAI } from "@google/genai";
import * as webllm from "@mlc-ai/web-llm";
import { getModelInfo } from "../models";
import { Settings } from "../db";
import { sanitizeBaseUrl } from "../utils";

async function withExponentialBackoff<T>(
  fn: () => Promise<T>,
  maxAttempts = 5,
  initialDelay = 1000,
  factor = 2,
  signal?: AbortSignal
): Promise<T> {
  let attempt = 0;
  while (true) {
    try {
      return await fn();
    } catch (err: any) {
      attempt++;
      const errMsg = String(err).toLowerCase();
      const isRateLimit = 
        errMsg.includes("429") || 
        errMsg.includes("rate limit") || 
        errMsg.includes("resourceexhausted") || 
        errMsg.includes("resource_exhausted") ||
        errMsg.includes("too many requests") ||
        errMsg.includes("quota exceeded") ||
        (err?.status === 429);
        
      if (!isRateLimit || attempt >= maxAttempts) {
        throw err;
      }
      if (signal?.aborted) {
        throw new Error("Aborted");
      }
      const delay = initialDelay * Math.pow(factor, attempt - 1) * (0.8 + Math.random() * 0.4);
      console.warn(`Rate limit hit (429). Retrying in ${Math.round(delay)}ms... (Attempt ${attempt}/${maxAttempts})`);
      await new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(resolve, delay);
        if (signal) {
          signal.addEventListener('abort', () => {
            clearTimeout(timeout);
            reject(new Error("Aborted"));
          });
        }
      });
    }
  }
}

const decodeBase64 = (b64: string): string => {
  try {
    return decodeURIComponent(atob(b64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  } catch (e) {
    try {
      return atob(b64);
    } catch (e2) {
      return b64;
    }
  }
};

export const getRelevantSnippets = (query: string, fileContent: string, maxExcerptChars: number = 5000): { excerpts: string; percentMatched: number } => {
  if (!fileContent) return { excerpts: '', percentMatched: 0 };
  if (fileContent.length <= maxExcerptChars) {
    return { excerpts: fileContent, percentMatched: 100 };
  }

  // Common stop words to exclude from query analysis
  const stopWords = new Set([
    'the', 'a', 'an', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 'to', 'for', 'in', 'on', 'with', 'by', 'at', 
    'this', 'that', 'of', 'from', 'it', 'its', 'as', 'if', 'then', 'else', 'your', 'my', 'how', 'what', 'why', 
    'who', 'where', 'when', 'which', 'them', 'they', 'you', 'he', 'she', 'we', 'us', 'i', 'me', 'please', 'can', 
    'should', 'would', 'could', 'does', 'do', 'did', 'done', 'has', 'have', 'had', 'any', 'some', 'all', 'more', 
    'most', 'many', 'few', 'about', 'above', 'after', 'again', 'against', 'am', 'arent', 
    'because', 'been', 'before', 'being', 'below', 'between', 'both', 'cant', 'cannot', 'couldnt', 
    'didnt', 'doesnt', 'doing', 'dont', 'down', 'during', 'each', 'further', 'hadnt', 'hasnt', 'havent', 'having', 
    'hed', 'hell', 'hes', 'her', 'here', 'heres', 'hers', 'herself', 'him', 'himself', 'his', 'hows', 'id', 'ill', 'im', 
    'ive', 'into', 'isnt', 'itself', 'lets', 'mustnt', 'myself', 'nor', 'not', 'off', 'once', 'only', 'other', 'ought', 
    'our', 'ours', 'ourselves', 'out', 'over', 'own', 'same', 'shant', 'shed', 'shell', 'shes', 'shouldnt', 
    'so', 'such', 'than', 'thats', 'their', 'theirs', 'themselves', 'there', 'theres', 'these', 'theyd', 'theyll', 
    'theyre', 'theyve', 'those', 'through', 'too', 'under', 'until', 'up', 'very', 'wasnt', 'wed', 'well', 
    'weve', 'werent', 'whats', 'whens', 'wheres', 'while', 'whos', 'whom', 'whys', 'wont', 'wouldnt', 'youd', 
    'youll', 'youre', 'youve', 'yours', 'yourself', 'yourselves'
  ]);

  const queryWords = (query || '').toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !stopWords.has(w));

  // If no search terms found, just retrieve the beginning of the file to preserve context overview
  if (queryWords.length === 0) {
    return {
      excerpts: fileContent.substring(0, maxExcerptChars) + "\n\n... [Truncated to save context, no specific keyword matches found] ...",
      percentMatched: 0
    };
  }

  const lines = fileContent.split(/\r?\n/);
  interface Chunk {
    text: string;
    startLine: number;
    endLine: number;
    score: number;
    index: number;
  }

  const chunks: Chunk[] = [];
  const chunkSize = 15; 
  const overlap = 4;

  for (let i = 0; i < lines.length; i += (chunkSize - overlap)) {
    const chunkLines = lines.slice(i, i + chunkSize);
    if (chunkLines.length === 0) break;
    const chunkText = chunkLines.join('\n');
    const lowercaseText = chunkText.toLowerCase();
    
    let score = 0;
    let matchedUniqueWords = 0;
    for (const word of queryWords) {
      if (word.length === 0) continue;
      let pos = lowercaseText.indexOf(word);
      let count = 0;
      while (pos !== -1) {
        count++;
        pos = lowercaseText.indexOf(word, pos + word.length);
      }
      if (count > 0) {
        score += count * (word.length / 3); 
        matchedUniqueWords++;
      }
    }

    if (matchedUniqueWords > 1) {
      score *= (1 + 0.5 * matchedUniqueWords); 
    }

    chunks.push({
      text: chunkText,
      startLine: i + 1,
      endLine: Math.min(i + chunkLines.length, lines.length),
      score,
      index: chunks.length
    });

    if (i + chunkSize >= lines.length) break;
  }

  const sortedByScore = [...chunks].sort((a, b) => b.score - a.score);
  const highestScore = sortedByScore[0]?.score || 0;

  const selectedChunks: Chunk[] = [];
  let currentLength = 0;

  if (highestScore > 0) {
    for (const chunk of sortedByScore) {
      if (chunk.score === 0 && selectedChunks.length > 0) break;
      if (currentLength + chunk.text.length > maxExcerptChars) {
        if (selectedChunks.length === 0) {
          selectedChunks.push(chunk);
        }
        break;
      }
      selectedChunks.push(chunk);
      currentLength += chunk.text.length;
    }
  }

  if (selectedChunks.length === 0) {
    for (const chunk of chunks) {
      if (currentLength + chunk.text.length > maxExcerptChars) {
        if (selectedChunks.length === 0) selectedChunks.push(chunk);
        break;
      }
      selectedChunks.push(chunk);
      currentLength += chunk.text.length;
    }
  }

  selectedChunks.sort((a, b) => a.index - b.index);

  const mergedExcerpts: string[] = [];
  let currentMerge: { text: string; startLine: number; endLine: number; index: number } | null = null;

  for (const chunk of selectedChunks) {
    if (!currentMerge) {
      currentMerge = { ...chunk };
    } else {
      if (chunk.startLine <= currentMerge.endLine + 1) {
        const chunkLines = chunk.text.split('\n');
        const overlapCount = currentMerge.endLine - chunk.startLine + 1;
        const nonOverlapLines = overlapCount > 0 ? chunkLines.slice(overlapCount) : chunkLines;
        currentMerge.text = [...currentMerge.text.split('\n'), ...nonOverlapLines].join('\n');
        currentMerge.endLine = chunk.endLine;
      } else {
        mergedExcerpts.push(`[Lines ${currentMerge.startLine}-${currentMerge.endLine}]\n${currentMerge.text}`);
        currentMerge = { ...chunk };
      }
    }
  }
  if (currentMerge) {
    mergedExcerpts.push(`[Lines ${currentMerge.startLine}-${currentMerge.endLine}]\n${currentMerge.text}`);
  }

  let matchedCount = 0;
  for (const word of queryWords) {
    if (fileContent.toLowerCase().includes(word)) {
      matchedCount++;
    }
  }
  const percentMatched = Math.round((matchedCount / queryWords.length) * 100);

  const finalString = mergedExcerpts.join('\n\n... [Content Truncated / Non-matching sections hidden to conserve context] ...\n\n');
  return {
    excerpts: finalString,
    percentMatched
  };
};

export const formatMessageWithAttachments = (msg: any) => {
  if (msg._formatted) {
    return msg;
  }
  let textContent = msg.content || '';
  
  if (msg.attachedFiles && msg.attachedFiles.length > 0) {
    // Treat SVGs as text documents instead of images, so the AI can inspect the code directly
    // and to prevent vision engine unsupported MIME errors.
    const documents = msg.attachedFiles.filter((f: any) => !f.type.startsWith('image/') || f.type === 'image/svg+xml');
    if (documents.length > 0) {
      const docSnippets = documents.map((doc: any) => {
        let fileBody = doc.content;
        if (doc.extractedText) {
          fileBody = doc.extractedText;
        } else if (typeof fileBody === 'string' && fileBody.startsWith('data:')) {
          const parts = fileBody.split(',');
          if (parts[1]) {
            const isText = doc.type.startsWith('text/') || 
                           doc.type === 'image/svg+xml' ||
                           ['json', 'py', 'js', 'ts', 'tsx', 'jsx', 'html', 'css', 'md', 'txt', 'csv', 'yaml', 'yml', 'rs', 'go', 'c', 'cpp', 'h', 'java', 'gradle', 'svg'].some(ext => doc.name.toLowerCase().endsWith('.' + ext));
            if (isText) {
              try {
                fileBody = decodeBase64(parts[1]);
              } catch (e) {
                fileBody = parts[1];
              }
            } else {
              fileBody = `[Binary / Document Data (${doc.type}) - Base64 Length: ${parts[1].length}]`;
            }
          }
        }
        
        const maxLimitChars = 5000;
        if (typeof fileBody === 'string' && fileBody.length > maxLimitChars) {
          const searchResult = getRelevantSnippets(msg.content || '', fileBody, maxLimitChars);
          return `\n\n### CHAT WINDOW FILE ATTACHMENT: ${doc.name} (${doc.type})\n[IMPORTANT: This is a TEMPORARY local file attachment uploaded to this specific chat query. Treat it as content source reference. Do NOT confuse it with long-term memories or system preferences]\n[CONTEXT OPTIMIZED: Showing only relevant sections based on your query (${searchResult.percentMatched}% query terms matched)]\n\n${searchResult.excerpts}\n-------------------------------------------`;
        }

        return `\n\n### CHAT WINDOW FILE ATTACHMENT: ${doc.name} (${doc.type})\n[IMPORTANT: This is a TEMPORARY local file attachment uploaded to this specific chat query. Treat it as content source reference. Do NOT confuse it with long-term memories or system preferences]\n\n${fileBody}\n-------------------------------------------`;
      }).join('');
      textContent += docSnippets;
    }
  }

  // Filter out image/svg+xml from the binary image queue
  const attachedFileImages = msg.attachedFiles
    ? msg.attachedFiles
        .filter((f: any) => f.type && typeof f.type === 'string' && f.type.startsWith('image/') && f.type !== 'image/svg+xml')
        .map((f: any) => f.content)
    : [];
  const attachedDirectImages = msg.attachedImages || [];

  const uniqueImagesSet = new Set<string>();
  attachedFileImages.forEach((img: any) => {
    if (typeof img === 'string') uniqueImagesSet.add(img);
  });
  attachedDirectImages.forEach((img: any) => {
    if (typeof img === 'string') uniqueImagesSet.add(img);
  });

  // Filter out any SVG base64 strings from standard vision models
  const images = Array.from(uniqueImagesSet).filter((img: string) => {
    return !img.startsWith('data:image/svg') && !img.includes('image/svg+xml');
  });

  return {
    role: msg.role,
    content: textContent,
    images: images.length > 0 ? images.map((img: string) => img.split(',')[1] || img) : undefined,
    attachedImages: images,
    attachedFiles: msg.attachedFiles,
    _formatted: true
  };
};

export interface GetCompletionConfig {
  messages: any[];
  config: {
    temperature?: number;
    max_tokens?: number;
    stream?: boolean;
    signal?: AbortSignal;
    modelOverride?: string;
  };
  settings: Settings;
  activeChatModel?: any;
  setThinkingProcess?: React.Dispatch<React.SetStateAction<any[]>>;
}

export const getCompletion = async ({
  messages,
  config,
  settings,
  activeChatModel,
  setThinkingProcess
}: GetCompletionConfig) => {
  const modelEquippedId = config.modelOverride || settings.puterModel || '';
  const modelInfo = getModelInfo(modelEquippedId);
  const equippedProvider = modelInfo.provider || 'puter';
  const modelToUse = modelInfo.modelId;
  const hasVision = modelInfo.hasVision;
  
  let effectiveMessages = messages.map(m => formatMessageWithAttachments(m));
  const hasImages = effectiveMessages.some(m => m.attachedImages && m.attachedImages.length > 0);

  if (hasImages && !hasVision) {
    if (setThinkingProcess) {
      setThinkingProcess(prev => [...prev, { 
        agent: 'System', 
        text: 'Warning: This model cannot see images. Images have been omitted from this request.' 
      }]);
    }
    effectiveMessages = effectiveMessages.map(m => {
      if (m.attachedImages && m.attachedImages.length > 0) {
        return { ...m, attachedImages: [] };
      }
      return m;
    });
  }

  // Extract system messages for proper formatting
  const systemMsgs = effectiveMessages.filter(m => m.role === 'system');
  const systemContent = systemMsgs.length > 0 
    ? systemMsgs.map(m => m.content).join('\n\n') 
    : settings.systemPrompt;
  const otherMsgs = effectiveMessages.filter(m => m.role !== 'system');
  
  // Use Gemini API if specifically equipped from google provider
  if (equippedProvider === 'openai') {
    const { modelId: modelToUse } = getModelInfo(modelEquippedId);
    const customModel = (settings.customOpenaiModels || []).find(m => m.id === modelToUse);

    if (!customModel) {
      throw new Error("The selected custom OpenAI model configuration was not found. Please select or add a custom model in the model settings.");
    }

    const apiKey = customModel.apiKey;
    const baseUrl = sanitizeBaseUrl(customModel.baseUrl || 'https://api.openai.com/v1');
    const targetModel = customModel.modelId;

    if (!apiKey) {
      throw new Error(`The custom OpenAI model "${customModel.name}" does not have an API key configured. Please edit the model's credentials in settings.`);
    }

    if (setThinkingProcess) {
      setThinkingProcess(prev => [...prev, {
        agent: 'OpenAI',
        text: `Connecting to OpenAI compatible endpoint at ${baseUrl} with model "${targetModel}"...`
      }]);
    }

    const formatOpenAIMessages = (msgs: any[]) => {
      return msgs.map(m => {
        const formatted = formatMessageWithAttachments(m);
        if (formatted.attachedImages && formatted.attachedImages.length > 0) {
          const contentParts: any[] = [{ type: 'text', text: formatted.content }];
          formatted.attachedImages.forEach((img: string) => {
            let processedUrl = img;
            if (!img.startsWith('data:')) {
              processedUrl = `data:image/jpeg;base64,${img}`;
            }
            contentParts.push({
              type: 'image_url',
              image_url: { url: processedUrl }
            });
          });
          return { role: m.role, content: contentParts };
        }
        return { role: m.role, content: formatted.content };
      });
    };

    const formattedMsgs = systemContent 
      ? [{ role: 'system', content: systemContent }, ...formatOpenAIMessages(otherMsgs)]
      : formatOpenAIMessages(otherMsgs);

    const extractContentFromMangledText = (text: string): { content: string, thought: string }[] => {
      const contents: { content: string, thought: string }[] = [];
      let cleanText = text.trim();
      
      if (cleanText.startsWith('data: ')) {
        const afterData = cleanText.substring(5).trim();
        if (afterData === '[DONE]') {
          return [];
        }
        cleanText = afterData;
      }
      
      if (!cleanText) {
        return [];
      }

      const extractFields = (obj: any): { content: string, thought: string } => {
        const thought = 
          obj.message?.reasoning_content ??
          obj.message?.reasoning ??
          obj.message?.thought ??
          obj.choices?.[0]?.delta?.reasoning_content ??
          obj.choices?.[0]?.delta?.reasoning ??
          obj.choices?.[0]?.delta?.thought ??
          obj?.reasoning_content ??
          obj?.reasoning ??
          obj?.thought ??
          '';
        const content = 
          obj.message?.content ?? 
          obj.response ?? 
          obj.choices?.[0]?.delta?.content ?? 
          obj.choices?.[0]?.message?.content ?? 
          obj.content ?? 
          obj.text ?? 
          '';
        return { content, thought };
      };

      try {
        const parsed = JSON.parse(cleanText);
        const { content, thought } = extractFields(parsed);
        if (content || thought) {
          contents.push({ content, thought });
        }
        return contents;
      } catch (e) {
        const parts: string[] = [];
        let depth = 0;
        let start = -1;
        for (let i = 0; i < cleanText.length; i++) {
          if (cleanText[i] === '{') {
            if (depth === 0) start = i;
            depth++;
          } else if (cleanText[i] === '}') {
            depth--;
            if (depth === 0 && start !== -1) {
              parts.push(cleanText.substring(start, i + 1));
              start = -1;
            }
          }
        }

        for (const part of parts) {
          let p = part.trim();
          if (!p) continue;
          try {
            const parsed = JSON.parse(p);
            const { content, thought } = extractFields(parsed);
            if (content || thought) {
              contents.push({ content, thought });
            }
          } catch (err) {
            // ignore
          }
        }
      }
      return contents;
    };

    if (config.stream) {
      const response = await withExponentialBackoff(async () => {
        const res = await fetch(`${baseUrl.replace(/\/$/, '')}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: targetModel,
            messages: formattedMsgs,
            temperature: settings.temperature,
            stream: true
          }),
          signal: config.signal
        });
        if (!res.ok) {
          const errText = await res.text();
          throw new Error(`OpenAI compatible endpoint error (${res.status}): ${errText || res.statusText}`);
        }
        return res;
      }, 5, 1000, 2, config.signal);

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      return (async function* () {
        if (!reader) return;
        let buffer = '';
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            if (config.signal?.aborted) throw new Error("Aborted");

            buffer += decoder.decode(value || new Uint8Array(), { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            for (const line of lines) {
              const trimmed = line.trim();
              if (trimmed) {
                const chunks = extractContentFromMangledText(trimmed);
                for (const chunkObj of chunks) {
                  yield { choices: [{ delta: { content: chunkObj.content, thought: chunkObj.thought } }] };
                }
              }
            }
          }

          if (buffer.trim()) {
            const chunks = extractContentFromMangledText(buffer);
            for (const chunkObj of chunks) {
              yield { choices: [{ delta: { content: chunkObj.content, thought: chunkObj.thought } }] };
            }
          }
        } finally {
          reader.releaseLock();
        }
      })();
    } else {
      const response = await withExponentialBackoff(async () => {
        const res = await fetch(`${baseUrl.replace(/\/$/, '')}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model: targetModel,
            messages: formattedMsgs,
            temperature: settings.temperature,
            stream: false
          }),
          signal: config.signal
        });
        if (!res.ok) {
          const errText = await res.text();
          throw new Error(`OpenAI compatible endpoint error (${res.status}): ${errText || res.statusText}`);
        }
        return res;
      }, 5, 1000, 2, config.signal);

      const resultJSON = await response.json();
      const content = resultJSON.choices?.[0]?.message?.content || '';
      const thought = resultJSON.choices?.[0]?.message?.reasoning_content || resultJSON.choices?.[0]?.message?.thought || '';
      return { choices: [{ message: { content, thought } }] };
    }
  }

  if (equippedProvider === 'google') {
    const apiKey = settings.geminiApiKey;
    if (!apiKey) {
      throw new Error("Gemini API key is not set. Please provide it in the app settings.");
    }
    
    const ai = new GoogleGenAI({ apiKey });
    const { modelId: rawModelId } = getModelInfo(modelEquippedId);
    let genModelId = rawModelId || 'gemini-3.5-flash';
    
    const formatGeminiMessages = (msgs: any[]) => {
      return msgs.map(m => {
        const parts: any[] = [];
        
        // Feed images to Gemini as inlineData
        if (m.attachedImages && m.attachedImages.length > 0) {
          m.attachedImages.forEach((img: string) => {
            const base64Data = img.split(',')[1] || img;
            const mimeType = img.includes('base64') 
              ? img.split(',')[0].split(':')[1].split(';')[0] 
              : 'image/jpeg';
            parts.push({ inlineData: { data: base64Data, mimeType } });
          });
        }
        
        // Feed video and audio attachments to Gemini as inlineData
        if (m.attachedFiles && m.attachedFiles.length > 0) {
          m.attachedFiles.forEach((file: any) => {
            const fileType = file.type || '';
            const fileName = (file.name || '').toLowerCase();
            const isVideo = fileType.startsWith('video/') || fileName.endsWith('.mp4') || fileName.endsWith('.mov') || fileName.endsWith('.avi') || fileName.endsWith('.webm');
            const isAudio = fileType.startsWith('audio/') || fileName.endsWith('.mp3') || fileName.endsWith('.wav') || fileName.endsWith('.aac') || fileName.endsWith('.ogg');
            
            if ((isVideo || isAudio) && typeof file.content === 'string') {
              let base64Data = file.content;
              if (base64Data.startsWith('data:')) {
                const commaIdx = base64Data.indexOf(',');
                if (commaIdx !== -1) {
                  base64Data = base64Data.substring(commaIdx + 1);
                }
              }
              const defaultMime = isVideo ? 'video/mp4' : 'audio/mp3';
              const resolvedMime = fileType || defaultMime;
              parts.push({ inlineData: { data: base64Data, mimeType: resolvedMime } });
            }
          });
        }

        parts.push({ text: m.content || '' });
        return { 
          role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user', 
          parts 
        };
      });
    };

    const geminiContents = formatGeminiMessages(otherMsgs);
    
    // "Remove the max response tokens, it should always be max"
    const modelMaxTokens = (modelInfo.catalogModel as any)?.maxTokens || 8192;
    const requestedMaxTokens = config.max_tokens || modelMaxTokens || 8192;
    const maxOutputTokens = requestedMaxTokens;

    if (config.stream) {
      const response = await withExponentialBackoff(() => ai.models.generateContentStream({
        model: genModelId,
        contents: geminiContents,
        config: {
          systemInstruction: systemContent,
          temperature: settings.temperature,
          maxOutputTokens,
        }
      }), 5, 1000, 2, config.signal);

      return (async function* () {
        try {
          for await (const chunk of response) {
            if (config.signal?.aborted) throw new Error("Aborted");
            
            let content = '';
            let thought = '';
            
            const parts = chunk.candidates?.[0]?.content?.parts ?? [];
            for (const part of parts) {
              const partAny = part as any;
              if (typeof partAny.text === 'string') {
                if (partAny.thought === true) {
                  thought += partAny.text;
                } else {
                  content += partAny.text;
                }
              }
              if (partAny.rawThought) {
                if (typeof partAny.rawThought === 'string') {
                  thought += partAny.rawThought;
                } else if (typeof partAny.rawThought === 'object' && partAny.rawThought !== null) {
                  if (typeof partAny.rawThought.text === 'string') {
                    thought += partAny.rawThought.text;
                  } else if (typeof partAny.rawThought.content === 'string') {
                    thought += partAny.rawThought.content;
                  }
                }
              }
            }
            
            if (!content && !thought) {
              try {
                const textVal = chunk.text;
                if (textVal) content = textVal;
              } catch (_) {}
            }

            if (content || thought) {
              yield { choices: [{ delta: { content, thought } }] };
            }
          }
        } catch (err: any) {
          if (err.message === 'Aborted') throw err;
          console.error("Gemini stream error:", err);
          throw err;
        }
      })();
    } else {
      const response = await withExponentialBackoff(() => ai.models.generateContent({
        model: genModelId,
        contents: geminiContents,
        config: {
          systemInstruction: systemContent,
          temperature: settings.temperature,
          maxOutputTokens,
        }
      }), 5, 1000, 2, config.signal);
      
      let content = '';
      let thought = '';
      
      const parts = response.candidates?.[0]?.content?.parts ?? [];
      for (const part of parts) {
        const partAny = part as any;
        if (typeof partAny.text === 'string') {
          if (partAny.thought === true) {
            thought += partAny.text;
          } else {
            content += partAny.text;
          }
        }
        if (partAny.rawThought) {
          if (typeof partAny.rawThought === 'string') {
            thought += partAny.rawThought;
          } else if (typeof partAny.rawThought === 'object' && partAny.rawThought !== null) {
            if (typeof partAny.rawThought.text === 'string') {
              thought += partAny.rawThought.text;
            } else if (typeof partAny.rawThought.content === 'string') {
              thought += partAny.rawThought.content;
            }
          }
        }
      }
      
      if (!content && !thought) {
        try {
          const textVal = response.text;
          if (textVal) content = textVal;
        } catch (_) {}
      }
      
      return { choices: [{ message: { content, thought } }] };
    }
  }

  if (equippedProvider === 'webllm') {
    const { modelId: modelToUse } = getModelInfo(modelEquippedId);
    
    let engine = (window as any)._webLlmEngine;
    if (!engine || (window as any)._webLlmModelId !== modelToUse) {
      if (setThinkingProcess) {
         setThinkingProcess(prev => [...prev, { agent: 'System', text: `Loading WebLLM model ${modelToUse}. This might take a while on first run...` }]);
      }
      engine = await webllm.CreateWebWorkerMLCEngine(
        new Worker(new URL('../worker.ts', import.meta.url), { type: 'module' }),
        modelToUse,
        {
          initProgressCallback: (progress) => {
            if (setThinkingProcess) {
              setThinkingProcess(prev => [...prev.filter(p => !p.text.startsWith('WebLLM Loading: ')), { agent: 'System', text: `WebLLM Loading: ${progress.text}` }]);
            }
          }
        }
      );
      (window as any)._webLlmEngine = engine;
      (window as any)._webLlmModelId = modelToUse;
    }

    const formatMessages = (msgs: any[]) => {
      return msgs.map(m => {
        return { role: m.role, content: m.content };
      });
    };

    const finalMessages = systemContent 
      ? [{ role: 'system', content: systemContent }, ...otherMsgs]
      : otherMsgs;

    if (config.stream) {
      const response = await engine.chat.completions.create({
        messages: formatMessages(finalMessages),
        temperature: settings.temperature,
        // Limit removed dynamically
        stream: true
      });

      return (async function* () {
        for await (const chunk of response) {
          if (config.signal?.aborted) throw new Error("Aborted");
          yield chunk;
        }
      })();
    } else {
      const response = await engine.chat.completions.create({
        messages: formatMessages(finalMessages),
        temperature: settings.temperature,
        // Limit removed dynamically
      });
      
      return response;
    }
  }

  const puter = (window as any).puter;
  if (!puter && equippedProvider === 'puter') throw new Error("Puter.js not loaded.");

  if (equippedProvider === 'puter') {
    if (puter && typeof puter.auth?.isSignedIn === 'function') {
      const signedIn = await puter.auth.isSignedIn();
      if (!signedIn) {
        if (typeof puter.auth?.signIn === 'function') {
          try {
            await puter.auth.signIn();
            const signedInRetry = await puter.auth.isSignedIn();
            if (!signedInRetry) {
              throw new Error("You must be signed into Puter to send messages using Puter.js models.");
            }
          } catch (signInErr: any) {
            let detail = '';
            if (signInErr) {
              if (typeof signInErr === 'string') detail = signInErr;
              else if (typeof signInErr === 'object') detail = signInErr.message || signInErr.error || JSON.stringify(signInErr);
              else detail = String(signInErr);
            }
            if (detail === '[object Object]' || !detail) {
              detail = 'Authentication popup closed or credentials rejected.';
            }
            throw new Error(`Puter login is required to send messages. Please log in to your Puter account.\nDetail: ${detail}`);
          }
        } else {
          throw new Error("You are not signed into Puter. Please sign in to use Puter.js");
        }
      }
    }
  }

  if (!modelToUse) throw new Error("Please select an AI model before starting the chat.");

  const formatMessagesForOllama = (msgs: any[]) => {
    return msgs.map(m => {
      const formatted = formatMessageWithAttachments(m);
      return { 
        role: m.role, 
        content: formatted.content, 
        images: formatted.images 
      };
    });
  };

  const formatOpenAIMessagesForOllama = (msgs: any[]) => {
    return msgs.map(m => {
      const formatted = formatMessageWithAttachments(m);
      if (formatted.attachedImages && formatted.attachedImages.length > 0) {
        const contentParts: any[] = [{ type: 'text', text: formatted.content }];
        formatted.attachedImages.forEach((img: string) => {
          contentParts.push({
            type: 'image_url',
            image_url: { url: img }
          });
        });
        return { role: m.role, content: contentParts };
      }
      return { role: m.role, content: formatted.content };
    });
  };

  const finalOllamaMessages = systemContent 
    ? [{ role: 'system', content: systemContent }, ...otherMsgs]
    : otherMsgs;

  if (equippedProvider === 'ollama') {
    const ollamaUrl = settings.ollamaUrl || 'http://127.0.0.1:11434';
    const modelMaxContext = (modelInfo.catalogModel as any)?.maxContext;
    const safeNumCtx = modelMaxContext || settings.maxContext || 32768;

    if (setThinkingProcess) {
      setThinkingProcess(prev => [...prev, {
        agent: 'Ollama',
        text: `Initializing connection to model "${modelToUse}" at ${ollamaUrl}...`
      }]);
    }

    const extractContentFromMangledText = (text: string): { content: string, thought: string }[] => {
      const contents: { content: string, thought: string }[] = [];
      let cleanText = text.trim();
      
      // Handle standard SSE line prefix "data: "
      if (cleanText.startsWith('data: ')) {
        const afterData = cleanText.substring(5).trim();
        if (afterData === '[DONE]') {
          return [];
        }
        cleanText = afterData;
      }
      
      if (!cleanText) {
        return [];
      }

      const extractFields = (obj: any): { content: string, thought: string } => {
        const thought = 
          obj.message?.reasoning_content ??
          obj.message?.reasoning ??
          obj.message?.thought ??
          obj.choices?.[0]?.delta?.reasoning_content ??
          obj.choices?.[0]?.delta?.reasoning ??
          obj.choices?.[0]?.delta?.thought ??
          obj?.reasoning_content ??
          obj?.reasoning ??
          obj?.thought ??
          '';
        const content = 
          obj.message?.content ?? 
          obj.response ?? 
          obj.choices?.[0]?.delta?.content ?? 
          obj.choices?.[0]?.message?.content ?? 
          obj.content ?? 
          obj.text ?? 
          '';
        return { content, thought };
      };

      // Try parsing single cohesive JSON first
      try {
        const parsed = JSON.parse(cleanText);
        const { content, thought } = extractFields(parsed);
        if (content || thought) {
          contents.push({ content, thought });
        }
        return contents;
      } catch (e) {
        // Safe conjoined-brace JSON extractor
        const parts: string[] = [];
        let depth = 0;
        let start = -1;
        for (let i = 0; i < cleanText.length; i++) {
          if (cleanText[i] === '{') {
            if (depth === 0) start = i;
            depth++;
          } else if (cleanText[i] === '}') {
            depth--;
            if (depth === 0 && start !== -1) {
              parts.push(cleanText.substring(start, i + 1));
              start = -1;
            }
          }
        }

        for (const part of parts) {
          let p = part.trim();
          if (!p) continue;
          try {
            const parsed = JSON.parse(p);
            const { content, thought } = extractFields(parsed);
            if (content || thought) {
              contents.push({ content, thought });
            }
          } catch (err) {
            // ignore
          }
        }
      }
      return contents;
    };

    if (config.stream) {
      let response;
      let endpoint = `${ollamaUrl}/v1/chat/completions`;
      let isNativeOllama = false;

      // Try OpenAI-compatible endpoint first for native streaming goodness
      try {
        console.log(`[Ollama] Trying OpenAI-compatible endpoint: ${endpoint}`);
        response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: modelToUse,
            messages: formatOpenAIMessagesForOllama(finalOllamaMessages),
            stream: true,
            temperature: settings.temperature,
            options: {
              temperature: settings.temperature,
              num_ctx: safeNumCtx
            }
          }),
          signal: config.signal
        });

        if (response.status === 404 || !response.ok) {
          console.warn(`[Ollama] OpenAI endpoint status ${response.status}. Falling back to native chat APIs.`);
          isNativeOllama = true;
        }
      } catch (err) {
        console.warn(`[Ollama] Error reaching OpenAI-compatible endpoint. Falling back to native chat API. Error:`, err);
        isNativeOllama = true;
      }

      if (isNativeOllama) {
        endpoint = `${ollamaUrl}/api/chat`;
        console.log(`[Ollama] Reaching native chat endpoint: ${endpoint}`);
        try {
          response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              model: modelToUse, 
              messages: formatMessagesForOllama(finalOllamaMessages),
              stream: true,
              options: {
                temperature: settings.temperature,
                num_ctx: safeNumCtx
              }
            }),
            signal: config.signal
          });
        } catch (err: any) {
          throw new Error(`Could not connect to Ollama server at ${ollamaUrl}. Ensure Ollama is running and has CORS enabled (e.g. OLLAMA_ORIGINS="*" ollama serve).`);
        }
      }

      if (!response.ok) {
        const errorText = await response.text().catch(() => '');
        throw new Error(`Ollama server error ${response.status}: ${errorText || 'Could not fetch stream.'}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      return (async function* () {
        if (!reader) return;
        let buffer = '';
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            if (config.signal?.aborted) throw new Error("Aborted");

            buffer += decoder.decode(value || new Uint8Array(), { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            for (const line of lines) {
              const trimmed = line.trim();
              if (trimmed) {
                const chunks = extractContentFromMangledText(trimmed);
                for (const chunkObj of chunks) {
                  yield { choices: [{ delta: { content: chunkObj.content, thought: chunkObj.thought } }] };
                }
              }
            }
          }

          if (buffer.trim()) {
            const chunks = extractContentFromMangledText(buffer);
            for (const chunkObj of chunks) {
              yield { choices: [{ delta: { content: chunkObj.content, thought: chunkObj.thought } }] };
            }
          }
        } finally {
          reader.releaseLock();
        }
      })();
    } else {
      let response;
      let endpoint = `${ollamaUrl}/v1/chat/completions`;
      let isNativeOllama = false;

      try {
        response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: modelToUse,
            messages: formatOpenAIMessagesForOllama(finalOllamaMessages),
            stream: false,
            temperature: settings.temperature,
            options: {
              temperature: settings.temperature,
              num_ctx: safeNumCtx
            }
          }),
          signal: config.signal
        });

        if (response.status === 404 || !response.ok) {
          isNativeOllama = true;
        }
      } catch (err) {
        isNativeOllama = true;
      }

      if (isNativeOllama) {
        endpoint = `${ollamaUrl}/api/chat`;
        try {
          response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              model: modelToUse, 
              messages: formatMessagesForOllama(finalOllamaMessages),
              stream: false,
              options: {
                temperature: settings.temperature,
                num_ctx: safeNumCtx
              }
            }),
            signal: config.signal
          });
        } catch (err: any) {
          throw new Error(`Could not connect to Ollama server at ${ollamaUrl}. Ensure Ollama is running and has CORS enabled (e.g. OLLAMA_ORIGINS="*" ollama serve).`);
        }
      }

      if (!response.ok) {
        const errorText = await response.text().catch(() => '');
        throw new Error(`Ollama server error ${response.status}: ${errorText || 'Could not fetch.'}`);
      }

      const data = await response.json();
      const aiResponse = 
        data.message?.content ?? 
        data.response ?? 
        data.choices?.[0]?.message?.content ?? 
        data.content ?? 
        data.text ?? 
        '';
      const aiThought = 
        data.message?.reasoning_content ??
        data.message?.reasoning ??
        data.message?.thought ??
        data.choices?.[0]?.message?.reasoning_content ??
        data.choices?.[0]?.message?.reasoning ??
        data.choices?.[0]?.message?.thought ??
        data.choices?.[0]?.delta?.reasoning_content ??
        data.choices?.[0]?.delta?.reasoning ??
        data.choices?.[0]?.delta?.thought ??
        data.reasoning_content ??
        data.reasoning ??
        data.thought ??
        '';
      return { choices: [{ message: { content: aiResponse, thought: aiThought } }] };
    }
  }

  const formatMessages = (msgs: any[]) => {
    return msgs.map(m => {
      if (m.attachedImages && m.attachedImages.length > 0) {
        const contentParts: any[] = [{ type: 'text', text: m.content }];
        m.attachedImages.forEach((img: string) => {
          contentParts.push({
            type: 'image_url',
            image_url: { url: img }
          });
        });
        return { role: m.role, content: contentParts };
      }
      return { role: m.role, content: m.content };
    });
  };

  const puterMessages = systemContent 
    ? [{ role: 'system', content: systemContent }, ...otherMsgs]
    : otherMsgs;

  if (config.stream) {
    // Return an async generator that normalizes Puter chunks to OpenAI-like format
    const ai = puter.ai;
    const stream = await withExponentialBackoff(() => ai.chat(
      formatMessages(puterMessages),
      { model: modelToUse, stream: true }
    ), 5, 1000, 2, config.signal) as any;

    return (async function* () {
      for await (const chunk of stream) {
        if (config.signal?.aborted) throw new Error("Aborted");
        // Puter yields strings directly or objects depending on version
        // We'll normalize to { choices: [{ delta: { content: string } }] }
        const content = typeof chunk === 'string' ? chunk : (chunk?.text || chunk?.message?.content || '');
        if (content) {
          yield { choices: [{ delta: { content } }] };
        }
      }
    })();
  } else {
    const ai = puter.ai;
    const response = await withExponentialBackoff(() => ai.chat(
      formatMessages(puterMessages),
      { model: modelToUse }
    ), 5, 1000, 2, config.signal) as any;
    const content = typeof response === 'string' ? response : (response?.message?.content || '');
    return { choices: [{ message: { content } }] };
  }
};

/**
 * Robust, unified token counting service across all providers
 */
export interface CountTokensConfig {
  messages: any[];
  attachedFiles: any[];
  pinnedFiles: any[];
  systemPrompt?: string;
  settings: Settings;
}

export async function countTokens({
  messages,
  attachedFiles,
  pinnedFiles,
  systemPrompt,
  settings
}: CountTokensConfig): Promise<number> {
  const modelEquippedId = settings.puterModel || '';
  const modelInfo = getModelInfo(modelEquippedId);
  const equippedProvider = modelInfo.provider || 'puter';
  const { modelId: modelTarget } = modelInfo;
  
  // Format the messages using the same attachment expansion as getCompletion
  let effectiveMessages = messages.map(m => formatMessageWithAttachments(m));
  
  // Extract system prompt and user messages
  const systemContent = systemPrompt || settings.systemPrompt || '';
  const activeMessages = effectiveMessages.filter(m => m.role !== 'system');

  // Helper for text formatting
  const getPromptText = () => {
    let fullText = systemContent ? `System: ${systemContent}\n\n` : '';
    activeMessages.forEach(msg => {
      const roleCapitalized = msg.role.charAt(0).toUpperCase() + msg.role.slice(1);
      fullText += `${roleCapitalized}: ${msg.content || ''}\n`;
    });
    return fullText;
  };

  const textToScan = getPromptText();

  // 1. Google Gemini API
  if (equippedProvider === 'google') {
    const apiKey = settings.geminiApiKey;
    if (!apiKey) {
      return estimateGeneralTokens(textToScan, activeMessages);
    }

    try {
      const ai = new GoogleGenAI({ apiKey });
      let genModelId = modelTarget || 'gemini-3.5-flash';

      // Format messages into Gemini API contents structure
      const formattedGeminiMsgs = activeMessages.map(m => {
        const parts: any[] = [];
        
        // Match handlePaste / formatMessageWithAttachments base64 handling for images
        if (m.attachedImages && m.attachedImages.length > 0) {
          m.attachedImages.forEach((img: string) => {
            const base64Data = img.split(',')[1] || img;
            const mimeType = img.includes('base64') 
              ? img.split(',')[0].split(':')[1].split(';')[0] 
              : 'image/jpeg';
            parts.push({ inlineData: { data: base64Data, mimeType } });
          });
        }
        
        // Match inlineData base64 handling for video/audio attachments
        if (m.attachedFiles && m.attachedFiles.length > 0) {
          m.attachedFiles.forEach((file: any) => {
            const fileType = file.type || '';
            const fileName = (file.name || '').toLowerCase();
            const isVideo = fileType.startsWith('video/') || fileName.endsWith('.mp4') || fileName.endsWith('.mov') || fileName.endsWith('.avi') || fileName.endsWith('.webm');
            const isAudio = fileType.startsWith('audio/') || fileName.endsWith('.mp3') || fileName.endsWith('.wav') || fileName.endsWith('.aac') || fileName.endsWith('.ogg');
            
            if ((isVideo || isAudio) && typeof file.content === 'string') {
              let base64Data = file.content;
              if (base64Data.startsWith('data:')) {
                const commaIdx = base64Data.indexOf(',');
                if (commaIdx !== -1) {
                  base64Data = base64Data.substring(commaIdx + 1);
                }
              }
              const defaultMime = isVideo ? 'video/mp4' : 'audio/mp3';
              const resolvedMime = fileType || defaultMime;
              parts.push({ inlineData: { data: base64Data, mimeType: resolvedMime } });
            }
          });
        }
        
        parts.push({ text: m.content || '' });
        return {
          role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
          parts
        };
      });

      const res = await ai.models.countTokens({
        model: genModelId,
        contents: formattedGeminiMsgs,
        config: systemContent ? { systemInstruction: systemContent } : undefined
      });
      
      if (typeof res.totalTokens === 'number') {
        return res.totalTokens;
      }
    } catch (err) {
      console.error("Gemini countTokens SDK call failed, falling back to contents only:", err);
      try {
        const ai = new GoogleGenAI({ apiKey });
        let genModelId = modelTarget || 'gemini-3.5-flash';
        
        // Fallback representation: append system prompt as user content block
        const backupMsgs = systemContent 
          ? [{ role: 'user', parts: [{ text: systemContent }] }, ...activeMessages.map(m => ({
              role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
              parts: [{ text: m.content || '' }]
            }))]
          : activeMessages.map(m => ({
              role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
              parts: [{ text: m.content || '' }]
            }));
            
        const res = await ai.models.countTokens({
          model: genModelId,
          contents: backupMsgs
        });
        if (typeof res.totalTokens === 'number') {
          return res.totalTokens;
        }
      } catch (innerErr) {
        console.error("Gemini fallback countTokens failed:", innerErr);
      }
    }
    
    return estimateGeneralTokens(textToScan, activeMessages);
  }

  // 2. Local Ollama Server
  if (equippedProvider === 'ollama') {
    const urls = settings.ollamaUrl || 'http://127.0.0.1:11434';
    try {
      const response = await fetch(`${urls}/api/tokenize`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: modelTarget || 'llama3',
          prompt: textToScan
        })
      });
      if (response.ok) {
        const data = await response.json();
        if (data && data.tokens && Array.isArray(data.tokens)) {
          // Multimodal additions: Ollama LLaVA/vision projectors consume ~1024 tokens per image
          let totalTokens = data.tokens.length;
          activeMessages.forEach(m => {
            if (m.attachedImages && m.attachedImages.length > 0) {
              totalTokens += m.attachedImages.length * 1024;
            }
          });
          return totalTokens;
        }
      }
    } catch (err) {
      console.error("Ollama /api/tokenize call failed:", err);
    }
    
    return estimateGeneralTokens(textToScan, activeMessages);
  }

  // 3. Local WebLLM Engine
  if (equippedProvider === 'webllm') {
    const engine = (window as any)._webLlmEngine;
    if (engine && typeof engine.getMessageTokenSize === 'function') {
      try {
        const mappedMsgs = activeMessages.map(m => ({ role: m.role, content: m.content }));
        const finalMsgsForWebLlm = systemContent
          ? [{ role: 'system', content: systemContent }, ...mappedMsgs]
          : mappedMsgs;
          
        const size = await engine.getMessageTokenSize(finalMsgsForWebLlm);
        if (typeof size === 'number') {
          return size;
        }
      } catch (err) {
        console.error("WebLLM getMessageTokenSize call failed:", err);
      }
    }
    
    return estimateGeneralTokens(textToScan, activeMessages);
  }

  // 4. Puter / Others (Estimate cl100k-base layout)
  return estimateGeneralTokens(textToScan, activeMessages);
}

/**
 * Heuristics-based cl100k_base tokenizer approximation
 * Handles multimodal overhead explicitly (258 tokens per image, 560 for video representation)
 */
export function estimateGeneralTokens(text: string, activeMessages: any[] = []): number {
  if (!text) return 0;
  
  // Detect if content is heavily code style (uses lots of delimiters, braces, math operators)
  const codeDelimiters = (text.match(/[\{\}\[\]\;\=\+\-\*]/g) || []).length;
  const isCode = codeDelimiters > text.length * 0.04;
  const charsPerToken = isCode ? 3.1 : 3.8;
  
  let totalTokens = Math.max(1, Math.round(text.length / charsPerToken));

  // Multimodal weight additions for prompt stage files (images and video files)
  activeMessages.forEach(m => {
    if (m.attachedImages && m.attachedImages.length > 0) {
      // Standard OpenAI / Anthropic / Gemini pricing/overhead is around 258-765 tokens per standard image slice
      totalTokens += m.attachedImages.length * 258;
    }
    if (m.attachedFiles && m.attachedFiles.length > 0) {
      m.attachedFiles.forEach((f: any) => {
        const fileType = f.type || '';
        const fileName = (f.name || '').toLowerCase();
        const isVideo = fileType.startsWith('video/') || fileName.endsWith('.mp4') || fileName.endsWith('.mov') || fileName.endsWith('.webm');
        if (isVideo) {
          // Video frames cost significant context representation, model baseline estimation ~560 tokens
          totalTokens += 560;
        }
      });
    }
  });

  return totalTokens;
}

