import React, { useState } from 'react';
import { User, BrainCircuit, Infinity as InfinityIcon, ChevronDown, Triangle, Info, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils';
import { Tooltip } from './Tooltip';

export type Mode = 'auto' | 'single' | 'multi';

export const ModeSelector = ({ 
  mode, 
  setMode, 
  infinityEnabled, 
  setInfinityEnabled,
  onOpenSettings,
  enabledModelsCount = 1,
  className
}: {
  mode: Mode;
  setMode: (m: Mode) => void;
  infinityEnabled: boolean;
  setInfinityEnabled: (e: boolean) => void;
  onOpenSettings: () => void;
  enabledModelsCount?: number;
  className?: string;
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const currentMode = infinityEnabled ? 'infinity' : mode;

  const modes = [
    { 
      id: 'auto', 
      name: 'Auto Orchestrator', 
      icon: Sparkles, 
      description: 'Intelligent routing. Dynamically decides whether to use Single Agent or optimal Multi-Agent architecture & picks the best model.' 
    },
    { 
      id: 'single', 
      name: 'Single Agent', 
      icon: User, 
      description: 'Standard mode. One model generates responses directly.' 
    },
    { 
      id: 'multi', 
      name: 'Multi-Agent', 
      icon: BrainCircuit, 
      description: 'Collaborative mode. Specialist agents work together for better results.' 
    },
    { 
      id: 'infinity', 
      name: 'Infinity Mode', 
      icon: InfinityIcon, 
      description: 'Continuous reasoning. Agents loop until a high-quality result is verified.' 
    }
  ];

  const visibleModes = enabledModelsCount > 1 
    ? modes 
    : modes.filter(m => m.id !== 'auto');

  const handleSelect = (id: string) => {
    if (id === 'auto') {
      setMode('auto');
      setInfinityEnabled(false);
    } else if (id === 'single') {
      setMode('single');
      setInfinityEnabled(false);
    } else if (id === 'multi') {
      setMode('multi');
      setInfinityEnabled(false);
    } else if (id === 'infinity') {
      setMode('multi');
      setInfinityEnabled(true);
    }
    setIsOpen(false);
  };

  const activeMode = visibleModes.find(m => m.id === currentMode) || visibleModes[0] || modes[1];

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <div className="relative">
        <Tooltip content={`Current Mode: ${activeMode.name}`} position="top">
          <button 
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center gap-1.5 px-3 py-1 bg-muted hover:bg-muted/80 border border-border text-foreground font-medium rounded-full text-xs transition-colors h-8 select-none shadow-sm cursor-pointer"
          >
            <activeMode.icon className="w-3.5 h-3.5 text-primary shrink-0" />
            <span className="hidden sm:inline">{activeMode.name}</span>
            <ChevronDown className="w-3 h-3 transition-transform text-muted-foreground" style={{ transform: isOpen ? 'rotate(180deg)' : 'none' }} />
          </button>
        </Tooltip>

        <AnimatePresence>
          {isOpen && (
            <>
              <div className="fixed inset-0 z-[60]" onClick={() => setIsOpen(false)} />
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute bottom-full left-0 mb-2 w-56 bg-popover border border-border rounded-2xl shadow-2xl z-[70] overflow-hidden"
              >
                <div className="p-2.5 border-b border-border bg-muted/30 flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Execution Mode</span>
                  <Tooltip content="Choose how agents are orchestrated">
                    <Info className="w-3 h-3 text-muted-foreground" />
                  </Tooltip>
                </div>
                <div className="p-1">
                  {visibleModes.map(m => (
                    <button
                      key={m.id}
                      onClick={() => handleSelect(m.id)}
                      className={cn(
                        "w-full text-left p-2 rounded-xl text-xs transition-colors flex flex-col gap-0.5",
                        currentMode === m.id ? "bg-primary/10 text-primary border border-primary/20 shadow-sm" : "hover:bg-accent border border-transparent text-muted-foreground hover:text-foreground"
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <m.icon className="w-3.5 h-3.5" />
                        <span className="font-bold">{m.name}</span>
                      </div>
                      <span className="text-[10px] opacity-70 ml-5.5 leading-tight">{m.description}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>

      <Tooltip content="Configure Multi-Agent Settings" position="top">
        <button 
          type="button"
          onClick={onOpenSettings}
          className="p-2 bg-muted hover:bg-muted/80 border border-border hover:border-border/80 rounded-full transition-all text-muted-foreground hover:text-primary h-8 w-8 flex items-center justify-center shrink-0 cursor-pointer shadow-sm"
        >
          <Triangle className="w-3 h-3 rotate-180 fill-current" />
        </button>
      </Tooltip>
    </div>
  );
};
