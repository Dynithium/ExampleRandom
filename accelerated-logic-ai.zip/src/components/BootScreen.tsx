import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";

interface BootScreenProps {
  isBooting: boolean;
}

export function BootScreen({ isBooting }: BootScreenProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!isBooting) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animFrameId: number | null = null;
    let startTime: number | null = null;
    let rotationAngle = 0;

    const BLUE = "#3b82f6";
    const BLUE_DIM = "rgba(59,130,246,0.25)";

    function resize() {
      const size = 200;
      canvas.width = size * window.devicePixelRatio;
      canvas.height = size * window.devicePixelRatio;
      canvas.style.width = size + "px";
      canvas.style.height = size + "px";
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    }

    function drawSwoosh(cx: number, cy: number, r: number, a1: number, a2: number, lw: number, grad: CanvasGradient) {
      ctx.save();
      ctx.strokeStyle = grad;
      ctx.lineWidth = lw;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.arc(cx, cy, r, a1, a2, false);
      ctx.stroke();
      ctx.restore();
    }

    function render(rot: number, progress: number) {
      const w = canvas.width / window.devicePixelRatio;
      const h = canvas.height / window.devicePixelRatio;
      const cx = w / 2, cy = h / 2;
      const radius = w * 0.32;
      const numTeeth = 14;
      const toothDepth = radius * 0.18;
      const innerRadius = radius - toothDepth;
      const shaftRadius = radius * 0.28;

      ctx.clearRect(0, 0, w, h);

      // Gradient for outer halo glow as it spins faster
      ctx.save();
      const outerHalo = ctx.createRadialGradient(cx, cy, radius * 0.8, cx, cy, radius * 1.5);
      outerHalo.addColorStop(0, `rgba(59, 130, 246, ${0.1 * (1 + progress)})`);
      outerHalo.addColorStop(1, "rgba(59, 130, 246, 0)");
      ctx.fillStyle = outerHalo;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 1.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Swooshes
      const swooshes = [
        { r: radius * 1.30, s: -Math.PI * 0.6 + rot, e: Math.PI * 0.5 + rot, w: 5, a: 0.95 },
        { r: radius * 1.18, s: -Math.PI * 0.4 - rot * 0.7, e: Math.PI * 0.3 - rot * 0.7, w: 3, a: 0.60 },
        { r: radius * 1.42, s: -Math.PI * 0.7 + rot * 1.2, e: Math.PI * 0.1 + rot * 1.2, w: 1.5, a: 0.35 }
      ];

      swooshes.forEach(s => {
        const g = ctx.createLinearGradient(
          cx + Math.cos(s.s) * s.r, cy + Math.sin(s.s) * s.r,
          cx + Math.cos(s.e) * s.r, cy + Math.sin(s.e) * s.r
        );
        g.addColorStop(0, `rgba(59, 130, 246, ${s.a * 0.05})`);
        g.addColorStop(0.6, `rgba(59, 130, 246, ${s.a * 0.8})`);
        g.addColorStop(1, `rgba(147, 197, 253, ${s.a})`);
        drawSwoosh(cx, cy, s.r, s.s, s.e, s.w, g);

        ctx.save();
        ctx.fillStyle = `rgba(59, 130, 246, ${s.a})`;
        ctx.shadowColor = BLUE;
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(cx + Math.cos(s.e) * s.r, cy + Math.sin(s.e) * s.r, s.w * 0.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Gear
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(rot);
      ctx.shadowColor = `rgba(59, 130, 246, 0.4)`;
      ctx.shadowBlur = 40;

      ctx.beginPath();
      const step = (Math.PI * 2) / numTeeth;
      for (let i = 0; i < numTeeth; i++) {
        const ang = i * step;
        ctx.lineTo(Math.cos(ang) * radius, Math.sin(ang) * radius);
        ctx.lineTo(Math.cos(ang + step * 0.32) * radius, Math.sin(ang + step * 0.32) * radius);
        ctx.lineTo(Math.cos(ang + step * 0.50) * innerRadius, Math.sin(ang + step * 0.50) * innerRadius);
        ctx.lineTo(Math.cos(ang + step * 0.82) * innerRadius, Math.sin(ang + step * 0.82) * innerRadius);
      }
      ctx.closePath();

      const gg = ctx.createRadialGradient(0, 0, shaftRadius, 0, 0, radius);
      gg.addColorStop(0, "#0f172a");
      gg.addColorStop(0.8, "#172554");
      gg.addColorStop(1, "#020617");
      ctx.fillStyle = gg;
      ctx.fill();

      ctx.shadowBlur = 0;
      ctx.strokeStyle = BLUE;
      ctx.lineWidth = 3.5;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, radius * 0.56, 0, Math.PI * 2);
      ctx.strokeStyle = BLUE_DIM;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, shaftRadius, 0, Math.PI * 2);
      ctx.fillStyle = "#111827";
      ctx.strokeStyle = BLUE;
      ctx.lineWidth = 3.5;
      ctx.fill();
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, 0, shaftRadius * 0.45, 0, Math.PI * 2);
      ctx.fillStyle = "#030712";
      ctx.fill();

      ctx.restore();
    }

    function tick(ts: number) {
      if (!startTime) startTime = ts;
      const elapsed = ts - startTime;
      
      // Calculate progress of loading (duration is approximately 2500ms)
      const progress = Math.min(1, elapsed / 2500);

      // Accelerating speed: starts slow and goes incredibly fast (exponential/pow)
      const speed = 0.015 + Math.pow(progress, 3) * 0.4;
      rotationAngle += speed;

      render(rotationAngle, progress);
      animFrameId = requestAnimationFrame(tick);
    }

    resize();
    animFrameId = requestAnimationFrame(tick);

    window.addEventListener("resize", resize);

    return () => {
      window.removeEventListener("resize", resize);
      if (animFrameId) {
        cancelAnimationFrame(animFrameId);
      }
    };
  }, [isBooting]);

  return (
    <AnimatePresence>
      {isBooting && (
        <motion.div 
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] bg-[#030712] flex flex-col items-center justify-center gap-10"
        >
          {/* Deep Ambient Background Glow */}
          <div className="absolute inset-0 pointer-events-none z-0 bg-[radial-gradient(ellipse_70%_50%_at_50%_50%,rgba(59,130,246,0.1)_0%,transparent_70%)]" />
          
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="relative z-10"
          >
            <canvas ref={canvasRef} />
          </motion.div>

          <div className="space-y-4 text-center z-10 select-none">
            <motion.h1 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="font-['Space_Grotesk'] text-lg font-normal tracking-[0.32em] uppercase text-[#64748b]"
            >
              <span className="font-semibold text-[#3b82f6] tracking-[0.36em]">ACCELERATED</span> LOGIC
            </motion.h1>
            
            <motion.div 
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 0.5, duration: 1.2 }}
              className="h-[1px] w-48 bg-[#3b82f6]/20 rounded-full overflow-hidden mx-auto"
            >
              <motion.div 
                animate={{ x: ["-100%", "100%"] }}
                transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                className="h-full w-1/2 bg-[#3b82f6] shadow-[0_0_8px_#3b82f6]"
              />
            </motion.div>
            
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="text-[10px] font-bold text-[#64748b] uppercase tracking-[0.4em]"
            >
              Accelerating cognitive engines
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
