import { useState, useEffect } from 'react';
import { ShieldCheck, AlertCircle, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface EulaModalProps {
  onAccept: () => void;
}

export function EulaModal({ onAccept }: EulaModalProps) {
  const [isChecked, setIsChecked] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const isAccepted = localStorage.getItem('accelerated_logic_license_accepted');
    if (isAccepted !== 'true') {
      setIsOpen(true);
    }
  }, []);

  const handleAgree = () => {
    if (isChecked) {
      localStorage.setItem('accelerated_logic_license_accepted', 'true');
      setIsOpen(false);
      onAccept();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md select-none">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ type: 'spring', duration: 0.5 }}
        className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl max-w-lg w-full shadow-2xl p-6 sm:p-8 flex flex-col space-y-5"
      >
        {/* Header */}
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="relative flex items-center justify-center w-10 h-10 bg-red-500/10 text-red-400 rounded-xl">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight text-white">End User License Agreement</h2>
            <p className="text-xs text-slate-400 font-mono">PROPRIETARY LICENSE</p>
          </div>
        </div>

        {/* EULA Body */}
        <div className="overflow-y-auto max-h-52 pr-2 space-y-4 text-xs leading-relaxed text-slate-300 scrollbar-thin scrollbar-thumb-slate-800">
          <div className="bg-slate-950/40 p-3 rounded-lg border border-slate-800/60 font-semibold text-red-400 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>ATTENTION: Unauthorized copying, distribution, or local hosting of this product is strictly path-constrained and legally actionable.</span>
          </div>

          <div>
            <h3 className="font-bold text-slate-200 uppercase tracking-wider mb-1">1. Proprietary Rights and Restrictions</h3>
            <p>
              All software, custom assets, compiled interfaces, underlying source code, HTML, CSS, JavaScript, 
              logic pipelines, and backend routing structures are the exclusive proprietary property of 
              <strong> Best Analytic Business Solutions Inc</strong>. You are granted a limited, revocable, non-exclusive, 
              non-transferable, and non-sublicensable license solely to view, execute, and interact with the 
              application through the officially hosted and licensed browser endpoints.
            </p>
          </div>

          <div>
            <h3 className="font-bold text-slate-200 uppercase tracking-wider mb-1">2. Prohibited Actions</h3>
            <p className="mb-2">
              By accessing this service, you strictly agree and bind yourself NEVER to:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-slate-400">
              <li>
                Duplicate, clone, reproduce, scrape, modify, or translate any part of the source files.
              </li>
              <li>
                Download or execute this application raw inside a local server or hosting node.
              </li>
              <li>
                Attempt to bypass, inspect, or decompile the client bundles, code frameworks, or interface controllers.
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-slate-200 uppercase tracking-wider mb-1">3. Contractual Integration</h3>
            <p>
              Unauthorized reproduction or compilation of this software constitutes copyright infringement under 
              United States federal law (Title 17, U.S. Code), and a breach of this contract. The author reserves 
              the right to issue immediate DMCA takedowns and pursue statutory damages up to $150,000 per willful 
              infringement, as well as breach of contract claims in competent jurisdictions.
            </p>
          </div>

          <div className="border-t border-slate-800 pt-3 mt-3">
            <p className="font-bold text-blue-400 uppercase tracking-wider mb-1">TL;DR</p>
            <p className="text-slate-200 font-semibold text-[11px] leading-relaxed">
              Please don't reproduce the website's code. Anyway, this website is completely free to use.
            </p>
          </div>
        </div>

        {/* Checkbox and Agreement */}
        <div className="pt-2">
          <label className="flex items-start gap-3 cursor-pointer group text-slate-300">
            <input
              type="checkbox"
              checked={isChecked}
              onChange={(e) => setIsChecked(e.target.checked)}
              className="mt-1 w-4 h-4 text-blue-600 bg-slate-800 border-slate-700 rounded focus:ring-blue-500 focus:ring-offset-slate-900 focus:ring-2"
            />
            <span className="text-xs select-none leading-normal group-hover:text-white transition-colors">
              I have read the Terms of Service and End User License Agreement, and I agree to bind myself legally to all terms and conditions specified.
            </span>
          </label>
        </div>

        {/* Action Button */}
        <div className="pt-2">
          <button
            onClick={handleAgree}
            disabled={!isChecked}
            className="w-full flex items-center justify-center gap-2 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:hover:bg-blue-600 text-white font-bold rounded-xl transition duration-200 cursor-pointer text-sm shadow-lg shadow-blue-500/10"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Accept & Access Accelerated Logic</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}
