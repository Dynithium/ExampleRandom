export interface FAQItem {
  id: number;
  question: string;
  answer: string;
  category: 'Getting Started' | 'Models & Workflow' | 'Features & Storage' | 'Troubleshooting';
}

export const HELP_QA_ITEMS: FAQItem[] = [
  {
    id: 1,
    category: 'Getting Started',
    question: "How do I start building code in the Web Sandbox?",
    answer: "Select 'Web Sandbox' from the top Mode Bar or side panel. Type your desired feature request (e.g., 'Make a pomodoro clock') into the chat prompt area at the bottom. Once submitted, our multi-agent workflow will automatically compile live preview code, link modern styles, and present the reactive application inside the sandbox workspace browser."
  },
  {
    id: 2,
    category: 'Models & Workflow',
    question: "How do I switch the active AI model or core LLM provider?",
    answer: "Click the active AI model badge displayed in the header, or click the settings gear icon and go to the 'AI Model Setup' tab. There, you can choose between available providers (such as Gemini, OpenAI, Anthropic, or local Ollama), configure temperature, or toggle individual active chat models."
  },
  {
    id: 3,
    category: 'Models & Workflow',
    question: "How do I run parallel testing across different models?",
    answer: "Open the Model Testing workspace by clicking the scale icon in the header. Select the checkboxes for the models you want to evaluate. When you run a test, models from differents providers will execute simultaneously in parallel, while models from the same provider execute sequentially to preserve rate limits."
  },
  {
    id: 4,
    category: 'Troubleshooting',
    question: "Why is the Speech Synthesis (Read Aloud) audio failing to play sound?",
    answer: "Modern browsers enforce strict sandbox frame security rules that block Audio/SpeechSynthesis inside nested iframes. To enjoy full interactive voice synthesis and Read Aloud, click the 'Open in New Tab' icon located at the top-right of your preview header to access the workspace directly in a standalone tab."
  },
  {
    id: 5,
    category: 'Features & Storage',
    question: "How can I download generated code blocks with correct file extensions?",
    answer: "Every code block displayed in chat features a download icon at its top right. Clicking it automatically package and downloads the snippet as a local file with the correct extension (e.g., .html for markup, .py for Python, .tsx for React, .sh for scripts), saving you from copy-pasting manually."
  },
  {
    id: 6,
    category: 'Getting Started',
    question: "How do I write and execute scripts in the Python Playground?",
    answer: "Toggle 'Python Playground' in the Mode Bar. Enter your script in the editor, and click the 'Run Code' play icon. High-performance compilers execute the script and output outputs, log traces, and standard data frames inside the integrated Python interactive console."
  },
  {
    id: 7,
    category: 'Models & Workflow',
    question: "What is the differences between developers, designers, and QC agents?",
    answer: "Our advanced Multi-Agent System partitions logic: the UX Designer designs visual layout guidelines and structural outlines; the Dev Worker writes the actual functional code; and the Quality Control (QC) agent parses errors and conducts automatic static debugging before returning results."
  },
  {
    id: 8,
    category: 'Troubleshooting',
    question: "How does the 'Auto-Healing' static debugger solve runtime bugs?",
    answer: "If the Web Sandbox catches any runtime errors or parsing fails, the diagnostic outputs are intercepted by the QC Agent. The agent compiles a delta corrective strategy and automatically pushes a repaired code stream back to the preview frame, running an immediate hot-reload."
  },
  {
    id: 9,
    category: 'Models & Workflow',
    question: "How can I configure local offline models via Ollama?",
    answer: "Go to Settings > AI Model Setup, scroll to local configurations, or select Ollama as your target service. Input your active Ollama host URI (usually http://localhost:11434). Ensure your local ollama daemon is running with correct CORS parameters configured."
  },
  {
    id: 10,
    category: 'Features & Storage',
    question: "How are my workspaces and files synchronized to the cloud?",
    answer: "Our database engines periodically back up active file structures and discussions to cloud storage. In the event of a simultaneous browser override, the Sync Conflict Modal is shown, letting you reconcile different revision logs instantly."
  },
  {
    id: 11,
    category: 'Features & Storage',
    question: "How do I configure custom environment skills or instructions?",
    answer: "Open the general Settings modal and go to the 'Skills Manager' tab. There, you can enable or disable platform-level skills—including Google Maps Platform, Firebase database schema builders, Workspace Integrations, and OAuth handlers—to load them into agent prompts."
  },
  {
    id: 12,
    category: 'Getting Started',
    question: "Are there quick keyboard shortcuts or control keys?",
    answer: "Yes. Focus on input: Alt + C (or Cmd + Shift + C on macOS). Toggle system Settings: Alt + S. Clear playground console terminal: Alt + L. Close or open sidebar rails: Ctrl + [ and Ctrl + ]."
  },
  {
    id: 13,
    category: 'Troubleshooting',
    question: "How do I reset or clear individual agent memory context?",
    answer: "Inside Settings, select the 'Memory' tab. Here you can inspect all stored dynamic facts, adjust memory weighting matrices, or click 'Clear All Data' to wipe local storage tables and database caches, resetting the AI's contextual state."
  },
  {
    id: 14,
    category: 'Getting Started',
    question: "Can I upload mockups or visual images to prompt the workspace?",
    answer: "Yes, our models are fully multimodal. Click the clip/image icon in the main prompt bar, upload any reference UI mockup or screenshot, and instruct the AI. It will analyze elements, layouts, and typography to generate a functional replica."
  },
  {
    id: 15,
    category: 'Features & Storage',
    question: "How do I view or edit files inside the active workspace manually?",
    answer: "The 'Files' tab in the sidebar lists the files currently generated. Click any file to open the interactive code editor or click edit directly. You can also instruct the model specifically with editing directives matching the file's path."
  },
  {
    id: 16,
    category: 'Models & Workflow',
    question: "What is represented inside the real-time 'Thinking Process' logs?",
    answer: "Below the active discussion pane, the 'Thinking Trace' chart documents actual multi-agent thoughts. Expanding it shows the analytical steps, constraint lists, design decisions, and debugging actions the agents explored before answering."
  },
  {
    id: 17,
    category: 'Getting Started',
    question: "How can I restart the guided visual tour or tutorial?",
    answer: "Click the info icon or search 'Tutorial' in the top right of your workspace view header. This re-triggers our spotlight guided onboarding tutorial, explaining how to interact with the sidebar, model selection, live previews, and chat frames."
  },
  {
    id: 18,
    category: 'Troubleshooting',
    question: "What should I do if a model rate-limit occurs during execution?",
    answer: "Choose lightweight fallback paths like Gemini 3.5 Flash inside active model providers, or navigate to Settings > AI Model Setup to input your individual developer credentials for higher dedicated rate-limit thresholds."
  },
  {
    id: 19,
    category: 'Features & Storage',
    question: "How do I switch dark and light themes of the application?",
    answer: "Navigate to Settings > Display config to select your favorite theme palette. It persists theme preferences so your environment remains eye-safe and retains consistent brightness setups on any workstation."
  },
  {
    id: 20,
    category: 'Features & Storage',
    question: "How do I integrate Google Workspace Apps (Drive, Calendar)?",
    answer: "Open Settings > Google Integrations. Select required APIs and click the 'Authorize Access' button. This starts a secure third-party OAuth consent process that securely loads Gmail, Sheets, or Drive assets right inside your sandbox agent workflows."
  }
];
