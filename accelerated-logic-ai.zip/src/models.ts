import * as webllm from '@mlc-ai/web-llm';
import { Settings } from './db';

const WEBLLM_MODELS = webllm.prebuiltAppConfig.model_list.map((m) => ({
  id: m.model_id,
  name: m.model_id,
  provider: 'webllm',
  maxContext: m.overrides?.context_window_size || 4096,
  maxTokens: 4096,
  hasVision: m.model_id.toLowerCase().includes('vlm') || m.model_id.toLowerCase().includes('vision') || (m as any).vlm === true,
  inputPrice: 'Free (Local)',
  outputPrice: 'Free (Local)'
}));

export const CHAT_MODELS = [
  ...WEBLLM_MODELS,
  { id: 'qwen3.5:0.8b', name: 'Ollama: Qwen 3.5 0.8B', provider: 'ollama', maxContext: 32768, maxTokens: 4096, hasVision: false, inputPrice: 'Free (Local)', outputPrice: 'Free (Local)' },
  { id: 'qwen3.5:2b', name: 'Ollama: Qwen 3.5 2B', provider: 'ollama', maxContext: 32768, maxTokens: 4096, hasVision: false, inputPrice: 'Free (Local)', outputPrice: 'Free (Local)' },
  { id: 'qwen3.5:9b', name: 'Ollama: Qwen 3.5 9B', provider: 'ollama', maxContext: 32768, maxTokens: 4096, hasVision: false, inputPrice: 'Free (Local)', outputPrice: 'Free (Local)' },
  { id: 'gemini-3.5-flash', name: 'Gemini 3.5 Flash', provider: 'google', maxContext: 1000000, maxTokens: 8192, hasVision: true, inputPrice: '$0.075 / 1M tokens', outputPrice: '$0.30 / 1M tokens' },
  { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite', provider: 'google', maxContext: 1000000, maxTokens: 8192, hasVision: true, inputPrice: '$0.0375 / 1M tokens', outputPrice: '$0.15 / 1M tokens' },
  { id: 'gemma-4-31b-it', name: 'Gemma 4 31B', provider: 'google', maxContext: 1000000, maxTokens: 4096, hasVision: false, inputPrice: '$0.07 / 1M tokens', outputPrice: '$0.14 / 1M tokens' },
  { id: 'gemma-4-26b-a4b-it', name: 'Gemma 4 26B', provider: 'google', maxContext: 1000000, maxTokens: 4096, hasVision: false, inputPrice: '$0.06 / 1M tokens', outputPrice: '$0.12 / 1M tokens' },
  { id: 'gpt-5.5', name: 'GPT-5.5 Omni', provider: 'openai', maxContext: 1050000, maxTokens: 128000, hasVision: true, inputPrice: '$2.50 / 1M tokens', outputPrice: '$10.00 / 1M tokens' },
  { id: 'grok-4.3', name: 'Grok 4.3', provider: 'xAI', maxContext: 2000000, maxTokens: 16384, hasVision: true, inputPrice: '$2.00 / 1M tokens', outputPrice: '$10.00 / 1M tokens' },
  { id: 'claude-opus-4.8', name: 'Claude Opus 4.8', provider: 'anthropic', maxContext: 1000000, maxTokens: 128000, hasVision: true, inputPrice: '$15.00 / 1M tokens', outputPrice: '$75.00 / 1M tokens' },
  { id: 'qwen/qwen3.7-plus', name: 'Qwen 3.7 Plus', provider: 'qwen', maxContext: 1000000, maxTokens: 128000, hasVision: true, inputPrice: '$0.40 / 1M tokens', outputPrice: '$1.20 / 1M tokens' },
  { id: 'deepseek-v4-pro', name: 'DeepSeek V4 Pro', provider: 'deepseek', maxContext: 1000000, maxTokens: 384000, hasVision: true, inputPrice: '$0.14 / 1M tokens', outputPrice: '$0.28 / 1M tokens' },
  { id: 'poolside/laguna-m.1:free', name: 'Laguna M.1 Free', provider: 'poolside', maxContext: 131072, maxTokens: 8192, hasVision: true, inputPrice: 'Free (Beta)', outputPrice: 'Free (Beta)' },
  { id: 'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free', name: 'Nemotron 3 Nano Omni Reasoning', provider: 'nvidia', maxContext: 256000, maxTokens: 4096, hasVision: true, inputPrice: 'Free (Beta)', outputPrice: 'Free (Beta)' },
];

export const IMAGE_MODELS = [
  { id: 'gpt-image-2', name: 'GPT Image 2', provider: 'puter-image' },
  { id: 'gemini-2.5-flash-image', name: 'Gemini 2.5 Flash Image', provider: 'google' },
  { id: 'qwen-image-2.0-pro', name: 'Qwen Image 2.0 Pro', provider: 'puter-image' },
  { id: 'flux-1.1-pro', name: 'FLUX 1.1 Pro', provider: 'puter-image' },
];

export const ALL_MODELS = [...CHAT_MODELS, ...IMAGE_MODELS];

export const OLLAMA_MODELS_CACHE: Record<string, {
  id: string;
  name: string;
  provider: string;
  maxContext: number;
  maxTokens: number;
  hasVision: boolean;
  inputPrice: string;
  outputPrice: string;
  systemPrompt?: string;
}> = {};

if (typeof window !== 'undefined') {
  try {
    const cached = localStorage.getItem('ollama_models_cache');
    if (cached) {
      Object.assign(OLLAMA_MODELS_CACHE, JSON.parse(cached));
    }
  } catch (e) {
    console.error('Failed to load Ollama models cache', e);
  }
}

export const getModelInfo = (equippedId: string) => {
  if (!equippedId) return { provider: '', modelId: '', catalogModel: null, hasVision: false };
  const firstColonIndex = equippedId.indexOf(':');
  let provider = firstColonIndex !== -1 ? equippedId.substring(0, firstColonIndex) : '';
  const modelId = firstColonIndex !== -1 ? equippedId.substring(firstColonIndex + 1) : equippedId;
  
  let catalogModel = CHAT_MODELS.find(m => m.id === modelId) || IMAGE_MODELS.find(m => m.id === modelId);
  
  // Custom OpenAI compatible models from localStorage
  let customOpenaiModels: any[] = [];
  if (typeof window !== 'undefined') {
    try {
      const cached = localStorage.getItem('custom_openai_models');
      if (cached) {
        customOpenaiModels = JSON.parse(cached);
      }
    } catch (e) {
      console.error('Failed to parse custom_openai_models', e);
    }
  }

  const customModel = customOpenaiModels.find(m => m.id === modelId || `openai:${m.id}` === equippedId);

  if (provider === 'ollama' && OLLAMA_MODELS_CACHE[modelId]) {
    catalogModel = OLLAMA_MODELS_CACHE[modelId];
  } else if (!catalogModel && provider === 'ollama') {
    catalogModel = OLLAMA_MODELS_CACHE[modelId];
  } else if (provider === 'openai') {
    if (customModel) {
      catalogModel = {
        id: customModel.id,
        name: customModel.name || customModel.modelId,
        provider: 'openai',
        maxContext: 128000,
        maxTokens: 4096,
        hasVision: true,
        inputPrice: 'Custom',
        outputPrice: 'Custom'
      } as any;
    } else {
      catalogModel = {
        id: modelId || 'custom-openai',
        name: modelId || 'Custom Model',
        provider: 'openai',
        maxContext: 128000,
        maxTokens: 4096,
        hasVision: true,
        inputPrice: 'Custom',
        outputPrice: 'Custom'
      } as any;
    }
  } else if (!catalogModel && provider === 'puter') {
    catalogModel = {
      id: modelId,
      name: modelId,
      provider: 'puter',
      maxContext: 128000,
      maxTokens: 4096,
      hasVision: !modelId.toLowerCase().includes('ling'),
      inputPrice: 'Puter',
      outputPrice: 'Puter'
    } as any;
  }

  if (!provider && catalogModel && 'provider' in catalogModel) {
    provider = catalogModel.provider;
  }

  let resolvedModelId = modelId;

  let hasVision = false;
  if (catalogModel && 'hasVision' in catalogModel) {
    hasVision = (catalogModel as any).hasVision;
  } else if (provider === 'google') {
    hasVision = true;
  } else if (provider === 'openai') {
    hasVision = true;
  } else if (provider === 'puter') {
    hasVision = !modelId.toLowerCase().includes('ling');
  } else if (provider === 'ollama') {
    const lowerName = modelId.toLowerCase();
    const visionKeywords = ['vision', 'vlm', 'llava', 'bakllava', 'moondream', 'minicpm', 'mllama'];
    hasVision = visionKeywords.some(kw => lowerName.includes(kw));
  }

  return { provider, modelId: resolvedModelId, catalogModel, hasVision };
};

export const DEFAULT_SETTINGS: Settings = {
  provider: 'puter',
  puterModel: 'puter:gemini-3.5-flash',
  ollamaUrl: 'http://127.0.0.1:11434',
  openaiApiKey: '',
  openaiBaseUrl: 'https://api.openai.com/v1',
  openaiModelId: 'gpt-4o',
  tokenReductionEnabled: false,
  tokenReductionAmount: 50,
  summarizeEnabled: false,
  temperature: 0.7,
  maxTokens: 4096,
  maxContext: 40960,
  systemPrompt: 'You are a helpful AI assistant.',
  favorites: [],
  masArchitecture: 'standard',
  criticStrictness: 7,
  toolsEnabled: {
    calculator: true,
    python: true,
    scratchpad: true
  },
  imageModelId: 'gpt-image-2',
  imageGenerationEnabled: true,
  aspectRatio: '1:1',
  resolution: '1024x1024',
  autoEnhance: true,
  skills: [],
  enabledChatModels: ['puter:gemini-3.5-flash'],
  autoMemoryEnabled: true,
  hasSeenTutorial: false,
  chatFontSize: 'sm',
  chatFontFamily: 'sans',
  chatDensity: 'cozy',
  promptQueueBackoff: 0,
  gdriveBackupSelector: {
    chats: true,
    files: true,
    projects: true,
    skills: true,
    memories: true
  }
};

export const AGENT_PRESETS = {
  'software': [
    { id: 'orch', name: 'Architect', systemPrompt: 'You are a software architect. Split the request into technical tasks.', count: 1, enabled: true, isFixed: true },
    { id: 'coder', name: 'Lead Developer', systemPrompt: 'You are a lead developer. Write high-quality, documented code. When generating Python code, you MUST output exactly ONE <python_tool>code</python_tool> block. For massive files, prefer using surgical diff blocks:\n\n<<<< SEARCH\ncode to find\n====\ncode to replace with\n>>>> REPLACE\n\nYou should use the python tool to verify your logic if the user request involves complex calculations or data processing.', count: 1, enabled: true },
    { id: 'auditor', name: 'Security Auditor', systemPrompt: 'You are a security auditor. Check for vulnerabilities and bugs.', count: 1, enabled: true, isFixed: true },
    { id: 'checker', name: 'Prompt Checker', systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.', count: 1, enabled: true, isFixed: true },
    { id: 'finalizer', name: 'Finalizer', systemPrompt: 'You are a finalizer. Combine agent outputs. IMPORTANT: Only output user-relevant content. When generating Python code, output exactly ONE <python_tool>code</python_tool> block. You can also output SURGICAL DIFFS to modify existing workspace code:\n\n<<<< SEARCH\ncode to find\n====\ncode to replace with\n>>>> REPLACE\n\nTo generate an interactive preview, wrap the source code in <canvas_preview title="..." lang="...">code</canvas_preview>.', count: 1, enabled: true, isFixed: true },
  ],
  'creative': [
    { id: 'orch', name: 'Director', systemPrompt: 'You are a creative director. Plan the story beats and themes.', count: 1, enabled: true, isFixed: true },
    { id: 'writer', name: 'Writer', systemPrompt: 'You are a creative writer. Write engaging and descriptive prose.', count: 1, enabled: true },
    { id: 'auditor', name: 'Editor', systemPrompt: 'You are an editor. Check for flow, tone, and grammar.', count: 1, enabled: true, isFixed: true },
    { id: 'checker', name: 'Prompt Checker', systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.', count: 1, enabled: true, isFixed: true },
    { id: 'finalizer', name: 'Finalizer', systemPrompt: 'You are a finalizer. Combine agent outputs. IMPORTANT: Only output user-relevant content. To generate an image (ONLY if specifically and explicitly requested by the user), use <image_gen prompt="..." />. To generate an interactive preview, wrap source code in <canvas_preview title="..." lang="...">code</canvas_preview>.', count: 1, enabled: true, isFixed: true },
  ],
  'analysis': [
    { id: 'orch', name: 'Data Scientist', systemPrompt: 'You are a data scientist. Plan the analysis steps.', count: 1, enabled: true, isFixed: true },
    { id: 'coder', name: 'Analyst', systemPrompt: 'You are a data analyst. Perform calculations and extract insights. When generating Python code, you MUST output exactly ONE <python_tool>code</python_tool> block. Always use the python tool to verify your datasets and calculations before drawing conclusions.', count: 1, enabled: true },
    { id: 'auditor', name: 'Fact Checker', systemPrompt: 'You are a fact checker. Verify the accuracy of the findings.', count: 1, enabled: true, isFixed: true },
    { id: 'checker', name: 'Prompt Checker', systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.', count: 1, enabled: true, isFixed: true },
    { id: 'finalizer', name: 'Finalizer', systemPrompt: 'You are a finalizer. Combine agent outputs. IMPORTANT: Only output user-relevant content. To generate an interactive preview, wrap source code in <canvas_preview title="..." lang="...">code</canvas_preview>.', count: 1, enabled: true, isFixed: true },
  ],
  'research': [
    { id: 'orch', name: 'Research Architect', systemPrompt: 'You are a lead research planner. Formulate a comprehensive search and investigation strategy for the topic.', count: 1, enabled: true, isFixed: true },
    { id: 'coder', name: 'Deep Researcher', systemPrompt: 'You are academic researcher. Analyze source texts, outline historical context, extract core arguments, and draft a rigorous review of literature on the subject.', count: 1, enabled: true },
    { id: 'auditor', name: 'Peer Reviewer', systemPrompt: 'You are a peer reviewer. Critically assess research findings for bias, gaps, methodology issues, and overall accuracy.', count: 1, enabled: true, isFixed: true },
    { id: 'checker', name: 'Prompt Checker', systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.', count: 1, enabled: true, isFixed: true },
    { id: 'finalizer', name: 'Finalizer', systemPrompt: 'You are a finalizer. Synthesize findings into a peerless, structured review. Format with beautiful tables, styled markdown, citations, and clear academic recommendations.', count: 1, enabled: true, isFixed: true },
  ],
  'product': [
    { id: 'orch', name: 'Product Lead', systemPrompt: 'You are a product management leader. Structure the product roadmap, technical requirements, and target user personas.', count: 1, enabled: true, isFixed: true },
    { id: 'coder', name: 'UX Designer', systemPrompt: 'You are a user experience designer. Design visual layout guidelines, wireframe wire structures, user journey maps, and high-fidelity specs in clean HTML/SVG or Markdown.', count: 1, enabled: true },
    { id: 'auditor', name: 'Specs Reviewer', systemPrompt: 'You are a product specs reviewer. Audit spec definitions for completeness, edge cases, scalability, and UX design best practices.', count: 1, enabled: true, isFixed: true },
    { id: 'checker', name: 'Prompt Checker', systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.', count: 1, enabled: true, isFixed: true },
    { id: 'finalizer', name: 'Finalizer', systemPrompt: 'You are a finalizer. Assemble the ultimate Product Requirements Document (PRD) with interactive UI design recommendations, diagrams, feature lists, and an actionable delivery plan.', count: 1, enabled: true, isFixed: true },
  ],
  'debate': [
    { id: 'orch', name: 'Debate Facilitator', systemPrompt: 'You are a neutral moderator. Frame the motion for intellectual debate and establish clear rules of engagement for both parties.', count: 1, enabled: true, isFixed: true },
    { id: 'coder', name: 'Affirmative Side', systemPrompt: 'You represent the affirmative of the motion. Build a rigorous, fact-backed defense of the core arguments.', count: 1, enabled: true },
    { id: 'auditor', name: 'Opposition Side', systemPrompt: 'You represent the opposition. Systematically dissect the affirmative case, presenting hard-hitting counterarguments and evidence-backed rebuttals.', count: 1, enabled: true, isFixed: true },
    { id: 'checker', name: 'Prompt Checker', systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.', count: 1, enabled: true, isFixed: true },
    { id: 'finalizer', name: 'Finalizer', systemPrompt: 'You are a finalizer. Synthesize the debate. Extract key points of contention, evaluate the strength of both sides arguments, and present a balanced consensus or final judgment.', count: 1, enabled: true, isFixed: true },
  ],
  'education': [
    { id: 'orch', name: 'Curriculum Planner', systemPrompt: 'You are an educational director. Map out the curriculum objectives, milestones, and baseline prerequisites.', count: 1, enabled: true, isFixed: true },
    { id: 'coder', name: 'Academic Tutor', systemPrompt: 'You are an elite private tutor. Break down complex topics into highly digestible concepts, utilizing analogies, real-world examples, and visual aids.', count: 1, enabled: true },
    { id: 'auditor', name: 'Quiz Architect', systemPrompt: 'You are an assessment specialist. Design strict, insightful quizzes and knowledge checks to challenge the runner of the materials.', count: 1, enabled: true, isFixed: true },
    { id: 'checker', name: 'Prompt Checker', systemPrompt: 'You are a Checker. Your sole job is to verify that the final response is directly, fully, and accurately answering the original user prompt. Review the output against the prompt, highlight missing points or misalignment, and ensure it satisfies the user.', count: 1, enabled: true, isFixed: true },
    { id: 'finalizer', name: 'Finalizer', systemPrompt: 'You are a finalizer. Print out a polished educational book or study guide, featuring clear modular chapters, student notes, interactive worksheets, and quiz keys.', count: 1, enabled: true, isFixed: true },
  ]
};
