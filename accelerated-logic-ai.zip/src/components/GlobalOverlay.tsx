import { motion, AnimatePresence } from "motion/react";

interface GlobalOverlayProps {
  isVisible: boolean;
  onClick: () => void;
}

export function GlobalOverlay({ isVisible, onClick }: GlobalOverlayProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClick}
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-[40]"
        />
      )}
    </AnimatePresence>
  );
}
